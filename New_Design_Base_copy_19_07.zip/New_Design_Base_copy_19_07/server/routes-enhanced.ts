/**
 * Enhanced Routes Implementation
 * Uses the new path management and file service systems
 */

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { dagConfigurationSchema, type DagConfigurationInput } from "@shared/schema";
import { getServerConfig, logConfiguration, validateConfiguration } from "@shared/config-enhanced";
import { pathManager } from "@shared/path-manager";
import { fileService } from "@shared/file-service";
import { z } from "zod";
import fs from "fs/promises";
import path from "path";
import { execSync } from "child_process";
import { registerChatbotRoutes } from "./chatbot-routes";
import { registerIncomingJsonRoutes } from "./incoming-json-routes-fixed";

// Get centralized configuration and validate it
const config = getServerConfig();
const validation = validateConfiguration();

// Log configuration on startup
logConfiguration();

// Warn about configuration issues
if (validation.warnings.length > 0) {
  console.warn('⚠️ Configuration warnings detected:', validation.warnings);
}

if (validation.errors.length > 0) {
  console.error('❌ Configuration errors detected:', validation.errors);
}

// Configure file upload
const upload = fileService.getMulterConfig();

// Cache for API responses
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiry: number;
}

class APICache {
  private cache = new Map<string, CacheEntry<any>>();
  
  set<T>(key: string, data: T, ttlSeconds = 30): void {
    const now = Date.now();
    this.cache.set(key, {
      data,
      timestamp: now,
      expiry: now + (ttlSeconds * 1000)
    });
  }
  
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    if (Date.now() > entry.expiry) {
      this.cache.delete(key);
      return null;
    }
    
    return entry.data;
  }
  
  clear(): void {
    this.cache.clear();
  }
  
  invalidatePattern(pattern: string): void {
    const keys = Array.from(this.cache.keys());
    for (const key of keys) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

const cache = new APICache();

// Airflow API configuration
const getAirflowConfig = () => ({
  baseUrl: config.connection.url,
  apiVersion: '/api/v2',
  authEndpoint: '/auth/token',
  defaultCredentials: {
    username: config.connection.username,
    password: config.connection.password
  }
});

// Global JWT token management
let currentJwtToken: string | null = null;
let tokenExpiry: number | null = null;
let isAuthenticating = false;

// Helper function to check if token is expired
const isTokenExpired = (): boolean => {
  if (!currentJwtToken || !tokenExpiry) return true;
  return Date.now() >= tokenExpiry - 30000; // Refresh 30 seconds before expiry
};

// Authentication function with proper error handling
const authenticateAirflow = async (): Promise<string | null> => {
  if (isAuthenticating) {
    // Wait for ongoing authentication
    return new Promise((resolve) => {
      const checkAuth = () => {
        if (!isAuthenticating) {
          resolve(currentJwtToken);
        } else {
          setTimeout(checkAuth, 100);
        }
      };
      checkAuth();
    });
  }

  if (!isTokenExpired()) {
    return currentJwtToken;
  }

  isAuthenticating = true;
  
  try {
    const AIRFLOW_CONFIG = getAirflowConfig();
    const authUrl = `${AIRFLOW_CONFIG.baseUrl}/api/v1/security/login`;
    
    const authResponse = await fetch(authUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: AIRFLOW_CONFIG.defaultCredentials.username,
        password: AIRFLOW_CONFIG.defaultCredentials.password,
      }),
    });

    if (!authResponse.ok) {
      throw new Error(`Authentication failed: ${authResponse.status} ${authResponse.statusText}`);
    }

    const authData = await authResponse.json();
    
    if (authData.access_token) {
      currentJwtToken = authData.access_token;
      // Set expiry to 50 minutes (tokens typically expire in 1 hour)
      tokenExpiry = Date.now() + (50 * 60 * 1000);
      
      if (config.debug.enableApiLogging) {
        console.log('✅ Airflow authentication successful');
      }
      
      return currentJwtToken;
    } else {
      throw new Error('No access token received from Airflow');
    }
  } catch (error) {
    console.error('❌ Airflow authentication failed:', error);
    currentJwtToken = null;
    tokenExpiry = null;
    return null;
  } finally {
    isAuthenticating = false;
  }
};

// Enhanced Airflow API request function
const makeAirflowRequest = async (endpoint: string, options: RequestInit = {}): Promise<any> => {
  const token = await authenticateAirflow();
  
  if (!token) {
    throw new Error('Failed to authenticate with Airflow');
  }

  const AIRFLOW_CONFIG = getAirflowConfig();
  const url = `${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.apiVersion}${endpoint}`;
  
  const response = await fetch(url, {
    ...options,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    if (response.status === 401) {
      // Token might be expired, clear it and retry once
      currentJwtToken = null;
      tokenExpiry = null;
      
      const newToken = await authenticateAirflow();
      if (newToken) {
        const retryResponse = await fetch(url, {
          ...options,
          headers: {
            'Authorization': `Bearer ${newToken}`,
            'Content-Type': 'application/json',
            ...options.headers,
          },
        });
        
        if (!retryResponse.ok) {
          throw new Error(`Airflow API error: ${retryResponse.status} ${retryResponse.statusText}`);
        }
        
        return retryResponse.json();
      }
    }
    
    throw new Error(`Airflow API error: ${response.status} ${response.statusText}`);
  }

  return response.json();
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Enhanced file upload endpoint
  app.post("/api/upload-csv", upload.single('csvFile'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ 
          success: false,
          message: "No file uploaded" 
        });
      }

      const result = await fileService.processUploadedFile(req.file);
      
      if (result.success) {
        res.json({
          success: true,
          fileName: result.fileName,
          fileSize: result.fileSize,
          headers: result.headers,
          previewRows: result.previewRows,
          metadata: result.metadata,
          message: result.message,
          localCsvPath: result.filePath
        });
      } else {
        res.status(400).json({
          success: false,
          message: result.error || 'Failed to process uploaded file'
        });
      }
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        success: false,
        message: "Failed to process uploaded file",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Enhanced file move endpoint
  app.post("/api/move-file-to-data", async (req, res) => {
    try {
      const { fileName, targetPath } = req.body;
      
      if (!fileName) {
        return res.status(400).json({ 
          success: false, 
          message: "fileName is required" 
        });
      }
      
      const result = await fileService.moveFileToAirflow(fileName, targetPath);
      
      if (result.success) {
        res.json({
          success: true,
          message: result.message,
          filePath: result.filePath,
          fileName: result.fileName,
          isLocalFallback: result.isLocalFallback,
          warnings: result.warnings
        });
      } else {
        res.status(500).json({
          success: false,
          message: result.error || 'Failed to move file'
        });
      }
    } catch (error) {
      console.error('File move error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to move file'
      });
    }
  });

  // Enhanced file verification endpoint
  app.post("/api/verify-file", async (req, res) => {
    try {
      const { fileName, directoryPath } = req.body;
      
      if (!fileName) {
        return res.status(400).json({
          success: false,
          message: 'fileName is required'
        });
      }

      const result = await fileService.verifyFile(fileName, directoryPath);
      
      res.json({
        success: result.exists,
        exists: result.exists,
        filePath: result.path,
        fileSize: result.size,
        error: result.error
      });
    } catch (error) {
      console.error('File verification error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to verify file'
      });
    }
  });

  // Get CSV record count
  app.post("/api/get-csv-record-count", async (req, res) => {
    try {
      const { fileName } = req.body;
      
      if (!fileName) {
        return res.status(400).json({
          success: false,
          message: 'fileName is required'
        });
      }

      const result = await fileService.getFileRecordCount(fileName);
      
      if (result.error) {
        res.status(404).json({
          success: false,
          message: result.error
        });
      } else {
        res.json({
          success: true,
          recordCount: result.count,
          fileName
        });
      }
    } catch (error) {
      console.error('Record count error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to count records'
      });
    }
  });

  // Enhanced DAG generation endpoint
  app.post("/api/generate-dag", async (req, res) => {
    try {
      const input = dagConfigurationSchema.parse(req.body);
      
      // Validate file exists if csvFileName is provided
      if (input.csvFileName) {
        const verification = await fileService.verifyFile(input.csvFileName);
        if (!verification.exists) {
          return res.status(400).json({
            success: false,
            message: `File not found: ${input.csvFileName}`
          });
        }
      }

      // Generate DAG content
      const dagContent = generateDAGContent(input);
      
      // Save DAG to proper location
      const dagsResult = await pathManager.resolvePath(config.paths.dagsDir, 'dags');
      const dagFileName = `${input.dagId}.py`;
      const dagPath = path.join(dagsResult.path, dagFileName);
      
      await pathManager.ensureDirectory(dagsResult.path);
      await fs.writeFile(dagPath, dagContent, 'utf-8');
      
      res.json({
        success: true,
        message: `DAG generated successfully: ${input.dagId}`,
        dagPath: dagPath,
        dagFileName: dagFileName,
        isLocalFallback: dagsResult.isLocal,
        warnings: dagsResult.isLocal ? ['DAG saved to local directory - ensure it reaches Airflow'] : undefined
      });
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          message: "Invalid input data",
          errors: error.errors
        });
      } else {
        console.error('DAG generation error:', error);
        res.status(500).json({
          success: false,
          message: error instanceof Error ? error.message : 'Failed to generate DAG'
        });
      }
    }
  });

  // Enhanced Airflow DAGs endpoint with caching
  app.get("/api/dags", async (req, res) => {
    try {
      const cacheKey = 'airflow-dags';
      const cached = cache.get(cacheKey);
      
      if (cached) {
        return res.json(cached);
      }

      const dagsData = await makeAirflowRequest('/dags');
      
      // Cache for 30 seconds
      cache.set(cacheKey, dagsData, 30);
      
      res.json(dagsData);
    } catch (error) {
      console.error('Failed to fetch DAGs:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch DAGs from Airflow'
      });
    }
  });

  // Enhanced DAG trigger endpoint
  app.post("/api/trigger-dag", async (req, res) => {
    try {
      const { dagId, conf } = req.body;
      
      if (!dagId) {
        return res.status(400).json({
          success: false,
          message: 'dagId is required'
        });
      }

      const triggerData = await makeAirflowRequest(`/dags/${dagId}/dagRuns`, {
        method: 'POST',
        body: JSON.stringify({
          conf: conf || {},
          dag_run_id: `manual_${Date.now()}`,
        }),
      });

      // Invalidate DAG-related cache
      cache.invalidatePattern('dag');

      res.json({
        success: true,
        message: `DAG ${dagId} triggered successfully`,
        dag_run: triggerData
      });
    } catch (error) {
      console.error('Failed to trigger DAG:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to trigger DAG'
      });
    }
  });

  // System health check endpoint
  app.get("/api/health", async (req, res) => {
    try {
      const health = {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        configuration: {
          environment: config.application.nodeEnv,
          airflowUrl: config.connection.url,
          pathsConfigured: !!config.paths.incomingCsvDir,
          validationResult: validation
        },
        paths: {
          incomingCsv: await pathManager.getPathInfo(config.paths.incomingCsvDir),
          processedCsv: await pathManager.getPathInfo(config.paths.processedCsvDir),
          dags: await pathManager.getPathInfo(config.paths.dagsDir)
        }
      };

      res.json(health);
    } catch (error) {
      res.status(500).json({
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Register additional route modules
  registerChatbotRoutes(app);
  registerIncomingJsonRoutes(app);

  const httpServer = createServer(app);
  return httpServer;
}

// DAG generation function (simplified for this example)
function generateDAGContent(input: DagConfigurationInput): string {
  return `# Generated DAG: ${input.dagId}
from airflow import DAG
from airflow.operators.dummy import DummyOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    '${input.dagId}',
    default_args=default_args,
    description='${input.description || 'Generated DAG'}',
    schedule_interval=${input.scheduleInterval || 'None'},
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['generated', 'csv-processing']
)

# Tasks would be generated based on input.csvFiles
start_task = DummyOperator(
    task_id='start',
    dag=dag
)

end_task = DummyOperator(
    task_id='end',
    dag=dag
)

start_task >> end_task
`;
}
