import { Express, Request, Response } from 'express';
import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { getUnifiedServerConfig } from "@shared/config-unified";

/**
 * Registers the routes for the incoming JSON handling with deployment mode-aware paths
 */
export async function registerIncomingJsonRoutes(app: Express) {
  
  // List JSON files from deployment mode-aware paths
  app.get("/api/list-incoming-json", async (req: Request, res: Response) => {
    try {
      console.log('=== LIST INCOMING JSON FILES ===');
      const config = getUnifiedServerConfig();
      console.log(`📂 Loading from deployment mode (${config.deploymentMode}) target directory: ${config.paths.incomingCsvDir}`);
      
      // Use unified configuration for target path
      const targetPath = config.paths.incomingCsvDir;
      const localFallbackPath = path.join(process.cwd(), 'data', 'incomingcsv');
      
      console.log(`� Primary target: ${targetPath}`);
      console.log(`📁 Local fallback: ${localFallbackPath}`);
      
      const searchResults: Array<{path: string, files: string[], success: boolean, isNetworkPath: boolean, error?: string}> = [];
      const allFiles: Array<{name: string, path: string, size: number, fileType: string, lastModified: string, isNetworkPath: boolean}> = [];
      
      // Try target path first (local or network based on deployment mode)
      try {
        console.log(`� Attempting target path: ${targetPath}`);
        
        await fs.access(targetPath);
        const items = await fs.readdir(targetPath);
        const jsonFiles = items.filter(file => file.toLowerCase().endsWith('.json'));
        
        console.log(`   ✅ Found ${jsonFiles.length} JSON files: ${jsonFiles.join(', ')}`);
        
        if (jsonFiles.length > 0) {
          const fileDetails = await Promise.all(
            jsonFiles.map(async (fileName) => {
              try {
                const fullPath = path.join(targetPath, fileName);
                const stats = await fs.stat(fullPath);
                const content = await fs.readFile(fullPath, 'utf8');
                const parsedContent = JSON.parse(content);
                
                let fileType = 'data_object';
                if (Array.isArray(parsedContent)) {
                  fileType = 'data_array';
                } else if (parsedContent.tables && Array.isArray(parsedContent.tables)) {
                  fileType = 'schema';
                }
                
                return {
                  name: fileName,
                  path: fullPath,
                  size: stats.size,
                  fileType: fileType,
                  lastModified: stats.mtime.toISOString(),
                  isNetworkPath: true
                };
              } catch (error) {
                console.warn(`   ⚠️ Error reading ${fileName}:`, error);
                return null;
              }
            })
          );
          
          const validFiles = fileDetails.filter(f => f !== null);
          allFiles.push(...validFiles);
          console.log(`   🎯 NETWORK: Added ${validFiles.length} files from target directory`);
        }
        
        searchResults.push({
          path: targetPath,
          files: jsonFiles,
          success: true,
          isNetworkPath: config.deploymentMode === 'network'
        });
        
      } catch (networkError) {
        console.log(`   ❌ Network path not accessible: ${networkError instanceof Error ? networkError.message : 'Unknown error'}`);
        
        searchResults.push({
          path: targetPath,
          files: [],
          success: false,
          isNetworkPath: config.deploymentMode === 'network',
          error: networkError instanceof Error ? networkError.message : 'Unknown error'
        });
        
        // Only fallback to local if network fails
        try {
          console.log(`📁 Falling back to local path: ${localFallbackPath}`);
          
          await fs.access(localFallbackPath);
          const items = await fs.readdir(localFallbackPath);
          const jsonFiles = items.filter(file => file.toLowerCase().endsWith('.json'));
          
          console.log(`   ✅ Found ${jsonFiles.length} JSON files in local fallback: ${jsonFiles.join(', ')}`);
          
          if (jsonFiles.length > 0) {
            const fileDetails = await Promise.all(
              jsonFiles.map(async (fileName) => {
                try {
                  const fullPath = path.join(localFallbackPath, fileName);
                  const stats = await fs.stat(fullPath);
                  const content = await fs.readFile(fullPath, 'utf8');
                  const parsedContent = JSON.parse(content);
                  
                  let fileType = 'data_object';
                  if (Array.isArray(parsedContent)) {
                    fileType = 'data_array';
                  } else if (parsedContent.tables && Array.isArray(parsedContent.tables)) {
                    fileType = 'schema';
                  }
                  
                  return {
                    name: fileName,
                    path: fullPath,
                    size: stats.size,
                    fileType: fileType,
                    lastModified: stats.mtime.toISOString(),
                    isNetworkPath: false
                  };
                } catch (error) {
                  console.warn(`   ⚠️ Error reading ${fileName}:`, error);
                  return null;
                }
              })
            );
            
            const validFiles = fileDetails.filter(f => f !== null);
            allFiles.push(...validFiles);
            console.log(`   📁 LOCAL: Added ${validFiles.length} files from fallback directory`);
          }
          
          searchResults.push({
            path: localFallbackPath,
            files: jsonFiles,
            success: true,
            isNetworkPath: false
          });
          
        } catch (localError) {
          console.log(`   ❌ Local fallback also failed: ${localError instanceof Error ? localError.message : 'Unknown error'}`);
          
          searchResults.push({
            path: localFallbackPath,
            files: [],
            success: false,
            isNetworkPath: false,
            error: localError instanceof Error ? localError.message : 'Unknown error'
          });
        }
      }
      
      const networkFilesCount = allFiles.filter(f => f.isNetworkPath).length;
      const localFilesCount = allFiles.filter(f => !f.isNetworkPath).length;
      const isUsingNetworkPath = networkFilesCount > 0;
      
      console.log(`📊 SUMMARY: ${allFiles.length} total files from TARGET DIRECTORY ONLY`);
      console.log(`   🌐 Network files: ${networkFilesCount}`);
      console.log(`   📁 Local files: ${localFilesCount}`);
      console.log(`   🎯 Using network path: ${isUsingNetworkPath}`);
      
      const response = {
        success: true,
        files: allFiles,
        searchResults: searchResults,
        totalDirectoriesSearched: searchResults.length,
        networkFilesFound: networkFilesCount,
        localFilesFound: localFilesCount,
        usingNetworkPath: config.deploymentMode === 'network',
        targetDirectory: targetPath
      };
      
      res.json(response);
      
    } catch (error) {
      console.error('❌ List incoming JSON error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to list JSON files' 
      });
    }
  });
  
  // Load JSON file from network path - ONLY TARGET DIRECTORY
  app.post("/api/load-json-file-from-network", async (req: Request, res: Response) => {
    try {
      const { fileName } = req.body;
      if (!fileName) {
        return res.status(400).json({ success: false, message: "fileName is required" });
      }
      
      console.log(`🔍 Loading JSON file: ${fileName}`);
      const config = getUnifiedServerConfig();
      console.log(`🎯 Searching in deployment mode (${config.deploymentMode}) target directory: ${config.paths.incomingCsvDir}`);
      
      // Use unified configuration for target path  
      const targetPath = config.paths.incomingCsvDir;
      const localFallbackPath = path.join(process.cwd(), 'data', 'incomingcsv');
      
      const fileNameWithExt = fileName.endsWith('.json') ? fileName : `${fileName}.json`;
      
      // Try target path first
      const targetFilePath = path.join(targetPath, fileNameWithExt);
      try {
        console.log(`� Trying target path: ${targetFilePath}`);
        
        await fs.access(targetFilePath);
        const content = await fs.readFile(targetFilePath, 'utf8');
        const jsonData = JSON.parse(content);
        
        console.log(`✅ Successfully loaded from target directory: ${targetFilePath}`);
        
        return res.json({
          success: true,
          jsonData: jsonData,
          filePath: targetFilePath,
          isNetworkPath: config.deploymentMode === 'network',
          message: `Loaded from target directory: ${targetPath}`
        });
        
      } catch (networkError) {
        console.log(`❌ Network target failed: ${networkError instanceof Error ? networkError.message : 'Unknown error'}`);
        
        // Fallback to local only if network fails
        const localFilePath = path.join(localFallbackPath, fileNameWithExt);
        try {
          console.log(`📁 Falling back to local: ${localFilePath}`);
          
          await fs.access(localFilePath);
          const content = await fs.readFile(localFilePath, 'utf8');
          const jsonData = JSON.parse(content);
          
          console.log(`✅ Successfully loaded from LOCAL fallback: ${localFilePath}`);
          
          return res.json({
            success: true,
            jsonData: jsonData,
            filePath: localFilePath,
            isNetworkPath: false,
            message: `Loaded from local fallback (network unavailable)`
          });
          
        } catch (localError) {
          console.log(`❌ Local fallback also failed: ${localError instanceof Error ? localError.message : 'Unknown error'}`);
        }
      }
      
      return res.status(404).json({
        success: false,
        message: `File ${fileName} not found in target directory ${targetPath} or local fallback`,
        searchedPaths: [targetFilePath, path.join(localFallbackPath, fileNameWithExt)]
      });
      
    } catch (error) {
      console.error('❌ Load JSON file error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to load JSON file' 
      });
    }
  });
  
  // Save JSON file to network path - ONLY TARGET DIRECTORY
  app.post("/api/save-json-file-to-network", async (req: Request, res: Response) => {
    try {
      const { fileName, data } = req.body;
      if (!fileName || !data) {
        return res.status(400).json({ success: false, message: "fileName and data are required" });
      }
      
      console.log(`💾 Saving JSON file: ${fileName}`);
      const config = getUnifiedServerConfig();
      console.log(`🎯 Saving to deployment mode (${config.deploymentMode}) target directory: ${config.paths.incomingCsvDir}`);
      
      const fileNameWithExt = fileName.endsWith('.json') ? fileName : `${fileName}.json`;
      
      // Save to deployment mode-aware target directory
      const targetFilePath = path.join(config.paths.incomingCsvDir, fileNameWithExt);
      const localFallbackPath = path.join(process.cwd(), 'data', 'incomingcsv', fileNameWithExt);
      
      const formattedJson = JSON.stringify(data, null, 2);
      
      try {
        // Try target path first
        console.log(`� Attempting to save to target: ${targetFilePath}`);
        await fs.writeFile(targetFilePath, formattedJson, 'utf8');
        console.log(`✅ Successfully saved to target directory: ${targetFilePath}`);
        
        return res.json({
          success: true,
          message: `File saved to target directory`,
          filePath: targetFilePath,
          isNetworkPath: config.deploymentMode === 'network'
        });
        
      } catch (networkError) {
        console.log(`❌ Network save failed: ${networkError instanceof Error ? networkError.message : 'Unknown error'}`);
        
        try {
          // Fallback to local path
          console.log(`📁 Falling back to local: ${localFallbackPath}`);
          
          // Ensure directory exists
          await fs.mkdir(path.dirname(localFallbackPath), { recursive: true });
          await fs.writeFile(localFallbackPath, formattedJson, 'utf8');
          console.log(`✅ Successfully saved to LOCAL: ${localFallbackPath}`);
          
          return res.json({
            success: true,
            message: `File saved to local path (target network unavailable)`,
            filePath: localFallbackPath,
            isNetworkPath: false,
            fallbackUsed: true
          });
          
        } catch (localError) {
          throw new Error(`Both target network and local save failed. Network: ${networkError instanceof Error ? networkError.message : 'Unknown'}. Local: ${localError instanceof Error ? localError.message : 'Unknown'}`);
        }
      }
      
    } catch (error) {
      console.error('❌ Save JSON file error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to save JSON file' 
      });
    }
  });
}
