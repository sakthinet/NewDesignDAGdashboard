/**
 * Unified Configuration Management System
 * Supports both local Docker and network Airflow deployments with a simple switch
 */

import * as path from 'path';

export type DeploymentMode = 'local' | 'network';

export interface PathConfiguration {
  incomingCsvDir: string;
  processedCsvDir: string;
  reportsDir: string;
  dagsDir: string;
  dataBaseDir: string;
}

export interface AirflowConnectionConfig {
  url: string;
  username: string;
  password: string;
  apiVersion: string;
}

export interface UnifiedAirflowConfig {
  // Current deployment mode
  deploymentMode: DeploymentMode;
  
  // Connection settings (automatically selected based on deployment mode)
  connection: AirflowConnectionConfig;
  
  // Path configurations for different modes
  networkPaths: PathConfiguration;
  localPaths: PathConfiguration;
  fallbackPaths: PathConfiguration;
  
  // Active paths (automatically selected based on deployment mode)
  paths: PathConfiguration;
  
  // Container paths for DAGs
  containerPaths: {
    dataDir: string;
    incomingCsvDir: string;
    processedCsvDir: string;
    dagsDir: string;
  };
  
  // Application settings
  application: {
    port: number;
    nodeEnv: string;
    maxFileSize: number;
    allowedFileTypes: string[];
    uploadTimeout: number;
  };
  
  // InfoArchive API settings
  infoArchive: {
    baseUrl: string;
    defaultChunkSize: number;
    defaultBearerToken: string;
    exportUrls: {
      purchaseOrderHeader: string;
      purchaseOrderItem: string;
      purchaseOrderPartner: string;
    };
  };
  
  // Debug settings
  debug: {
    enablePathLogging: boolean;
    debugAirflowApi: boolean;
    debugConfigResolution: boolean;
  };
  
  // Database
  database: {
    url: string;
  };
}

/**
 * Safe environment variable getter with fallback
 */
function getEnvVar(key: string, fallback: string = ''): string {
  if (typeof process !== 'undefined' && process.env) {
    return process.env[key] || fallback;
  }
  return fallback;
}

/**
 * Get deployment mode from environment variable
 */
function getDeploymentMode(): DeploymentMode {
  const mode = getEnvVar('DEPLOYMENT_MODE', 'local').toLowerCase();
  
  if (mode === 'local' || mode === 'network') {
    return mode;
  }
  
  console.warn(`Invalid DEPLOYMENT_MODE: ${mode}. Defaulting to 'local'`);
  return 'local';
}

/**
 * Get connection configuration based on deployment mode
 */
function getConnectionConfig(mode: DeploymentMode): AirflowConnectionConfig {
  if (mode === 'network') {
    return {
      url: getEnvVar('NETWORK_AIRFLOW_URL', 'http://10.73.88.101:8080'),
      username: getEnvVar('NETWORK_AIRFLOW_USERNAME', 'airflow'),
      password: getEnvVar('NETWORK_AIRFLOW_PASSWORD', 'airflow'),
      apiVersion: getEnvVar('AIRFLOW_API_VERSION', 'v2')
    };
  } else {
    return {
      url: getEnvVar('LOCAL_AIRFLOW_URL', 'http://localhost:8083'),
      username: getEnvVar('LOCAL_AIRFLOW_USERNAME', 'admin'),
      password: getEnvVar('LOCAL_AIRFLOW_PASSWORD', 'admin123'),
      apiVersion: getEnvVar('AIRFLOW_API_VERSION', 'v2')
    };
  }
}

/**
 * Get path configuration for a specific mode
 */
function getPathConfiguration(prefix: string): PathConfiguration {
  return {
    incomingCsvDir: getEnvVar(`${prefix}_AIRFLOW_INCOMING_CSV_DIR`, ''),
    processedCsvDir: getEnvVar(`${prefix}_AIRFLOW_PROCESSED_CSV_DIR`, ''),
    reportsDir: getEnvVar(`${prefix}_AIRFLOW_REPORTS_DIR`, ''),
    dagsDir: getEnvVar(`${prefix}_AIRFLOW_DAGS_DIR`, ''),
    dataBaseDir: getEnvVar(`${prefix}_AIRFLOW_DATA_BASE_DIR`, '')
  };
}

/**
 * Get the unified server-side configuration
 */
export function getUnifiedServerConfig(): UnifiedAirflowConfig {
  const deploymentMode = getDeploymentMode();
  
  // Get all path configurations
  const networkPaths = getPathConfiguration('NETWORK');
  const localPaths = getPathConfiguration('LOCAL');
  const fallbackPaths = getPathConfiguration('FALLBACK');
  
  // Select active paths based on deployment mode
  const activePaths = deploymentMode === 'network' ? networkPaths : localPaths;
  
  const config: UnifiedAirflowConfig = {
    deploymentMode,
    connection: getConnectionConfig(deploymentMode),
    networkPaths,
    localPaths,
    fallbackPaths,
    paths: activePaths,
    containerPaths: {
      dataDir: getEnvVar('AIRFLOW_CONTAINER_DATA_DIR', '/opt/airflow/data'),
      incomingCsvDir: getEnvVar('AIRFLOW_CONTAINER_INCOMING_CSV_DIR', '/opt/airflow/data/incomingcsv'),
      processedCsvDir: getEnvVar('AIRFLOW_CONTAINER_PROCESSED_CSV_DIR', '/opt/airflow/data/processedcsv'),
      dagsDir: getEnvVar('AIRFLOW_CONTAINER_DAGS_DIR', '/opt/airflow/dags')
    },
    application: {
      port: parseInt(getEnvVar('PORT', '3001'), 10),
      nodeEnv: getEnvVar('NODE_ENV', 'development'),
      maxFileSize: parseInt(getEnvVar('MAX_FILE_SIZE', '10485760'), 10),
      allowedFileTypes: getEnvVar('ALLOWED_FILE_TYPES', '.csv,.txt,.json').split(','),
      uploadTimeout: parseInt(getEnvVar('UPLOAD_TIMEOUT', '30000'), 10)
    },
    infoArchive: {
      baseUrl: getEnvVar('INFOARCHIVE_API_BASE_URL', 'http://10.73.91.23:8765'),
      defaultChunkSize: parseInt(getEnvVar('DEFAULT_CHUNK_SIZE', '5000'), 10),
      defaultBearerToken: getEnvVar('DEFAULT_BEARER_TOKEN', ''),
      exportUrls: {
        purchaseOrderHeader: getEnvVar('PURCHASEORDERHEADER_URL', ''),
        purchaseOrderItem: getEnvVar('PURCHASEORDERITEM_URL', ''),
        purchaseOrderPartner: getEnvVar('PURCHASEORDERPARTNER_URL', '')
      }
    },
    debug: {
      enablePathLogging: getEnvVar('ENABLE_PATH_LOGGING', 'false') === 'true',
      debugAirflowApi: getEnvVar('DEBUG_AIRFLOW_API', 'false') === 'true',
      debugConfigResolution: getEnvVar('DEBUG_CONFIG_RESOLUTION', 'false') === 'true'
    },
    database: {
      url: getEnvVar('DATABASE_URL', 'sqlite:./local.db')
    }
  };
  
  // Debug logging
  if (config.debug.debugConfigResolution) {
    console.log('🔧 Unified Config Resolution:', {
      deploymentMode,
      connectionUrl: config.connection.url,
      activePaths: {
        incomingCsv: config.paths.incomingCsvDir,
        processedCsv: config.paths.processedCsvDir,
        reports: config.paths.reportsDir,
        dags: config.paths.dagsDir
      }
    });
  }
  
  return config;
}

/**
 * Get unified client-side configuration (for Vite/React)
 */
export function getUnifiedClientConfig(): Partial<UnifiedAirflowConfig> {
  const deploymentMode = getDeploymentMode();
  const serverConfig = getUnifiedServerConfig();
  
  // Generate VITE environment variables dynamically based on deployment mode
  const generateViteConfig = () => {
    if (typeof window !== 'undefined' && typeof import.meta !== 'undefined') {
      // Browser environment - use Vite environment variables
      const env = import.meta.env;
      
      return {
        url: env.VITE_AIRFLOW_URL as string,
        paths: {
          incomingCsvDir: env.VITE_AIRFLOW_INCOMING_CSV_DIR as string,
          processedCsvDir: env.VITE_AIRFLOW_PROCESSED_CSV_DIR as string,
          reportsDir: env.VITE_AIRFLOW_REPORTS_DIR as string,
          dagsDir: env.VITE_AIRFLOW_DAGS_DIR as string,
          dataBaseDir: env.VITE_AIRFLOW_DATA_BASE_DIR as string
        }
      };
    } else {
      // Server-side rendering - generate from server config
      return {
        url: serverConfig.connection.url,
        paths: serverConfig.paths
      };
    }
  };
  
  const viteConfig = generateViteConfig();
  
  return {
    deploymentMode: serverConfig.deploymentMode,
    connection: {
      url: viteConfig.url || serverConfig.connection.url,
      username: '', // Don't expose credentials to client
      password: '',
      apiVersion: serverConfig.connection.apiVersion
    },
    paths: viteConfig.paths || serverConfig.paths,
    application: {
      port: 0, // Not relevant for client
      nodeEnv: 'client',
      maxFileSize: serverConfig.application.maxFileSize,
      allowedFileTypes: serverConfig.application.allowedFileTypes,
      uploadTimeout: serverConfig.application.uploadTimeout
    }
  };
}

/**
 * Switch deployment mode programmatically (for testing/development)
 */
export function switchDeploymentMode(mode: DeploymentMode): void {
  if (typeof process !== 'undefined' && process.env) {
    process.env.DEPLOYMENT_MODE = mode;
    console.log(`🔄 Switched deployment mode to: ${mode}`);
  } else {
    console.warn('Cannot switch deployment mode in browser environment');
  }
}

/**
 * Validate unified configuration and report issues
 */
export function validateUnifiedConfiguration(): { 
  valid: boolean; 
  errors: string[]; 
  warnings: string[]; 
  deploymentMode: DeploymentMode;
} {
  const config = getUnifiedServerConfig();
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check deployment mode
  if (!config.deploymentMode) {
    errors.push('DEPLOYMENT_MODE not set or invalid');
  }

  // Check connection settings
  if (!config.connection.url) {
    errors.push('Airflow URL not configured');
  } else {
    try {
      new URL(config.connection.url);
    } catch {
      errors.push(`Invalid Airflow URL: ${config.connection.url}`);
    }
  }

  // Check path configurations
  const pathsToCheck = config.deploymentMode === 'network' ? config.networkPaths : config.localPaths;
  
  if (!pathsToCheck.incomingCsvDir) {
    errors.push(`Missing incoming CSV directory for ${config.deploymentMode} mode`);
  }
  
  if (!pathsToCheck.processedCsvDir) {
    errors.push(`Missing processed CSV directory for ${config.deploymentMode} mode`);
  }

  // Check InfoArchive settings
  if (!config.infoArchive.defaultBearerToken) {
    warnings.push('No default bearer token configured');
  }

  try {
    new URL(config.infoArchive.baseUrl);
  } catch {
    errors.push(`Invalid InfoArchive API URL: ${config.infoArchive.baseUrl}`);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    deploymentMode: config.deploymentMode
  };
}

/**
 * Get current deployment mode info
 */
export function getDeploymentInfo(): {
  mode: DeploymentMode;
  connectionUrl: string;
  pathsInfo: {
    incoming: string;
    processed: string;
    reports: string;
    dags: string;
  };
  isNetworkMode: boolean;
  isLocalMode: boolean;
} {
  const config = getUnifiedServerConfig();
  
  return {
    mode: config.deploymentMode,
    connectionUrl: config.connection.url,
    pathsInfo: {
      incoming: config.paths.incomingCsvDir,
      processed: config.paths.processedCsvDir,
      reports: config.paths.reportsDir,
      dags: config.paths.dagsDir
    },
    isNetworkMode: config.deploymentMode === 'network',
    isLocalMode: config.deploymentMode === 'local'
  };
}

/**
 * Log unified configuration for debugging
 */
export function logUnifiedConfiguration(): void {
  if (typeof window !== 'undefined') {
    console.warn('Configuration logging is only available on server-side');
    return;
  }

  const config = getUnifiedServerConfig();
  const validation = validateUnifiedConfiguration();
  
  if (config.debug.enablePathLogging) {
    console.log('=== UNIFIED AIRFLOW CONFIGURATION ===');
    console.log(`🚀 Deployment Mode: ${config.deploymentMode.toUpperCase()}`);
    console.log(`🔗 Airflow URL: ${config.connection.url}`);
    console.log(`👤 Username: ${config.connection.username}`);
    console.log(`🗂️ Active Paths:`);
    console.log(`   📁 Incoming CSV: ${config.paths.incomingCsvDir}`);
    console.log(`   📁 Processed CSV: ${config.paths.processedCsvDir}`);
    console.log(`   📁 Reports: ${config.paths.reportsDir}`);
    console.log(`   📁 DAGs: ${config.paths.dagsDir}`);
    console.log(`📦 Container Paths:`);
    console.log(`   📁 Data: ${config.containerPaths.dataDir}`);
    console.log(`   📁 DAGs: ${config.containerPaths.dagsDir}`);
    console.log(`🔧 InfoArchive API: ${config.infoArchive.baseUrl}`);
    console.log(`💾 Database: ${config.database.url}`);
    
    if (validation.warnings.length > 0) {
      console.log('\n=== CONFIGURATION WARNINGS ===');
      validation.warnings.forEach(warning => console.warn(`⚠️ ${warning}`));
    }
    
    if (validation.errors.length > 0) {
      console.log('\n=== CONFIGURATION ERRORS ===');
      validation.errors.forEach(error => console.error(`❌ ${error}`));
    }
    
    console.log('=====================================\n');
  }
}

/**
 * Set VITE environment variables for client-side use
 * This function should be called during server startup to ensure client-side configs are available
 */
export function setViteEnvironmentVariables(): void {
  const config = getUnifiedServerConfig();
  
  // Set VITE environment variables based on current deployment mode
  const viteVars = {
    VITE_AIRFLOW_URL: config.connection.url,
    VITE_AIRFLOW_INCOMING_CSV_DIR: config.paths.incomingCsvDir,
    VITE_AIRFLOW_PROCESSED_CSV_DIR: config.paths.processedCsvDir,
    VITE_AIRFLOW_REPORTS_DIR: config.paths.reportsDir,
    VITE_AIRFLOW_DAGS_DIR: config.paths.dagsDir,
    VITE_AIRFLOW_DATA_BASE_DIR: path.dirname(config.paths.incomingCsvDir), // Base data directory
    VITE_DEPLOYMENT_MODE: config.deploymentMode
  };
  
  // Update process.env with VITE variables for development server
  Object.entries(viteVars).forEach(([key, value]) => {
    process.env[key] = value;
  });
  
  console.log('🔄 VITE Environment Variables Updated:');
  console.log(`   VITE_AIRFLOW_URL: ${viteVars.VITE_AIRFLOW_URL}`);
  console.log(`   VITE_DEPLOYMENT_MODE: ${viteVars.VITE_DEPLOYMENT_MODE}`);
  console.log(`   VITE_AIRFLOW_INCOMING_CSV_DIR: ${viteVars.VITE_AIRFLOW_INCOMING_CSV_DIR}`);
}

// Legacy compatibility exports (for existing code)
export const getServerConfig = getUnifiedServerConfig;
export const getClientConfig = getUnifiedClientConfig;
export const validateConfiguration = validateUnifiedConfiguration;
export const logConfiguration = logUnifiedConfiguration;

export type { UnifiedAirflowConfig as AirflowConfig };
