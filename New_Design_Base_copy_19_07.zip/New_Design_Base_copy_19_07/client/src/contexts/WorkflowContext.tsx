import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Step, UploadedFile, DagConfig } from '@/pages/dag-generator';

// Schema configuration type
export interface SchemaConfig {
  applicationName: string;
  defaultSchemaName: string;
  locale: string;
  schemaName: string;
}

/**
 * WorkflowContext - Manages workflow session, step validation, and file persistence
 * 
 * 🚧 TEMPORARY DEVELOPMENT MODE:
 * Process validation is currently DISABLED to allow independent page development.
 * Set DISABLE_PROCESS_VALIDATION = false to re-enable strict workflow validation.
 */

interface WorkflowSession {
  id: string;
  startTime: Date;
  selectedFiles: UploadedFile[];
  completedSteps: Step[];
  currentStep: Step;
  isValid: boolean;
  schemaConfig?: SchemaConfig; // Add schema configuration to session
}

interface WorkflowContextType {
  // Session management
  session: WorkflowSession | null;
  initializeSession: (files: UploadedFile[]) => void;
  resetSession: () => void;
  
  // Step management
  currentStep: Step;
  setCurrentStep: (step: Step) => void;
  canAccessStep: (step: Step) => boolean;
  markStepCompleted: (step: Step) => void;
  
  // File management
  selectedFiles: UploadedFile[];
  isFileInSession: (fileName: string) => boolean;
  
  // Schema configuration management
  schemaConfig: SchemaConfig | null;
  setSchemaConfig: (config: SchemaConfig) => void;
  
  // Validation
  validateWorkflowIntegrity: () => boolean;
  getValidationErrors: () => string[];
  
  // Utils
  getSessionInfo: () => WorkflowSession | null;
}

const WorkflowContext = createContext<WorkflowContextType | undefined>(undefined);

export const useWorkflow = (): WorkflowContextType => {
  const context = useContext(WorkflowContext);
  if (!context) {
    throw new Error('useWorkflow must be used within a WorkflowProvider');
  }
  return context;
};

interface WorkflowProviderProps {
  children: React.ReactNode;
}

export const WorkflowProvider: React.FC<WorkflowProviderProps> = ({ children }) => {
  const [session, setSession] = useState<WorkflowSession | null>(null);
  const [currentStep, setCurrentStepState] = useState<Step>('upload');
  const { toast } = useToast();

  // 🚧 TEMPORARY: Process validation disabled for individual page development
  // TODO: Re-enable when individual page logics are complete
  const DISABLE_PROCESS_VALIDATION = true;

  // Step dependencies - defines which steps are required before accessing a step
  const stepDependencies: Record<Step, Step[]> = {
    'dashboard': [],
    'migration-workspace': [],
    'migration-metrics': [],
    'reports': [],
    'upload': [],
    'configure': ['upload'],
    'editable-schema': ['upload', 'configure'],
    'view-xml-schema': ['upload', 'configure', 'editable-schema'],
    'transform-csv-upload': ['upload', 'configure', 'editable-schema', 'view-xml-schema']
  };

  // Initialize a new workflow session
  const initializeSession = useCallback((files: UploadedFile[]) => {
    if (!files || files.length === 0) {
      toast({
        title: "Invalid session initialization",
        description: "Cannot start workflow without files",
        variant: "destructive",
      });
      return;
    }

    const newSession: WorkflowSession = {
      id: `session_${Date.now()}`,
      startTime: new Date(),
      selectedFiles: files,
      completedSteps: ['upload'], // Upload is completed when files are selected
      currentStep: 'upload',
      isValid: true
    };

    setSession(newSession);
    setCurrentStepState('upload');

    console.log('🚀 Workflow session initialized:', {
      sessionId: newSession.id,
      fileCount: files.length,
      files: files.map(f => f.fileName)
    });

    toast({
      title: "Workflow session started",
      description: `${files.length} file(s) selected for processing`,
      duration: 3000,
    });
  }, [toast]);

  // Reset workflow session
  const resetSession = useCallback(() => {
    console.log('🔄 Resetting workflow session');
    setSession(null);
    setCurrentStepState('upload');
    
    toast({
      title: "Session reset",
      description: "Workflow has been reset. Please upload files to start again.",
      duration: 3000,
    });
  }, [toast]);

  // Check if user can access a specific step
  const canAccessStep = useCallback((step: Step): boolean => {
    // 🚧 TEMPORARY: Allow access to all steps when validation is disabled
    if (DISABLE_PROCESS_VALIDATION) {
      return true;
    }

    if (!session) {
      return step === 'upload' || ['dashboard', 'migration-workspace', 'migration-metrics', 'reports'].includes(step);
    }

    const requiredSteps = stepDependencies[step] || [];
    return requiredSteps.every(requiredStep => session.completedSteps.includes(requiredStep));
  }, [session]);

  // Set current step with validation
  const setCurrentStep = useCallback((step: Step) => {
    console.log(`📍 Attempting to navigate to step: ${step}`);
    
    // Allow navigation to dashboard and reporting screens without session
    if (['dashboard', 'migration-workspace', 'migration-metrics', 'reports'].includes(step)) {
      setCurrentStepState(step);
      return;
    }

    // 🚧 TEMPORARY: Skip session validation when process validation is disabled
    if (DISABLE_PROCESS_VALIDATION) {
      setCurrentStepState(step);
      return;
    }

    // For workflow steps, check if session exists
    if (!session && step !== 'upload') {
      toast({
        title: "No active session",
        description: "Please upload files first to start the workflow",
        variant: "destructive",
      });
      setCurrentStepState('upload');
      return;
    }

    // Check if step is accessible
    if (!canAccessStep(step)) {
      const requiredSteps = stepDependencies[step] || [];
      const missingSteps = requiredSteps.filter(req => !session?.completedSteps.includes(req));
      
      toast({
        title: "Step not accessible",
        description: `Please complete the following steps first: ${missingSteps.join(', ')}`,
        variant: "destructive",
      });
      return;
    }

    setCurrentStepState(step);
    
    // Update session if it exists
    if (session) {
      setSession(prev => prev ? { ...prev, currentStep: step } : null);
    }
  }, [session, canAccessStep, toast]);

  // Mark a step as completed
  const markStepCompleted = useCallback((step: Step) => {
    if (!session) return;

    if (!session.completedSteps.includes(step)) {
      setSession(prev => {
        if (!prev) return null;
        
        const newCompletedSteps = [...prev.completedSteps, step];
        console.log(`✅ Step completed: ${step}`, { completedSteps: newCompletedSteps });
        
        return {
          ...prev,
          completedSteps: newCompletedSteps
        };
      });
    }
  }, [session]);

  // Check if a file is part of current session
  const isFileInSession = useCallback((fileName: string): boolean => {
    if (!session) return false;
    return session.selectedFiles.some(file => file.fileName === fileName);
  }, [session]);

  // Validate workflow integrity
  const validateWorkflowIntegrity = useCallback((): boolean => {
    // 🚧 TEMPORARY: Always return true when process validation is disabled
    if (DISABLE_PROCESS_VALIDATION) {
      return true;
    }

    if (!session) return false;

    const errors = getValidationErrors();
    return errors.length === 0;
  }, [session]);

  // Get validation errors
  const getValidationErrors = useCallback((): string[] => {
    // 🚧 TEMPORARY: Return empty errors when process validation is disabled
    if (DISABLE_PROCESS_VALIDATION) {
      return [];
    }

    const errors: string[] = [];

    if (!session) {
      errors.push("No active workflow session");
      return errors;
    }

    if (session.selectedFiles.length === 0) {
      errors.push("No files selected in the session");
    }

    if (!session.isValid) {
      errors.push("Session has been invalidated");
    }

    // Check for step sequence integrity
    const requiredSteps = stepDependencies[session.currentStep] || [];
    const missingSteps = requiredSteps.filter(step => !session.completedSteps.includes(step));
    
    if (missingSteps.length > 0) {
      errors.push(`Missing required steps: ${missingSteps.join(', ')}`);
    }

    return errors;
  }, [session]);

  // Get session info
  const getSessionInfo = useCallback((): WorkflowSession | null => {
    return session;
  }, [session]);

  // Schema configuration management
  const setSchemaConfig = useCallback((config: SchemaConfig) => {
    console.log('📝 Setting schema configuration:', config);
    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        schemaConfig: config
      };
    });
  }, []);

  // Session validation on step change
  useEffect(() => {
    // 🚧 TEMPORARY: Skip session validation when process validation is disabled
    if (DISABLE_PROCESS_VALIDATION) {
      return;
    }

    if (session && currentStep !== 'upload') {
      const isValid = validateWorkflowIntegrity();
      
      if (!isValid) {
        console.warn('⚠️ Workflow integrity check failed');
        const errors = getValidationErrors();
        
        toast({
          title: "Workflow integrity issue",
          description: `${errors.join(', ')}. Redirecting to upload step.`,
          variant: "destructive",
        });
        
        // Reset to upload step
        setCurrentStepState('upload');
      }
    }
  }, [session, currentStep, validateWorkflowIntegrity, getValidationErrors, toast]);

  const value: WorkflowContextType = {
    session,
    initializeSession,
    resetSession,
    currentStep,
    setCurrentStep,
    canAccessStep,
    markStepCompleted,
    selectedFiles: session?.selectedFiles || [],
    isFileInSession,
    schemaConfig: session?.schemaConfig || null,
    setSchemaConfig,
    validateWorkflowIntegrity,
    getValidationErrors,
    getSessionInfo
  };

  return (
    <WorkflowContext.Provider value={value}>
      {children}
    </WorkflowContext.Provider>
  );
};
