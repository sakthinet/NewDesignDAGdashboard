import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  ArrowRight, 
  Database, 
  FileText, 
  PlayCircle,
  Loader2,
  Calendar,
  Globe,
  Settings
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useWorkflow } from "@/contexts/WorkflowContext";

// API request function
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

// Types for the new schema generation
export interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

export interface SchemaConfig {
  applicationName: string;
  defaultSchemaName: string;
  locale: string;
  schemaName: string;
}

export interface FileSchemaInfo {
  fileName: string;
  tableName: string;
  recordCount: number;
  dataTypes: { [key: string]: string };
  isMovedToAirflow: boolean;
  moveError?: string;
}

interface IATableSchemaGeneratorProps {
  uploadedFiles: UploadedFile[];
  onNext: () => void;
  onPrev: () => void;
  onAnalyze: () => void;
}

export function IATableSchemaGenerator({ 
  uploadedFiles, 
  onNext, 
  onPrev, 
  onAnalyze 
}: IATableSchemaGeneratorProps) {
  // Airflow API hook
  const { triggerDag, loading: dagLoading, error: dagError } = useAirflowApi();
  
  // Workflow context
  const workflow = useWorkflow();
  
  // Schema configuration state - Initialize from workflow context if available
  const [schemaConfig, setSchemaConfig] = useState<SchemaConfig>(() => {
    const contextConfig = workflow.schemaConfig;
    if (contextConfig) {
      console.log('✅ Loading existing schema configuration from workflow context:', contextConfig);
      return contextConfig;
    }
    return {
      applicationName: 'InfoArchive_Application',
      defaultSchemaName: 'DefaultSchema',
      locale: 'en-US',
      schemaName: 'DataArchival_Schema'
    };
  });

  // File processing state
  const [fileSchemaInfos, setFileSchemaInfos] = useState<FileSchemaInfo[]>([]);
  const [isProcessingFiles, setIsProcessingFiles] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);

  const { toast } = useToast();

  // Effect to sync schema configuration with workflow context when it changes
  useEffect(() => {
    if (JSON.stringify(schemaConfig) !== JSON.stringify(workflow.schemaConfig)) {
      console.log('📝 Schema configuration changed, updating workflow context');
      workflow.setSchemaConfig(schemaConfig);
    }
  }, [schemaConfig, workflow]);

  // Process uploaded files to extract schema information
  const processUploadedFiles = async () => {
    if (uploadedFiles.length === 0) return;

    setIsProcessingFiles(true);
    setProcessingProgress(0);

    const processedFiles: FileSchemaInfo[] = [];

    for (let i = 0; i < uploadedFiles.length; i++) {
      const file = uploadedFiles[i];
      
      try {
        // Extract table name from filename (remove .csv extension)
        const tableName = file.fileName.replace(/\.csv$/i, '');
        
        // Get actual record count from the server
        let actualRecordCount = 0;
        try {
          const countResponse = await apiRequest('POST', '/api/get-csv-record-count', {
            fileName: file.fileName
          });
          
          if (countResponse.ok) {
            const countResult = await countResponse.json();
            actualRecordCount = countResult.recordCount || 0;
            console.log(`✅ Got record count for ${file.fileName}: ${actualRecordCount}`);
          } else {
            console.warn(`Could not get record count for ${file.fileName}, using preview count`);
            actualRecordCount = file.previewRows.length;
          }
        } catch (error) {
          console.warn(`Error getting record count for ${file.fileName}:`, error);
          actualRecordCount = file.previewRows.length;
        }
        
        // Improved data type detection from headers and preview rows
        const dataTypes: { [key: string]: string } = {};
        
        file.headers.forEach((header, index) => {
          // Simple data type detection based on first few rows
          let detectedType = 'VARCHAR(255)'; // Default
          
          if (file.previewRows.length > 0) {
            const sampleValues = file.previewRows.map(row => row[index]).filter(val => val && val.trim() !== '');
            
            if (sampleValues.length > 0) {
              // Check if all values are numbers
              const allNumbers = sampleValues.every(val => {
                const num = Number(val);
                return !isNaN(num) && isFinite(num);
              });
              
              if (allNumbers) {
                // Check if integers or decimals
                const hasDecimals = sampleValues.some(val => val.includes('.') && Number(val) % 1 !== 0);
                detectedType = hasDecimals ? 'DECIMAL(10,2)' : 'INTEGER';
              }
              // Check if all values are dates (improved detection)
              else if (sampleValues.every(val => {
                const date = new Date(val);
                return !isNaN(date.getTime()) && val.match(/^\d{4}-\d{2}-\d{2}|\d{2}\/\d{2}\/\d{4}|\d{2}-\d{2}-\d{4}/);
              })) {
                detectedType = 'DATE';
              }
              // Check if boolean values
              else if (sampleValues.every(val => ['true', 'false', '1', '0', 'yes', 'no'].includes(val.toLowerCase()))) {
                detectedType = 'BOOLEAN';
              }
              // For long text, use TEXT instead of VARCHAR
              else if (sampleValues.some(val => val.length > 255)) {
                detectedType = 'TEXT';
              }
              // Check for email patterns
              else if (sampleValues.some(val => val.includes('@') && val.includes('.'))) {
                detectedType = 'VARCHAR(320)'; // Email max length
              }
            }
          }
          
          dataTypes[header] = detectedType;
        });

        // Move file to Airflow data directory
        const moveResult = await moveFileToAirflowDirectory(file);
        
        const fileInfo: FileSchemaInfo = {
          fileName: file.fileName,
          tableName,
          recordCount: actualRecordCount, // Use actual record count
          dataTypes,
          isMovedToAirflow: moveResult.success,
          moveError: moveResult.error
        };

        processedFiles.push(fileInfo);
        
        // Update progress
        setProcessingProgress(Math.round(((i + 1) / uploadedFiles.length) * 100));
        
      } catch (error) {
        console.error(`Error processing file ${file.fileName}:`, error);
        
        // Add error file info but still include basic info from upload
        const errorFileInfo: FileSchemaInfo = {
          fileName: file.fileName,
          tableName: file.fileName.replace(/\.csv$/i, ''),
          recordCount: file.previewRows.length || 0, // Use preview rows count as fallback
          dataTypes: file.headers.reduce((acc, header) => {
            acc[header] = 'VARCHAR(255)'; // Default type
            return acc;
          }, {} as { [key: string]: string }),
          isMovedToAirflow: false,
          moveError: error instanceof Error ? error.message : 'Unknown error'
        };
        
        processedFiles.push(errorFileInfo);
        setProcessingProgress(Math.round(((i + 1) / uploadedFiles.length) * 100));
      }
    }

    setFileSchemaInfos(processedFiles);
    setIsProcessingFiles(false);
    
    // Show summary toast
    const successCount = processedFiles.filter(f => f.isMovedToAirflow).length;
    const errorCount = processedFiles.length - successCount;
    
    if (errorCount === 0) {
      toast({
        title: "✅ Files processed successfully",
        description: `${successCount} files moved to Airflow and schema generated`,
        duration: 4000,
      });
    } else {
      toast({
        title: "⚠️ Some files had issues",
        description: `${successCount} succeeded, ${errorCount} failed`,
        variant: "destructive",
        duration: 6000,
      });
    }
  };

  // Move file to Airflow directory
  const moveFileToAirflowDirectory = async (file: UploadedFile): Promise<{ success: boolean; error?: string }> => {
    try {
      console.log(`🔄 Moving file to Airflow directory: ${file.fileName}`);
      
      // Use the specialized endpoint that doesn't require client-side path knowledge
      const response = await apiRequest('POST', '/api/move-file-to-airflow', {
        fileName: file.fileName
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`✅ File move successful: ${file.fileName}`);
        console.log('Move result:', result);
        return { success: true };
      } else {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { message: errorText };
        }
        console.error(`❌ File move failed: ${file.fileName}`, errorData);
        return { success: false, error: errorData.message || 'Failed to move file' };
      }
    } catch (error) {
      console.error(`❌ File move error: ${file.fileName}`, error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error during file move' 
      };
    }
  };

  // Handle analyze button click
  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    
    try {
      // Save schema configuration to workflow context
      console.log('💾 Saving schema configuration to workflow context:', schemaConfig);
      workflow.setSchemaConfig(schemaConfig);
      
      // Prepare DAG configuration with the specified format
      const dagConfig = {
        "Application Name": schemaConfig.applicationName,
        "Default Schema Name": schemaConfig.defaultSchemaName,
        "Locale": schemaConfig.locale,
        "Schema Name": schemaConfig.schemaName
      };

      // Trigger the specific DAG: IA_CSV_Metadata_Generator
      const result = await triggerDag('IA_CSV_Metadata_Generator', dagConfig);
      
      if (result && result.success) {
        toast({
          title: "🚀 DAG Triggered Successfully!",
          description: `DAG 'IA_CSV_Metadata_Generator' executed successfully. DAG Run ID: ${result.dag_run?.dag_run_id || 'Unknown'}`,
          duration: 6000,
        });
        
        // Navigate to the next page (Step 2.1: Validate and Finalize Schema)
        onAnalyze();
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
    } catch (error) {
      console.error('Error triggering DAG:', error);
      toast({
        title: "❌ Analysis Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Process files when component mounts or files change
  useEffect(() => {
    if (uploadedFiles.length > 0 && fileSchemaInfos.length === 0) {
      processUploadedFiles();
    }
  }, [uploadedFiles]);
  
  // For debugging any process errors
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      console.error('Caught global error:', event.error);
    };
    
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  // Check if form is valid
  const isFormValid = () => {
    return (
      schemaConfig.applicationName.trim() !== '' &&
      schemaConfig.defaultSchemaName.trim() !== '' &&
      schemaConfig.locale.trim() !== '' &&
      schemaConfig.schemaName.trim() !== '' &&
      fileSchemaInfos.length > 0 &&
      fileSchemaInfos.some(f => f.isMovedToAirflow)
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Step 2 - Generate Schema for InfoArchive</h2>
          <p className="text-sm text-gray-600 mt-1">
            Configure schema settings and review uploaded CSV files for InfoArchive processing
          </p>
          {uploadedFiles.length > 0 && (
            <div className="mt-2 text-sm text-blue-600">
              <span className="font-medium">Uploaded Files: </span>
              {uploadedFiles.map((file, index) => (
                <span key={index}>
                  {file.fileName}
                  {index < uploadedFiles.length - 1 ? ', ' : ''}
                </span>
              ))}
            </div>
          )}
        </div>
        <div className="flex flex-col items-end space-y-1 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4" />
            <span>{uploadedFiles.length} files uploaded</span>
          </div>
          {fileSchemaInfos.length > 0 && (
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>{fileSchemaInfos.length} files processed</span>
            </div>
          )}
        </div>
      </div>

      {/* Back to Upload Button */}
      <div className="flex justify-start">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Upload
        </Button>
      </div>

      {/* Schema Configuration */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Schema Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="applicationName" className="text-sm font-medium text-gray-700">
                Application Name
              </Label>
              <Input
                id="applicationName"
                value={schemaConfig.applicationName}
                onChange={(e) => setSchemaConfig(prev => ({ ...prev, applicationName: e.target.value }))}
                placeholder="Enter application name"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="defaultSchemaName" className="text-sm font-medium text-gray-700">
                Default Schema Name
              </Label>
              <Input
                id="defaultSchemaName"
                value={schemaConfig.defaultSchemaName}
                onChange={(e) => setSchemaConfig(prev => ({ ...prev, defaultSchemaName: e.target.value }))}
                placeholder="Enter default schema name"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="locale" className="text-sm font-medium text-gray-700">
                Locale
              </Label>
              <Input
                id="locale"
                value={schemaConfig.locale}
                onChange={(e) => setSchemaConfig(prev => ({ ...prev, locale: e.target.value }))}
                placeholder="e.g., en-US, fr-FR"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="schemaName" className="text-sm font-medium text-gray-700">
                Schema Name
              </Label>
              <Input
                id="schemaName"
                value={schemaConfig.schemaName}
                onChange={(e) => setSchemaConfig(prev => ({ ...prev, schemaName: e.target.value }))}
                placeholder="Enter schema name"
                className="mt-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* File Processing Progress */}
      {isProcessingFiles && (
        <Card className="shadow-sm border border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3">
              <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
              <div className="flex-1">
                <div className="text-sm font-medium text-blue-900">Processing uploaded files...</div>
                <div className="text-xs text-blue-700">Moving files to Airflow and generating schema information</div>
              </div>
              <div className="text-sm font-medium text-blue-900">{processingProgress}%</div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Analyze Button */}
      <Card className="shadow-sm border border-gray-200">
        <CardContent className="pt-6">
          <div className="flex items-center justify-end">
            <Button 
              onClick={handleAnalyze}
              disabled={!isFormValid() || isAnalyzing || dagLoading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {(isAnalyzing || dagLoading) ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating Schema...
                </>
              ) : (
                <>
                  <PlayCircle className="mr-2 h-4 w-4" />
                  Generate Schema
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
