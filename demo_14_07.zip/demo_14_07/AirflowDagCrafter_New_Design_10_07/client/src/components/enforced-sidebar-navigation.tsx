import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Upload,
  Settings,
  Code,
  Eye,
  CheckCircle,
  Lock,
  AlertCircle,
  BarChart3,
  FileText,
  Database,
  Plus,
  Activity
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SidebarProps {
  currentStep: 'upload' | 'configure' | 'generate' | 'preview';
  completedSteps: string[];
  onStepChange: (step: 'upload' | 'configure' | 'generate' | 'preview') => void;
  isStepAccessible: (step: string) => boolean;
}

interface NavigationItem {
  id: 'upload' | 'configure' | 'generate' | 'preview';
  label: string;
  icon: React.ComponentType<any>;
  description: string;
  requiredSteps: string[];
}

interface QuickAction {
  id: string;
  label: string;
  icon: React.ComponentType<any>;
  description: string;
  action: () => void;
  disabled?: boolean;
  requiresCompletion?: string[];
}

const DAG_GENERATOR_STEPS: NavigationItem[] = [
  {
    id: 'upload',
    label: 'Upload CSV',
    icon: Upload,
    description: 'Upload your data file',
    requiredSteps: []
  },
  {
    id: 'configure',
    label: 'Configure Workspace',
    icon: Settings,
    description: 'Set Workspace parameters',
    requiredSteps: ['upload']
  },
  {
    id: 'generate',
    label: 'Generate Script',
    icon: Code,
    description: 'Create Workspace script',
    requiredSteps: ['upload', 'configure']
  },
  {
    id: 'preview',
    label: 'XML Viewer',
    icon: Eye,
    description: 'Preview output format',
    requiredSteps: ['upload', 'configure', 'generate']
  }
];

export function EnforcedSidebarNavigation({ 
  currentStep, 
  completedSteps, 
  onStepChange, 
  isStepAccessible 
}: SidebarProps) {
  const { toast } = useToast();

  // Handle navigation attempt
  const handleNavigationAttempt = (stepId: 'upload' | 'configure' | 'generate' | 'preview') => {
    const step = DAG_GENERATOR_STEPS.find(s => s.id === stepId);
    if (!step) return;

    // Check if step is accessible
    const canAccess = step.requiredSteps.every(reqStep => 
      completedSteps.includes(reqStep)
    );

    if (!canAccess) {
      const missingSteps = step.requiredSteps.filter(reqStep => 
        !completedSteps.includes(reqStep)
      );
      
      toast({
        title: "Step locked",
        description: `Complete the following steps first: ${missingSteps.join(', ')}`,
        variant: "destructive",
      });
      return;
    }

    // If accessible, navigate
    onStepChange(stepId);
  };

  // Quick actions that depend on completion
  const quickActions: QuickAction[] = [
    {
      id: 'view-dags',
      label: 'View All Workspaces',
      icon: BarChart3,
      description: 'Browse existing Workspaces',
      action: () => window.location.href = '/dashboard',
      disabled: false
    },
    {
      id: 'create-new',
      label: 'Create New Workspace',
      icon: Plus,
      description: 'Start fresh workflow',
      action: () => {
        if (window.confirm('This will start a new Workspace generation process. Continue?')) {
          window.location.reload();
        }
      },
      disabled: false
    },
    {
      id: 'view-reports',
      label: 'View Reports',
      icon: FileText,
      description: 'Check processing reports',
      action: () => window.location.href = '/reports',
      disabled: false
    }
  ];

  // Calculate progress
  const totalSteps = DAG_GENERATOR_STEPS.length;
  const progressPercentage = (completedSteps.length / totalSteps) * 100;

  return (
    <aside className="w-80 bg-white border-r border-gray-200 flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-900">WORKSPACE GENERATOR</h2>
        <p className="text-sm text-gray-600 mt-1">Step-by-step workflow creation</p>
        
        {/* Progress bar */}
        <div className="mt-4">
          <div className="flex justify-between text-xs text-gray-600 mb-1">
            <span>Progress</span>
            <span>{completedSteps.length}/{totalSteps} completed</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* Workspace Generation Steps */}
      <div className="flex-1 p-6 overflow-y-auto custom-scrollbar">
        <div className="space-y-2">
          {DAG_GENERATOR_STEPS.map((item) => {
            const isCompleted = completedSteps.includes(item.id);
            const isCurrent = currentStep === item.id;
            const canAccess = item.requiredSteps.every(reqStep => 
              completedSteps.includes(reqStep)
            );
            
            const IconComponent = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => handleNavigationAttempt(item.id)}
                disabled={!canAccess && !isCompleted}
                className={`w-full p-3 rounded-lg text-left transition-all duration-200 ${
                  isCurrent
                    ? 'bg-blue-50 border-2 border-blue-200 text-blue-900'
                    : isCompleted
                    ? 'bg-green-50 border border-green-200 text-green-900 hover:bg-green-100'
                    : canAccess
                    ? 'bg-gray-50 border border-gray-200 text-gray-700 hover:bg-gray-100'
                    : 'bg-gray-25 border border-gray-100 text-gray-400 cursor-not-allowed opacity-60'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`mt-0.5 p-1 rounded ${
                    isCompleted 
                      ? 'bg-green-600 text-white' 
                      : isCurrent
                      ? 'bg-blue-600 text-white'
                      : canAccess
                      ? 'bg-gray-400 text-white'
                      : 'bg-gray-300 text-gray-500'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : canAccess ? (
                      <IconComponent className="w-4 h-4" />
                    ) : (
                      <Lock className="w-4 h-4" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium">{item.label}</div>
                      {isCurrent && (
                        <Badge variant="secondary" className="ml-2 text-xs">
                          Current
                        </Badge>
                      )}
                      {isCompleted && (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      )}
                      {!canAccess && !isCompleted && (
                        <Lock className="w-4 h-4 text-gray-400" />
                      )}
                    </div>
                    <div className="text-xs mt-1 opacity-75">
                      {item.description}
                    </div>
                    
                    {/* Show required steps if locked */}
                    {!canAccess && !isCompleted && item.requiredSteps.length > 0 && (
                      <div className="text-xs mt-2 text-red-600 flex items-center">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Requires: {item.requiredSteps.join(', ')}
                      </div>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <Separator className="my-6" />

        {/* Current Step Info */}
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-center text-blue-700 mb-2">
            <Activity className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Current Step</span>
          </div>
          <div className="text-sm text-blue-800">
            {DAG_GENERATOR_STEPS.find(s => s.id === currentStep)?.label || 'Unknown'}
          </div>
          <div className="text-xs text-blue-600 mt-1">
            {DAG_GENERATOR_STEPS.find(s => s.id === currentStep)?.description || ''}
          </div>
        </div>

        <Separator className="my-6" />

        {/* Quick Actions */}
        <div>
          <h3 className="text-sm font-medium text-gray-900 mb-3">QUICK ACTIONS</h3>
          <div className="space-y-2">
            {quickActions.map((action) => {
              const IconComponent = action.icon;
              const isDisabled = action.disabled || 
                (action.requiresCompletion && 
                 !action.requiresCompletion.every(step => completedSteps.includes(step)));
              
              return (
                <button
                  key={action.id}
                  onClick={action.action}
                  disabled={isDisabled}
                  className={`w-full p-2 rounded-lg text-left transition-colors ${
                    isDisabled
                      ? 'bg-gray-25 text-gray-400 cursor-not-allowed'
                      : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <IconComponent className="w-4 h-4" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{action.label}</div>
                      <div className="text-xs opacity-75">{action.description}</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-6 border-t border-gray-200 bg-gray-50">
        <div className="text-xs text-gray-600 space-y-1">
          <div className="flex items-center">
            <Database className="w-3 h-3 mr-1" />
            <span>Sequential workflow enforced</span>
          </div>
          <div className="flex items-center">
            <Lock className="w-3 h-3 mr-1" />
            <span>Complete steps to unlock next</span>
          </div>
          <div className="flex items-center">
            <CheckCircle className="w-3 h-3 mr-1" />
            <span>Progress automatically saved</span>
          </div>
        </div>
      </div>
    </aside>
  );
}