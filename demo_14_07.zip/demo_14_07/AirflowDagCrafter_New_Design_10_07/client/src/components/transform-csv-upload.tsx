import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Upload, Database, FileText } from "lucide-react";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";

interface TransformCsvUploadProps {
  uploadedFile: UploadedFile | null;
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

export function TransformCsvUpload({ 
  uploadedFile, 
  config, 
  onPrev, 
  onStartOver 
}: TransformCsvUploadProps) {
  const [selectedCsvFile, setSelectedCsvFile] = useState<string>('');
  const [bearerToken, setBearerToken] = useState<string>('');
  const [tableUrl, setTableUrl] = useState<string>('');
  const [chunkSize, setChunkSize] = useState<number>(5000);
  const [isUploading, setIsUploading] = useState<boolean>(false);

  const handleUploadToIA = async () => {
    if (!selectedCsvFile || !bearerToken || !tableUrl) {
      alert('Please fill in all required fields');
      return;
    }

    setIsUploading(true);
    
    try {
      // Simulate upload process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Here you would implement the actual upload logic
      console.log('Uploading to IA with config:', {
        csvFile: selectedCsvFile,
        bearerToken,
        tableUrl,
        chunkSize
      });
      
      alert('Successfully uploaded to InfoArchive!');
    } catch (error) {
      console.error('Upload failed:', error);
      alert('Upload failed. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Transform CSV Data dump to IA XML Format and Upload</h2>
          <p className="text-slate-600 mt-2">
            Configure the transformation parameters and upload processed data to InfoArchive
          </p>
        </div>
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Upload Configuration
            </CardTitle>
            <CardDescription>
              Configure the CSV transformation and upload settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* CSV File Selection */}
            <div className="space-y-2">
              <Label htmlFor="csv-file">
                Point 0: Dropdown having list of all csv uploaded in step 1
              </Label>
              <Select value={selectedCsvFile} onValueChange={setSelectedCsvFile}>
                <SelectTrigger>
                  <SelectValue placeholder="Select CSV file to process" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customer_data_csv.csv">customer_data_csv.csv</SelectItem>
                  <SelectItem value="customers-1000.csv">customers-1000.csv</SelectItem>
                  <SelectItem value="features_csv_template.csv">features_csv_template.csv</SelectItem>
                  <SelectItem value="metadata_training_data.csv">metadata_training_data.csv</SelectItem>
                  <SelectItem value="SAP_PurchaseOrderPartner.csv">SAP_PurchaseOrderPartner.csv</SelectItem>
                  {uploadedFile && (
                    <SelectItem value={uploadedFile.fileName}>{uploadedFile.fileName}</SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                (once processed, remove the table list from here)
              </p>
            </div>

            {/* Bearer Token */}
            <div className="space-y-2">
              <Label htmlFor="bearer-token">Bearer Token: &lt;&gt;</Label>
              <Input
                id="bearer-token"
                type="password"
                value={bearerToken}
                onChange={(e) => setBearerToken(e.target.value)}
                placeholder="Enter your bearer token"
                className="font-mono"
              />
            </div>

            {/* Table URL */}
            <div className="space-y-2">
              <Label htmlFor="table-url">Table URL: // - Textbox</Label>
              <Input
                id="table-url"
                type="url"
                value={tableUrl}
                onChange={(e) => setTableUrl(e.target.value)}
                placeholder="Enter table URL"
              />
            </div>

            {/* Chunk Size */}
            <div className="space-y-2">
              <Label htmlFor="chunk-size">Chunk Size: 5000</Label>
              <Input
                id="chunk-size"
                type="number"
                value={chunkSize}
                onChange={(e) => setChunkSize(Number(e.target.value))}
                min="1000"
                max="10000"
                step="1000"
              />
            </div>

            {/* Upload Button */}
            <Button
              onClick={handleUploadToIA}
              disabled={!selectedCsvFile || !bearerToken || !tableUrl || isUploading}
              className="w-full"
            >
              {isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  Uploading to IA...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload to IA
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Status/Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Process Status
            </CardTitle>
            <CardDescription>
              Current transformation and upload status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Selected CSV File</span>
                <span className="text-sm text-gray-600">
                  {selectedCsvFile || 'None selected'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Chunk Size</span>
                <span className="text-sm text-gray-600">{chunkSize.toLocaleString()}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Bearer Token</span>
                <span className="text-sm text-gray-600">
                  {bearerToken ? '••••••••' : 'Not set'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Table URL</span>
                <span className="text-sm text-gray-600">
                  {tableUrl || 'Not set'}
                </span>
              </div>
            </div>

            {/* Progress indicator */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Uploading...</span>
                  <span>Processing</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full animate-pulse w-[45%]"></div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-6 border-t">
        <Button
          variant="outline"
          onClick={onStartOver}
          className="flex items-center gap-2"
        >
          Start Over
        </Button>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={onPrev}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Previous
          </Button>
        </div>
      </div>
    </div>
  );
}
