import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Settings, 
  Upload, 
  Code, 
  FileCode, 
  X, 
  CheckCircle,
  XCircle,
  BarChart3,
  Database,
  Activity,
  FileText,
  TrendingUp,
  ChevronDown,
  ChevronRight,
  Menu,
  Workflow,
  Archive,
  Play,
  Pause,
  LineChart,
  FileSearch,
  Shield,
  Upload as UploadIcon,
  Settings as SettingsIcon,
  CheckSquare,
  Edit3
} from "lucide-react";
import { Step } from "@/pages/dag-generator";
import { useState } from "react";

interface SidebarProps {
  currentStep: Step;
  onStepChange: (step: Step) => void;
  isOpen: boolean;
  onClose: () => void;
  connectionStatus: {
    connected: boolean;
    url: string;
  };
}

interface MenuSection {
  id: string;
  title: string;
  icon: any;
  isExpanded: boolean;
  children: MenuChild[];
}

interface MenuChild {
  id: string;
  label: string;
  icon: any;
  step?: Step;
  description?: string;
}

export function Sidebar({ 
  currentStep, 
  onStepChange, 
  isOpen, 
  onClose, 
  connectionStatus 
}: SidebarProps) {
  const [expandedSections, setExpandedSections] = useState<string[]>(['migration-orchestration']);

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const menuSections: MenuSection[] = [
    {
      id: 'migration-orchestration',
      title: 'Migration Orchestration Engine',
      icon: Workflow,
      isExpanded: expandedSections.includes('migration-orchestration'),
      children: [
        {
          id: 'migration-dashboard',
          label: 'Migration Dashboard',
          icon: BarChart3,
          step: 'dashboard',
          description: ''
        },
        {
          id: 'migration-workspace',
          label: 'Migration Workspace Running Jobs',
          icon: Activity,
          step: 'migration-workspace',
          description: ''
        },
        {
          id: 'migration-metrics',
          label: 'Migration Metrics',
          icon: LineChart,
          step: 'migration-metrics',
          description: ''
        },
        {
          id: 'migration-reports',
          label: 'Migration Reports',
          icon: FileText,
          step: 'reports',
          description: ''
        }
      ]
    },
    {
      id: 'structured-data',
      title: 'Structured Data Archival',
      icon: Archive,
      isExpanded: expandedSections.includes('structured-data'),
      children: [
        {
          id: 'prerequisites-upload',
          label: 'Prerequisites & Source Data Upload',
          icon: UploadIcon,
          step: 'upload',
          description: ''
        },
        {
          id: 'generate-schema',
          label: 'Generate IA Table Schema for Incoming Table Data CSV',
          icon: SettingsIcon,
          step: 'configure',
          description: ''
        },
        {
          id: 'editable-schema',
          label: 'Validate and Finalize Schema',
          icon: Edit3,
          step: 'editable-schema',
          description: ''
        },
        {
          id: 'view-xml-schema',
          label: 'View Generated IA XML Schema',
          icon: FileCode,
          step: 'view-xml-schema',
          description: ''
        },
        {
          id: 'transform-csv-upload',
          label: 'Transform CSV Data dump to IA XML Format and Upload',
          icon: Upload,
          step: 'transform-csv-upload',
          description: ''
        }
      ]
    }
  ];

  return (
    <div className={`
      fixed inset-y-0 left-0 z-50 w-72 bg-white shadow-xl border-r border-slate-200 transform transition-transform duration-300 ease-in-out
      lg:translate-x-0 lg:static lg:inset-0
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
    `}>
      <div className="flex items-center justify-between h-16 px-6 border-b border-slate-200 bg-slate-50">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center shadow-md">
            <Menu className="text-white h-5 w-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-800 tracking-wide">TCS ECM</h1>
            <p className="text-xs text-slate-500 font-medium">Workflow Design Studio</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden text-slate-600 hover:bg-slate-100"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      <nav className="mt-4 px-4 space-y-4 max-h-[calc(100vh-12rem)] overflow-y-auto custom-scrollbar">
        {/* Airflow Connection Status */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-widest letter-spacing-wider">
            Connection Status
          </h3>
          <div className={`flex items-center p-3 rounded-lg border ${
            connectionStatus.connected 
              ? 'bg-green-50 border-green-200 text-green-800' 
              : 'bg-red-50 border-red-200 text-red-800'
          }`}>
            {connectionStatus.connected ? (
              <CheckCircle className="w-5 h-5 mr-2 text-green-500" />
            ) : (
              <XCircle className="w-5 h-5 mr-2 text-red-500" />
            )}
            <div className="text-sm">
              <div className="font-bold">
                {connectionStatus.connected ? 'Connected' : 'Disconnected'}
              </div>
              <div className="text-xs opacity-80 text-slate-500">
                {connectionStatus.url}
              </div>
            </div>
          </div>
        </div>

        <Separator className="bg-slate-200" />

        {/* Hierarchical Navigation Menu */}
        <div className="space-y-2">
          {menuSections.map((section) => (
            <div key={section.id} className="space-y-1">
              {/* Parent Node */}
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between p-3 text-left rounded-lg hover:bg-slate-100 transition-colors group border border-transparent hover:border-slate-200"
              >
                <div className="flex items-center space-x-3">
                  <section.icon className="w-5 h-5 text-blue-600 group-hover:text-blue-700" />
                  <span className="text-base font-semibold text-slate-800 group-hover:text-blue-800">
                    {section.title}
                  </span>
                </div>
                {section.isExpanded ? (
                  <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-blue-500" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-500" />
                )}
              </button>

              {/* Child Nodes */}
              {section.isExpanded && (
                <div className="ml-4 pl-4 border-l-2 border-slate-200 space-y-1">
                  {section.children.map((child) => (
                    <button
                      key={child.id}
                      onClick={() => child.step && onStepChange(child.step)}
                      className={`
                        w-full flex items-start p-3 text-left rounded-lg transition-colors
                        ${currentStep === child.step 
                          ? 'bg-blue-50 text-blue-900 border-l-4 border-blue-600 shadow-sm' 
                          : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                        }
                      `}
                    >
                      <child.icon className={`w-5 h-5 mr-3 mt-0.5 ${
                        currentStep === child.step ? 'text-blue-600' : 'text-blue-400'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="text-base font-semibold">{child.label}</div>
                        {child.description && (
                          <div className="text-xs text-slate-500 mt-1">{child.description}</div>
                        )}
                      </div>
                      {currentStep === child.step && (
                        <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </nav>

      {/* Quick Actions Footer */}
      {connectionStatus.connected && (
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-slate-50 border-t border-slate-200">
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-widest">
              Quick Actions
            </h3>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 text-xs border-blue-500 text-blue-700 hover:bg-blue-50 hover:text-blue-900"
                onClick={() => onStepChange('dashboard')}
              >
                <BarChart3 className="mr-1 h-4 w-4 text-blue-600" />
                Dashboard
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 text-xs border-blue-500 text-blue-700 hover:bg-blue-50 hover:text-blue-900"
                onClick={() => onStepChange('upload')}
              >
                <Upload className="mr-1 h-4 w-4 text-blue-600" />
                Data Archival
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}