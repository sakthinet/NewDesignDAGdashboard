import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, RotateCcw, Download, RefreshCw, Play, CheckCircle, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";

interface ViewXmlSchemaProps {
  uploadedFile: UploadedFile | null;
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

interface DagRun {
  dagId: string;
  runId: string;
  state: 'success' | 'running' | 'failed' | 'queued';
  runType: 'manual' | 'scheduled';
  startDate: string;
  endDate?: string;
  duration?: string;
  dagVersion: string;
}

export function ViewXmlSchema({ uploadedFile, config, onPrev, onStartOver }: ViewXmlSchemaProps) {
  const [dagRuns, setDagRuns] = useState<DagRun[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [downloadPath, setDownloadPath] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    // Simulate DAG execution data
    const mockDagRuns: DagRun[] = [
      {
        dagId: 'InfoArchiveSchemaGenerator',
        runId: '2025-07-10_06:53:59',
        state: 'success',
        runType: 'manual',
        startDate: '2025-07-10, 06:53:02',
        endDate: '2025-07-10, 06:53:09',
        duration: '6.67s',
        dagVersion: 'v1'
      }
    ];
    
    setDagRuns(mockDagRuns);
    setDownloadPath('//opt/airflow/data/processedcsv/dbschema.xml');
  }, []);

  const handleRefresh = async () => {
    setIsLoading(true);
    try {
      // Simulate API call to refresh DAG status
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "DAG Status Refreshed",
        description: "Latest execution status has been retrieved.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh DAG status.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = async () => {
    try {
      toast({
        title: "Download Started",
        description: "XML schema file download initiated.",
      });
      // Simulate download logic
      console.log('Downloading from:', downloadPath);
    } catch (error) {
      toast({
        title: "Download Error",
        description: "Failed to download XML schema file.",
        variant: "destructive",
      });
    }
  };

  const getStateColor = (state: string) => {
    switch (state) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'running': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'queued': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStateIcon = (state: string) => {
    switch (state) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'running': return <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />;
      case 'failed': return <X className="w-4 h-4 text-red-600" />;
      case 'queued': return <Play className="w-4 h-4 text-yellow-600" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            STEP 3: View Generated IA XML Schema 
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Monitor DAG execution and download generated XML schema
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isLoading}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
        </div>
      </div>

      {/* DAG Execution Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Play className="w-5 h-5" />
            <span>Workspace Table (Calling InfoArchiveSchemaGenerator DAG Run)</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>DAG ID</TableHead>
                  <TableHead>Run After</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Run Type</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>DAG Version(s)</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dagRuns.map((run, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{run.dagId}</TableCell>
                    <TableCell className="text-blue-600">{run.runId}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStateColor(run.state)}>
                        <span className="flex items-center space-x-1">
                          {getStateIcon(run.state)}
                          <span>{run.state}</span>
                        </span>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="flex items-center space-x-1">
                        <Play className="w-3 h-3" />
                        <span>{run.runType}</span>
                      </span>
                    </TableCell>
                    <TableCell>{run.startDate}</TableCell>
                    <TableCell>{run.endDate || '-'}</TableCell>
                    <TableCell>{run.duration || '-'}</TableCell>
                    <TableCell>{run.dagVersion}</TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm">
                          <RefreshCw className="w-3 h-3" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <span className="text-xs">•</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Download Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download className="w-5 h-5" />
            <span>Generated XML Schema</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600 mb-2">Download Path:</p>
              <p className="font-mono text-sm bg-white p-2 rounded border">
                {downloadPath}
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                onClick={handleDownload}
                className="flex items-center space-x-2"
              >
                <Download className="w-4 h-4" />
                <span>Download XML Schema</span>
              </Button>
              
              <div className="text-sm text-gray-600">
                <div className="flex items-center space-x-1">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span>Schema generated successfully</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-6 border-t">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Previous</span>
        </Button>
        
        <Button
          variant="outline"
          onClick={onStartOver}
          className="flex items-center space-x-2"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Start Over</span>
        </Button>
      </div>
    </div>
  );
}
