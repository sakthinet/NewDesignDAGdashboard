import { useState, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { ColDef, GridApi } from 'ag-grid-community';
import { 
  ArrowLeft, 
  ArrowRight, 
  Database, 
  FileText, 
  Save,
  Loader2,
  Settings,
  CheckCircle,
  AlertCircle,
  Play
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

// API request function
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

// Types for the schema configuration (following the image exactly)
export interface SchemaConfiguration {
  applicationName: string;     // Text Box (Non-Editable)
  defaultSchemaName: string;   // Text Box (Non-Editable)  
  locale: string;              // Text Box (Non-Editable)
  schemaName: string;          // Text Box (Non-Editable)
}

export interface TableRowData {
  id: string;
  table: string;           // Taken from CSV file name (Editable)
  recordCount: number;     // Calculated based on number of records in CSV (Editable)
  dataType: string;        // Based on column data type (Editable)
  fileName: string;        // Original file name for reference
}

interface EditableSchemaGeneratorProps {
  uploadedFiles: any[];
  onNext: () => void;
  onPrev: () => void;
  onFinalize: () => void;
}

// Data type options for the grid
const DATA_TYPE_OPTIONS = [
  'VARCHAR(50)',
  'VARCHAR(100)', 
  'VARCHAR(255)',
  'TEXT',
  'INT',
  'BIGINT',
  'DECIMAL(10,2)',
  'DATE',
  'DATETIME',
  'TIMESTAMP',
  'BOOLEAN',
  'FLOAT',
  'DOUBLE'
];

export function EditableSchemaGenerator({ 
  uploadedFiles, 
  onNext, 
  onPrev, 
  onFinalize 
}: EditableSchemaGeneratorProps) {
  
  // Step 2.1: Schema Configuration State (Non-Editable as per image)
  const [schemaConfig] = useState<SchemaConfiguration>({
    applicationName: 'InfoArchive_Application',
    defaultSchemaName: 'DefaultSchema', 
    locale: 'en-US',
    schemaName: 'DataArchival_Schema'
  });

  // Grid data state
  const [rowData, setRowData] = useState<TableRowData[]>([]);
  const [gridApi, setGridApi] = useState<GridApi | null>(null);
  const [isFinalizing, setIsFinalizing] = useState(false);

  const { toast } = useToast();

  // Initialize row data from uploaded files
  useEffect(() => {
    if (uploadedFiles.length > 0) {
      const initialData: TableRowData[] = uploadedFiles.map((file, index) => ({
        id: `file_${index}`,
        table: file.fileName.replace(/\.csv$/i, ''), // Editable: Taken from CSV file name
        recordCount: file.previewRows?.length || 0,   // Editable: Calculated based on records
        dataType: 'VARCHAR(255)',                     // Editable: Based on column data type
        fileName: file.fileName
      }));
      setRowData(initialData);
    }
  }, [uploadedFiles]);

  // AG-Grid column definitions
  const columnDefs: ColDef[] = useMemo(() => [
    {
      headerName: 'Table',
      field: 'table',
      editable: true,
      cellEditor: 'agTextCellEditor',
      flex: 1,
      headerTooltip: 'Taken from CSV file name (Editable)'
    },
    {
      headerName: 'Record Count', 
      field: 'recordCount',
      editable: true,
      cellEditor: 'agNumberCellEditor',
      type: 'numericColumn',
      flex: 1,
      headerTooltip: 'Calculated based on number of records in CSV (Editable)'
    },
    {
      headerName: 'Data Type',
      field: 'dataType', 
      editable: true,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: DATA_TYPE_OPTIONS
      },
      flex: 1,
      headerTooltip: 'Based on column data type (Editable)'
    }
  ], []);

  // Grid event handlers
  const onGridReady = useCallback((params: any) => {
    setGridApi(params.api);
  }, []);

  const onCellValueChanged = useCallback((event: any) => {
    console.log('Cell value changed:', event);
    // Update the row data state
    const updatedData = [...rowData];
    const rowIndex = event.rowIndex;
    if (rowIndex >= 0 && rowIndex < updatedData.length) {
      updatedData[rowIndex] = { ...updatedData[rowIndex], [event.colDef.field]: event.newValue };
      setRowData(updatedData);
    }
  }, [rowData]);

  // Handle DAG Run 2 (Finalize and Generate IA Schema)
  const handleDAGRun2 = async () => {
    setIsFinalizing(true);
    
    try {
      // Prepare the final schema data
      const finalSchemaData = {
        schemaConfig,
        tableData: rowData
      };

      console.log('=== DAG RUN 2 TRIGGERED ===');
      console.log('Schema Configuration:', schemaConfig);
      console.log('Table Data:', rowData);

      // Send to backend to generate IA schema
      const response = await apiRequest('POST', '/api/generate-ia-schema', finalSchemaData);

      if (response.ok) {
        const result = await response.json();
        toast({
          title: "🎉 IA Schema Generated Successfully",
          description: `DAG Run 2 completed. Schema files created: ${result.schemaFiles?.length || 0}`,
        });
        onFinalize();
      } else {
        const errorData = await response.json();
        toast({
          title: "❌ DAG Run 2 Failed",
          description: errorData.message || 'Failed to generate IA schema',
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "❌ DAG Run 2 Failed",
        description: error instanceof Error ? error.message : 'Unknown error',
        variant: "destructive",
      });
    } finally {
      setIsFinalizing(false);
    }
  };

  // Validate form
  const isFormValid = () => {
    return rowData.length > 0 && rowData.every(row => 
      row.table.trim() !== '' && row.recordCount > 0 && row.dataType.trim() !== ''
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">STEP 2.1: Validate and Finalize Schema</h2>
          <p className="text-sm text-gray-600 mt-1">
            Configure schema settings and validate table information for InfoArchive processing
          </p>
          {uploadedFiles.length > 0 && (
            <div className="mt-2 text-sm text-blue-600">
              <span className="font-medium">Processing Files: </span>
              {uploadedFiles.map((file, index) => (
                <span key={index}>
                  {file.fileName}
                  {index < uploadedFiles.length - 1 ? ', ' : ''}
                </span>
              ))}
            </div>
          )}
        </div>
        <div className="flex flex-col items-end space-y-1 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4" />
            <span>{rowData.length} tables configured</span>
          </div>
          <div className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Schema validation ready</span>
          </div>
        </div>
      </div>

      {/* Schema Configuration - Non-Editable Fields (1-4) */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Schema Configuration
            <Badge variant="outline" className="ml-2 text-red-600 border-red-200">
              Non-Editable
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-medium text-gray-700">
                1. Application Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.applicationName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                2. Default Schema Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.defaultSchemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                3. Locale: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.locale}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                4. Schema Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.schemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editable Table Schema Information (Fields 5-7) */}
      <Card className="shadow-sm border border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <FileText className="mr-2 h-5 w-5" />
            Table Schema Information
            <Badge variant="outline" className="ml-2 text-green-600 border-green-200">
              Editable
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm text-gray-700">
              <p><strong>5. Table:</strong> Taken from CSV file name (Editable)</p>
              <p><strong>6. Record Count:</strong> Calculated based on number of records in CSV (Editable)</p>
              <p><strong>7. Data Type:</strong> Based on column data type (Editable)</p>
            </div>
            
            {/* AG-Grid for Excel-like editing */}
            <div className="ag-theme-alpine h-[300px] w-full">
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                onGridReady={onGridReady}
                onCellValueChanged={onCellValueChanged}
                defaultColDef={{
                  sortable: true,
                  filter: true,
                  resizable: true,
                }}
                animateRows={true}
                enableCellTextSelection={true}
                ensureDomOrder={true}
                suppressRowClickSelection={true}
                stopEditingWhenCellsLoseFocus={true}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Finalize Button - DAG Run 2 */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <Play className="mr-2 h-5 w-5" />
                Finalize and Generate IA Schema
              </h3>            
            </div>
            <Button 
              onClick={handleDAGRun2}
              disabled={!isFormValid() || isFinalizing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isFinalizing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Running DAG 2...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Finalize and Generate IA Schema
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Validate Schema
        </Button>
        <Button 
          onClick={onNext}
          disabled={!isFormValid()}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Continue to Transform
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
