// pages/api/move-file-to-data.ts
// Enhanced version with server-side path resolution and no hardcoding
import { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  console.log('=== MOVE FILE TO DATA API CALLED ===');
  console.log('Method:', req.method);
  console.log('Body:', req.body);

  if (req.method !== 'POST') {
    return res.status(405).json({ 
      success: false, 
      message: 'Method not allowed' 
    });
  }

  try {
    const { fileName, targetPath: providedTargetPath, targetDirectory } = req.body;

    if (!fileName) {
      console.log('❌ Missing fileName parameter');
      return res.status(400).json({
        success: false,
        message: 'fileName is required'
      });
    }

    console.log(`📁 Processing file move request for: ${fileName}`);

    // Server-side path resolution using environment variables
    const resolveTargetPath = (): string => {
      // If a complete target path is provided, use it
      if (providedTargetPath) {
        console.log(`📍 Using provided target path: ${providedTargetPath}`);
        return providedTargetPath;
      }

      // If target directory is provided, combine with filename
      if (targetDirectory) {
        const fullPath = path.join(targetDirectory, fileName);
        console.log(`📍 Using provided directory + filename: ${fullPath}`);
        return fullPath;
      }

      // Resolve from environment variables (server-side)
      console.log('🔍 Resolving path from environment variables...');
      
      const envTargetDir = process.env.AIRFLOW_DATA_DIR || 
                          process.env.AIRFLOW_INCOMING_CSV_DIR || 
                          process.env.AIRFLOW_DAGS_DIR;

      if (envTargetDir) {
        // For data directory, ensure we're pointing to the incomingcsv subdirectory
        let resolvedDir = envTargetDir;
        if (envTargetDir.includes('\\dags') || envTargetDir.includes('/dags')) {
          // If it's the dags directory, switch to data/incomingcsv
          resolvedDir = envTargetDir.replace(/[\\\/]dags[\\\/]?$/, '/data/incomingcsv');
        } else if (!envTargetDir.includes('incomingcsv')) {
          // If it's a data directory but not specifically incomingcsv, append it
          resolvedDir = path.join(envTargetDir, 'incomingcsv');
        }
        
        const fullPath = path.join(resolvedDir, fileName);
        console.log(`📍 Resolved from environment: ${fullPath}`);
        console.log(`📍 Environment variable used: ${envTargetDir}`);
        return fullPath;
      }

      // Fallback: construct default WSL path
      const fallbackDir = '\\\\wsl$\\Ubuntu-22.04\\home\\netrasami\\airflow\\data\\incomingcsv';
      const fullPath = path.join(fallbackDir, fileName);
      console.log(`⚠️ Using fallback path (no env vars found): ${fullPath}`);
      return fullPath;
    };

    const targetPath = resolveTargetPath();
    console.log(`🎯 Final target path: ${targetPath}`);

    // Assume uploaded files are temporarily stored in uploads folder
    const tempDir = path.join(process.cwd(), 'uploads');
    const sourcePath = path.join(tempDir, fileName);
    
    console.log(`📂 Source path: ${sourcePath}`);
    console.log(`📂 Target path: ${targetPath}`);

    // Normalize target path for better cross-platform support
    const normalizedTargetPath = path.resolve(targetPath);
    console.log(`📂 Normalized target path: ${normalizedTargetPath}`);
    
    // Ensure target directory exists
    const targetDir = path.dirname(normalizedTargetPath);
    console.log(`📁 Target directory: ${targetDir}`);
    
    if (!fs.existsSync(targetDir)) {
      console.log(`📁 Creating target directory: ${targetDir}`);
      try {
        fs.mkdirSync(targetDir, { recursive: true });
        console.log(`✅ Target directory created successfully`);
      } catch (dirError) {
        console.error(`❌ Failed to create target directory: ${dirError}`);
        return res.status(500).json({
          success: false,
          message: `Failed to create target directory: ${targetDir}`,
          error: dirError instanceof Error ? dirError.message : String(dirError)
        });
      }
    } else {
      console.log(`✅ Target directory already exists`);
    }

    // Check if source file exists
    if (!fs.existsSync(sourcePath)) {
      console.log(`❌ Source file not found: ${sourcePath}`);
      return res.status(404).json({
        success: false,
        message: `Source file not found: ${fileName}`,
        sourcePath: sourcePath,
        expectedLocation: tempDir
      });
    }

    console.log(`✅ Source file exists: ${sourcePath}`);

    // Get source file info
    const sourceStats = fs.statSync(sourcePath);
    console.log(`📊 Source file size: ${sourceStats.size} bytes`);

    // Check if target file already exists
    if (fs.existsSync(normalizedTargetPath)) {
      // Backup existing file
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = normalizedTargetPath.replace(/(\.[^.]+)$/, `_backup_${timestamp}$1`);
      try {
        fs.copyFileSync(normalizedTargetPath, backupPath);
        console.log(`💾 Existing file backed up to: ${backupPath}`);
      } catch (backupError) {
        console.warn(`⚠️ Failed to backup existing file: ${backupError}`);
      }
    }

    // Copy file to target location
    console.log(`📋 Copying file from ${sourcePath} to ${normalizedTargetPath}`);
    try {
      fs.copyFileSync(sourcePath, normalizedTargetPath);
      console.log(`✅ File copy operation completed`);
    } catch (copyError) {
      console.error(`❌ File copy failed: ${copyError}`);
      return res.status(500).json({
        success: false,
        message: `File copy operation failed`,
        error: copyError instanceof Error ? copyError.message : String(copyError)
      });
    }
    
    // Verify the file was copied successfully
    if (!fs.existsSync(normalizedTargetPath)) {
      throw new Error('File copy verification failed - target file does not exist');
    }

    const targetStats = fs.statSync(normalizedTargetPath);
    console.log(`✅ File successfully moved. Target size: ${targetStats.size} bytes`);

    // Verify file sizes match
    if (sourceStats.size !== targetStats.size) {
      console.warn(`⚠️ File size mismatch! Source: ${sourceStats.size}, Target: ${targetStats.size}`);
    } else {
      console.log(`✅ File size verification passed: ${targetStats.size} bytes`);
    }

    // Optional: Remove the temporary file (uncomment if you want to clean up temp files)
    // try {
    //   fs.unlinkSync(sourcePath);
    //   console.log(`🗑️ Temporary file removed: ${sourcePath}`);
    // } catch (cleanupError) {
    //   console.warn(`⚠️ Failed to remove temporary file: ${cleanupError}`);
    // }

    return res.status(200).json({
      success: true,
      message: `File successfully moved to Airflow data directory`,
      fileName: fileName,
      sourcePath: sourcePath,
      targetPath: normalizedTargetPath,
      sourceSize: sourceStats.size,
      targetSize: targetStats.size,
      resolvedFromEnv: !!(process.env.AIRFLOW_DATA_DIR || process.env.AIRFLOW_INCOMING_CSV_DIR),
      environmentVariable: process.env.AIRFLOW_DATA_DIR ? 'AIRFLOW_DATA_DIR' : 
                          process.env.AIRFLOW_INCOMING_CSV_DIR ? 'AIRFLOW_INCOMING_CSV_DIR' : 'fallback'
    });

  } catch (error) {
    console.error('❌ Error moving file to data directory:', error);
    
    return res.status(500).json({
      success: false,
      message: error instanceof Error ? error.message : 'Failed to move file to data directory',
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined
    });
  }
}