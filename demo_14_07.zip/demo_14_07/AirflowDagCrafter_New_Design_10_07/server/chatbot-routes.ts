import type { Express } from "express";

// Fallback LLM service using Hugging Face Inference API (free tier)
const HUGGINGFACE_API_URL = "https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium";
const HUGGINGFACE_API_KEY = process.env.HUGGINGFACE_API_KEY; // Optional, works without for limited usage

interface ChatbotRequest {
  message: string;
  context: {
    dags: any[];
    totalDags: number;
    runningDags: number;
    pausedDags: number;
    recentRuns: any[];
    connectionStatus: boolean;
  };
  systemPrompt: string;
}

const callHuggingFaceLLM = async (prompt: string): Promise<string> => {
  try {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    
    if (HUGGINGFACE_API_KEY) {
      headers['Authorization'] = `Bearer ${HUGGINGFACE_API_KEY}`;
    }

    const response = await fetch(HUGGINGFACE_API_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_length: 500,
          temperature: 0.7,
          do_sample: true,
          pad_token_id: 50256
        }
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    
    if (Array.isArray(data) && data[0]?.generated_text) {
      return data[0].generated_text.replace(prompt, '').trim();
    }
    
    throw new Error('Invalid response format from Hugging Face');
  } catch (error) {
    console.error('Hugging Face LLM error:', error);
    throw error;
  }
};

const generateContextualResponse = (message: string, context: any): string => {
  const msg = message.toLowerCase();
  
  // Enhanced rule-based responses with context
  if (msg.includes('status') || msg.includes('dashboard')) {
    return `📊 **Dashboard Overview**

**DAG Status:**
• Total DAGs: ${context.totalDags}
• Active (Running): ${context.runningDags}
• Paused: ${context.pausedDags}
• Airflow Connection: ${context.connectionStatus ? '✅ Connected' : '❌ Disconnected'}

**Recent Activity:**
• Recent Runs: ${context.recentRuns.length}

${context.totalDags === 0 ? 
  '💡 **Tip:** You can create your first DAG using the Upload section.' : 
  '💡 **Tip:** Click on individual DAGs in the dashboard to see detailed run history.'}`;
  }

  // NEW: Enhanced reports section responses
  if (msg.includes('report') || msg.includes('analytics') || msg.includes('intelligence') || msg.includes('metrics') || msg.includes('visualization')) {
    return `📈 **TCS ECM Analytics & Intelligence Reports**

**Available Report Types:**
• **Chart Reports**: Visual data distributions with pie and bar charts
• **Metrics Reports**: Key performance indicators and statistics
• **Table Reports**: Structured data views with advanced analytics
• **Complex Reports**: Multi-dimensional data analysis
• **Raw Data Reports**: Complete dataset exports and previews

**Features:**
• **Auto-Detection**: Reports are automatically categorized based on JSON structure
• **Interactive Charts**: Pie charts, bar charts, and time series analysis
• **Statistics**: Automatic calculation of averages, min/max, totals
• **Data Location**: C:\\Docker\\airflow3x2\\data\\metrics_json_files

**How to Access:**
1. Navigate to "Reports" in the sidebar
2. Reports are auto-loaded from Airflow data directory
3. Click on any report to view detailed analytics
4. Charts and visualizations are generated automatically

**Report Data Sources:**
• JSON files from your DAG executions
• Performance metrics from workflow runs
• Business intelligence data exports
• Custom analytics outputs

💡 **Tip:** Reports are refreshed automatically when new JSON files are added to the data directory.`;
  }

  if (msg.includes('view report') || msg.includes('show report') || msg.includes('open report')) {
    return `📋 **How to View Reports:**

**Steps:**
1. **Navigate**: Click "Reports" in the left sidebar
2. **Browse**: See all available reports in the reports list
3. **Select**: Click on any report to view its content
4. **Analyze**: Use the generated charts and statistics

**Report Viewer Features:**
• **Smart Analytics**: Automatic data analysis and visualization
• **Multiple Views**: Charts, tables, and raw data views
• **Statistics Panel**: Key metrics and performance indicators
• **Export Options**: Download data for external analysis

**Supported File Types:**
• JSON reports (*.json)
• Metrics files from DAG runs
• Business intelligence exports
• Performance monitoring data

**Current Reports Status:**
• Location: TCS ECM Analytics & Reports section
• Auto-refresh: Updates when new files are detected
• Interactive: Click and explore data visualizations

💡 **Pro Tip:** Reports with numeric data automatically generate charts and statistics!`;
  }

  if (msg.includes('no report') || msg.includes('empty report') || msg.includes('report not found')) {
    return `📂 **No Reports Found - Troubleshooting:**

**Common Causes:**
• No JSON files in the data directory
• Reports location not accessible
• DAGs haven't generated output files yet

**Solutions:**
1. **Check Data Directory**: Ensure C:\\Docker\\airflow3x2\\data\\metrics_json_files exists
2. **Run DAGs**: Execute your workflows to generate report data
3. **Verify Permissions**: Check folder access permissions
4. **Refresh**: Click the "Refresh Reports" button

**Expected File Locations:**
• Primary: C:\\Docker\\airflow3x2\\data\\metrics_json_files\\
• Fallback: Local data directories

**Generate Sample Reports:**
• Run a CSV to XML DAG to create metrics
• Check DAG logs for output file locations
• Verify successful DAG execution completion

💡 **Quick Fix:** Try running one of your DAGs first to generate sample report data!`;
  }

  if (msg.includes('report type') || msg.includes('chart report') || msg.includes('metrics report')) {
    return `📊 **Report Types & Visualization:**

**Chart Reports** 📈
• Pie charts for data distribution
• Bar charts for comparisons  
• Time series for trends
• Auto-generated from labels + counts data

**Metrics Reports** 📋
• Key performance indicators
• Statistical summaries
• Numeric data analysis
• Performance counters

**Table Reports** 📄
• Structured data views
• Sortable columns
• Detailed record inspection
• Data export capabilities

**Complex Reports** 🔄
• Multi-dimensional analysis
• Nested data structures
• Advanced visualizations
• Custom data layouts

**Raw Data Reports** 📝
• Complete dataset views
• JSON structure preview
• Data validation
• Debug information

**Auto-Detection Logic:**
• Structure analysis determines report type
• Smart categorization based on content
• Automatic chart generation for compatible data
• Enhanced statistics for all report types

💡 **Example:** Upload a CSV with categories → Get automatic pie chart distribution!`;
  }

  if (msg.includes('business intelligence') || msg.includes('bi') || msg.includes('analytics dashboard')) {
    return `🎯 **TCS ECM Business Intelligence & Analytics:**

**Executive Dashboard Features:**
• Real-time workflow monitoring
• Performance trend analysis  
• Resource utilization metrics
• Success/failure rate tracking

**Advanced Analytics:**
• Predictive workflow insights
• Bottleneck identification
• Performance optimization recommendations
• Historical trend analysis

**Key Metrics Tracked:**
• DAG execution success rates
• Average processing times
• Data throughput volumes
• System resource usage
• Error patterns and frequencies

**Business Value:**
• **Operational Efficiency**: Monitor workflow performance
• **Data Quality**: Track transformation success rates
• **Resource Planning**: Analyze system utilization
• **Compliance**: Audit trail and reporting

**Current Dashboard Status:**
• DAGs: ${context.totalDags} total workflows
• Active: ${context.runningDags} currently running
• Performance: ${context.recentRuns.length} recent executions
• System: ${context.connectionStatus ? 'Operational' : 'Needs Attention'}

💡 **Insight:** Your ${context.totalDags} DAGs provide comprehensive business process automation!`;
  }
  
  if (msg.includes('dag') && (msg.includes('list') || msg.includes('show'))) {
    if (context.dags.length === 0) {
      return "You don't have any DAGs yet. Use the Upload section to create your first CSV to XML conversion DAG.";
    }
    
    const dagList = context.dags.map((dag: any) => 
      `• **${dag.dag_id}**: ${dag.is_paused ? '⏸️ Paused' : '▶️ Active'} (${dag.recent_runs?.length || 0} recent runs)`
    ).join('\n');
    
    return `📋 **Your DAGs (${context.dags.length} total):**\n\n${dagList}`;
  }
  
  if (msg.includes('create') || msg.includes('upload') || msg.includes('new dag')) {
    return `🚀 **Creating a New DAG:**

1. **Upload CSV**: Go to the Upload section and select your CSV file
2. **Configure**: Set DAG ID, directories, and schedule
3. **Generate**: Create and deploy the DAG script
4. **Monitor**: View progress in the dashboard

**Current Setup:**
• Input Directory: C:\\Docker\\airflow3x2\\data
• Output Directory: C:\\Docker\\airflow3x2\\data
• DAGs Directory: C:\\Docker\\airflow3x2\\dags

💡 **Tip:** Make sure your CSV file has proper headers for the best XML conversion results.`;
  }
  
  if (msg.includes('error') || msg.includes('failed') || msg.includes('troubleshoot')) {
    return `🔧 **Common Troubleshooting Steps:**

**Connection Issues:**
• Ensure Airflow is running at http://localhost:8083
• Check Docker containers are up: \`docker ps\`
• Verify network connectivity

**DAG Issues:**
• Check DAG syntax in the Generated Script section
• Verify file paths are accessible
• Ensure CSV files are in the input directory

**Performance:**
• Monitor DAG run history in dashboard
• Check Airflow logs for detailed error messages
• Consider adjusting schedule intervals for heavy workloads

Current Connection: ${context.connectionStatus ? '✅ Connected' : '❌ Disconnected'}`;
  }
  
  if (msg.includes('help') || msg.includes('commands')) {
    return `🤖 **TCS ECM Airflow Assistant Commands:**

**Dashboard & Status:**
• "What's my dashboard status?"
• "Show me all DAGs"
• "List active DAGs"

**Reports & Analytics:**
• "Show me reports section"
• "What reports are available?"
• "How do I view analytics?"
• "Business intelligence features"

**DAG Management:**
• "How do I create a DAG?"
• "Troubleshoot failed DAGs"
• "Best practices for scheduling"

**File Operations:**
• "CSV upload requirements"
• "XML output format"
• "File path configuration"

**System:**
• "Connection status"
• "Performance tips"
• "Error troubleshooting"

💡 Just ask in natural language - I understand context about your ${context.totalDags} DAGs and analytics!`;
  }
  
  // Default response with enhanced context including reports
  return `I understand you're asking about: "${message}"

Based on your current setup:
• ${context.totalDags} DAGs (${context.runningDags} active, ${context.pausedDags} paused)
• Airflow: ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}

I can help with:
🔹 **Dashboard**: Monitor and manage your workflows
🔹 **Reports & Analytics**: View business intelligence and metrics
🔹 **DAG Creation**: Build new data pipelines
🔹 **CSV to XML**: Data transformation guidance
🔹 **Troubleshooting**: System optimization and fixes
🔹 **Performance**: Monitor and improve efficiency

Try asking: 
• "Show me my reports"
• "What analytics are available?" 
• "How do I view business intelligence?"
• "Dashboard status"`;
};

export function registerChatbotRoutes(app: Express): void {
  // Main chatbot query endpoint
  app.post("/api/chatbot/query", async (req, res) => {
    try {
      const { message, context, systemPrompt }: ChatbotRequest = req.body;
      
      if (!message || !context) {
        return res.status(400).json({
          success: false,
          error: "Message and context are required"
        });
      }

      console.log(`🤖 Chatbot query: "${message}"`);
      console.log(`📊 Context: ${context.totalDags} DAGs, ${context.runningDags} active`);

      let response: string;

      try {
        // Try Hugging Face LLM first
        const prompt = `${systemPrompt}\n\nUser: ${message}\nAssistant:`;
        response = await callHuggingFaceLLM(prompt);
        console.log('✅ Using Hugging Face LLM response');
      } catch (llmError) {
        console.log('⚠️ LLM failed, using contextual fallback');
        response = generateContextualResponse(message, context);
      }

      res.json({
        success: true,
        response: response,
        timestamp: new Date().toISOString(),
        context: {
          totalDags: context.totalDags,
          activeDags: context.runningDags,
          connectionStatus: context.connectionStatus
        }
      });

    } catch (error) {
      console.error('❌ Chatbot query error:', error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : 'Internal server error',
        fallbackResponse: "I apologize, but I'm experiencing technical difficulties. Please try again or contact support."
      });
    }
  });

  // Health check endpoint for LLM services
  app.get("/api/chatbot/health", async (req, res) => {
    const health = {
      ollama: false,
      huggingface: false,
      fallback: true
    };

    // Check Ollama
    try {
      const ollamaResponse = await fetch('http://localhost:11434/api/tags', {
        method: 'GET',
        signal: AbortSignal.timeout(3000)
      });
      health.ollama = ollamaResponse.ok;
    } catch (error) {
      health.ollama = false;
    }

    // Check Hugging Face
    try {
      const hfResponse = await fetch(HUGGINGFACE_API_URL, {
        method: 'POST',
        headers: HUGGINGFACE_API_KEY ? {
          'Authorization': `Bearer ${HUGGINGFACE_API_KEY}`,
          'Content-Type': 'application/json'
        } : { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inputs: "test" }),
        signal: AbortSignal.timeout(5000)
      });
      health.huggingface = hfResponse.status !== 403; // 403 means rate limited but service is up
    } catch (error) {
      health.huggingface = false;
    }

    res.json({
      success: true,
      services: health,
      recommendation: health.ollama ? 'ollama' : health.huggingface ? 'huggingface' : 'fallback',
      timestamp: new Date().toISOString()
    });
  });

  // Get conversation context
  app.get("/api/chatbot/context", async (req, res) => {
    try {
      // This would typically fetch fresh data from your DAG endpoints
      // For now, return a basic structure
      res.json({
        success: true,
        context: {
          appName: "TCS ECM Airflow DAG Generator",
          version: "1.0.0",
          capabilities: [
            "CSV to XML conversion",
            "DAG generation and management",
            "Workflow automation",
            "Dashboard monitoring",
            "Real-time status updates"
          ],
          supportedQueries: [
            "Dashboard status and insights",
            "DAG creation and management",
            "File upload and conversion",
            "Troubleshooting and optimization",
            "Best practices and recommendations"
          ]
        }
      });
    } catch (error) {
      console.error('Context fetch error:', error);
      res.status(500).json({
        success: false,
        error: "Failed to fetch context"
      });
    }
  });
}
