# Overview

Context Craft is a full-stack web application that provides an enterprise data platform for transforming and delivering unstructured data to GenAI systems. The application features a React frontend with a Node.js/Express backend, designed to help users create data processing pipelines, manage document parsers, connect to various data sources, and serve data through APIs.

## Recent Updates (September 18, 2025)

- **Complete Connector Management System**: Implemented full CRUD functionality for data source connectors
  - Created configuration pages for all 6 connector types (AWS S3, Google Cloud Storage, Azure Blob, File Share, Google Drive, File Upload)
  - Added backend API routes for connector management (create, read, update, delete)
  - Renamed "Existing Connectors" to "Saved Connectors" for clarity
  - Integrated with PostgreSQL database for persistent storage
  - Fixed nested form issues to ensure proper form submission
  - All connectors can be saved, viewed, and deleted through the UI

- **Pipeline Designer Integration**: Integrated saved connectors and parser profiles into the pipeline designer
  - Source nodes can now select from saved connectors based on the selected source type
  - Parser nodes can select from saved parser profiles based on the selected parser type
  - Visual nodes display the selected connector/profile names when configured
  - Configuration automatically loads from saved items into pipeline nodes
  - Added API filtering for connectors and parser profiles by type
  - Users can choose between "Configure New" or selecting from saved configurations

## Previous Updates (September 17, 2025)

- **Parser Profiles Enhancement**: Replaced navigation-based parser configuration with modal dialogs
  - Parser configuration now opens in a modal when clicking parser type cards
  - Added document test view tab for testing parser configuration
  - Configured parsers table includes JSON view and download functionality
  - Supports Azure Document AI, Google Document AI, Tesseract OCR, and PaddleOCR

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using React 19 with TypeScript, utilizing Vite as the build tool and development server. The application uses a modern component-based architecture with the following key design decisions:

- **UI Framework**: Implements shadcn/ui components built on Radix UI primitives for consistent, accessible design
- **Styling**: TailwindCSS for utility-first styling with custom CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing instead of React Router
- **State Management**: TanStack React Query for server state management and caching
- **Form Handling**: React Hook Form with Zod validation schemas
- **Code Organization**: Feature-based structure with shared components, pages, and utilities

## Backend Architecture
The backend follows a simple Express.js structure with TypeScript:

- **Server Framework**: Express.js with middleware for JSON parsing, CORS, and request logging
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage Interface**: Abstracted storage layer with both memory-based and database implementations
- **Development Setup**: Vite integration for hot module replacement in development

## Data Storage Solutions
The application uses a hybrid approach for data persistence:

- **Primary Database**: PostgreSQL for structured data (users, configurations)
- **ORM**: Drizzle ORM provides type-safe database interactions with automatic migration support
- **Vector Database Integration**: Support for external vector databases (Qdrant, Pinecone, Weaviate)
- **Session Storage**: In-memory storage for development, with plans for database-backed sessions

## Authentication and Authorization
Currently implements a basic authentication system:

- **Session Management**: Cookie-based sessions with Express middleware
- **User Storage**: Simple user table with username/password authentication
- **Route Protection**: Frontend route guards that check authentication status
- **Development Approach**: Uses memory storage for rapid development iteration

# External Dependencies

## Database and ORM
- **PostgreSQL**: Primary database using Neon serverless PostgreSQL
- **Drizzle ORM**: Type-safe database toolkit with automatic migrations
- **Drizzle Kit**: Database migration and introspection tools

## Frontend Libraries
- **React**: UI library with modern hooks and functional components
- **Vite**: Build tool and development server with HMR support
- **TailwindCSS**: Utility-first CSS framework
- **shadcn/ui**: Pre-built component library based on Radix UI
- **Radix UI**: Headless component primitives for accessibility
- **TanStack React Query**: Server state management and caching
- **Wouter**: Minimalist routing library
- **React Hook Form**: Form handling with validation
- **Zod**: Runtime type validation

## Development Tools
- **TypeScript**: Static type checking across the entire stack
- **ESLint**: Code linting with React and TypeScript rules
- **Replit**: Development environment with specialized plugins for error handling

## Vector Database Support
- **Qdrant**: Vector similarity search database
- **Pinecone**: Managed vector database service
- **Weaviate**: Open-source vector database
- **FAISS**: Facebook AI Similarity Search library

## External Services Integration
- **AWS S3**: Document storage and retrieval
- **Azure Document AI**: Cloud-based document processing with modal configuration
- **Google Document AI**: Document parsing and analysis with modal configuration
- **Tesseract OCR**: Open-source OCR with local processing and modal configuration
- **PaddleOCR**: High-accuracy multilingual OCR engine with modal configuration
- **Unstructured.io SDK**: Advanced document parsing and extraction
- **Airbyte**: Data integration and connector management
- **Apache Airflow**: Workflow orchestration for data pipelines