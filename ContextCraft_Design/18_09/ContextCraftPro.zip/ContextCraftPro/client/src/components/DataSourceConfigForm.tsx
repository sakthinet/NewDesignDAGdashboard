import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  awsS3ConfigSchema, 
  googleCloudStorageConfigSchema,
  azureBlobConfigSchema,
  fileShareConfigSchema,
  googleDriveConfigSchema,
  fileUploadConfigSchema,
  type AwsS3Config,
  type GoogleCloudStorageConfig,
  type AzureBlobConfig,
  type FileShareConfig,
  type GoogleDriveConfig,
  type FileUploadConfig
} from "@shared/schema";
import { Plug, AlertTriangle, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface DataSourceConfigFormProps {
  dataSourceType: string;
  initialConfig?: any;
  onSave: (config: any) => void;
  onTestConnection?: () => void;
}

export function DataSourceConfigForm({ 
  dataSourceType, 
  initialConfig, 
  onSave,
  onTestConnection 
}: DataSourceConfigFormProps) {
  switch (dataSourceType) {
    case "s3":
      return <AwsS3ConfigForm initialConfig={initialConfig} onSave={onSave} onTestConnection={onTestConnection} />;
    case "gcs":
      return <GoogleCloudStorageConfigForm initialConfig={initialConfig} onSave={onSave} onTestConnection={onTestConnection} />;
    case "azure-blob":
      return <AzureBlobConfigForm initialConfig={initialConfig} onSave={onSave} onTestConnection={onTestConnection} />;
    case "file-share":
      return <FileShareConfigForm initialConfig={initialConfig} onSave={onSave} onTestConnection={onTestConnection} />;
    case "google-drive":
      return <GoogleDriveConfigForm initialConfig={initialConfig} onSave={onSave} onTestConnection={onTestConnection} />;
    case "file-upload":
      return <FileUploadConfigForm initialConfig={initialConfig} onSave={onSave} onTestConnection={onTestConnection} />;
    default:
      return (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Configuration not available for this data source type
          </AlertDescription>
        </Alert>
      );
  }
}

// AWS S3 Configuration Form
function AwsS3ConfigForm({ 
  initialConfig, 
  onSave, 
  onTestConnection 
}: { 
  initialConfig?: AwsS3Config; 
  onSave: (config: AwsS3Config) => void;
  onTestConnection?: () => void;
}) {
  const form = useForm<AwsS3Config>({
    resolver: zodResolver(awsS3ConfigSchema),
    defaultValues: initialConfig || {
      bucketName: "",
      region: "us-east-1",
      authType: "access-keys",
      accessKeyId: "",
      secretAccessKey: "",
      pathPrefix: "",
      filePattern: "",
    },
  });

  const authType = form.watch("authType");

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Connection Details</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="bucketName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bucket Name</FormLabel>
                <FormControl>
                  <Input placeholder="my-s3-bucket" {...field} data-testid="input-bucket-name" />
                </FormControl>
                <FormDescription>
                  The name of your S3 bucket
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="region"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Region</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-region">
                      <SelectValue placeholder="Select a region" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                    <SelectItem value="us-west-2">US West (Oregon)</SelectItem>
                    <SelectItem value="eu-west-1">EU (Ireland)</SelectItem>
                    <SelectItem value="eu-central-1">EU (Frankfurt)</SelectItem>
                    <SelectItem value="ap-southeast-1">Asia Pacific (Singapore)</SelectItem>
                    <SelectItem value="ap-northeast-1">Asia Pacific (Tokyo)</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  AWS region where your bucket is located
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">Authentication</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="authType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Authentication Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-auth-type">
                      <SelectValue placeholder="Select authentication type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="access-keys">Access Keys</SelectItem>
                    <SelectItem value="iam-role">IAM Role</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Method to authenticate with AWS
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          {authType === "access-keys" && (
            <>
              <FormField
                control={form.control}
                name="accessKeyId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Access Key ID</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="AKIA..." 
                        {...field} 
                        data-testid="input-access-key-id"
                      />
                    </FormControl>
                    <FormDescription>
                      Your AWS Access Key ID
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="secretAccessKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Secret Access Key</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="••••••••" 
                        {...field}
                        data-testid="input-secret-access-key"
                      />
                    </FormControl>
                    <FormDescription>
                      Your AWS Secret Access Key
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </>
          )}

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">Advanced Options</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="pathPrefix"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Path Prefix (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="documents/invoices/" 
                    {...field}
                    data-testid="input-path-prefix"
                  />
                </FormControl>
                <FormDescription>
                  Only process files within this path
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="filePattern"
            render={({ field }) => (
              <FormItem>
                <FormLabel>File Pattern (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="*.pdf, *.csv" 
                    {...field}
                    data-testid="input-file-pattern"
                  />
                </FormControl>
                <FormDescription>
                  Only process files matching this pattern
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-config">
            Save Configuration
          </Button>
          {onTestConnection && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestConnection}
              data-testid="button-test-connection"
            >
              <Plug className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// Google Cloud Storage Configuration Form
function GoogleCloudStorageConfigForm({ 
  initialConfig, 
  onSave,
  onTestConnection 
}: { 
  initialConfig?: GoogleCloudStorageConfig; 
  onSave: (config: GoogleCloudStorageConfig) => void;
  onTestConnection?: () => void;
}) {
  const form = useForm<GoogleCloudStorageConfig>({
    resolver: zodResolver(googleCloudStorageConfigSchema),
    defaultValues: initialConfig || {
      bucketName: "",
      serviceAccountJson: "",
      projectId: "",
      pathPrefix: "",
      filePattern: "",
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Connection Details</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="bucketName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bucket Name</FormLabel>
                <FormControl>
                  <Input placeholder="my-gcs-bucket" {...field} data-testid="input-gcs-bucket-name" />
                </FormControl>
                <FormDescription>
                  The name of your Google Cloud Storage bucket
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="projectId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Project ID</FormLabel>
                <FormControl>
                  <Input placeholder="my-project-123456" {...field} data-testid="input-project-id" />
                </FormControl>
                <FormDescription>
                  Your Google Cloud project ID
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="serviceAccountJson"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Service Account JSON</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder='{"type": "service_account", "project_id": "...", ...}' 
                    className="font-mono text-xs h-32"
                    {...field}
                    data-testid="textarea-service-account"
                  />
                </FormControl>
                <FormDescription>
                  Paste your service account JSON key here
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">Advanced Options</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="pathPrefix"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Path Prefix (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="documents/invoices/" {...field} data-testid="input-gcs-path-prefix" />
                </FormControl>
                <FormDescription>
                  Only process files within this path
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="filePattern"
            render={({ field }) => (
              <FormItem>
                <FormLabel>File Pattern (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="*.pdf, *.csv" {...field} data-testid="input-gcs-file-pattern" />
                </FormControl>
                <FormDescription>
                  Only process files matching this pattern
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-gcs-config">
            Save Configuration
          </Button>
          {onTestConnection && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestConnection}
              data-testid="button-test-gcs-connection"
            >
              <Plug className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// Azure Blob Storage Configuration Form
function AzureBlobConfigForm({ 
  initialConfig, 
  onSave,
  onTestConnection 
}: { 
  initialConfig?: AzureBlobConfig; 
  onSave: (config: AzureBlobConfig) => void;
  onTestConnection?: () => void;
}) {
  const form = useForm<AzureBlobConfig>({
    resolver: zodResolver(azureBlobConfigSchema),
    defaultValues: initialConfig || {
      storageAccountName: "",
      containerName: "",
      authType: "sas-token",
      sasToken: "",
      connectionString: "",
      pathPrefix: "",
    },
  });

  const authType = form.watch("authType");

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Connection Details</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="storageAccountName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Storage Account Name</FormLabel>
                <FormControl>
                  <Input placeholder="mystorageaccount" {...field} data-testid="input-storage-account" />
                </FormControl>
                <FormDescription>
                  The name of your Azure storage account
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="containerName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Container Name</FormLabel>
                <FormControl>
                  <Input placeholder="my-container" {...field} data-testid="input-container-name" />
                </FormControl>
                <FormDescription>
                  The name of your blob container
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">Authentication</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="authType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Authentication Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-azure-auth-type">
                      <SelectValue placeholder="Select authentication type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="sas-token">SAS Token</SelectItem>
                    <SelectItem value="connection-string">Connection String</SelectItem>
                    <SelectItem value="oauth2">OAuth 2.0</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Method to authenticate with Azure
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          {authType === "sas-token" && (
            <FormField
              control={form.control}
              name="sasToken"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SAS Token</FormLabel>
                  <FormControl>
                    <Input 
                      type="password" 
                      placeholder="?sv=2021-06-08&ss=..." 
                      {...field}
                      data-testid="input-sas-token"
                    />
                  </FormControl>
                  <FormDescription>
                    Your Azure SAS token for authentication
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          {authType === "connection-string" && (
            <FormField
              control={form.control}
              name="connectionString"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Connection String</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="DefaultEndpointsProtocol=https;AccountName=..." 
                      className="font-mono text-xs"
                      {...field}
                      data-testid="textarea-connection-string"
                    />
                  </FormControl>
                  <FormDescription>
                    Your Azure storage connection string
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">Advanced Options</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="pathPrefix"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Path Prefix (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="documents/invoices/" {...field} data-testid="input-azure-path-prefix" />
                </FormControl>
                <FormDescription>
                  Only process files within this path
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-azure-config">
            Save Configuration
          </Button>
          {onTestConnection && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestConnection}
              data-testid="button-test-azure-connection"
            >
              <Plug className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// File Share Configuration Form
function FileShareConfigForm({ 
  initialConfig, 
  onSave,
  onTestConnection 
}: { 
  initialConfig?: FileShareConfig; 
  onSave: (config: FileShareConfig) => void;
  onTestConnection?: () => void;
}) {
  const form = useForm<FileShareConfig>({
    resolver: zodResolver(fileShareConfigSchema),
    defaultValues: initialConfig || {
      networkPath: "",
      username: "",
      password: "",
      domain: "",
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Connection Details</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="networkPath"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Network Path</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="\\server\share\folder" 
                    {...field} 
                    data-testid="input-network-path"
                  />
                </FormControl>
                <FormDescription>
                  The UNC path to your network share
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">Authentication (Optional)</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="domain"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Domain (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="MYDOMAIN" {...field} data-testid="input-domain" />
                </FormControl>
                <FormDescription>
                  Windows domain for authentication
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="john.doe" {...field} data-testid="input-username" />
                </FormControl>
                <FormDescription>
                  Username for network authentication
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="••••••••" 
                    {...field}
                    data-testid="input-password"
                  />
                </FormControl>
                <FormDescription>
                  Password for network authentication
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-fileshare-config">
            Save Configuration
          </Button>
          {onTestConnection && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestConnection}
              data-testid="button-test-fileshare-connection"
            >
              <Plug className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// Google Drive Configuration Form
function GoogleDriveConfigForm({ 
  initialConfig, 
  onSave,
  onTestConnection 
}: { 
  initialConfig?: GoogleDriveConfig; 
  onSave: (config: GoogleDriveConfig) => void;
  onTestConnection?: () => void;
}) {
  const form = useForm<GoogleDriveConfig>({
    resolver: zodResolver(googleDriveConfigSchema),
    defaultValues: initialConfig || {
      clientId: "",
      clientSecret: "",
      refreshToken: "",
      folderId: "",
      fileTypes: [],
    },
  });

  const fileTypeOptions = [
    { value: "documents", label: "Documents" },
    { value: "spreadsheets", label: "Spreadsheets" },
    { value: "pdfs", label: "PDFs" },
    { value: "images", label: "Images" },
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              You'll need to set up OAuth 2.0 credentials in Google Cloud Console to use Google Drive integration.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <h4 className="text-sm font-semibold">OAuth Credentials</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="clientId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Client ID</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="123456789-abc...apps.googleusercontent.com" 
                    {...field} 
                    data-testid="input-client-id"
                  />
                </FormControl>
                <FormDescription>
                  OAuth 2.0 Client ID from Google Cloud Console
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="clientSecret"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Client Secret</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="GOCSPX-..." 
                    {...field}
                    data-testid="input-client-secret"
                  />
                </FormControl>
                <FormDescription>
                  OAuth 2.0 Client Secret
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="refreshToken"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Refresh Token</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="1//0g..." 
                    {...field}
                    data-testid="input-refresh-token"
                  />
                </FormControl>
                <FormDescription>
                  OAuth 2.0 Refresh Token for persistent access
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2 pt-4">
            <h4 className="text-sm font-semibold">File Selection</h4>
            <Separator />
          </div>

          <FormField
            control={form.control}
            name="folderId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Folder ID (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="1a2b3c4d5e6f..." 
                    {...field}
                    data-testid="input-folder-id"
                  />
                </FormControl>
                <FormDescription>
                  Specific folder ID to sync from (leave empty for all accessible files)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="fileTypes"
            render={() => (
              <FormItem>
                <FormLabel>File Types</FormLabel>
                <FormDescription>
                  Select the types of files to process
                </FormDescription>
                <div className="space-y-2 mt-2">
                  {fileTypeOptions.map((option) => (
                    <FormField
                      key={option.value}
                      control={form.control}
                      name="fileTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(option.value as any)}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                const updated = checked
                                  ? [...current, option.value]
                                  : current.filter((v) => v !== option.value);
                                field.onChange(updated);
                              }}
                              data-testid={`checkbox-${option.value}`}
                            />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">
                            {option.label}
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-gdrive-config">
            Save Configuration
          </Button>
          {onTestConnection && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestConnection}
              data-testid="button-test-gdrive-connection"
            >
              <Plug className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// File Upload Configuration Form
function FileUploadConfigForm({ 
  initialConfig, 
  onSave,
  onTestConnection 
}: { 
  initialConfig?: FileUploadConfig; 
  onSave: (config: FileUploadConfig) => void;
  onTestConnection?: () => void;
}) {
  const form = useForm<FileUploadConfig>({
    resolver: zodResolver(fileUploadConfigSchema),
    defaultValues: initialConfig || {
      maxFileSize: 10,
      allowedFileTypes: [],
      storageLocation: "local",
    },
  });

  const fileTypeOptions = [
    { value: "PDF", label: "PDF Documents" },
    { value: "DOC", label: "Word Documents (.doc)" },
    { value: "DOCX", label: "Word Documents (.docx)" },
    { value: "TXT", label: "Text Files" },
    { value: "CSV", label: "CSV Files" },
    { value: "JSON", label: "JSON Files" },
    { value: "XML", label: "XML Files" },
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Upload Settings</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="maxFileSize"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Maximum File Size (MB)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min={1} 
                    max={100}
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                    data-testid="input-max-file-size"
                  />
                </FormControl>
                <FormDescription>
                  Maximum allowed file size in megabytes (1-100 MB)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="storageLocation"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Storage Location</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-storage-location">
                      <SelectValue placeholder="Select storage location" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="local">Local Storage</SelectItem>
                    <SelectItem value="cloud">Cloud Storage</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Where uploaded files will be stored
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="allowedFileTypes"
            render={() => (
              <FormItem>
                <FormLabel>Allowed File Types</FormLabel>
                <FormDescription>
                  Select the file types users can upload
                </FormDescription>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {fileTypeOptions.map((option) => (
                    <FormField
                      key={option.value}
                      control={form.control}
                      name="allowedFileTypes"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(option.value as any)}
                              onCheckedChange={(checked) => {
                                const current = field.value || [];
                                const updated = checked
                                  ? [...current, option.value]
                                  : current.filter((v) => v !== option.value);
                                field.onChange(updated);
                              }}
                              data-testid={`checkbox-filetype-${option.value.toLowerCase()}`}
                            />
                          </FormControl>
                          <FormLabel className="font-normal cursor-pointer">
                            {option.label}
                          </FormLabel>
                        </FormItem>
                      )}
                    />
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-upload-config">
            Save Configuration
          </Button>
        </div>
      </form>
    </Form>
  );
}