import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Cloud, TestTube, Save } from "lucide-react";
import { Link } from "wouter";

export default function NewS3ConnectorPage() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    bucketName: "",
    region: "",
    accessKeyId: "",
    secretAccessKey: "",
    prefix: "",
    includeSubfolders: true,
    fileTypes: [] as string[],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement connector creation
    setLocation("/import-connectors");
  };

  const handleFileTypeChange = (fileType: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        fileTypes: [...formData.fileTypes, fileType],
      });
    } else {
      setFormData({
        ...formData,
        fileTypes: formData.fileTypes.filter((type) => type !== fileType),
      });
    }
  };

  const supportedFileTypes = [
    { id: "pdf", label: "PDF Documents" },
    { id: "docx", label: "Word Documents" },
    { id: "txt", label: "Text Files" },
    { id: "html", label: "HTML Files" },
    { id: "json", label: "JSON Files" },
    { id: "csv", label: "CSV Files" },
  ];

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      {/* Back Navigation */}
      <div className="flex items-center space-x-4">
        <Link href="/import-connectors">
          <Button variant="outline" size="sm" data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>
                  Provide a name and description for this connector
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Connector Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Financial Documents S3"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                    data-testid="input-connector-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Optional description for this connector"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    data-testid="input-connector-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* S3 Configuration */}
            <Card>
              <CardHeader>
                <CardTitle>S3 Configuration</CardTitle>
                <CardDescription>
                  Configure your AWS S3 bucket access
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="bucketName">Bucket Name *</Label>
                    <Input
                      id="bucketName"
                      placeholder="my-documents-bucket"
                      value={formData.bucketName}
                      onChange={(e) =>
                        setFormData({ ...formData, bucketName: e.target.value })
                      }
                      required
                      data-testid="input-bucket-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="region">Region *</Label>
                    <Select
                      value={formData.region}
                      onValueChange={(value) =>
                        setFormData({ ...formData, region: value })
                      }
                    >
                      <SelectTrigger data-testid="select-region">
                        <SelectValue placeholder="Select AWS region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                        <SelectItem value="us-west-2">US West (Oregon)</SelectItem>
                        <SelectItem value="eu-west-1">Europe (Ireland)</SelectItem>
                        <SelectItem value="ap-southeast-1">Asia Pacific (Singapore)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="accessKeyId">Access Key ID *</Label>
                    <Input
                      id="accessKeyId"
                      type="password"
                      placeholder="AKIAIOSFODNN7EXAMPLE"
                      value={formData.accessKeyId}
                      onChange={(e) =>
                        setFormData({ ...formData, accessKeyId: e.target.value })
                      }
                      required
                      data-testid="input-access-key"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secretAccessKey">Secret Access Key *</Label>
                    <Input
                      id="secretAccessKey"
                      type="password"
                      placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
                      value={formData.secretAccessKey}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          secretAccessKey: e.target.value,
                        })
                      }
                      required
                      data-testid="input-secret-key"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="prefix">Path Prefix (Optional)</Label>
                  <Input
                    id="prefix"
                    placeholder="documents/financial/"
                    value={formData.prefix}
                    onChange={(e) =>
                      setFormData({ ...formData, prefix: e.target.value })
                    }
                    data-testid="input-prefix"
                  />
                  <p className="text-xs text-muted-foreground">
                    Specify a folder path to limit import to specific directories
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* File Type Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Supported File Types</CardTitle>
                <CardDescription>
                  Select which file types to import from this connector
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {supportedFileTypes.map((fileType) => (
                    <div
                      key={fileType.id}
                      className="flex items-center space-x-2"
                    >
                      <Checkbox
                        id={fileType.id}
                        checked={formData.fileTypes.includes(fileType.id)}
                        onCheckedChange={(checked) =>
                          handleFileTypeChange(fileType.id, checked as boolean)
                        }
                        data-testid={`checkbox-${fileType.id}`}
                      />
                      <Label
                        htmlFor={fileType.id}
                        className="text-sm font-normal cursor-pointer"
                      >
                        {fileType.label}
                      </Label>
                    </div>
                  ))}
                </div>
                <div className="flex items-center space-x-2 mt-4">
                  <Checkbox
                    id="includeSubfolders"
                    checked={formData.includeSubfolders}
                    onCheckedChange={(checked) =>
                      setFormData({
                        ...formData,
                        includeSubfolders: checked as boolean,
                      })
                    }
                    data-testid="checkbox-include-subfolders"
                  />
                  <Label
                    htmlFor="includeSubfolders"
                    className="text-sm font-medium cursor-pointer"
                  >
                    Include subfolders in import
                  </Label>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Configuration Summary</CardTitle>
                <CardDescription>
                  Review your connector settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="text-foreground font-medium">
                    {formData.name || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bucket:</span>
                  <span className="text-foreground font-medium">
                    {formData.bucketName || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Region:</span>
                  <span className="text-foreground font-medium">
                    {formData.region || "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">File Types:</span>
                  <span className="text-foreground font-medium">
                    {formData.fileTypes.length || "None selected"}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  data-testid="button-test-connection"
                >
                  <TestTube className="w-4 h-4 mr-2" />
                  Test Connection
                </Button>
                <Button
                  type="submit"
                  className="w-full"
                  data-testid="button-create-connector"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Create Connector
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
