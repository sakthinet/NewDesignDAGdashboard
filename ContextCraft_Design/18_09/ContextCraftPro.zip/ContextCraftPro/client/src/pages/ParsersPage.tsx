import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/ui/status-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import {
  Plus,
  Search,
  FileText,
  Cpu,
  Cloud,
  Settings,
  Trash2,
  Filter,
  Copy,
  Download,
  Upload,
  Eye,
  FileJson,
  TestTube,
  Save,
  X,
} from "lucide-react";

interface ParserConfig {
  id: string;
  name: string;
  type: string;
  category: string;
  status: string;
  configuration: {
    apiKey?: string;
    endpoint?: string;
    region?: string;
    projectId?: string;
    modelName?: string;
    confidence?: number;
    language?: string;
    outputFormat?: string;
    enableTables?: boolean;
    enableForms?: boolean;
    [key: string]: any;
  };
  documentsProcessed: string;
  lastUsed: string;
  accuracy: string;
  createdAt: string;
  updatedAt: string;
}

export default function ParsersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedParserType, setSelectedParserType] = useState<string>("");
  const [testDocument, setTestDocument] = useState("");
  const [configuredParsers, setConfiguredParsers] = useState<ParserConfig[]>([]);
  const [parserConfig, setParserConfig] = useState<any>({});
  const { toast } = useToast();

  const handleOpenModal = (parserType: string) => {
    setSelectedParserType(parserType);
    setIsModalOpen(true);
    setParserConfig({
      name: '',
      type: parserType,
      apiKey: '',
      endpoint: '',
      region: '',
      projectId: '',
      modelName: '',
      confidence: 0.8,
      language: 'en',
      outputFormat: 'json',
      enableTables: true,
      enableForms: true,
    });
  };

  const handleSaveParser = () => {
    const newParser: ParserConfig = {
      id: `parser_${Date.now()}`,
      name: parserConfig.name || `${selectedParserType} Parser`,
      type: selectedParserType,
      category: ['Azure Document AI', 'Google Document AI'].includes(selectedParserType) ? 'cloud' : 'local',
      status: 'active',
      configuration: parserConfig,
      documentsProcessed: '0',
      lastUsed: 'Never',
      accuracy: 'N/A',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setConfiguredParsers([...configuredParsers, newParser]);
    
    toast({
      title: "Parser configured successfully",
      description: `${newParser.name} has been added to your configured parsers.`,
    });

    setIsModalOpen(false);
    setSelectedParserType('');
    setParserConfig({});
    setTestDocument('');
  };

  const handleDownloadConfig = (parser: ParserConfig) => {
    const jsonContent = JSON.stringify(parser, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${parser.name.replace(/\s+/g, '_').toLowerCase()}_config.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Configuration downloaded",
      description: `Parser configuration saved as JSON file.`,
    });
  };

  const handleViewConfig = (parser: ParserConfig) => {
    const jsonContent = JSON.stringify(parser, null, 2);
    navigator.clipboard.writeText(jsonContent);
    toast({
      title: "Configuration copied",
      description: "Parser configuration has been copied to clipboard.",
    });
  };

  const parserTypes = [
    {
      name: "Azure Document AI",
      description: "Advanced cloud-based document intelligence",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "99%+",
      href: "/parsers/new?type=azure-ai",
    },
    {
      name: "Google Document AI",
      description: "Google's document processing service",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "98%+",
      href: "/parsers/new?type=google-ai",
    },
    {
      name: "Tesseract OCR",
      description: "Open-source optical character recognition",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "95%",
      href: "/parsers/new?type=tesseract",
    },
    {
      name: "PaddleOCR",
      description: "High-accuracy multilingual OCR engine",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "96%",
      href: "/parsers/new?type=paddle",
    },
    {
      name: "Unstructured.io SDK",
      description: "Advanced document parsing and extraction",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "97%",
      href: "/parsers/new?type=unstructured",
    },
  ];

  const filteredParsers = configuredParsers.filter((parser) =>
    parser.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parser.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-8">
      {/* Header Actions */}
      <div className="flex items-center justify-end">
        <Link href="/parsers/new">
          <Button data-testid="button-new-parser">
            <Plus className="w-4 h-4 mr-2" />
            New Parser
          </Button>
        </Link>
      </div>

      {/* Available Parser Types */}
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Available Parser Types
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {parserTypes.map((type) => (
            <Card 
              key={type.name} 
              className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1"
              onClick={() => handleOpenModal(type.name)}
            >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <type.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{type.category}</p>
                      <p className="text-xs font-medium text-success">{type.accuracy}</p>
                    </div>
                  </div>
                  <CardTitle className="text-lg leading-tight">{type.name}</CardTitle>
                  <CardDescription className="text-sm">
                    {type.description}
                  </CardDescription>
                </CardHeader>
              </Card>
          ))}
        </div>
      </div>

      {/* Configured Parsers */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-primary" />
                Configured Parsers
              </CardTitle>
              <CardDescription>
                Manage your document parsing configurations
              </CardDescription>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search parsers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                  data-testid="input-search-parsers"
                />
              </div>
              <Button variant="outline" size="sm" data-testid="button-filter">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Documents Processed</TableHead>
                  <TableHead>Accuracy</TableHead>
                  <TableHead>Last Used</TableHead>
                  <TableHead>Configuration</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredParsers.map((parser) => (
                  <TableRow key={parser.id} data-testid={`parser-row-${parser.id}`}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-muted rounded-lg">
                          {parser.category === "cloud" ? (
                            <Cloud className="w-4 h-4 text-muted-foreground" />
                          ) : (
                            <Cpu className="w-4 h-4 text-muted-foreground" />
                          )}
                        </div>
                        <div>
                          <span className="font-medium">{parser.name}</span>
                          <p className="text-xs text-muted-foreground capitalize">
                            {parser.category} Parser
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{parser.type}</TableCell>
                    <TableCell>
                      <StatusBadge
                        status={parser.status === "active" ? "success" : "error"}
                      >
                        {parser.status === "active" ? "Active" : "Error"}
                      </StatusBadge>
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {parser.documentsProcessed}
                    </TableCell>
                    <TableCell>
                      <span className={parser.accuracy === "N/A" ? "text-muted-foreground" : "text-success font-medium"}>
                        {parser.accuracy}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {parser.lastUsed}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewConfig(parser)}
                          data-testid={`view-config-${parser.id}`}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View JSON
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDownloadConfig(parser)}
                          data-testid={`download-config-${parser.id}`}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`configure-parser-${parser.id}`}
                        >
                          <Settings className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => {
                            setConfiguredParsers(configuredParsers.filter(p => p.id !== parser.id));
                            toast({
                              title: "Parser deleted",
                              description: "Parser configuration has been removed.",
                            });
                          }}
                          data-testid={`delete-parser-${parser.id}`}
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Parser Configuration Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2 text-primary" />
              Configure {selectedParserType}
            </DialogTitle>
            <DialogDescription>
              Set up your parser configuration and test document extraction
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="configuration" className="mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="configuration">Configuration</TabsTrigger>
              <TabsTrigger value="test">Test Document</TabsTrigger>
            </TabsList>

            <TabsContent value="configuration" className="mt-4 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="parser-name">Parser Name *</Label>
                  <Input
                    id="parser-name"
                    placeholder={`My ${selectedParserType} Parser`}
                    value={parserConfig.name || ''}
                    onChange={(e) => setParserConfig({...parserConfig, name: e.target.value})}
                    data-testid="input-parser-name"
                  />
                </div>

                {selectedParserType === 'Azure Document AI' && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="endpoint">Endpoint *</Label>
                      <Input
                        id="endpoint"
                        placeholder="https://your-resource.cognitiveservices.azure.com"
                        value={parserConfig.endpoint || ''}
                        onChange={(e) => setParserConfig({...parserConfig, endpoint: e.target.value})}
                        data-testid="input-endpoint"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="api-key">API Key *</Label>
                      <Input
                        id="api-key"
                        type="password"
                        placeholder="Your Azure API Key"
                        value={parserConfig.apiKey || ''}
                        onChange={(e) => setParserConfig({...parserConfig, apiKey: e.target.value})}
                        data-testid="input-api-key"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="model">Model Type</Label>
                      <Select
                        value={parserConfig.modelName || 'prebuilt-document'}
                        onValueChange={(value) => setParserConfig({...parserConfig, modelName: value})}
                      >
                        <SelectTrigger id="model" data-testid="select-model">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="prebuilt-document">General Document</SelectItem>
                          <SelectItem value="prebuilt-invoice">Invoice</SelectItem>
                          <SelectItem value="prebuilt-receipt">Receipt</SelectItem>
                          <SelectItem value="prebuilt-idDocument">ID Document</SelectItem>
                          <SelectItem value="prebuilt-businessCard">Business Card</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {selectedParserType === 'Google Document AI' && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="project-id">Project ID *</Label>
                      <Input
                        id="project-id"
                        placeholder="your-gcp-project-id"
                        value={parserConfig.projectId || ''}
                        onChange={(e) => setParserConfig({...parserConfig, projectId: e.target.value})}
                        data-testid="input-project-id"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="api-key-gcp">API Key *</Label>
                      <Input
                        id="api-key-gcp"
                        type="password"
                        placeholder="Your GCP API Key"
                        value={parserConfig.apiKey || ''}
                        onChange={(e) => setParserConfig({...parserConfig, apiKey: e.target.value})}
                        data-testid="input-api-key-gcp"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="processor-type">Processor Type</Label>
                      <Select
                        value={parserConfig.modelName || 'OCR_PROCESSOR'}
                        onValueChange={(value) => setParserConfig({...parserConfig, modelName: value})}
                      >
                        <SelectTrigger id="processor-type" data-testid="select-processor">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="OCR_PROCESSOR">OCR Processor</SelectItem>
                          <SelectItem value="FORM_PARSER_PROCESSOR">Form Parser</SelectItem>
                          <SelectItem value="INVOICE_PROCESSOR">Invoice Parser</SelectItem>
                          <SelectItem value="EXPENSE_PROCESSOR">Expense Parser</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {(selectedParserType === 'Tesseract OCR' || selectedParserType === 'PaddleOCR') && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="language">Language</Label>
                      <Select
                        value={parserConfig.language || 'eng'}
                        onValueChange={(value) => setParserConfig({...parserConfig, language: value})}
                      >
                        <SelectTrigger id="language" data-testid="select-language">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="eng">English</SelectItem>
                          <SelectItem value="chi_sim">Chinese (Simplified)</SelectItem>
                          <SelectItem value="jpn">Japanese</SelectItem>
                          <SelectItem value="spa">Spanish</SelectItem>
                          <SelectItem value="fra">French</SelectItem>
                          <SelectItem value="deu">German</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confidence">Confidence Threshold</Label>
                      <Input
                        id="confidence"
                        type="number"
                        min="0"
                        max="1"
                        step="0.1"
                        placeholder="0.8"
                        value={parserConfig.confidence || 0.8}
                        onChange={(e) => setParserConfig({...parserConfig, confidence: parseFloat(e.target.value)})}
                        data-testid="input-confidence"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="output-format">Output Format</Label>
                  <Select
                    value={parserConfig.outputFormat || 'json'}
                    onValueChange={(value) => setParserConfig({...parserConfig, outputFormat: value})}
                  >
                    <SelectTrigger id="output-format" data-testid="select-output-format">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="text">Plain Text</SelectItem>
                      <SelectItem value="markdown">Markdown</SelectItem>
                      <SelectItem value="xml">XML</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Advanced Options</Label>
                <div className="flex flex-wrap gap-4">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={parserConfig.enableTables || false}
                      onChange={(e) => setParserConfig({...parserConfig, enableTables: e.target.checked})}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">Extract Tables</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={parserConfig.enableForms || false}
                      onChange={(e) => setParserConfig({...parserConfig, enableForms: e.target.checked})}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">Extract Forms</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={parserConfig.enableHandwriting || false}
                      onChange={(e) => setParserConfig({...parserConfig, enableHandwriting: e.target.checked})}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">Detect Handwriting</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={parserConfig.enableBarcode || false}
                      onChange={(e) => setParserConfig({...parserConfig, enableBarcode: e.target.checked})}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">Detect Barcodes</span>
                  </label>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="test" className="mt-4 space-y-4">
              <Alert>
                <FileText className="h-4 w-4" />
                <AlertDescription>
                  Upload a test document to preview how your parser will extract content
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                    <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground mb-2">
                      Drop your test document here or click to browse
                    </p>
                    <Input
                      type="file"
                      accept=".pdf,.png,.jpg,.jpeg,.docx,.txt"
                      className="hidden"
                      id="test-doc-upload"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setTestDocument(file.name);
                        }
                      }}
                    />
                    <label htmlFor="test-doc-upload">
                      <Button variant="outline" size="sm" asChild>
                        <span>
                          <Upload className="w-4 h-4 mr-2" />
                          Select File
                        </span>
                      </Button>
                    </label>
                  </div>

                  {testDocument && (
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm font-medium mb-2">Test Document:</p>
                      <p className="text-sm text-muted-foreground">{testDocument}</p>
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-3 w-full"
                        onClick={() => {
                          toast({
                            title: "Testing parser",
                            description: "Processing document...",
                          });
                          setTimeout(() => {
                            toast({
                              title: "Test complete",
                              description: "Document processed successfully",
                            });
                          }, 2000);
                        }}
                      >
                        <TestTube className="w-4 h-4 mr-2" />
                        Run Test
                      </Button>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <div className="border border-border rounded-lg p-4">
                    <p className="text-sm font-medium mb-2">Extraction Preview:</p>
                    <Textarea
                      placeholder="Extracted content will appear here after running the test..."
                      className="min-h-[300px] font-mono text-sm"
                      readOnly
                      value={testDocument ? `{
  "document_type": "invoice",
  "extracted_text": "Sample extracted content...",
  "tables": [],
  "forms": [],
  "confidence": 0.95,
  "language": "en",
  "pages": 1
}` : ''}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-6">
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveParser} data-testid="button-save-parser">
              <Save className="w-4 h-4 mr-2" />
              Save Configuration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
