import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertConnectorSchema, insertParserProfileSchema } from "@shared/schema";
import { z } from "zod";

// Validation schemas for connector routes
const createConnectorSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.enum(["s3", "gcs", "azure-blob", "file-share", "google-drive", "file-upload"]),
  config: z.object({}).passthrough(), // Allow any object for config
});

const updateConnectorSchema = z.object({
  name: z.string().min(1).optional(),
  type: z.enum(["s3", "gcs", "azure-blob", "file-share", "google-drive", "file-upload"]).optional(),
  config: z.object({}).passthrough().optional(),
  status: z.enum(["active", "inactive", "error"]).optional(),
  lastSync: z.string().nullable().optional(),
  documentsCount: z.number().int().min(0).optional(),
}).refine(data => Object.keys(data).length > 0, {
  message: "At least one field must be provided for update"
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Connector routes

  // GET /api/connectors - Get all connectors, optionally filtered by type
  app.get("/api/connectors", async (req, res) => {
    try {
      const { type } = req.query;
      const connectors = await storage.getAllConnectors();
      
      // If type is provided, filter connectors by type
      if (type && typeof type === 'string') {
        const filteredConnectors = connectors.filter(connector => connector.type === type);
        res.json(filteredConnectors);
      } else {
        res.json(connectors);
      }
    } catch (error) {
      console.error("Error fetching connectors:", error);
      res.status(500).json({ error: "Failed to fetch connectors" });
    }
  });

  // GET /api/connectors/:id - Get single connector by ID
  app.get("/api/connectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const connector = await storage.getConnector(id);
      
      if (!connector) {
        return res.status(404).json({ error: "Connector not found" });
      }
      
      res.json(connector);
    } catch (error) {
      console.error("Error fetching connector:", error);
      res.status(500).json({ error: "Failed to fetch connector" });
    }
  });

  // POST /api/connectors - Create new connector
  app.post("/api/connectors", async (req, res) => {
    try {
      // Validate request body
      const validationResult = createConnectorSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const { name, type, config } = validationResult.data;
      
      // Create connector with initial status and documentsCount
      const newConnector = await storage.createConnector({
        name,
        type,
        config,
        status: "inactive",
        documentsCount: 0,
        lastSync: null,
      });
      
      res.status(201).json(newConnector);
    } catch (error) {
      console.error("Error creating connector:", error);
      res.status(500).json({ error: "Failed to create connector" });
    }
  });

  // PUT /api/connectors/:id - Update existing connector
  app.put("/api/connectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate request body
      const validationResult = updateConnectorSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const updates = validationResult.data;
      const updatedConnector = await storage.updateConnector(id, updates);
      
      if (!updatedConnector) {
        return res.status(404).json({ error: "Connector not found" });
      }
      
      res.json(updatedConnector);
    } catch (error) {
      console.error("Error updating connector:", error);
      res.status(500).json({ error: "Failed to update connector" });
    }
  });

  // DELETE /api/connectors/:id - Delete connector
  app.delete("/api/connectors/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteConnector(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Connector not found" });
      }
      
      res.json({ message: "Connector deleted successfully" });
    } catch (error) {
      console.error("Error deleting connector:", error);
      res.status(500).json({ error: "Failed to delete connector" });
    }
  });

  // Parser Profile routes

  // Validation schemas for parser profile routes
  const createParserProfileSchema = z.object({
    name: z.string().min(1, "Name is required"),
    type: z.enum(["azure-ai", "google-ai", "tesseract", "paddle", "unstructured"]),
    config: z.object({}).passthrough(), // Allow any object for config
  });

  const updateParserProfileSchema = z.object({
    name: z.string().min(1).optional(),
    type: z.enum(["azure-ai", "google-ai", "tesseract", "paddle", "unstructured"]).optional(),
    config: z.object({}).passthrough().optional(),
    status: z.enum(["active", "inactive", "error"]).optional(),
  }).refine(data => Object.keys(data).length > 0, {
    message: "At least one field must be provided for update"
  });

  // GET /api/parser-profiles - Get all parser profiles, optionally filtered by type
  app.get("/api/parser-profiles", async (req, res) => {
    try {
      const { type } = req.query;
      const parserProfiles = await storage.getAllParserProfiles();
      
      // If type is provided, filter parser profiles by type
      if (type && typeof type === 'string') {
        const filteredProfiles = parserProfiles.filter(profile => profile.type === type);
        res.json(filteredProfiles);
      } else {
        res.json(parserProfiles);
      }
    } catch (error) {
      console.error("Error fetching parser profiles:", error);
      res.status(500).json({ error: "Failed to fetch parser profiles" });
    }
  });

  // GET /api/parser-profiles/:id - Get single parser profile by ID
  app.get("/api/parser-profiles/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const parserProfile = await storage.getParserProfile(id);
      
      if (!parserProfile) {
        return res.status(404).json({ error: "Parser profile not found" });
      }
      
      res.json(parserProfile);
    } catch (error) {
      console.error("Error fetching parser profile:", error);
      res.status(500).json({ error: "Failed to fetch parser profile" });
    }
  });

  // POST /api/parser-profiles - Create new parser profile
  app.post("/api/parser-profiles", async (req, res) => {
    try {
      // Validate request body
      const validationResult = createParserProfileSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const { name, type, config } = validationResult.data;
      
      // Create parser profile with initial status
      const newParserProfile = await storage.createParserProfile({
        name,
        type,
        config,
        status: "inactive",
      });
      
      res.status(201).json(newParserProfile);
    } catch (error) {
      console.error("Error creating parser profile:", error);
      res.status(500).json({ error: "Failed to create parser profile" });
    }
  });

  // PUT /api/parser-profiles/:id - Update existing parser profile
  app.put("/api/parser-profiles/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate request body
      const validationResult = updateParserProfileSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validationResult.error.errors 
        });
      }
      
      const updates = validationResult.data;
      const updatedParserProfile = await storage.updateParserProfile(id, updates);
      
      if (!updatedParserProfile) {
        return res.status(404).json({ error: "Parser profile not found" });
      }
      
      res.json(updatedParserProfile);
    } catch (error) {
      console.error("Error updating parser profile:", error);
      res.status(500).json({ error: "Failed to update parser profile" });
    }
  });

  // DELETE /api/parser-profiles/:id - Delete parser profile
  app.delete("/api/parser-profiles/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteParserProfile(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Parser profile not found" });
      }
      
      res.json({ message: "Parser profile deleted successfully" });
    } catch (error) {
      console.error("Error deleting parser profile:", error);
      res.status(500).json({ error: "Failed to delete parser profile" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
