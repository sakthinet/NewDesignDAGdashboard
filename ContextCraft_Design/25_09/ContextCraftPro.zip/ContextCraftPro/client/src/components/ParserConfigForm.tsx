import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { AlertTriangle, TestTube } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { z } from "zod";

// Parser configuration schemas
const azureAIConfigSchema = z.object({
  endpoint: z.string().min(1, "Endpoint is required"),
  apiKey: z.string().min(1, "API key is required"),
  modelType: z.string().default("prebuilt-document"),
  enableTables: z.boolean().default(true),
  enableForms: z.boolean().default(true),
  confidence: z.number().min(0).max(1).default(0.8),
});

const googleAIConfigSchema = z.object({
  projectId: z.string().min(1, "Project ID is required"),
  location: z.string().default("us"),
  processorId: z.string().min(1, "Processor ID is required"),
  apiKey: z.string().min(1, "API key is required"),
  enableTables: z.boolean().default(true),
  enableForms: z.boolean().default(true),
});

const tesseractConfigSchema = z.object({
  language: z.string().default("eng"),
  oem: z.number().min(0).max(3).default(3),
  psm: z.number().min(0).max(13).default(6),
  confidence: z.number().min(0).max(1).default(0.6),
  whitelist: z.string().optional(),
  blacklist: z.string().optional(),
});

const paddleConfigSchema = z.object({
  language: z.string().default("en"),
  useAngleCls: z.boolean().default(true),
  useGpu: z.boolean().default(false),
  confidence: z.number().min(0).max(1).default(0.7),
  enableLayoutAnalysis: z.boolean().default(true),
  enableTableRecognition: z.boolean().default(true),
});

const unstructuredConfigSchema = z.object({
  apiKey: z.string().optional(),
  apiUrl: z.string().optional(),
  strategy: z.string().default("auto"),
  chunking: z.boolean().default(false),
  chunkSize: z.number().min(100).max(10000).default(1000),
  enableHiRes: z.boolean().default(false),
  enablePdf: z.boolean().default(true),
});

type AzureAIConfig = z.infer<typeof azureAIConfigSchema>;
type GoogleAIConfig = z.infer<typeof googleAIConfigSchema>;
type TesseractConfig = z.infer<typeof tesseractConfigSchema>;
type PaddleConfig = z.infer<typeof paddleConfigSchema>;
type UnstructuredConfig = z.infer<typeof unstructuredConfigSchema>;

interface ParserConfigFormProps {
  parserType: string;
  initialConfig?: any;
  onSave: (config: any) => void;
  onTestParser?: () => void;
}

export function ParserConfigForm({ 
  parserType, 
  initialConfig, 
  onSave,
  onTestParser 
}: ParserConfigFormProps) {
  switch (parserType) {
    case "azure-ai":
      return <AzureAIConfigForm initialConfig={initialConfig} onSave={onSave} onTestParser={onTestParser} />;
    case "google-ai":
      return <GoogleAIConfigForm initialConfig={initialConfig} onSave={onSave} onTestParser={onTestParser} />;
    case "tesseract":
      return <TesseractConfigForm initialConfig={initialConfig} onSave={onSave} onTestParser={onTestParser} />;
    case "paddle":
      return <PaddleConfigForm initialConfig={initialConfig} onSave={onSave} onTestParser={onTestParser} />;
    case "unstructured":
      return <UnstructuredConfigForm initialConfig={initialConfig} onSave={onSave} onTestParser={onTestParser} />;
    default:
      return (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Configuration not available for this parser type
          </AlertDescription>
        </Alert>
      );
  }
}

// Azure Document AI Configuration Form
function AzureAIConfigForm({ 
  initialConfig, 
  onSave, 
  onTestParser 
}: { 
  initialConfig?: AzureAIConfig; 
  onSave: (config: AzureAIConfig) => void;
  onTestParser?: () => void;
}) {
  const form = useForm<AzureAIConfig>({
    resolver: zodResolver(azureAIConfigSchema),
    defaultValues: initialConfig || {
      endpoint: "",
      apiKey: "",
      modelType: "prebuilt-document",
      enableTables: true,
      enableForms: true,
      confidence: 0.8,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Azure Document AI Configuration</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="endpoint"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Endpoint URL</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="https://your-resource.cognitiveservices.azure.com/" 
                    {...field} 
                    data-testid="input-azure-endpoint" 
                  />
                </FormControl>
                <FormDescription>
                  Your Azure Document AI endpoint URL
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="apiKey"
            render={({ field }) => (
              <FormItem>
                <FormLabel>API Key</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="Your Azure API key" 
                    {...field}
                    data-testid="input-azure-api-key"
                  />
                </FormControl>
                <FormDescription>
                  Your Azure Document AI API key
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="modelType"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Model Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-azure-model">
                      <SelectValue placeholder="Select model type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="prebuilt-document">General Document</SelectItem>
                    <SelectItem value="prebuilt-invoice">Invoice</SelectItem>
                    <SelectItem value="prebuilt-receipt">Receipt</SelectItem>
                    <SelectItem value="prebuilt-idDocument">ID Document</SelectItem>
                    <SelectItem value="prebuilt-businessCard">Business Card</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Choose the appropriate model for your document type
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="confidence"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Confidence Threshold</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    {...field}
                    onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    data-testid="input-azure-confidence"
                  />
                </FormControl>
                <FormDescription>
                  Minimum confidence score for extracted data (0-1)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-3">
            <FormField
              control={form.control}
              name="enableTables"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-azure-tables"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Table Extraction</FormLabel>
                    <FormDescription>
                      Extract table structures and data from documents
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="enableForms"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-azure-forms"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Form Extraction</FormLabel>
                    <FormDescription>
                      Extract key-value pairs from forms and structured documents
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-azure-config">
            Save Configuration
          </Button>
          {onTestParser && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestParser}
              data-testid="button-test-azure-parser"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Test Document
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// Google Document AI Configuration Form
function GoogleAIConfigForm({ 
  initialConfig, 
  onSave,
  onTestParser 
}: { 
  initialConfig?: GoogleAIConfig; 
  onSave: (config: GoogleAIConfig) => void;
  onTestParser?: () => void;
}) {
  const form = useForm<GoogleAIConfig>({
    resolver: zodResolver(googleAIConfigSchema),
    defaultValues: initialConfig || {
      projectId: "",
      location: "us",
      processorId: "",
      apiKey: "",
      enableTables: true,
      enableForms: true,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Google Document AI Configuration</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="projectId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Project ID</FormLabel>
                <FormControl>
                  <Input placeholder="your-gcp-project-id" {...field} data-testid="input-google-project-id" />
                </FormControl>
                <FormDescription>
                  Your Google Cloud project ID
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="location"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Location</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-google-location">
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="us">United States</SelectItem>
                    <SelectItem value="eu">Europe</SelectItem>
                    <SelectItem value="asia">Asia</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Google Cloud region for processing
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="processorId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Processor ID</FormLabel>
                <FormControl>
                  <Input placeholder="your-processor-id" {...field} data-testid="input-google-processor-id" />
                </FormControl>
                <FormDescription>
                  Your Document AI processor ID
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="apiKey"
            render={({ field }) => (
              <FormItem>
                <FormLabel>API Key</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="Your Google Cloud API key" 
                    {...field}
                    data-testid="input-google-api-key"
                  />
                </FormControl>
                <FormDescription>
                  Your Google Cloud API key
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-3">
            <FormField
              control={form.control}
              name="enableTables"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-google-tables"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Table Extraction</FormLabel>
                    <FormDescription>
                      Extract table structures and data from documents
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="enableForms"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-google-forms"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Form Extraction</FormLabel>
                    <FormDescription>
                      Extract key-value pairs from forms and structured documents
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-google-config">
            Save Configuration
          </Button>
          {onTestParser && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestParser}
              data-testid="button-test-google-parser"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Test Document
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// Tesseract OCR Configuration Form
function TesseractConfigForm({ 
  initialConfig, 
  onSave,
  onTestParser 
}: { 
  initialConfig?: TesseractConfig; 
  onSave: (config: TesseractConfig) => void;
  onTestParser?: () => void;
}) {
  const form = useForm<TesseractConfig>({
    resolver: zodResolver(tesseractConfigSchema),
    defaultValues: initialConfig || {
      language: "eng",
      oem: 3,
      psm: 6,
      confidence: 0.6,
      whitelist: "",
      blacklist: "",
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Tesseract OCR Configuration</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="language"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Language</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-tesseract-language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="eng">English</SelectItem>
                    <SelectItem value="chi_sim">Chinese (Simplified)</SelectItem>
                    <SelectItem value="chi_tra">Chinese (Traditional)</SelectItem>
                    <SelectItem value="jpn">Japanese</SelectItem>
                    <SelectItem value="kor">Korean</SelectItem>
                    <SelectItem value="spa">Spanish</SelectItem>
                    <SelectItem value="fra">French</SelectItem>
                    <SelectItem value="deu">German</SelectItem>
                    <SelectItem value="rus">Russian</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Primary language for OCR recognition
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-3">
            <FormField
              control={form.control}
              name="oem"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>OCR Engine Mode</FormLabel>
                  <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value.toString()}>
                    <FormControl>
                      <SelectTrigger data-testid="select-tesseract-oem">
                        <SelectValue placeholder="Select OEM" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="0">Legacy Engine</SelectItem>
                      <SelectItem value="1">Neural Nets LSTM</SelectItem>
                      <SelectItem value="2">Legacy + LSTM</SelectItem>
                      <SelectItem value="3">Default (Based on availability)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    OCR engine mode selection
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="psm"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Page Segmentation Mode</FormLabel>
                  <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value.toString()}>
                    <FormControl>
                      <SelectTrigger data-testid="select-tesseract-psm">
                        <SelectValue placeholder="Select PSM" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="3">Fully automatic page segmentation</SelectItem>
                      <SelectItem value="6">Uniform block of text</SelectItem>
                      <SelectItem value="7">Single text line</SelectItem>
                      <SelectItem value="8">Single word</SelectItem>
                      <SelectItem value="13">Raw line (for line detection)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Page segmentation mode
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="confidence"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Confidence Threshold</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    {...field}
                    onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    data-testid="input-tesseract-confidence"
                  />
                </FormControl>
                <FormDescription>
                  Minimum confidence score for character recognition (0-1)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="whitelist"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Character Whitelist (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz" 
                    {...field}
                    data-testid="input-tesseract-whitelist"
                  />
                </FormControl>
                <FormDescription>
                  Only recognize these characters (leave empty to recognize all)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="blacklist"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Character Blacklist (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Characters to ignore" 
                    {...field}
                    data-testid="input-tesseract-blacklist"
                  />
                </FormControl>
                <FormDescription>
                  Ignore these characters during recognition
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-tesseract-config">
            Save Configuration
          </Button>
          {onTestParser && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestParser}
              data-testid="button-test-tesseract-parser"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Test Document
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// PaddleOCR Configuration Form
function PaddleConfigForm({ 
  initialConfig, 
  onSave,
  onTestParser 
}: { 
  initialConfig?: PaddleConfig; 
  onSave: (config: PaddleConfig) => void;
  onTestParser?: () => void;
}) {
  const form = useForm<PaddleConfig>({
    resolver: zodResolver(paddleConfigSchema),
    defaultValues: initialConfig || {
      language: "en",
      useAngleCls: true,
      useGpu: false,
      confidence: 0.7,
      enableLayoutAnalysis: true,
      enableTableRecognition: true,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">PaddleOCR Configuration</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="language"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Language</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-paddle-language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ch">Chinese</SelectItem>
                    <SelectItem value="japan">Japanese</SelectItem>
                    <SelectItem value="korean">Korean</SelectItem>
                    <SelectItem value="spanish">Spanish</SelectItem>
                    <SelectItem value="french">French</SelectItem>
                    <SelectItem value="german">German</SelectItem>
                    <SelectItem value="russian">Russian</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Primary language for OCR recognition
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="confidence"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Confidence Threshold</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    max="1" 
                    step="0.1" 
                    {...field}
                    onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    data-testid="input-paddle-confidence"
                  />
                </FormControl>
                <FormDescription>
                  Minimum confidence score for text recognition (0-1)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-3">
            <FormField
              control={form.control}
              name="useAngleCls"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-paddle-angle-cls"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Use Angle Classification</FormLabel>
                    <FormDescription>
                      Automatically detect and correct text rotation
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="useGpu"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-paddle-gpu"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Use GPU Acceleration</FormLabel>
                    <FormDescription>
                      Enable GPU processing for faster performance (requires CUDA)
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="enableLayoutAnalysis"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-paddle-layout"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Layout Analysis</FormLabel>
                    <FormDescription>
                      Analyze document layout and structure
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="enableTableRecognition"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-paddle-tables"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Table Recognition</FormLabel>
                    <FormDescription>
                      Detect and extract table structures
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-paddle-config">
            Save Configuration
          </Button>
          {onTestParser && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestParser}
              data-testid="button-test-paddle-parser"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Test Document
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}

// Unstructured.io SDK Configuration Form
function UnstructuredConfigForm({ 
  initialConfig, 
  onSave,
  onTestParser 
}: { 
  initialConfig?: UnstructuredConfig; 
  onSave: (config: UnstructuredConfig) => void;
  onTestParser?: () => void;
}) {
  const form = useForm<UnstructuredConfig>({
    resolver: zodResolver(unstructuredConfigSchema),
    defaultValues: initialConfig || {
      apiKey: "",
      apiUrl: "",
      strategy: "auto",
      chunking: false,
      chunkSize: 1000,
      enableHiRes: false,
      enablePdf: true,
    },
  });

  const isCloudMode = form.watch("apiKey") || form.watch("apiUrl");

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSave)} className="space-y-4">
        <div className="space-y-3">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold">Unstructured.io SDK Configuration</h4>
            <Separator />
          </div>
          
          <FormField
            control={form.control}
            name="apiKey"
            render={({ field }) => (
              <FormItem>
                <FormLabel>API Key (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    type="password" 
                    placeholder="Your Unstructured.io API key" 
                    {...field}
                    data-testid="input-unstructured-api-key"
                  />
                </FormControl>
                <FormDescription>
                  Leave empty to use local processing, or provide API key for cloud processing
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="apiUrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>API URL (Optional)</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="https://api.unstructured.io" 
                    {...field}
                    data-testid="input-unstructured-api-url"
                  />
                </FormControl>
                <FormDescription>
                  Custom API endpoint URL (leave empty for default)
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="strategy"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Processing Strategy</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-unstructured-strategy">
                      <SelectValue placeholder="Select strategy" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="auto">Auto (Recommended)</SelectItem>
                    <SelectItem value="fast">Fast</SelectItem>
                    <SelectItem value="ocr_only">OCR Only</SelectItem>
                    <SelectItem value="hi_res">High Resolution</SelectItem>
                  </SelectContent>
                </Select>
                <FormDescription>
                  Document processing strategy
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-3">
            <FormField
              control={form.control}
              name="chunking"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-unstructured-chunking"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable Text Chunking</FormLabel>
                    <FormDescription>
                      Split documents into smaller chunks for processing
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            {form.watch("chunking") && (
              <FormField
                control={form.control}
                name="chunkSize"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Chunk Size</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="100" 
                        max="10000" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-unstructured-chunk-size"
                      />
                    </FormControl>
                    <FormDescription>
                      Maximum number of characters per chunk (100-10000)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="enableHiRes"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-unstructured-hi-res"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable High Resolution Processing</FormLabel>
                    <FormDescription>
                      Use high-resolution OCR for better accuracy (slower)
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="enablePdf"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="checkbox-unstructured-pdf"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Enable PDF Processing</FormLabel>
                    <FormDescription>
                      Extract text and structure from PDF documents
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button type="submit" data-testid="button-save-unstructured-config">
            Save Configuration
          </Button>
          {onTestParser && (
            <Button 
              type="button" 
              variant="outline" 
              onClick={onTestParser}
              data-testid="button-test-unstructured-parser"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Test Document
            </Button>
          )}
        </div>
      </form>
    </Form>
  );
}