import { useState, useCallback, useEffect } from "react";
import ReactFlow, {
  Node,
  Edge,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  Handle,
  Position,
} from "reactflow";
import "reactflow/dist/style.css";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { DataSourceConfigForm } from "@/components/DataSourceConfigForm";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import type { Connector, ParserProfile } from "@shared/schema";
import {
  Database,
  FileText,
  Cpu,
  Send,
  Play,
  Save,
  Settings,
  Workflow,
  FolderOpen,
  Type,
  Layers,
  Share2,
  Download,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Custom node types with Unstructured UI styling
const nodeTypes = {
  source: ({ data, selected }: { data: any; selected: boolean }) => (
    <div 
      className={`px-8 py-6 rounded-lg border-2 transition-all min-w-[200px] ${
        selected 
          ? 'border-primary bg-primary/5 shadow-lg' 
          : 'border-border bg-yellow-50/50 dark:bg-yellow-900/10 hover:border-primary/50'
      }`}
    >
      <Handle 
        type="target" 
        position={Position.Left} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
      <div className="flex flex-col items-center gap-2">
        <FolderOpen className="w-8 h-8 text-yellow-600 dark:text-yellow-500" />
        <div className="text-lg font-semibold">Source</div>
        <div className="text-xs text-muted-foreground">{data.connectorName || data.sourceType || 'Configure source'}</div>
      </div>
      <Handle 
        type="source" 
        position={Position.Right} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
    </div>
  ),
  
  parser: ({ data, selected }: { data: any; selected: boolean }) => (
    <div 
      className={`px-8 py-6 rounded-lg border-2 transition-all min-w-[200px] ${
        selected 
          ? 'border-primary bg-primary/5 shadow-lg' 
          : 'border-border bg-card hover:border-primary/50'
      }`}
    >
      <Handle 
        type="target" 
        position={Position.Left} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
      <div className="flex flex-col items-center gap-2">
        <FileText className="w-8 h-8 text-blue-600 dark:text-blue-500" />
        <div className="text-lg font-semibold">Parser</div>
        <div className="text-xs text-muted-foreground">{data.parserProfileName || data.parserType || 'Document parser'}</div>
      </div>
      <Handle 
        type="source" 
        position={Position.Right} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
    </div>
  ),
  
  textProcessing: ({ data, selected }: { data: any; selected: boolean }) => (
    <div 
      className={`px-8 py-6 rounded-lg border-2 transition-all min-w-[200px] ${
        selected 
          ? 'border-primary bg-primary/5 shadow-lg' 
          : 'border-border bg-card hover:border-primary/50'
      }`}
    >
      <Handle 
        type="target" 
        position={Position.Left} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
      <div className="flex flex-col items-center gap-2">
        <Type className="w-8 h-8 text-purple-600 dark:text-purple-500" />
        <div className="text-lg font-semibold">Text Processing</div>
        <div className="text-xs text-muted-foreground">{data.processingType || 'Clean & normalize'}</div>
      </div>
      <Handle 
        type="source" 
        position={Position.Right} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
    </div>
  ),
  
  chunk: ({ data, selected }: { data: any; selected: boolean }) => (
    <div 
      className={`px-8 py-6 rounded-lg border-2 transition-all min-w-[200px] ${
        selected 
          ? 'border-primary bg-primary/5 shadow-lg' 
          : 'border-border bg-card hover:border-primary/50'
      }`}
    >
      <Handle 
        type="target" 
        position={Position.Left} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
      <div className="flex flex-col items-center gap-2">
        <Layers className="w-8 h-8 text-green-600 dark:text-green-500" />
        <div className="text-lg font-semibold">Chunk</div>
        <div className="text-xs text-muted-foreground">{data.chunkSize || '1000 tokens'}</div>
      </div>
      <Handle 
        type="source" 
        position={Position.Right} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
    </div>
  ),
  
  embedding: ({ data, selected }: { data: any; selected: boolean }) => (
    <div 
      className={`px-8 py-6 rounded-lg border-2 transition-all min-w-[200px] ${
        selected 
          ? 'border-primary bg-primary/5 shadow-lg' 
          : 'border-border bg-card hover:border-primary/50'
      }`}
    >
      <Handle 
        type="target" 
        position={Position.Left} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
      <div className="flex flex-col items-center gap-2">
        <Share2 className="w-8 h-8 text-orange-600 dark:text-orange-500" />
        <div className="text-lg font-semibold">Embedding</div>
        <div className="text-xs text-muted-foreground">{data.embeddingModel || 'text-embedding-3'}</div>
      </div>
      <Handle 
        type="source" 
        position={Position.Right} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
    </div>
  ),
  
  export: ({ data, selected }: { data: any; selected: boolean }) => (
    <div 
      className={`px-8 py-6 rounded-lg border-2 transition-all min-w-[200px] ${
        selected 
          ? 'border-primary bg-primary/5 shadow-lg' 
          : 'border-border bg-green-50/50 dark:bg-green-900/10 hover:border-primary/50'
      }`}
    >
      <Handle 
        type="target" 
        position={Position.Left} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
      <div className="flex flex-col items-center gap-2">
        <Download className="w-8 h-8 text-green-600 dark:text-green-500" />
        <div className="text-lg font-semibold">Export</div>
        <div className="text-xs text-muted-foreground">{data.destination || 'Configure destination'}</div>
      </div>
      <Handle 
        type="source" 
        position={Position.Right} 
        style={{ background: '#6b7280', width: '12px', height: '12px' }} 
      />
    </div>
  ),
};

// Fixed linear workflow nodes
const initialNodes: Node[] = [
  {
    id: "source",
    type: "source",
    position: { x: 50, y: 250 },
    data: { 
      label: "Source",
      sourceType: "",
      configuration: {}
    },
  },
  {
    id: "parser",
    type: "parser",
    position: { x: 300, y: 250 },
    data: { 
      label: "Parser",
      parserType: "",
      configuration: {}
    },
  },
  {
    id: "textProcessing",
    type: "textProcessing",
    position: { x: 550, y: 250 },
    data: { 
      label: "Text Processing",
      processingType: "",
      configuration: {}
    },
  },
  {
    id: "chunk",
    type: "chunk",
    position: { x: 800, y: 250 },
    data: { 
      label: "Chunk",
      chunkSize: "",
      configuration: {}
    },
  },
  {
    id: "embedding",
    type: "embedding",
    position: { x: 1050, y: 250 },
    data: { 
      label: "Embedding",
      embeddingModel: "",
      configuration: {}
    },
  },
  {
    id: "export",
    type: "export",
    position: { x: 1300, y: 250 },
    data: { 
      label: "Export",
      destination: "",
      configuration: {}
    },
  },
];

// Fixed edges connecting the pipeline
const initialEdges: Edge[] = [
  { id: "e-source-parser", source: "source", target: "parser", animated: true },
  { id: "e-parser-textProcessing", source: "parser", target: "textProcessing", animated: true },
  { id: "e-textProcessing-chunk", source: "textProcessing", target: "chunk", animated: true },
  { id: "e-chunk-embedding", source: "chunk", target: "embedding", animated: true },
  { id: "e-embedding-export", source: "embedding", target: "export", animated: true },
];

export default function PipelineDesigner() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, , onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [pipelineName, setPipelineName] = useState("");
  const [selectedConnectorId, setSelectedConnectorId] = useState<string>("");
  const [selectedParserProfileId, setSelectedParserProfileId] = useState<string>("");
  const { toast } = useToast();

  // Fetch saved connectors based on source type
  const sourceType = selectedNode?.type === "source" ? selectedNode?.data?.sourceType : null;
  const { data: savedConnectors = [], isLoading: isLoadingConnectors } = useQuery<Connector[]>({
    queryKey: sourceType ? [`/api/connectors?type=${sourceType === 'local' ? 'file-upload' : sourceType}`] : [],
    enabled: !!sourceType,
  });

  // Fetch saved parser profiles based on parser type
  const parserType = selectedNode?.type === "parser" ? selectedNode?.data?.parserType : null;
  // Map UI parser types to API values
  const parserTypeMap: Record<string, string> = {
    'azure-ai': 'azure-ai',
    'google-ai': 'google-ai',
    'tesseract': 'tesseract',
    'unstructured': 'unstructured',
    'paddle': 'paddle'
  };
  const mappedParserType = parserType ? (parserTypeMap[parserType] || parserType) : null;
  
  const { data: savedParserProfiles = [], isLoading: isLoadingParserProfiles } = useQuery<ParserProfile[]>({
    queryKey: mappedParserType ? [`/api/parser-profiles?type=${mappedParserType}`] : [],
    enabled: !!parserType,
  });

  // Reset selected connector when source type changes
  useEffect(() => {
    if (selectedNode?.type === "source") {
      setSelectedConnectorId("");
    }
  }, [selectedNode?.data?.sourceType]);

  // Reset selected parser profile when parser type changes
  useEffect(() => {
    if (selectedNode?.type === "parser") {
      setSelectedParserProfileId("");
    }
  }, [selectedNode?.data?.parserType]);

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  const handleConfigUpdate = (nodeId: string, field: string, value: any) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === nodeId) {
          const updatedNode = {
            ...node,
            data: {
              ...node.data,
              [field]: value,
              configuration: {
                ...node.data.configuration,
                [field]: value
              }
            },
          };
          // Update selectedNode if it's the same node
          if (selectedNode && selectedNode.id === nodeId) {
            setSelectedNode(updatedNode);
          }
          return updatedNode;
        }
        return node;
      })
    );
  };

  const handleSavePipeline = () => {
    if (!pipelineName.trim()) {
      toast({
        title: "Pipeline name required",
        description: "Please enter a name for your pipeline before saving.",
        variant: "destructive",
      });
      return;
    }

    // Create pipeline configuration object with key-value pairs
    const pipelineConfig = {
      pipeline_name: pipelineName,
      pipeline_id: `pipeline_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      version: "1.0.0",
      stages: nodes.reduce((acc, node) => {
        acc[node.type || ''] = {
          id: node.id,
          type: node.type,
          label: node.data.label,
          position: {
            x: node.position.x,
            y: node.position.y
          },
          configuration: node.data.configuration || {},
          settings: {
            ...(node.data.sourceType && { source_type: node.data.sourceType }),
            ...(node.data.parserType && { parser_type: node.data.parserType }),
            ...(node.data.processingType && { processing_type: node.data.processingType }),
            ...(node.data.chunkSize && { chunk_size: node.data.chunkSize }),
            ...(node.data.embeddingModel && { embedding_model: node.data.embeddingModel }),
            ...(node.data.destination && { destination: node.data.destination }),
          }
        };
        return acc;
      }, {} as Record<string, any>),
      connections: edges.map(edge => ({
        source: edge.source,
        target: edge.target,
        source_handle: edge.sourceHandle,
        target_handle: edge.targetHandle
      })),
      metadata: {
        total_stages: nodes.length,
        total_connections: edges.length,
        pipeline_type: "document_processing",
        status: "configured"
      }
    };

    // Create and download JSON file
    const jsonContent = JSON.stringify(pipelineConfig, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${pipelineName.replace(/\s+/g, '_').toLowerCase()}_config.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    // Also save to localStorage for persistence
    const savedPipelines = JSON.parse(localStorage.getItem('pipelines') || '[]');
    const existingIndex = savedPipelines.findIndex((p: any) => p.pipeline_name === pipelineName);
    
    if (existingIndex >= 0) {
      savedPipelines[existingIndex] = pipelineConfig;
    } else {
      savedPipelines.push(pipelineConfig);
    }
    
    localStorage.setItem('pipelines', JSON.stringify(savedPipelines));

    toast({
      title: "Pipeline saved and downloaded",
      description: `Pipeline "${pipelineName}" has been saved and downloaded as JSON.`,
    });
  };

  const handleRunPipeline = () => {
    // Check if all nodes are configured
    const unconfiguredNodes = nodes.filter(node => {
      if (node.id === 'source' && !node.data.sourceType) return true;
      if (node.id === 'parser' && !node.data.parserType) return true;
      if (node.id === 'export' && !node.data.destination) return true;
      return false;
    });

    if (unconfiguredNodes.length > 0) {
      toast({
        title: "Configuration incomplete",
        description: "Please configure all required nodes before running the pipeline.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Pipeline started",
      description: "Your pipeline is now running. Check the logs for progress.",
    });
  };

  // Configuration panels for each node type
  const renderConfigPanel = () => {
    if (!selectedNode) {
      return (
        <div className="text-center text-muted-foreground py-8">
          <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>Select a node to configure its properties</p>
        </div>
      );
    }

    switch (selectedNode.type) {
      case "source":
        const selectedConnector = savedConnectors.find(c => c.id === selectedConnectorId);
        
        return (
          <div className="space-y-4 w-full">
            <div className="w-full">
              <Label htmlFor="source-type" className="block mb-2">Data Source Type</Label>
              <Select 
                value={selectedNode.data.sourceType || ""} 
                onValueChange={(value) => {
                  handleConfigUpdate(selectedNode.id, 'sourceType', value);
                  setSelectedConnectorId(""); // Reset connector selection when source type changes
                  // Clear connectorName when source type changes
                  setNodes((nds) =>
                    nds.map((node) => {
                      if (node.id === selectedNode.id) {
                        return {
                          ...node,
                          data: {
                            ...node.data,
                            connectorName: undefined,
                          },
                        };
                      }
                      return node;
                    })
                  );
                }}
              >
                <SelectTrigger id="source-type" data-testid="select-source-type" className="w-full">
                  <SelectValue placeholder="Select a source" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="s3">AWS S3</SelectItem>
                  <SelectItem value="gcs">Google Cloud Storage</SelectItem>
                  <SelectItem value="azure-blob">Azure Blob Storage</SelectItem>
                  <SelectItem value="local">Local Files</SelectItem>
                  <SelectItem value="google-drive">Google Drive</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {selectedNode.data.sourceType && (
              <>
                <div className="w-full">
                  <Label htmlFor="saved-connector" className="block mb-2">Use Saved Connector</Label>
                  <Select 
                    value={selectedConnectorId} 
                    onValueChange={(value) => {
                      setSelectedConnectorId(value);
                      if (value && value !== "new") {
                        // Load the selected connector's configuration into the node
                        const connector = savedConnectors.find(c => c.id === value);
                        if (connector) {
                          setNodes((nds) =>
                            nds.map((node) => {
                              if (node.id === selectedNode.id) {
                                return {
                                  ...node,
                                  data: {
                                    ...node.data,
                                    configuration: connector.config,
                                    connectorId: connector.id,
                                    connectorName: connector.name,
                                  },
                                };
                              }
                              return node;
                            })
                          );
                          toast({
                            title: "Connector loaded",
                            description: `Using saved connector: ${connector.name}`,
                          });
                        }
                      } else if (value === "new") {
                        // Clear the configuration when "Configure New" is selected
                        setNodes((nds) =>
                          nds.map((node) => {
                            if (node.id === selectedNode.id) {
                              return {
                                ...node,
                                data: {
                                  ...node.data,
                                  configuration: {},
                                  connectorId: undefined,
                                  connectorName: undefined,
                                },
                              };
                            }
                            return node;
                          })
                        );
                      }
                    }}
                  >
                    <SelectTrigger id="saved-connector" data-testid="select-saved-connector" className="w-full">
                      <SelectValue placeholder={isLoadingConnectors ? "Loading..." : "Select a connector"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">Configure New</SelectItem>
                      {savedConnectors.length > 0 && <Separator className="my-1" />}
                      {savedConnectors.map((connector) => (
                        <SelectItem key={connector.id} value={connector.id}>
                          <div className="flex items-center justify-between w-full">
                            <span>{connector.name}</span>
                            <Badge variant="outline" className="ml-2">
                              {connector.status === 'active' ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedConnectorId && selectedConnectorId !== "new" && selectedConnector && (
                  <Alert>
                    <AlertDescription className="space-y-2">
                      <div className="font-semibold">Connector Details:</div>
                      <div className="text-sm space-y-1">
                        <div>Name: {selectedConnector.name}</div>
                        <div>Status: {selectedConnector.status}</div>
                        {selectedConnector.documentsCount !== undefined && (
                          <div>Documents: {selectedConnector.documentsCount}</div>
                        )}
                        {selectedConnector.lastSync && (
                          <div>Last Sync: {new Date(selectedConnector.lastSync).toLocaleString()}</div>
                        )}
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
                
                {(!selectedConnectorId || selectedConnectorId === "new") && (
                  <div className="w-full overflow-hidden">
                    <DataSourceConfigForm
                    dataSourceType={selectedNode.data.sourceType === 'local' ? 'file-upload' : selectedNode.data.sourceType}
                    initialConfig={selectedNode.data.configuration}
                    onSave={(config) => {
                      setNodes((nds) =>
                        nds.map((node) => {
                          if (node.id === selectedNode.id) {
                            return {
                              ...node,
                              data: {
                                ...node.data,
                                configuration: config,
                              },
                            };
                          }
                          return node;
                        })
                      );
                      const sourceTypeLabelMap: Record<string, string> = {
                        's3': 'AWS S3',
                        'gcs': 'Google Cloud Storage',
                        'azure-blob': 'Azure Blob Storage',
                        'local': 'Local Files',
                        'google-drive': 'Google Drive'
                      };
                      const sourceTypeLabel = sourceTypeLabelMap[selectedNode.data.sourceType] || selectedNode.data.sourceType;
                      toast({
                        title: "Source configured",
                        description: `${sourceTypeLabel} connection settings have been saved.`,
                      });
                    }}
                    onTestConnection={() => {
                      toast({
                        title: "Testing connection",
                        description: "Verifying connection to data source...",
                      });
                      // Simulate connection test
                      setTimeout(() => {
                        toast({
                          title: "Connection successful",
                          description: "Successfully connected to the data source.",
                        });
                      }, 2000);
                    }}
                    />
                  </div>
                )}
              </>
            )}
          </div>
        );

      case "parser":
        const selectedParserProfile = savedParserProfiles.find(p => p.id === selectedParserProfileId);
        
        return (
          <div className="space-y-4 w-full">
            <div className="w-full">
              <Label htmlFor="parser-type" className="block mb-2">Parser Type</Label>
              <Select 
                value={selectedNode.data.parserType || ""} 
                onValueChange={(value) => {
                  handleConfigUpdate(selectedNode.id, 'parserType', value);
                  setSelectedParserProfileId(""); // Reset parser profile selection when parser type changes
                }}
              >
                <SelectTrigger id="parser-type" data-testid="select-parser-type" className="w-full">
                  <SelectValue placeholder="Select a parser" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="azure-ai">Azure Document AI</SelectItem>
                  <SelectItem value="google-ai">Google Document AI</SelectItem>
                  <SelectItem value="tesseract">Tesseract OCR</SelectItem>
                  <SelectItem value="unstructured">Unstructured.io</SelectItem>
                  <SelectItem value="paddle">PaddleOCR</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {selectedNode.data.parserType && (
              <>
                <div className="w-full">
                  <Label htmlFor="saved-parser-profile" className="block mb-2">Use Saved Parser Profile</Label>
                  <Select 
                    value={selectedParserProfileId} 
                    onValueChange={(value) => {
                      setSelectedParserProfileId(value);
                      if (value && value !== "new") {
                        // Load the selected parser profile's configuration into the node
                        const profile = savedParserProfiles.find(p => p.id === value);
                        if (profile) {
                          setNodes((nds) =>
                            nds.map((node) => {
                              if (node.id === selectedNode.id) {
                                return {
                                  ...node,
                                  data: {
                                    ...node.data,
                                    configuration: profile.config,
                                    parserProfileId: profile.id,
                                    parserProfileName: profile.name,
                                  },
                                };
                              }
                              return node;
                            })
                          );
                          toast({
                            title: "Parser profile loaded",
                            description: `Using saved parser profile: ${profile.name}`,
                          });
                        }
                      } else if (value === "new") {
                        // Clear the configuration when "Configure New" is selected
                        setNodes((nds) =>
                          nds.map((node) => {
                            if (node.id === selectedNode.id) {
                              return {
                                ...node,
                                data: {
                                  ...node.data,
                                  configuration: {},
                                  parserProfileId: undefined,
                                  parserProfileName: undefined,
                                },
                              };
                            }
                            return node;
                          })
                        );
                      }
                    }}
                  >
                    <SelectTrigger id="saved-parser-profile" data-testid="select-saved-parser-profile" className="w-full">
                      <SelectValue placeholder={isLoadingParserProfiles ? "Loading..." : "Select a parser profile"} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">Configure New</SelectItem>
                      {savedParserProfiles.length > 0 && <Separator className="my-1" />}
                      {savedParserProfiles.map((profile) => (
                        <SelectItem key={profile.id} value={profile.id}>
                          <div className="flex items-center justify-between w-full">
                            <span>{profile.name}</span>
                            <Badge variant="outline" className="ml-2">
                              {profile.status === 'active' ? 'Active' : 'Inactive'}
                            </Badge>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedParserProfileId && selectedParserProfileId !== "new" && selectedParserProfile && (
                  <Alert>
                    <AlertDescription className="space-y-2">
                      <div className="font-semibold">Parser Profile Details:</div>
                      <div className="text-sm space-y-1">
                        <div>Name: {selectedParserProfile.name}</div>
                        <div>Status: {selectedParserProfile.status}</div>
                        <div>Type: {selectedParserProfile.type}</div>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
                
                {(!selectedParserProfileId || selectedParserProfileId === "new") && (
                  <>
                    <Separator />
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="extract-tables">Extract Tables</Label>
                        <Switch id="extract-tables" data-testid="switch-extract-tables" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="extract-images">Extract Images</Label>
                        <Switch id="extract-images" data-testid="switch-extract-images" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="preserve-formatting">Preserve Formatting</Label>
                        <Switch id="preserve-formatting" data-testid="switch-preserve-formatting" />
                      </div>
                    </div>
                  </>
                )}
              </>
            )}
          </div>
        );

      case "textProcessing":
        return (
          <div className="space-y-4 w-full">
            <div className="w-full">
              <Label htmlFor="processing-type" className="block mb-2">Processing Type</Label>
              <Select 
                value={selectedNode.data.processingType || ""} 
                onValueChange={(value) => handleConfigUpdate(selectedNode.id, 'processingType', value)}
              >
                <SelectTrigger id="processing-type" data-testid="select-processing-type" className="w-full">
                  <SelectValue placeholder="Select processing" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="clean">Clean & Normalize</SelectItem>
                  <SelectItem value="summarize">Summarization</SelectItem>
                  <SelectItem value="translate">Translation</SelectItem>
                  <SelectItem value="custom">Custom Processing</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="remove-headers">Remove Headers/Footers</Label>
                <Switch id="remove-headers" defaultChecked data-testid="switch-remove-headers" />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="remove-special">Remove Special Characters</Label>
                <Switch id="remove-special" defaultChecked data-testid="switch-remove-special" />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="normalize-whitespace">Normalize Whitespace</Label>
                <Switch id="normalize-whitespace" defaultChecked data-testid="switch-normalize-whitespace" />
              </div>
            </div>
          </div>
        );

      case "chunk":
        return (
          <div className="space-y-4 w-full">
            <div className="w-full">
              <Label htmlFor="chunk-size" className="block mb-2">Chunk Size (tokens)</Label>
              <Input 
                id="chunk-size"
                type="number"
                placeholder="1000"
                value={selectedNode.data.chunkSize || ""}
                onChange={(e) => handleConfigUpdate(selectedNode.id, 'chunkSize', e.target.value)}
                data-testid="input-chunk-size"
                className="w-full"
              />
            </div>
            
            <div className="w-full">
              <Label htmlFor="chunk-overlap" className="block mb-2">Overlap (tokens)</Label>
              <Input 
                id="chunk-overlap"
                type="number"
                placeholder="200"
                data-testid="input-chunk-overlap"
                className="w-full"
              />
            </div>
            
            <div className="w-full">
              <Label htmlFor="chunking-strategy" className="block mb-2">Chunking Strategy</Label>
              <Select defaultValue="token">
                <SelectTrigger id="chunking-strategy" data-testid="select-chunking-strategy" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="token">Token-based</SelectItem>
                  <SelectItem value="sentence">Sentence-based</SelectItem>
                  <SelectItem value="paragraph">Paragraph-based</SelectItem>
                  <SelectItem value="semantic">Semantic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Alert>
              <AlertDescription>
                Smaller chunks improve search precision but may lose context. 
                Recommended: 500-1500 tokens with 10-20% overlap.
              </AlertDescription>
            </Alert>
          </div>
        );

      case "embedding":
        return (
          <div className="space-y-4 w-full">
            <div className="w-full">
              <Label htmlFor="embedding-model" className="block mb-2">Embedding Model</Label>
              <Select 
                value={selectedNode.data.embeddingModel || ""} 
                onValueChange={(value) => handleConfigUpdate(selectedNode.id, 'embeddingModel', value)}
              >
                <SelectTrigger id="embedding-model" data-testid="select-embedding-model" className="w-full">
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text-embedding-3-small">OpenAI text-embedding-3-small</SelectItem>
                  <SelectItem value="text-embedding-3-large">OpenAI text-embedding-3-large</SelectItem>
                  <SelectItem value="text-embedding-ada-002">OpenAI text-embedding-ada-002</SelectItem>
                  <SelectItem value="voyage-2">Voyage AI voyage-2</SelectItem>
                  <SelectItem value="cohere-embed">Cohere Embed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full">
              <Label htmlFor="batch-size" className="block mb-2">Batch Size</Label>
              <Input 
                id="batch-size"
                type="number"
                placeholder="100"
                defaultValue="100"
                data-testid="input-batch-size"
                className="w-full"
              />
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="normalize-embeddings">Normalize Embeddings</Label>
                <Switch id="normalize-embeddings" defaultChecked data-testid="switch-normalize-embeddings" />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="cache-embeddings">Cache Embeddings</Label>
                <Switch id="cache-embeddings" defaultChecked data-testid="switch-cache-embeddings" />
              </div>
            </div>
            
            <Alert>
              <AlertDescription>
                Model dimensions: text-embedding-3-small (1536), text-embedding-3-large (3072)
              </AlertDescription>
            </Alert>
          </div>
        );

      case "export":
        return (
          <div className="space-y-4 w-full">
            <div className="w-full">
              <Label htmlFor="destination" className="block mb-2">Export Destination</Label>
              <Select 
                value={selectedNode.data.destination || ""} 
                onValueChange={(value) => handleConfigUpdate(selectedNode.id, 'destination', value)}
              >
                <SelectTrigger id="destination" data-testid="select-destination" className="w-full">
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pinecone">Pinecone</SelectItem>
                  <SelectItem value="weaviate">Weaviate</SelectItem>
                  <SelectItem value="chroma">ChromaDB</SelectItem>
                  <SelectItem value="qdrant">Qdrant</SelectItem>
                  <SelectItem value="elasticsearch">Elasticsearch</SelectItem>
                  <SelectItem value="postgres">PostgreSQL (pgvector)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {selectedNode.data.destination === 'pinecone' && (
              <>
                <div className="w-full">
                  <Label htmlFor="index-name" className="block mb-2">Index Name</Label>
                  <Input 
                    id="index-name"
                    placeholder="my-index"
                    data-testid="input-index-name"
                    className="w-full"
                  />
                </div>
                
                <div className="w-full">
                  <Label htmlFor="namespace" className="block mb-2">Namespace (optional)</Label>
                  <Input 
                    id="namespace"
                    placeholder="default"
                    data-testid="input-namespace"
                    className="w-full"
                  />
                </div>
                
                <div className="w-full">
                  <Label htmlFor="api-key" className="block mb-2">API Key</Label>
                  <Input 
                    id="api-key"
                    type="password"
                    placeholder="••••••••"
                    data-testid="input-api-key"
                    className="w-full"
                  />
                </div>
              </>
            )}
            
            <Separator />
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="upsert-batch">Batch Upsert</Label>
                <Switch id="upsert-batch" defaultChecked data-testid="switch-upsert-batch" />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="include-metadata">Include Metadata</Label>
                <Switch id="include-metadata" defaultChecked data-testid="switch-include-metadata" />
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-4 h-[calc(100vh-120px)]">
      {/* Header Actions */}
      <div className="flex items-center justify-between mb-6">
        <Input
          placeholder="Enter pipeline name"
          value={pipelineName}
          onChange={(e) => setPipelineName(e.target.value)}
          className="w-64"
          data-testid="input-pipeline-name"
        />
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" onClick={handleSavePipeline} data-testid="button-save-pipeline">
            <Save className="w-4 h-4 mr-2" />
            Save Pipeline
          </Button>
          <Button size="sm" onClick={handleRunPipeline} data-testid="button-run-pipeline">
            <Play className="w-4 h-4 mr-2" />
            Run Pipeline
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-[calc(100%-80px)]">
        {/* Pipeline Canvas - Now takes up more space */}
        <div className="lg:col-span-9">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Pipeline Workflow</CardTitle>
              <CardDescription>
                Click on any stage to configure its properties
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0 h-[calc(100%-80px)]">
              <div className="h-full w-full">
                <ReactFlow
                  nodes={nodes}
                  edges={edges}
                  onNodesChange={onNodesChange}
                  onEdgesChange={onEdgesChange}
                  onNodeClick={onNodeClick}
                  nodeTypes={nodeTypes}
                  fitView
                  attributionPosition="bottom-left"
                  nodesDraggable={true}
                  nodesConnectable={false}
                  elementsSelectable={true}
                  zoomOnScroll={false}
                  panOnScroll={true}
                  preventScrolling={false}
                >
                  <Controls showInteractive={false} />
                  <Background variant={"dots" as any} gap={20} size={1} color="#e5e7eb" />
                </ReactFlow>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Properties Panel */}
        <div className="lg:col-span-3">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Configuration</CardTitle>
              <CardDescription>
                {selectedNode ? selectedNode.data.label : 'Select a node'}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-4">
              <ScrollArea className="h-[calc(100vh-320px)] pr-4">
                <div className="space-y-4">
                  {selectedNode && selectedNode.type && (
                    <div className="mb-4">
                      <Badge variant="outline" className="w-full justify-center py-2 text-sm">
                        {selectedNode.type.charAt(0).toUpperCase() + selectedNode.type.slice(1)} Stage
                      </Badge>
                    </div>
                  )}
                  <div className="w-full">
                    {renderConfigPanel()}
                  </div>
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}