import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import AppLayout from "@/components/layout/AppLayout";
// Import all pages
import {
  // Auth
  Login,
  // Dashboard
  DashboardPage,
  // Import Connectors
  ImportConnectorsPage,
  NewS3ConnectorPage,
  NewGCSConnectorPage,
  NewAzureConnectorPage,
  NewFileShareConnectorPage,
  NewGoogleDriveConnectorPage,
  NewFileUploadConnectorPage,
  // Parser Profiles
  ParsersPage,
  NewParserPage,
  NewAzureParserPage,
  NewGoogleParserPage,
  NewTesseractParserPage,
  NewPaddleParserPage,
  NewUnstructuredParserPage,
  // Vector Pipelines
  VectorPipelinesPage,
  // Pipeline Designer
  PipelineDesigner,
  // Create API
  CreateApiPage,
  // Test API
  TestApiPage,
  // Common
  NotFound,
} from "@/pages";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" nest>
        <AppLayout>
          <Switch>
            <Route path="/" component={DashboardPage} />
            <Route path="/import-connectors" component={ImportConnectorsPage} />
            <Route path="/import-connectors/new-s3" component={NewS3ConnectorPage} />
            <Route path="/import-connectors/new-gcs" component={NewGCSConnectorPage} />
            <Route path="/import-connectors/new-azure" component={NewAzureConnectorPage} />
            <Route path="/import-connectors/new-fileshare" component={NewFileShareConnectorPage} />
            <Route path="/import-connectors/new-google-drive" component={NewGoogleDriveConnectorPage} />
            <Route path="/import-connectors/new-file-upload" component={NewFileUploadConnectorPage} />
            <Route path="/parsers" component={ParsersPage} />
            <Route path="/parsers/new" component={NewParserPage} />
            <Route path="/parsers/new-azure" component={NewAzureParserPage} />
            <Route path="/parsers/new-google" component={NewGoogleParserPage} />
            <Route path="/parsers/new-tesseract" component={NewTesseractParserPage} />
            <Route path="/parsers/new-paddle" component={NewPaddleParserPage} />
            <Route path="/parsers/new-unstructured" component={NewUnstructuredParserPage} />
            <Route path="/create-pipeline" component={VectorPipelinesPage} />
            <Route path="/pipeline-designer" component={PipelineDesigner} />
            <Route path="/create-api" component={CreateApiPage} />
            <Route path="/test-api" component={TestApiPage} />
            <Route component={NotFound} />
          </Switch>
        </AppLayout>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="context-craft-theme">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
