import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer, timestamp, uuid, bigint, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`uuid_generate_v4()`),
  username: varchar("username", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  email: varchar("email", { length: 255 }).unique(),
  fullName: varchar("full_name", { length: 255 }),
  role: varchar("role", { length: 50 }).default("user"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
  lastLogin: timestamp("last_login", { withTimezone: true }),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const connectors = pgTable("connectors", {
  id: uuid("id").primaryKey().default(sql`uuid_generate_v4()`),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // "s3", "gcs", "azure-blob", "file-share", "google-drive", "file-upload"
  config: jsonb("config").notNull(), // Stores the connector configuration based on type
  status: text("status").notNull().default("inactive"), // "active", "inactive", "error", "testing", "syncing"
  lastSync: timestamp("last_sync", { withTimezone: true }),
  lastSyncStatus: text("last_sync_status"), // "success", "failed", "in_progress"
  documentsCount: integer("documents_count").notNull().default(0),
  totalSizeBytes: bigint("total_size_bytes", { mode: "number" }).notNull().default(0),
  errorMessage: text("error_message"),
  createdBy: uuid("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertConnectorSchema = createInsertSchema(connectors).omit({
  id: true,
  createdAt: true,
});

export type InsertConnector = z.infer<typeof insertConnectorSchema>;
export type Connector = typeof connectors.$inferSelect;

// Data Source Configuration Schemas
export const awsS3ConfigSchema = z.object({
  bucketName: z.string().min(1, "Bucket name is required"),
  region: z.enum(["us-east-1", "us-west-2", "eu-west-1", "eu-central-1", "ap-southeast-1", "ap-northeast-1"]),
  authType: z.enum(["access-keys", "iam-role"]),
  accessKeyId: z.string().optional(),
  secretAccessKey: z.string().optional(),
  pathPrefix: z.string().optional(),
  filePattern: z.string().optional(),
}).refine((data) => {
  if (data.authType === "access-keys") {
    return data.accessKeyId && data.secretAccessKey;
  }
  return true;
}, {
  message: "Access Key ID and Secret Access Key are required when using Access Keys authentication",
  path: ["accessKeyId"],
});

export const googleCloudStorageConfigSchema = z.object({
  bucketName: z.string().min(1, "Bucket name is required"),
  serviceAccountJson: z.string().min(1, "Service Account JSON is required"),
  projectId: z.string().min(1, "Project ID is required"),
  pathPrefix: z.string().optional(),
  filePattern: z.string().optional(),
});

export const azureBlobConfigSchema = z.object({
  storageAccountName: z.string().min(1, "Storage Account Name is required"),
  containerName: z.string().min(1, "Container Name is required"),
  authType: z.enum(["sas-token", "connection-string", "oauth2"]),
  sasToken: z.string().optional(),
  connectionString: z.string().optional(),
  pathPrefix: z.string().optional(),
}).refine((data) => {
  if (data.authType === "sas-token") {
    return !!data.sasToken;
  }
  if (data.authType === "connection-string") {
    return !!data.connectionString;
  }
  return true;
}, {
  message: "Authentication credentials are required for the selected authentication type",
  path: ["sasToken"],
});

export const fileShareConfigSchema = z.object({
  networkPath: z.string().min(1, "Network path is required"),
  username: z.string().optional(),
  password: z.string().optional(),
  domain: z.string().optional(),
});

export const googleDriveConfigSchema = z.object({
  clientId: z.string().min(1, "Client ID is required"),
  clientSecret: z.string().min(1, "Client Secret is required"),
  refreshToken: z.string().min(1, "Refresh Token is required"),
  folderId: z.string().optional(),
  fileTypes: z.array(z.enum(["documents", "spreadsheets", "pdfs", "images"])).min(1, "Select at least one file type"),
});

export const fileUploadConfigSchema = z.object({
  maxFileSize: z.number().min(1).max(100).default(10),
  allowedFileTypes: z.array(z.enum(["PDF", "DOC", "DOCX", "TXT", "CSV", "JSON", "XML"])).min(1, "Select at least one file type"),
  storageLocation: z.enum(["local", "cloud"]),
});

export type AwsS3Config = z.infer<typeof awsS3ConfigSchema>;
export type GoogleCloudStorageConfig = z.infer<typeof googleCloudStorageConfigSchema>;
export type AzureBlobConfig = z.infer<typeof azureBlobConfigSchema>;
export type FileShareConfig = z.infer<typeof fileShareConfigSchema>;
export type GoogleDriveConfig = z.infer<typeof googleDriveConfigSchema>;
export type FileUploadConfig = z.infer<typeof fileUploadConfigSchema>;

export type DataSourceConfig = 
  | { type: "s3"; config: AwsS3Config }
  | { type: "gcs"; config: GoogleCloudStorageConfig }
  | { type: "azure-blob"; config: AzureBlobConfig }
  | { type: "file-share"; config: FileShareConfig }
  | { type: "google-drive"; config: GoogleDriveConfig }
  | { type: "file-upload"; config: FileUploadConfig };

// Parser Profiles table and schemas
export const parserProfiles = pgTable("parser_profiles", {
  id: uuid("id").primaryKey().default(sql`uuid_generate_v4()`),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // "azure-ai", "google-ai", "tesseract", "paddle", "unstructured"
  config: jsonb("config").notNull(), // Stores the parser configuration based on type
  status: text("status").notNull().default("inactive"), // "active", "inactive", "error", "testing"
  version: varchar("version", { length: 50 }).default("1.0.0"),
  supportedFormats: text("supported_formats").array().default(sql`ARRAY['pdf', 'docx', 'txt', 'html', 'json']`),
  performanceMetrics: jsonb("performance_metrics"),
  testResults: jsonb("test_results"),
  createdBy: uuid("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

// Pipelines table
export const pipelines = pgTable("pipelines", {
  id: uuid("id").primaryKey().default(sql`uuid_generate_v4()`),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull().default("document_processing"), // "document_processing", "data_ingestion", "vector_processing", "custom"
  config: jsonb("config").notNull(), // Complete pipeline configuration
  nodes: jsonb("nodes").notNull(), // ReactFlow nodes configuration
  edges: jsonb("edges").notNull(), // ReactFlow edges configuration
  status: text("status").notNull().default("configured"), // "configured", "active", "inactive", "running", "completed", "failed", "paused"
  version: varchar("version", { length: 50 }).default("1.0.0"),
  
  // Pipeline execution tracking
  lastRun: timestamp("last_run", { withTimezone: true }),
  lastRunStatus: text("last_run_status"), // "success", "failed", "in_progress", "cancelled"
  lastRunDuration: integer("last_run_duration"), // Duration in seconds
  totalRuns: integer("total_runs").default(0),
  successfulRuns: integer("successful_runs").default(0),
  failedRuns: integer("failed_runs").default(0),
  
  // Document processing metrics
  documentsProcessed: integer("documents_processed").default(0),
  vectorsGenerated: integer("vectors_generated").default(0),
  totalProcessingTime: integer("total_processing_time").default(0), // Total time in seconds
  averageProcessingTime: integer("average_processing_time"), // Average time per document
  
  // Pipeline metadata
  metadata: jsonb("metadata"),
  scheduleConfig: jsonb("schedule_config"),
  notificationConfig: jsonb("notification_config"),
  
  // Relationships
  sourceConnectorId: uuid("source_connector_id"),
  parserProfileId: uuid("parser_profile_id"),
  
  // Audit fields
  createdBy: uuid("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

// API Endpoints table
export const apiEndpoints = pgTable("api_endpoints", {
  id: uuid("id").primaryKey().default(sql`uuid_generate_v4()`),
  name: text("name").notNull(),
  description: text("description"),
  endpointPath: text("endpoint_path").notNull(), // e.g., "/api/financial/search"
  method: text("method").notNull().default("POST"), // "GET", "POST", "PUT", "DELETE", "PATCH"
  
  // Configuration
  pipelineId: uuid("pipeline_id"),
  config: jsonb("config").notNull(), // API endpoint configuration
  requestSchema: jsonb("request_schema"), // Request validation schema
  responseSchema: jsonb("response_schema"), // Response format schema
  
  // Security and access
  authRequired: boolean("auth_required").default(true),
  rateLimit: integer("rate_limit").default(1000), // Requests per hour
  allowedOrigins: text("allowed_origins").array(), // CORS origins
  apiKeyRequired: boolean("api_key_required").default(false),
  
  // Status and metrics
  status: text("status").notNull().default("inactive"), // "active", "inactive", "deprecated"
  totalCalls: integer("total_calls").default(0),
  successfulCalls: integer("successful_calls").default(0),
  failedCalls: integer("failed_calls").default(0),
  lastCalled: timestamp("last_called", { withTimezone: true }),
  
  // Audit
  createdBy: uuid("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertParserProfileSchema = createInsertSchema(parserProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPipelineSchema = createInsertSchema(pipelines).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertApiEndpointSchema = createInsertSchema(apiEndpoints).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertParserProfile = z.infer<typeof insertParserProfileSchema>;
export type ParserProfile = typeof parserProfiles.$inferSelect;
export type InsertPipeline = z.infer<typeof insertPipelineSchema>;
export type Pipeline = typeof pipelines.$inferSelect;
export type InsertApiEndpoint = z.infer<typeof insertApiEndpointSchema>;
export type ApiEndpoint = typeof apiEndpoints.$inferSelect;
