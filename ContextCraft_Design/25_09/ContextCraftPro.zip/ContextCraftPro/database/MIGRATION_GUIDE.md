# Database Migration Guide

This document explains how to migrate your ContextCraft database to the comprehensive schema.

## Overview

The comprehensive database schema includes:
- Enhanced **Users** table with roles and permissions
- **Connectors** table with full audit trail
- **Parser Profiles** table for document processing
- **Pipelines** table for workflow management  
- **API Endpoints** table for published APIs
- Proper indexes, constraints, and triggers

## Migration Process

### Option 1: Automated Migration (Recommended)

1. **Backup your existing data** (if any):
   ```bash
   pg_dump postgresql://postgres:admin%4012345@localhost:5432/contextcraft > backup.sql
   ```

2. **Run the migration script**:
   ```bash
   npm run db:migrate
   ```

This will:
- Create all new tables with proper structure
- Set up indexes and constraints
- Add triggers for automatic timestamp updates
- Insert sample admin user

### Option 2: Manual Migration

1. **Connect to your database**:
   ```bash
   psql postgresql://postgres:admin%4012345@localhost:5432/contextcraft
   ```

2. **Run the migration file**:
   ```sql
   \i migrations/0001_comprehensive_schema.sql
   ```

## What Changes

### Schema Updates

| Table | Changes |
|-------|---------|
| `users` | Added email, full_name, role, is_active fields |
| `connectors` | Updated field names, added proper constraints |
| `parser_profiles` | New table for document processing |
| `pipelines` | New table for workflow management |
| `api_endpoints` | New table for API management |

### Field Mapping

**Connectors table field changes**:
- `lastSync` → `last_sync` 
- `lastSyncStatus` → `last_sync_status`
- `documentsCount` → `documents_count`
- `totalSizeBytes` → `total_size_bytes` (now BIGINT)
- `errorMessage` → `error_message`
- `createdBy` → `created_by` (now UUID reference)
- `createdAt` → `created_at`
- `updatedAt` → `updated_at`

## Data Preservation

The migration script:
- **Preserves existing connector data** (if compatible)
- **Creates default admin user**
- **Maintains backward compatibility** where possible

## Post-Migration Steps

1. **Verify tables were created**:
   ```sql
   \dt
   ```

2. **Check indexes**:
   ```sql
   \di
   ```

3. **Test basic operations**:
   ```sql
   SELECT * FROM connectors LIMIT 5;
   SELECT * FROM users WHERE role = 'admin';
   ```

4. **Update application code** to use new field names

## Rollback (if needed)

If you need to rollback:

1. **Restore from backup**:
   ```bash
   dropdb contextcraft
   createdb contextcraft
   psql contextcraft < backup.sql
   ```

2. **Revert code changes** in `shared/schema.ts`

## Development Workflow

For future schema changes:

1. **Generate migrations**:
   ```bash
   npm run db:generate
   ```

2. **Push changes**:
   ```bash  
   npm run db:push
   ```

3. **Open Drizzle Studio**:
   ```bash
   npm run db:studio
   ```

## Environment Variables

Ensure these are set:

```env
DATABASE_URL=postgresql://postgres:admin%4012345@localhost:5432/contextcraft
```

## Troubleshooting

### Common Issues

1. **UUID extension error**:
   ```sql
   CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
   ```

2. **Permission errors**: Ensure your database user has CREATE privileges

3. **Connection errors**: Verify DATABASE_URL format and credentials

4. **Existing data conflicts**: Check for name collisions or constraint violations

### Getting Help

If you encounter issues:
1. Check the error logs
2. Verify database connection
3. Ensure PostgreSQL version >= 12
4. Check for conflicting data

## Schema Documentation

See `database/DATABASE_SCHEMA_README.md` for complete schema documentation including:
- Table relationships
- JSON configuration examples
- Query examples
- Performance considerations