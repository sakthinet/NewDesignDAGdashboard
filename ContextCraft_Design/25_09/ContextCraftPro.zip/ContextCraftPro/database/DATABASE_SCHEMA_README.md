# ContextCraft Database Schema Documentation

## Overview
This PostgreSQL database schema is designed to support all major features of ContextCraft:
- **Import Connectors**: Data source configurations for various cloud providers and file systems
- **Parser Profiles**: Document parsing configurations for different AI services and local parsers
- **Vector Pipelines**: Complete document processing workflows
- **Pipeline Designer**: Visual pipeline configuration with ReactFlow
- **API Endpoints**: Published APIs for accessing processed data

## Table Structure

### Core Tables

1. **users** - User authentication and management
2. **connectors** - Data source configurations (Import Connectors page)
3. **parser_profiles** - Document parser configurations (Parser Profiles page)
4. **pipelines** - Complete processing workflows (Vector Pipelines & Pipeline Designer)
5. **pipeline_executions** - Execution history and metrics
6. **documents** - Individual document tracking
7. **api_endpoints** - Published API configurations (Create API page)
8. **system_settings** - System-wide configuration
9. **audit_logs** - Activity tracking

## Sample JSON Configurations

### Connector Configurations

#### AWS S3 Connector
```json
{
  "bucketName": "my-documents-bucket",
  "region": "us-east-1",
  "authType": "access-keys",
  "accessKeyId": "AKIA...",
  "secretAccessKey": "...",
  "pathPrefix": "documents/",
  "filePattern": "*.pdf",
  "encryption": {
    "enabled": true,
    "kmsKeyId": "arn:aws:kms:..."
  }
}
```

#### Google Cloud Storage Connector
```json
{
  "bucketName": "company-docs",
  "serviceAccountJson": "{\"type\": \"service_account\", ...}",
  "projectId": "my-project-123",
  "pathPrefix": "processed/",
  "filePattern": "**/*.{pdf,docx,txt}",
  "location": "us-central1"
}
```

#### Azure Blob Storage Connector
```json
{
  "storageAccountName": "mydocuments",
  "containerName": "files",
  "authType": "connection-string",
  "connectionString": "DefaultEndpointsProtocol=https;...",
  "pathPrefix": "inbox/",
  "enableVersioning": true
}
```

### Parser Profile Configurations

#### Azure Document AI Parser
```json
{
  "endpoint": "https://myresource.cognitiveservices.azure.com/",
  "apiKey": "...",
  "modelId": "prebuilt-document",
  "features": ["tables", "keyValuePairs", "entities"],
  "confidence": 0.8,
  "locale": "en-US",
  "outputFormat": "markdown"
}
```

#### Google Document AI Parser
```json
{
  "projectId": "my-project-123",
  "location": "us",
  "processorId": "abc123...",
  "serviceAccountJson": "{...}",
  "mimeTypes": ["application/pdf", "image/jpeg"],
  "fieldMask": "text,entities,pages.pageNumber"
}
```

#### Tesseract OCR Parser
```json
{
  "language": "eng+fra",
  "oem": 3,
  "psm": 6,
  "dpi": 300,
  "preprocessing": {
    "denoise": true,
    "deskew": true,
    "enhance": true
  },
  "outputFormat": "text"
}
```

### Pipeline Configurations

#### Complete Document Processing Pipeline
```json
{
  "pipeline_name": "Financial Documents Processing",
  "pipeline_id": "pipeline_1727181234567",
  "created_at": "2025-09-24T10:30:00Z",
  "version": "1.0.0",
  "stages": {
    "source": {
      "id": "source-1",
      "type": "source",
      "label": "S3 Source",
      "position": {"x": 100, "y": 100},
      "configuration": {
        "connector_id": "uuid-123...",
        "source_type": "s3",
        "file_filters": ["*.pdf", "*.docx"],
        "batch_size": 10
      }
    },
    "parser": {
      "id": "parser-1",
      "type": "parser",
      "label": "Azure AI Parser",
      "position": {"x": 300, "y": 100},
      "configuration": {
        "parser_profile_id": "uuid-456...",
        "parser_type": "azure-ai",
        "parallel_processing": true,
        "retry_attempts": 3
      }
    },
    "textProcessing": {
      "id": "text-1",
      "type": "textProcessing",
      "label": "Text Cleaning",
      "position": {"x": 500, "y": 100},
      "configuration": {
        "processing_type": "clean_normalize",
        "remove_headers": true,
        "remove_footers": true,
        "normalize_whitespace": true,
        "extract_metadata": true
      }
    },
    "chunk": {
      "id": "chunk-1",
      "type": "chunk",
      "label": "Document Chunking",
      "position": {"x": 700, "y": 100},
      "configuration": {
        "chunk_size": 1000,
        "chunk_overlap": 200,
        "chunk_strategy": "semantic",
        "preserve_structure": true
      }
    },
    "embedding": {
      "id": "embed-1",
      "type": "embedding",
      "label": "Generate Embeddings",
      "position": {"x": 900, "y": 100},
      "configuration": {
        "embedding_model": "text-embedding-3-small",
        "dimensions": 1536,
        "batch_size": 100,
        "normalize": true
      }
    },
    "export": {
      "id": "export-1",
      "type": "export",
      "label": "Vector Database",
      "position": {"x": 1100, "y": 100},
      "configuration": {
        "destination": "pinecone",
        "index_name": "financial-docs",
        "namespace": "documents",
        "metadata_fields": ["title", "author", "created_date"]
      }
    }
  },
  "connections": [
    {"source": "source-1", "target": "parser-1"},
    {"source": "parser-1", "target": "text-1"},
    {"source": "text-1", "target": "chunk-1"},
    {"source": "chunk-1", "target": "embed-1"},
    {"source": "embed-1", "target": "export-1"}
  ],
  "metadata": {
    "total_stages": 6,
    "total_connections": 5,
    "pipeline_type": "document_processing",
    "status": "configured",
    "tags": ["financial", "documents", "ai"],
    "category": "document_processing"
  }
}
```

### API Endpoint Configuration

#### Search API Endpoint
```json
{
  "name": "Financial Search API",
  "endpoint_path": "/api/financial/search",
  "method": "POST",
  "pipeline_id": "uuid-789...",
  "config": {
    "search_type": "semantic",
    "max_results": 20,
    "similarity_threshold": 0.7,
    "include_metadata": true,
    "response_format": "json"
  },
  "request_schema": {
    "type": "object",
    "properties": {
      "query": {"type": "string", "minLength": 1},
      "filters": {"type": "object"},
      "limit": {"type": "integer", "minimum": 1, "maximum": 100}
    },
    "required": ["query"]
  },
  "response_schema": {
    "type": "object",
    "properties": {
      "results": {"type": "array"},
      "total": {"type": "integer"},
      "took": {"type": "integer"}
    }
  }
}
```

## Database Indexes and Performance

### Key Indexes Created:
- **GIN indexes** on all JSONB columns for fast JSON queries
- **B-tree indexes** on frequently queried columns (status, type, dates)
- **Unique indexes** on business keys (names, paths)
- **Composite indexes** for common query patterns

### Performance Considerations:
- Use JSONB instead of JSON for better performance
- Partitioning can be added for large tables (pipeline_executions, documents, audit_logs)
- Consider materialized views for complex reporting queries

## Migration and Deployment

### To deploy this schema:

1. **Create the database:**
   ```sql
   CREATE DATABASE contextcraft;
   ```

2. **Connect and run the schema:**
   ```bash
   psql -d contextcraft -f database_schema.sql
   ```

3. **Verify installation:**
   ```sql
   \dt  -- List tables
   \di  -- List indexes
   SELECT * FROM system_settings;  -- Check sample data
   ```

### Environment Variables Needed:
```env
DATABASE_URL=postgresql://username:password@localhost:5432/contextcraft
DB_HOST=localhost
DB_PORT=5432
DB_NAME=contextcraft
DB_USER=your_username
DB_PASSWORD=your_password
```

## Usage Examples

### Query Examples:

#### Get all active connectors:
```sql
SELECT id, name, type, status, documents_count 
FROM connectors 
WHERE status = 'active';
```

#### Find pipelines using a specific connector:
```sql
SELECT p.name, p.status, c.name as connector_name
FROM pipelines p
JOIN connectors c ON p.source_connector_id = c.id
WHERE c.id = 'your-connector-uuid';
```

#### Get pipeline execution history:
```sql
SELECT pe.execution_id, pe.status, pe.documents_processed, 
       pe.started_at, pe.duration, p.name as pipeline_name
FROM pipeline_executions pe
JOIN pipelines p ON pe.pipeline_id = p.id
ORDER BY pe.started_at DESC
LIMIT 10;
```

#### Search documents by metadata:
```sql
SELECT filename, file_type, metadata
FROM documents
WHERE metadata @> '{"category": "financial"}'
  AND status = 'completed';
```

This schema provides a solid foundation for storing all ContextCraft configurations and data, with excellent performance and scalability characteristics.