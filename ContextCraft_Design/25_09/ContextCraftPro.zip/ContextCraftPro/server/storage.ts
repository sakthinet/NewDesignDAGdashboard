import { 
  type User, 
  type InsertUser, 
  type Connector, 
  type InsertConnector,
  type ParserProfile,
  type InsertParserProfile
} from "@shared/schema";
import { randomUUID } from "crypto";
import { databaseStorage } from "./database";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Connector CRUD methods
  getAllConnectors(): Promise<Connector[]>;
  getConnector(id: string): Promise<Connector | undefined>;
  createConnector(connector: InsertConnector): Promise<Connector>;
  updateConnector(id: string, updates: Partial<InsertConnector>): Promise<Connector | undefined>;
  deleteConnector(id: string): Promise<boolean>;
  
  // Parser Profile CRUD methods
  getAllParserProfiles(): Promise<ParserProfile[]>;
  getParserProfile(id: string): Promise<ParserProfile | undefined>;
  createParserProfile(parserProfile: InsertParserProfile): Promise<ParserProfile>;
  updateParserProfile(id: string, updates: Partial<InsertParserProfile>): Promise<ParserProfile | undefined>;
  deleteParserProfile(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private connectors: Map<string, Connector>;
  private parserProfiles: Map<string, ParserProfile>;

  constructor() {
    this.users = new Map();
    this.connectors = new Map();
    this.parserProfiles = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      email: insertUser.email ?? null,
      fullName: insertUser.fullName ?? null,
      role: 'user',
      isActive: true,
      createdAt: now,
      updatedAt: now,
      lastLogin: null
    };
    this.users.set(id, user);
    return user;
  }

  // Connector CRUD implementations
  async getAllConnectors(): Promise<Connector[]> {
    return Array.from(this.connectors.values());
  }

  async getConnector(id: string): Promise<Connector | undefined> {
    return this.connectors.get(id);
  }

  async createConnector(insertConnector: InsertConnector): Promise<Connector> {
    const id = randomUUID();
    const now = new Date();
    const connector: Connector = {
      id,
      name: insertConnector.name,
      description: insertConnector.description ?? null,
      type: insertConnector.type,
      config: insertConnector.config,
      status: insertConnector.status ?? "inactive",
      lastSync: insertConnector.lastSync ?? null,
      lastSyncStatus: insertConnector.lastSyncStatus ?? null,
      documentsCount: insertConnector.documentsCount ?? 0,
      totalSizeBytes: insertConnector.totalSizeBytes ?? 0,
      errorMessage: insertConnector.errorMessage ?? null,
      createdBy: insertConnector.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.connectors.set(id, connector);
    return connector;
  }

  async updateConnector(id: string, updates: Partial<InsertConnector>): Promise<Connector | undefined> {
    const connector = this.connectors.get(id);
    if (!connector) {
      return undefined;
    }
    const updatedConnector: Connector = {
      ...connector,
      ...updates,
    };
    this.connectors.set(id, updatedConnector);
    return updatedConnector;
  }

  async deleteConnector(id: string): Promise<boolean> {
    return this.connectors.delete(id);
  }

  // Parser Profile CRUD implementations
  async getAllParserProfiles(): Promise<ParserProfile[]> {
    return Array.from(this.parserProfiles.values());
  }

  async getParserProfile(id: string): Promise<ParserProfile | undefined> {
    return this.parserProfiles.get(id);
  }

  async createParserProfile(insertParserProfile: InsertParserProfile): Promise<ParserProfile> {
    const id = randomUUID();
    const now = new Date();
    const parserProfile: ParserProfile = {
      ...insertParserProfile,
      id,
      description: insertParserProfile.description ?? null,
      status: insertParserProfile.status ?? "inactive",
      version: insertParserProfile.version ?? "1.0.0",
      supportedFormats: insertParserProfile.supportedFormats ?? ['pdf', 'docx', 'txt', 'html', 'json'],
      performanceMetrics: insertParserProfile.performanceMetrics ?? null,
      testResults: insertParserProfile.testResults ?? null,
      createdBy: insertParserProfile.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.parserProfiles.set(id, parserProfile);
    return parserProfile;
  }

  async updateParserProfile(id: string, updates: Partial<InsertParserProfile>): Promise<ParserProfile | undefined> {
    const parserProfile = this.parserProfiles.get(id);
    if (!parserProfile) {
      return undefined;
    }
    const updatedParserProfile: ParserProfile = {
      ...parserProfile,
      ...updates,
    };
    this.parserProfiles.set(id, updatedParserProfile);
    return updatedParserProfile;
  }

  async deleteParserProfile(id: string): Promise<boolean> {
    return this.parserProfiles.delete(id);
  }
}

export const storage = process.env.NODE_ENV === 'development' ? new MemStorage() : databaseStorage;

// For now, let's use database storage directly
export { databaseStorage as dbStorage };
