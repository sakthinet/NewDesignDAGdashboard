import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { 
  connectors, 
  parserProfiles, 
  pipelines, 
  apiEndpoints,
  users,
  type Connector, 
  type InsertConnector,
  type ParserProfile,
  type InsertParserProfile,
  type Pipeline,
  type InsertPipeline,
  type ApiEndpoint,
  type InsertApiEndpoint,
  type User,
  type InsertUser
} from '@shared/schema';
import { eq } from 'drizzle-orm';

// Database connection
const connectionString = process.env.DATABASE_URL || 'postgresql://postgres:admin%4012345@localhost:5432/contextcraft';
const client = postgres(connectionString);
export const db = drizzle(client);

export class DatabaseStorage {
  // =============================================================================
  // CONNECTOR CRUD METHODS
  // =============================================================================
  async getAllConnectors(): Promise<Connector[]> {
    return await db.select().from(connectors);
  }

  async getConnector(id: string): Promise<Connector | undefined> {
    const result = await db.select().from(connectors).where(eq(connectors.id, id));
    return result[0];
  }

  async createConnector(connector: InsertConnector): Promise<Connector> {
    const result = await db.insert(connectors).values({
      ...connector,
      updatedAt: new Date()
    }).returning();
    return result[0];
  }

  async updateConnector(id: string, updates: Partial<InsertConnector>): Promise<Connector | undefined> {
    const result = await db.update(connectors)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(connectors.id, id))
      .returning();
    return result[0];
  }

  async deleteConnector(id: string): Promise<boolean> {
    const result = await db.delete(connectors).where(eq(connectors.id, id));
    return result.length > 0;
  }

  async getConnectorsByType(type: string): Promise<Connector[]> {
    return await db.select().from(connectors).where(eq(connectors.type, type));
  }

  // =============================================================================
  // PARSER PROFILE CRUD METHODS
  // =============================================================================
  async getAllParserProfiles(): Promise<ParserProfile[]> {
    return await db.select().from(parserProfiles);
  }

  async getParserProfile(id: string): Promise<ParserProfile | undefined> {
    const result = await db.select().from(parserProfiles).where(eq(parserProfiles.id, id));
    return result[0];
  }

  async createParserProfile(profile: InsertParserProfile): Promise<ParserProfile> {
    const result = await db.insert(parserProfiles).values({
      ...profile,
      updatedAt: new Date()
    }).returning();
    return result[0];
  }

  async updateParserProfile(id: string, updates: Partial<InsertParserProfile>): Promise<ParserProfile | undefined> {
    const result = await db.update(parserProfiles)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(parserProfiles.id, id))
      .returning();
    return result[0];
  }

  async deleteParserProfile(id: string): Promise<boolean> {
    const result = await db.delete(parserProfiles).where(eq(parserProfiles.id, id));
    return result.length > 0;
  }

  // =============================================================================
  // PIPELINE CRUD METHODS
  // =============================================================================
  async getAllPipelines(): Promise<Pipeline[]> {
    return await db.select().from(pipelines);
  }

  async getPipeline(id: string): Promise<Pipeline | undefined> {
    const result = await db.select().from(pipelines).where(eq(pipelines.id, id));
    return result[0];
  }

  async createPipeline(pipeline: InsertPipeline): Promise<Pipeline> {
    const result = await db.insert(pipelines).values({
      ...pipeline,
      updatedAt: new Date()
    }).returning();
    return result[0];
  }

  async updatePipeline(id: string, updates: Partial<InsertPipeline>): Promise<Pipeline | undefined> {
    const result = await db.update(pipelines)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(pipelines.id, id))
      .returning();
    return result[0];
  }

  async deletePipeline(id: string): Promise<boolean> {
    const result = await db.delete(pipelines).where(eq(pipelines.id, id));
    return result.length > 0;
  }

  // =============================================================================
  // API ENDPOINT CRUD METHODS
  // =============================================================================
  async getAllApiEndpoints(): Promise<ApiEndpoint[]> {
    return await db.select().from(apiEndpoints);
  }

  async getApiEndpoint(id: string): Promise<ApiEndpoint | undefined> {
    const result = await db.select().from(apiEndpoints).where(eq(apiEndpoints.id, id));
    return result[0];
  }

  async createApiEndpoint(endpoint: InsertApiEndpoint): Promise<ApiEndpoint> {
    const result = await db.insert(apiEndpoints).values({
      ...endpoint,
      updatedAt: new Date()
    }).returning();
    return result[0];
  }

  async updateApiEndpoint(id: string, updates: Partial<InsertApiEndpoint>): Promise<ApiEndpoint | undefined> {
    const result = await db.update(apiEndpoints)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(apiEndpoints.id, id))
      .returning();
    return result[0];
  }

  async deleteApiEndpoint(id: string): Promise<boolean> {
    const result = await db.delete(apiEndpoints).where(eq(apiEndpoints.id, id));
    return result.length > 0;
  }

  // =============================================================================
  // USER CRUD METHODS
  // =============================================================================
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values({
      ...user,
      updatedAt: new Date()
    }).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async deleteUser(id: string): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return result.length > 0;
  }
}

export const databaseStorage = new DatabaseStorage();