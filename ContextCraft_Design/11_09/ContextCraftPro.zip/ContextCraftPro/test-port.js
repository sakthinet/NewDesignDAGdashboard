// Simple test script to verify dynamic port allocation
import portfinder from "portfinder";

async function testPorts() {
  console.log("Testing dynamic port allocation...");
  
  // Try to get an available port starting from 5000
  const port1 = await portfinder.getPortPromise({ port: 5000 });
  console.log(`First available port: ${port1}`);
  
  // Since 5000 might be in use, try again
  const port2 = await portfinder.getPortPromise({ port: 5000 });
  console.log(`Second check for available port: ${port2}`);
  
  // Try starting from a different base port
  const port3 = await portfinder.getPortPromise({ port: 3000 });
  console.log(`Available port starting from 3000: ${port3}`);
}

testPorts().catch(console.error);
