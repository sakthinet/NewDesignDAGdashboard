import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import {
  LayoutDashboard,
  Database,
  FileText,
  GitBranch,
  Workflow,
  Waypoints,
  PlayCircle,
  Zap,
  User,
  RefreshCw,
  Plus,
  Menu,
  X,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface AppLayoutProps {
  children: React.ReactNode;
}

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Import Connectors", href: "/import-connectors", icon: Database },
  { name: "Parser Profiles", href: "/parsers", icon: FileText },
  { name: "Vector Pipelines", href: "/create-pipeline", icon: GitBranch },
  { name: "Pipeline Designer", href: "/pipeline-designer", icon: Workflow },
  { name: "Create API", href: "/create-api", icon: Waypoints },
  { name: "Test API", href: "/test-api", icon: PlayCircle },
];

export default function AppLayout({ children }: AppLayoutProps) {
  const [location] = useLocation();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside className={cn(
        "bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300",
        sidebarCollapsed ? "w-16" : "w-64"
      )}>
        {/* Logo Section */}
        <div className="p-6 border-b border-sidebar-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-sidebar-primary-foreground" />
            </div>
            {!sidebarCollapsed && (
              <div>
                <h1 className="text-lg font-bold text-sidebar-foreground">Context Craft</h1>
                <p className="text-xs text-sidebar-foreground/60">Enterprise Data Platform</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <TooltipProvider>
          <nav className="flex-1 p-4 space-y-2">
            {navigation.map((item) => {
              const isActive = location === item.href;
              const linkContent = (
                <Link 
                  key={item.name} 
                  href={item.href}
                  className={cn(
                    "nav-item flex items-center w-full text-sm font-medium rounded-lg transition-all duration-200",
                    sidebarCollapsed ? "px-3 py-3 justify-center" : "px-4 py-3",
                    isActive
                      ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                  data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <item.icon className={cn(sidebarCollapsed ? "w-6 h-6" : "w-5 h-5", !sidebarCollapsed && "mr-3")} />
                  {!sidebarCollapsed && item.name}
                </Link>
              );
              
              if (sidebarCollapsed) {
                return (
                  <Tooltip key={item.name}>
                    <TooltipTrigger asChild>
                      {linkContent}
                    </TooltipTrigger>
                    <TooltipContent side="right" className="ml-2">
                      {item.name}
                    </TooltipContent>
                  </Tooltip>
                );
              }
              
              return linkContent;
            })}
          </nav>
        </TooltipProvider>

        {/* User Section */}
        <div className="p-4 border-t border-sidebar-border">
          <div className={cn(
            "flex items-center",
            sidebarCollapsed ? "justify-center" : "space-x-3"
          )}>
            {sidebarCollapsed ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="w-10 h-10 bg-sidebar-accent rounded-full flex items-center justify-center cursor-pointer">
                    <User className="w-5 h-5 text-sidebar-accent-foreground" />
                  </div>
                </TooltipTrigger>
                <TooltipContent side="right" className="ml-2">
                  Account
                </TooltipContent>
              </Tooltip>
            ) : (
              <>
                <div className="w-8 h-8 bg-sidebar-accent rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-sidebar-accent-foreground" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-sidebar-foreground">Admin User</p>
                  <p className="text-xs text-sidebar-foreground/60">admin@contextcraft.com</p>
                </div>
              </>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                aria-expanded={!sidebarCollapsed}
                aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                data-testid="hamburger-menu"
              >
                {sidebarCollapsed ? (
                  <Menu className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </Button>
              <div>
                <h2 className="text-2xl font-bold text-foreground">
                  {navigation.find(item => item.href === location)?.name || "Dashboard"}
                </h2>
                <p className="text-sm text-muted-foreground">
                  Manage your vectorization pipelines and APIs
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <Button variant="outline" size="sm" data-testid="refresh-button">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button size="sm" data-testid="new-pipeline-button">
                <Plus className="w-4 h-4 mr-2" />
                New Pipeline
              </Button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto page-transition">
          {children}
        </div>
      </main>
    </div>
  );
}
