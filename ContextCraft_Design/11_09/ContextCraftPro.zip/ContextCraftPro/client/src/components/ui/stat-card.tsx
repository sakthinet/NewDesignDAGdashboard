import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  description?: string;
  trend?: string;
  icon: LucideIcon;
  className?: string;
}

export function StatCard({
  title,
  value,
  description,
  trend,
  icon: Icon,
  className,
}: StatCardProps) {
  return (
    <Card
      className={cn(
        "relative overflow-hidden border-l-4 border-l-primary transition-all duration-300 hover:shadow-lg hover:-translate-y-1",
        className
      )}
      data-testid="stat-card"
    >
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          {trend && (
            <span className="text-xs text-muted-foreground" data-testid="stat-trend">
              {trend}
            </span>
          )}
        </div>
        <h3 className="text-sm font-medium text-muted-foreground mb-1" data-testid="stat-title">
          {title}
        </h3>
        <p className="text-3xl font-bold text-foreground" data-testid="stat-value">
          {value}
        </p>
        {description && (
          <p className="text-xs text-muted-foreground mt-1" data-testid="stat-description">
            {description}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
