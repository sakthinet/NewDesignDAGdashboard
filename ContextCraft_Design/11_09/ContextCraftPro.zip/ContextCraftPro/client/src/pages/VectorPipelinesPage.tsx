import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tag,
  Database,
  FileType,
  Cpu,
  Settings,
  Eye,
  Save,
  Play,
  GitBranch,
} from "lucide-react";

export default function VectorPipelinesPage() {
  const [formData, setFormData] = useState({
    pipelineName: "",
    sourceType: "",
    uncPath: "",
    documentFormats: [] as string[],
    parserType: "",
    parserCategory: "local",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement pipeline creation
    console.log("Creating pipeline:", formData);
  };

  const handleFormatChange = (format: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        documentFormats: [...formData.documentFormats, format],
      });
    } else {
      setFormData({
        ...formData,
        documentFormats: formData.documentFormats.filter((f) => f !== format),
      });
    }
  };

  const documentFormats = [
    { id: "pdf", label: "PDF" },
    { id: "docx", label: "DOCX" },
    { id: "html", label: "HTML" },
    { id: "txt", label: "TXT" },
    { id: "json", label: "JSON" },
  ];

  const localParsers = [
    { id: "tesseract", label: "Tesseract" },
    { id: "unstructured", label: "Unstructured.io SDK" },
  ];

  const cloudParsers = [
    { id: "azure-ai", label: "Azure Document AI" },
    { id: "google-ai", label: "Google Document AI" },
  ];

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center">
          <GitBranch className="w-8 h-8 mr-3 text-primary" />
          Document Vectorization Pipeline
        </h1>
        <p className="text-muted-foreground">
          Configure your document processing and vectorization workflow
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-6">
            {/* Pipeline Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Tag className="w-5 h-5 mr-2 text-primary" />
                  Pipeline Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="pipelineName">Pipeline Name</Label>
                  <Input
                    id="pipelineName"
                    placeholder="Enter pipeline name"
                    value={formData.pipelineName}
                    onChange={(e) =>
                      setFormData({ ...formData, pipelineName: e.target.value })
                    }
                    data-testid="input-pipeline-name"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Data Source */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="w-5 h-5 mr-2 text-primary" />
                  Data Source
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="sourceType">Source Type</Label>
                  <Select
                    value={formData.sourceType}
                    onValueChange={(value) =>
                      setFormData({ ...formData, sourceType: value })
                    }
                  >
                    <SelectTrigger data-testid="select-source-type">
                      <SelectValue placeholder="Select source type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="aws-s3">AWS S3</SelectItem>
                      <SelectItem value="gcs">Google Cloud Storage</SelectItem>
                      <SelectItem value="azure-blob">Azure Blob Storage</SelectItem>
                      <SelectItem value="file-shares">File Shares & Network Drives</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {formData.sourceType === "file-shares" && (
                  <div className="space-y-2">
                    <Label htmlFor="uncPath">UNC Folder Path</Label>
                    <Input
                      id="uncPath"
                      placeholder="\\server\folder"
                      value={formData.uncPath}
                      onChange={(e) =>
                        setFormData({ ...formData, uncPath: e.target.value })
                      }
                      data-testid="input-unc-path"
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Document Formats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileType className="w-5 h-5 mr-2 text-primary" />
                  Document Formats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {documentFormats.map((format) => (
                    <div key={format.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={format.id}
                        checked={formData.documentFormats.includes(format.id)}
                        onCheckedChange={(checked) =>
                          handleFormatChange(format.id, checked as boolean)
                        }
                        data-testid={`checkbox-format-${format.id}`}
                      />
                      <Label
                        htmlFor={format.id}
                        className="text-sm text-foreground cursor-pointer"
                      >
                        {format.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Parser Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Cpu className="w-5 h-5 mr-2 text-primary" />
                  Document Parser
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <RadioGroup
                  value={formData.parserCategory}
                  onValueChange={(value) =>
                    setFormData({ ...formData, parserCategory: value, parserType: "" })
                  }
                  className="grid grid-cols-2 gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="local" id="local" />
                    <Label htmlFor="local">Local Parsers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="cloud" id="cloud" />
                    <Label htmlFor="cloud">Cloud Parsers</Label>
                  </div>
                </RadioGroup>

                <div className="space-y-4">
                  {formData.parserCategory === "local" && (
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">
                        Local Parsers
                      </h4>
                      <RadioGroup
                        value={formData.parserType}
                        onValueChange={(value) =>
                          setFormData({ ...formData, parserType: value })
                        }
                        className="grid grid-cols-1 md:grid-cols-2 gap-3"
                      >
                        {localParsers.map((parser) => (
                          <div key={parser.id} className="flex items-center space-x-2">
                            <RadioGroupItem value={parser.id} id={parser.id} />
                            <Label htmlFor={parser.id} className="text-sm text-foreground cursor-pointer">
                              {parser.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  )}

                  {formData.parserCategory === "cloud" && (
                    <div>
                      <h4 className="text-sm font-medium text-muted-foreground mb-3">
                        Cloud Parsers
                      </h4>
                      <RadioGroup
                        value={formData.parserType}
                        onValueChange={(value) =>
                          setFormData({ ...formData, parserType: value })
                        }
                        className="grid grid-cols-1 md:grid-cols-2 gap-3"
                      >
                        {cloudParsers.map((parser) => (
                          <div key={parser.id} className="flex items-center space-x-2">
                            <RadioGroupItem value={parser.id} id={parser.id} />
                            <Label htmlFor={parser.id} className="text-sm text-foreground cursor-pointer">
                              {parser.label}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2 text-primary" />
                  Configuration Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Pipeline Name:</span>
                  <span className="text-foreground font-medium">
                    {formData.pipelineName || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Source Type:</span>
                  <span className="text-foreground font-medium">
                    {formData.sourceType || "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Formats:</span>
                  <span className="text-foreground font-medium">
                    {formData.documentFormats.length ? 
                      formData.documentFormats.join(", ").toUpperCase() : 
                      "None selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Parser:</span>
                  <span className="text-foreground font-medium">
                    {formData.parserType ? 
                      [...localParsers, ...cloudParsers].find(p => p.id === formData.parserType)?.label || "Unknown"
                      : "Not selected"}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Play className="w-5 h-5 mr-2 text-primary" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-preview-config"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Preview Configuration
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full justify-start"
                  data-testid="button-save-template"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save as Template
                </Button>
                <Button
                  type="submit"
                  className="w-full justify-start"
                  data-testid="button-create-pipeline"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Create Pipeline
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
