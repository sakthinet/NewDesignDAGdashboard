import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/status-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plus,
  Search,
  Database,
  Cloud,
  HardDrive,
  Settings,
  Trash2,
  Filter,
} from "lucide-react";

export default function ImportConnectorsPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const connectors = [
    {
      id: "1",
      name: "S3 Financial Documents",
      type: "AWS S3",
      status: "active",
      lastSync: "2 hours ago",
      documents: "1,234",
      icon: Cloud,
    },
    {
      id: "2",
      name: "Local File Share",
      type: "File Share",
      status: "active",
      lastSync: "1 day ago",
      documents: "567",
      icon: HardDrive,
    },
    {
      id: "3",
      name: "Azure Document Store",
      type: "Azure Blob",
      status: "error",
      lastSync: "Failed",
      documents: "0",
      icon: Cloud,
    },
  ];

  const connectorTypes = [
    {
      name: "AWS S3",
      description: "Connect to Amazon S3 buckets",
      icon: Cloud,
      href: "/import-connectors/new-s3",
    },
    {
      name: "Google Cloud Storage",
      description: "Connect to GCS buckets",
      icon: Cloud,
      href: "/import-connectors/new-gcs",
    },
    {
      name: "Azure Blob Storage",
      description: "Connect to Azure storage accounts",
      icon: Cloud,
      href: "/import-connectors/new-azure",
    },
    {
      name: "File Shares",
      description: "Connect to network drives and file shares",
      icon: HardDrive,
      href: "/import-connectors/new-fileshare",
    },
  ];

  const filteredConnectors = connectors.filter((connector) =>
    connector.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    connector.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Import Connectors</h1>
          <p className="text-muted-foreground">
            Connect to your data sources and import documents for vectorization
          </p>
        </div>
        <Button data-testid="button-new-connector">
          <Plus className="w-4 h-4 mr-2" />
          New Connector
        </Button>
      </div>

      {/* Quick Create Cards */}
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Create New Connector
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {connectorTypes.map((type) => (
            <Link key={type.name} href={type.href}>
              <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
                <CardHeader className="text-center pb-3">
                  <div className="flex justify-center mb-3">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <type.icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                  <CardTitle className="text-lg">{type.name}</CardTitle>
                  <CardDescription className="text-sm">
                    {type.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Existing Connectors */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2 text-primary" />
                Existing Connectors
              </CardTitle>
              <CardDescription>
                Manage your configured data source connections
              </CardDescription>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search connectors..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                  data-testid="input-search-connectors"
                />
              </div>
              <Button variant="outline" size="sm" data-testid="button-filter">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Sync</TableHead>
                  <TableHead>Documents</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredConnectors.map((connector) => (
                  <TableRow key={connector.id} data-testid={`connector-row-${connector.id}`}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-muted rounded-lg">
                          <connector.icon className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <span className="font-medium">{connector.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>{connector.type}</TableCell>
                    <TableCell>
                      <StatusBadge
                        status={connector.status === "active" ? "success" : "error"}
                      >
                        {connector.status === "active" ? "Active" : "Error"}
                      </StatusBadge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {connector.lastSync}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {connector.documents}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`configure-connector-${connector.id}`}
                        >
                          <Settings className="w-4 h-4 mr-1" />
                          Configure
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          data-testid={`delete-connector-${connector.id}`}
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
