import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/status-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plus,
  Search,
  FileText,
  Cpu,
  Cloud,
  Settings,
  Trash2,
  Filter,
  Copy,
} from "lucide-react";

export default function ParsersPage() {
  const [searchTerm, setSearchTerm] = useState("");

  const parsers = [
    {
      id: "1",
      name: "Financial Document Parser",
      type: "Azure Document AI",
      category: "cloud",
      status: "active",
      documentsProcessed: "2,345",
      lastUsed: "30 minutes ago",
      accuracy: "98.5%",
    },
    {
      id: "2",
      name: "General Text Extractor",
      type: "Tesseract OCR",
      category: "local",
      status: "active",
      documentsProcessed: "1,567",
      lastUsed: "2 hours ago",
      accuracy: "94.2%",
    },
    {
      id: "3",
      name: "Structured Document Parser",
      type: "Unstructured.io SDK",
      category: "local",
      status: "error",
      documentsProcessed: "89",
      lastUsed: "Failed",
      accuracy: "N/A",
    },
  ];

  const parserTypes = [
    {
      name: "Azure Document AI",
      description: "Advanced cloud-based document intelligence",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "99%+",
      href: "/parsers/new?type=azure-ai",
    },
    {
      name: "Google Document AI",
      description: "Google's document processing service",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "98%+",
      href: "/parsers/new?type=google-ai",
    },
    {
      name: "Tesseract OCR",
      description: "Open-source optical character recognition",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "95%",
      href: "/parsers/new?type=tesseract",
    },
    {
      name: "Unstructured.io SDK",
      description: "Advanced document parsing and extraction",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "97%",
      href: "/parsers/new?type=unstructured",
    },
  ];

  const filteredParsers = parsers.filter((parser) =>
    parser.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parser.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Parser Profiles</h1>
          <p className="text-muted-foreground">
            Configure document parsing and text extraction engines
          </p>
        </div>
        <Link href="/parsers/new">
          <Button data-testid="button-new-parser">
            <Plus className="w-4 h-4 mr-2" />
            New Parser
          </Button>
        </Link>
      </div>

      {/* Available Parser Types */}
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Available Parser Types
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {parserTypes.map((type) => (
            <Link key={type.name} href={type.href}>
              <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <type.icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{type.category}</p>
                      <p className="text-xs font-medium text-success">{type.accuracy}</p>
                    </div>
                  </div>
                  <CardTitle className="text-lg leading-tight">{type.name}</CardTitle>
                  <CardDescription className="text-sm">
                    {type.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Configured Parsers */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-primary" />
                Configured Parsers
              </CardTitle>
              <CardDescription>
                Manage your document parsing configurations
              </CardDescription>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search parsers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                  data-testid="input-search-parsers"
                />
              </div>
              <Button variant="outline" size="sm" data-testid="button-filter">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Documents Processed</TableHead>
                  <TableHead>Accuracy</TableHead>
                  <TableHead>Last Used</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredParsers.map((parser) => (
                  <TableRow key={parser.id} data-testid={`parser-row-${parser.id}`}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-muted rounded-lg">
                          {parser.category === "cloud" ? (
                            <Cloud className="w-4 h-4 text-muted-foreground" />
                          ) : (
                            <Cpu className="w-4 h-4 text-muted-foreground" />
                          )}
                        </div>
                        <div>
                          <span className="font-medium">{parser.name}</span>
                          <p className="text-xs text-muted-foreground capitalize">
                            {parser.category} Parser
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{parser.type}</TableCell>
                    <TableCell>
                      <StatusBadge
                        status={parser.status === "active" ? "success" : "error"}
                      >
                        {parser.status === "active" ? "Active" : "Error"}
                      </StatusBadge>
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {parser.documentsProcessed}
                    </TableCell>
                    <TableCell>
                      <span className={parser.accuracy === "N/A" ? "text-muted-foreground" : "text-success font-medium"}>
                        {parser.accuracy}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {parser.lastUsed}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`duplicate-parser-${parser.id}`}
                        >
                          <Copy className="w-4 h-4 mr-1" />
                          Duplicate
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`configure-parser-${parser.id}`}
                        >
                          <Settings className="w-4 h-4 mr-1" />
                          Configure
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          data-testid={`delete-parser-${parser.id}`}
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
