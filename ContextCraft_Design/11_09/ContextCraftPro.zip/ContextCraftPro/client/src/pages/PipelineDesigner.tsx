import { useState, useCallback } from "react";
import ReactFlow, {
  Node,
  Edge,
  addEdge,
  Connection,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  MiniMap,
} from "reactflow";
import "reactflow/dist/style.css";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Database,
  FileText,
  Cpu,
  Send,
  Play,
  Save,
  Download,
  Upload,
  Workflow,
} from "lucide-react";

// Custom node types
const nodeTypes = {
  dataSource: ({ data }: { data: any }) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-card border border-border">
      <div className="flex items-center">
        <Database className="w-4 h-4 mr-2 text-primary" />
        <div className="text-sm font-medium">{data.label}</div>
      </div>
    </div>
  ),
  parser: ({ data }: { data: any }) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-card border border-border">
      <div className="flex items-center">
        <FileText className="w-4 h-4 mr-2 text-chart-2" />
        <div className="text-sm font-medium">{data.label}</div>
      </div>
    </div>
  ),
  processor: ({ data }: { data: any }) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-card border border-border">
      <div className="flex items-center">
        <Cpu className="w-4 h-4 mr-2 text-warning" />
        <div className="text-sm font-medium">{data.label}</div>
      </div>
    </div>
  ),
  output: ({ data }: { data: any }) => (
    <div className="px-4 py-2 shadow-md rounded-md bg-card border border-border">
      <div className="flex items-center">
        <Send className="w-4 h-4 mr-2 text-success" />
        <div className="text-sm font-medium">{data.label}</div>
      </div>
    </div>
  ),
};

const initialNodes: Node[] = [
  {
    id: "1",
    type: "dataSource",
    position: { x: 50, y: 100 },
    data: { label: "S3 Data Source" },
  },
  {
    id: "2",
    type: "parser",
    position: { x: 300, y: 100 },
    data: { label: "Azure Document AI" },
  },
  {
    id: "3",
    type: "processor",
    position: { x: 550, y: 100 },
    data: { label: "Text Chunking" },
  },
  {
    id: "4",
    type: "processor",
    position: { x: 800, y: 100 },
    data: { label: "Vectorization" },
  },
  {
    id: "5",
    type: "output",
    position: { x: 1050, y: 100 },
    data: { label: "Vector Database" },
  },
];

const initialEdges: Edge[] = [
  { id: "e1-2", source: "1", target: "2" },
  { id: "e2-3", source: "2", target: "3" },
  { id: "e3-4", source: "3", target: "4" },
  { id: "e4-5", source: "4", target: "5" },
];

export default function PipelineDesigner() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onNodeClick = useCallback((event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  const availableComponents = [
    {
      category: "Data Sources",
      items: [
        { id: "s3", label: "AWS S3", icon: Database, type: "dataSource" },
        { id: "gcs", label: "Google Cloud Storage", icon: Database, type: "dataSource" },
        { id: "azure-blob", label: "Azure Blob", icon: Database, type: "dataSource" },
        { id: "file-share", label: "File Share", icon: Database, type: "dataSource" },
      ],
    },
    {
      category: "Document Parsers",
      items: [
        { id: "azure-ai", label: "Azure Document AI", icon: FileText, type: "parser" },
        { id: "google-ai", label: "Google Document AI", icon: FileText, type: "parser" },
        { id: "tesseract", label: "Tesseract OCR", icon: FileText, type: "parser" },
        { id: "unstructured", label: "Unstructured.io", icon: FileText, type: "parser" },
      ],
    },
    {
      category: "Processors",
      items: [
        { id: "chunking", label: "Text Chunking", icon: Cpu, type: "processor" },
        { id: "cleaning", label: "Text Cleaning", icon: Cpu, type: "processor" },
        { id: "embedding", label: "Vectorization", icon: Cpu, type: "processor" },
        { id: "filtering", label: "Content Filtering", icon: Cpu, type: "processor" },
      ],
    },
    {
      category: "Outputs",
      items: [
        { id: "vector-db", label: "Vector Database", icon: Send, type: "output" },
        { id: "search-api", label: "Search API", icon: Send, type: "output" },
        { id: "webhook", label: "Webhook", icon: Send, type: "output" },
      ],
    },
  ];

  const handleDragStart = (event: React.DragEvent, nodeType: string, label: string) => {
    event.dataTransfer.setData("application/reactflow", nodeType);
    event.dataTransfer.setData("application/label", label);
    event.dataTransfer.effectAllowed = "move";
  };

  return (
    <div className="p-6 h-[calc(100vh-200px)]">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center">
            <Workflow className="w-8 h-8 mr-3 text-primary" />
            Pipeline Designer
          </h1>
          <p className="text-muted-foreground">
            Design and configure your document processing pipeline
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" data-testid="button-import-pipeline">
            <Upload className="w-4 h-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm" data-testid="button-export-pipeline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" data-testid="button-save-pipeline">
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
          <Button size="sm" data-testid="button-run-pipeline">
            <Play className="w-4 h-4 mr-2" />
            Run Pipeline
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100%-80px)]">
        {/* Component Library */}
        <div className="lg:col-span-1 space-y-4 overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Component Library</CardTitle>
              <CardDescription>
                Drag components to build your pipeline
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {availableComponents.map((category) => (
                <div key={category.category}>
                  <h3 className="text-sm font-semibold text-muted-foreground mb-2">
                    {category.category}
                  </h3>
                  <div className="space-y-2">
                    {category.items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center p-2 bg-muted/30 rounded-lg cursor-move hover:bg-muted/50 transition-colors"
                        draggable
                        onDragStart={(e) => handleDragStart(e, item.type, item.label)}
                        data-testid={`component-${item.id}`}
                      >
                        <item.icon className="w-4 h-4 mr-2 text-muted-foreground" />
                        <span className="text-sm font-medium">{item.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Pipeline Canvas */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-lg">Pipeline Canvas</CardTitle>
              <CardDescription>
                Current pipeline: Financial Document Processing
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0 h-[calc(100%-80px)]">
              <div className="h-full w-full">
                <ReactFlow
                  nodes={nodes}
                  edges={edges}
                  onNodesChange={onNodesChange}
                  onEdgesChange={onEdgesChange}
                  onConnect={onConnect}
                  onNodeClick={onNodeClick}
                  nodeTypes={nodeTypes}
                  fitView
                  attributionPosition="bottom-left"
                >
                  <Controls />
                  <MiniMap />
                  <Background variant="dots" gap={12} size={1} />
                </ReactFlow>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Properties Panel */}
        <div className="lg:col-span-1 space-y-4 overflow-y-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Properties</CardTitle>
              <CardDescription>
                Configure selected component
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedNode ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium text-foreground mb-2">
                      {selectedNode.data.label}
                    </h3>
                    <Badge variant="outline" className="mb-4">
                      {selectedNode.type}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3 text-sm">
                    <div>
                      <label className="block text-muted-foreground mb-1">Node ID</label>
                      <p className="font-mono bg-muted px-2 py-1 rounded">
                        {selectedNode.id}
                      </p>
                    </div>
                    <div>
                      <label className="block text-muted-foreground mb-1">Position</label>
                      <p className="font-mono bg-muted px-2 py-1 rounded">
                        x: {Math.round(selectedNode.position.x)}, y: {Math.round(selectedNode.position.y)}
                      </p>
                    </div>
                  </div>

                  {/* Component-specific configuration would go here */}
                  <div className="pt-4 border-t">
                    <h4 className="font-medium text-foreground mb-2">Configuration</h4>
                    <p className="text-sm text-muted-foreground">
                      Component configuration options will appear here based on the selected node type.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center text-muted-foreground">
                  <Workflow className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Select a component to view its properties</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Pipeline Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Components:</span>
                <Badge variant="outline">{nodes.length}</Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Connections:</span>
                <Badge variant="outline">{edges.length}</Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Status:</span>
                <Badge variant="outline" className="text-warning">
                  Design Mode
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
