import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import AppLayout from "@/components/layout/AppLayout";
import Login from "@/pages/Login";
import DashboardPage from "@/pages/DashboardPage";
import ImportConnectorsPage from "@/pages/ImportConnectorsPage";
import NewS3ConnectorPage from "@/pages/NewS3ConnectorPage";
import ParsersPage from "@/pages/ParsersPage";
import NewParserPage from "@/pages/NewParserPage";
import VectorPipelinesPage from "@/pages/VectorPipelinesPage";
import PipelineDesigner from "@/pages/PipelineDesigner";
import CreateApiPage from "@/pages/CreateApiPage";
import TestApiPage from "@/pages/TestApiPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/" nest>
        <AppLayout>
          <Switch>
            <Route path="/" component={DashboardPage} />
            <Route path="/import-connectors" component={ImportConnectorsPage} />
            <Route path="/import-connectors/new-s3" component={NewS3ConnectorPage} />
            <Route path="/parsers" component={ParsersPage} />
            <Route path="/parsers/new" component={NewParserPage} />
            <Route path="/create-pipeline" component={VectorPipelinesPage} />
            <Route path="/pipeline-designer" component={PipelineDesigner} />
            <Route path="/create-api" component={CreateApiPage} />
            <Route path="/test-api" component={TestApiPage} />
            <Route component={NotFound} />
          </Switch>
        </AppLayout>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="context-craft-theme">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
