# Dynamic Port Configuration

This project now supports dynamic port allocation to handle cases where the default port is already in use.

## How It Works

The server will automatically find an available port starting from the configured base port:

1. **Default behavior**: Tries to use port 5000 (or the port specified in `PORT` environment variable)
2. **Port occupied**: If the default port is busy, it automatically finds the next available port
3. **Feedback**: The console will show which port is being used

## Usage

### Standard Development

```bash
npm run dev
```

This will start the server on port 5000, or the next available port if 5000 is occupied.

### Custom Port

You can specify a different base port using the `PORT` environment variable:

```bash
# Windows PowerShell
$env:PORT=3000; npm run dev

# Windows Command Prompt
set PORT=3000 && npm run dev

# Cross-platform (using cross-env)
npx cross-env PORT=3000 npm run dev
```

### Using the dev:port script

```bash
npm run dev:port --port=3000
```

## Features

- ✅ Automatic port detection and allocation
- ✅ Cross-platform compatibility (Windows, macOS, Linux)
- ✅ Clear console feedback showing which port is being used
- ✅ Graceful fallback when preferred port is occupied
- ✅ Support for custom base ports via environment variables

## Console Output

When the server starts, you'll see messages like:

```
🚀 Server is running on http://localhost:5000
📱 Application ready at http://localhost:5000
```

If port 5000 is occupied:

```
Port 5000 is occupied, using port 5001 instead
🚀 Server is running on http://localhost:5001
📱 Application ready at http://localhost:5001
```
