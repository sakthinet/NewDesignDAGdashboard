import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const connectors = pgTable("connectors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // "s3", "gcs", "azure-blob", "file-share", "google-drive", "file-upload"
  config: jsonb("config").notNull(), // Stores the connector configuration based on type
  status: text("status").notNull().default("inactive"), // "active", "inactive", "error"
  lastSync: text("last_sync"), // Optional: last sync timestamp or status message
  documentsCount: integer("documents_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertConnectorSchema = createInsertSchema(connectors).omit({
  id: true,
  createdAt: true,
});

export type InsertConnector = z.infer<typeof insertConnectorSchema>;
export type Connector = typeof connectors.$inferSelect;

// Data Source Configuration Schemas
export const awsS3ConfigSchema = z.object({
  bucketName: z.string().min(1, "Bucket name is required"),
  region: z.enum(["us-east-1", "us-west-2", "eu-west-1", "eu-central-1", "ap-southeast-1", "ap-northeast-1"]),
  authType: z.enum(["access-keys", "iam-role"]),
  accessKeyId: z.string().optional(),
  secretAccessKey: z.string().optional(),
  pathPrefix: z.string().optional(),
  filePattern: z.string().optional(),
}).refine((data) => {
  if (data.authType === "access-keys") {
    return data.accessKeyId && data.secretAccessKey;
  }
  return true;
}, {
  message: "Access Key ID and Secret Access Key are required when using Access Keys authentication",
  path: ["accessKeyId"],
});

export const googleCloudStorageConfigSchema = z.object({
  bucketName: z.string().min(1, "Bucket name is required"),
  serviceAccountJson: z.string().min(1, "Service Account JSON is required"),
  projectId: z.string().min(1, "Project ID is required"),
  pathPrefix: z.string().optional(),
  filePattern: z.string().optional(),
});

export const azureBlobConfigSchema = z.object({
  storageAccountName: z.string().min(1, "Storage Account Name is required"),
  containerName: z.string().min(1, "Container Name is required"),
  authType: z.enum(["sas-token", "connection-string", "oauth2"]),
  sasToken: z.string().optional(),
  connectionString: z.string().optional(),
  pathPrefix: z.string().optional(),
}).refine((data) => {
  if (data.authType === "sas-token") {
    return !!data.sasToken;
  }
  if (data.authType === "connection-string") {
    return !!data.connectionString;
  }
  return true;
}, {
  message: "Authentication credentials are required for the selected authentication type",
  path: ["sasToken"],
});

export const fileShareConfigSchema = z.object({
  networkPath: z.string().min(1, "Network path is required"),
  username: z.string().optional(),
  password: z.string().optional(),
  domain: z.string().optional(),
});

export const googleDriveConfigSchema = z.object({
  clientId: z.string().min(1, "Client ID is required"),
  clientSecret: z.string().min(1, "Client Secret is required"),
  refreshToken: z.string().min(1, "Refresh Token is required"),
  folderId: z.string().optional(),
  fileTypes: z.array(z.enum(["documents", "spreadsheets", "pdfs", "images"])).min(1, "Select at least one file type"),
});

export const fileUploadConfigSchema = z.object({
  maxFileSize: z.number().min(1).max(100).default(10),
  allowedFileTypes: z.array(z.enum(["PDF", "DOC", "DOCX", "TXT", "CSV", "JSON", "XML"])).min(1, "Select at least one file type"),
  storageLocation: z.enum(["local", "cloud"]),
});

export type AwsS3Config = z.infer<typeof awsS3ConfigSchema>;
export type GoogleCloudStorageConfig = z.infer<typeof googleCloudStorageConfigSchema>;
export type AzureBlobConfig = z.infer<typeof azureBlobConfigSchema>;
export type FileShareConfig = z.infer<typeof fileShareConfigSchema>;
export type GoogleDriveConfig = z.infer<typeof googleDriveConfigSchema>;
export type FileUploadConfig = z.infer<typeof fileUploadConfigSchema>;

export type DataSourceConfig = 
  | { type: "s3"; config: AwsS3Config }
  | { type: "gcs"; config: GoogleCloudStorageConfig }
  | { type: "azure-blob"; config: AzureBlobConfig }
  | { type: "file-share"; config: FileShareConfig }
  | { type: "google-drive"; config: GoogleDriveConfig }
  | { type: "file-upload"; config: FileUploadConfig };

// Parser Profiles table and schemas
export const parserProfiles = pgTable("parser_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // "azure-ai", "google-ai", "tesseract", "paddle", "unstructured"
  config: jsonb("config").notNull(), // Stores the parser configuration based on type
  status: text("status").notNull().default("inactive"), // "active", "inactive", "error"
  createdAt: timestamp("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const insertParserProfileSchema = createInsertSchema(parserProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertParserProfile = z.infer<typeof insertParserProfileSchema>;
export type ParserProfile = typeof parserProfiles.$inferSelect;
