import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/status-badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ParserProfile } from "@shared/schema";
import {
  Plus,
  Search,
  FileText,
  Cpu,
  Cloud,
  Settings,
  Trash2,
  Filter,
  Download,
  Eye,
  TestTube,
  Upload,
  FileImage,
  X,
} from "lucide-react";

export default function ParsersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [selectedParser, setSelectedParser] = useState<ParserProfile | null>(null);
  const [testDocument, setTestDocument] = useState("");
  const [testResults, setTestResults] = useState("");
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch saved parser profiles
  const { data: savedParsers = [], isLoading } = useQuery<ParserProfile[]>({
    queryKey: ["/api/parser-profiles"],
  });

  const handleTestDocument = (parser: ParserProfile) => {
    setSelectedParser(parser);
    setIsTestModalOpen(true);
    setTestDocument("");
    setTestResults("");
    setUploadedFile(null);
    setFilePreview(null);
    setIsAnalyzing(false);
  };

  const handleDeleteParser = async (parserId: string) => {
    try {
      setIsDeleting(parserId);
      await apiRequest("DELETE", `/api/parser-profiles/${parserId}`);

      toast({
        title: "Parser deleted",
        description: "Parser profile has been removed successfully.",
      });

      queryClient.invalidateQueries({ queryKey: ["/api/parser-profiles"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete parser profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(null);
    }
  };

  const handleDownloadConfig = (parser: ParserProfile) => {
    const jsonContent = JSON.stringify(parser, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${parser.name.replace(/\s+/g, '_').toLowerCase()}_config.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Configuration downloaded",
      description: `Parser configuration saved as JSON file.`,
    });
  };

  const handleViewConfig = (parser: ParserProfile) => {
    const jsonContent = JSON.stringify(parser, null, 2);
    navigator.clipboard.writeText(jsonContent);
    toast({
      title: "Configuration copied",
      description: "Parser configuration has been copied to clipboard.",
    });
  };

  const handleFileUpload = (file: File) => {
    setUploadedFile(file);
    
    // Create file preview for images
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setFilePreview(null);
    }
  };

  const runDocumentAnalysis = async () => {
    if (!uploadedFile && !testDocument.trim()) {
      toast({
        title: "No document provided",
        description: "Please upload a document or provide sample text to analyze.",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);
    setTestResults("Analyzing document...");
    
    try {
      // Simulate API call to Tesseract or other parser service
      // TODO: Replace with actual API integration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockResults = {
        parser: selectedParser?.name,
        type: selectedParser?.type,
        filename: uploadedFile?.name || "text-input",
        fileSize: uploadedFile?.size || testDocument.length,
        extractedText: uploadedFile ? "Sample OCR extracted text from uploaded document..." : testDocument,
        confidence: 0.95,
        entities: [
          { type: "PERSON", text: "John Doe", confidence: 0.98 },
          { type: "DATE", text: "2023-01-15", confidence: 0.92 },
          { type: "AMOUNT", text: "$1,250.00", confidence: 0.89 }
        ],
        tables: [
          { rows: 3, columns: 4, confidence: 0.87 }
        ],
        metadata: {
          processingTime: "2.1s",
          timestamp: new Date().toISOString(),
          apiProvider: selectedParser?.type === "tesseract" ? "Tesseract OCR" : "Parser Service"
        }
      };

      setTestResults(JSON.stringify(mockResults, null, 2));
      
      toast({
        title: "Document analyzed",
        description: "Analysis results are ready for review.",
      });
    } catch (error) {
      toast({
        title: "Analysis failed",
        description: "Failed to analyze document. Please try again.",
        variant: "destructive",
      });
      setTestResults("Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const parserTypes = [
    {
      name: "Azure Document AI",
      description: "Advanced cloud-based document intelligence",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "99%+",
      href: "/parsers/new-azure",
    },
    {
      name: "Google Document AI",
      description: "Google's document processing service",
      category: "Cloud Parser",
      icon: Cloud,
      accuracy: "98%+",
      href: "/parsers/new-google",
    },
    {
      name: "Tesseract OCR",
      description: "Open-source optical character recognition",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "95%",
      href: "/parsers/new-tesseract",
    },
    {
      name: "PaddleOCR",
      description: "High-accuracy multilingual OCR engine",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "96%",
      href: "/parsers/new-paddle",
    },
    {
      name: "Unstructured.io SDK",
      description: "Advanced document parsing and extraction",
      category: "Local Parser",
      icon: Cpu,
      accuracy: "97%",
      href: "/parsers/new-unstructured",
    },
  ];

  const filteredParsers = savedParsers.filter((parser) =>
    parser.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    parser.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 space-y-4">
      {/* Header Actions */}
      <div className="flex items-center justify-end">
        <Button data-testid="button-new-parser">
          <Plus className="w-4 h-4 mr-2" />
          New Parser
        </Button>
      </div>

      {/* Create New Parser */}
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Create New Parser
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {parserTypes.map((type) => (
            <Link key={type.name} href={type.href}>
              <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
                <CardHeader className="text-center pb-3">
                  <div className="flex justify-center mb-3">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <type.icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                  <CardTitle className="text-lg">{type.name}</CardTitle>
                  <CardDescription className="text-sm">
                    {type.description}
                  </CardDescription>
                  <div className="text-xs text-muted-foreground mt-2">
                    {type.category} • {type.accuracy}
                  </div>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Saved Parser Profiles */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-primary" />
                Saved Parser Profiles
              </CardTitle>
              <CardDescription>
                Manage your configured document parsing profiles
              </CardDescription>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search parsers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                  data-testid="input-search-parsers"
                />
              </div>
              <Button variant="outline" size="sm" data-testid="button-filter">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Loading parser profiles...</p>
            </div>
          ) : filteredParsers.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">No parser profiles found</p>
              <p className="text-sm text-muted-foreground">Create your first parser profile to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Configuration</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredParsers.map((parser) => (
                    <TableRow key={parser.id} data-testid={`parser-row-${parser.id}`}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-muted rounded-lg">
                            {['azure-ai', 'google-ai'].includes(parser.type) ? (
                              <Cloud className="w-4 h-4 text-muted-foreground" />
                            ) : (
                              <Cpu className="w-4 h-4 text-muted-foreground" />
                            )}
                          </div>
                          <div>
                            <span className="font-medium">{parser.name}</span>
                            <p className="text-xs text-muted-foreground capitalize">
                              {['azure-ai', 'google-ai'].includes(parser.type) ? 'Cloud' : 'Local'} Parser
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="capitalize">{parser.type}</TableCell>
                      <TableCell>
                        <StatusBadge
                          status={parser.status === "active" ? "success" : "warning"}
                        >
                          {parser.status === "active" ? "Active" : "Inactive"}
                        </StatusBadge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(parser.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewConfig(parser)}
                            data-testid={`view-config-${parser.id}`}
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View JSON
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownloadConfig(parser)}
                            data-testid={`download-config-${parser.id}`}
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Download
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTestDocument(parser)}
                            data-testid={`test-parser-${parser.id}`}
                          >
                            <TestTube className="w-4 h-4 mr-1" />
                            Test Document
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteParser(parser.id)}
                            disabled={isDeleting === parser.id}
                            data-testid={`delete-parser-${parser.id}`}
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            {isDeleting === parser.id ? "Deleting..." : "Delete"}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Document Test Modal */}
      <Dialog open={isTestModalOpen} onOpenChange={setIsTestModalOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <FileImage className="w-5 h-5 mr-2 text-primary" />
              Test Document - {selectedParser?.name}
            </DialogTitle>
            <DialogDescription>
              Upload a document or provide sample text to test your parser configuration
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-3">
            {/* Upload Section */}
            <div className="space-y-3">
              <div className="space-y-2">
                <label className="text-sm font-medium">Document Upload</label>
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center hover:border-muted-foreground/50 transition-colors">
                  {uploadedFile ? (
                    <div className="space-y-2">
                      <FileText className="w-8 h-8 mx-auto text-primary" />
                      <p className="font-medium">{uploadedFile.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {(uploadedFile.size / 1024).toFixed(1)} KB
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setUploadedFile(null);
                          setFilePreview(null);
                        }}
                      >
                        <X className="w-4 h-4 mr-2" />
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="w-8 h-8 mx-auto text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        Drop your document here or click to browse
                      </p>
                      <input
                        type="file"
                        accept=".pdf,.png,.jpg,.jpeg,.tiff,.bmp,.gif"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleFileUpload(file);
                        }}
                        className="hidden"
                        id="document-upload"
                        data-testid="input-document-upload"
                      />
                      <label htmlFor="document-upload">
                        <Button variant="outline" className="cursor-pointer" asChild>
                          <span>
                            <Upload className="w-4 h-4 mr-2" />
                            Choose File
                          </span>
                        </Button>
                      </label>
                    </div>
                  )}
                </div>
              </div>

              <div className="text-center text-sm text-muted-foreground">OR</div>

              <div className="space-y-2">
                <label htmlFor="test-document" className="text-sm font-medium">
                  Sample Document Text
                </label>
                <Textarea
                  id="test-document"
                  placeholder="Paste your sample document text here..."
                  value={testDocument}
                  onChange={(e) => setTestDocument(e.target.value)}
                  className="min-h-[150px]"
                  data-testid="textarea-test-document"
                />
              </div>
            </div>

            {/* Preview Section */}
            <div className="space-y-3">
              <div className="space-y-2">
                <label className="text-sm font-medium">Document Preview</label>
                <div className="border rounded-lg p-4 bg-muted/50 min-h-[200px] flex items-center justify-center">
                  {filePreview ? (
                    <img
                      src={filePreview}
                      alt="Document preview"
                      className="max-w-full max-h-[300px] object-contain rounded"
                    />
                  ) : uploadedFile ? (
                    <div className="text-center space-y-2">
                      <FileText className="w-12 h-12 mx-auto text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        {uploadedFile.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Preview not available for this file type
                      </p>
                    </div>
                  ) : testDocument ? (
                    <div className="text-left w-full">
                      <p className="text-sm text-muted-foreground mb-2">Text Preview:</p>
                      <pre className="text-sm whitespace-pre-wrap text-left bg-background p-3 rounded border">
                        {testDocument.substring(0, 200)}
                        {testDocument.length > 200 && '...'}
                      </pre>
                    </div>
                  ) : (
                    <div className="text-center space-y-2">
                      <FileImage className="w-12 h-12 mx-auto text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        Upload a document or enter text to see preview
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Analysis Section */}
          <div className="space-y-3 mt-4">
            <div className="flex items-center space-x-2">
              <Button 
                onClick={runDocumentAnalysis}
                disabled={(!uploadedFile && !testDocument.trim()) || isAnalyzing}
                data-testid="button-run-analysis"
              >
                {isAnalyzing ? (
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-background border-t-transparent" />
                ) : (
                  <TestTube className="w-4 h-4 mr-2" />
                )}
                {isAnalyzing ? "Analyzing..." : "Run Analysis"}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setTestDocument("");
                  setUploadedFile(null);
                  setFilePreview(null);
                  setTestResults("");
                }}
              >
                Clear All
              </Button>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Analysis Results</label>
              <div className="bg-muted rounded-lg p-4 min-h-[250px] font-mono text-sm">
                {testResults ? (
                  <pre className="whitespace-pre-wrap">
                    {testResults}
                  </pre>
                ) : (
                  <p className="text-muted-foreground italic">
                    Analysis results will appear here after running analysis
                  </p>
                )}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsTestModalOpen(false);
                setSelectedParser(null);
                setTestDocument('');
                setTestResults('');
                setUploadedFile(null);
                setFilePreview(null);
                setIsAnalyzing(false);
              }}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}