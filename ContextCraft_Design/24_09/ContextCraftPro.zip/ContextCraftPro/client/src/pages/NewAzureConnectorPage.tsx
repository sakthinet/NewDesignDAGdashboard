import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Cloud, Save } from "lucide-react";
import { Link } from "wouter";
import { DataSourceConfigForm } from "@/components/DataSourceConfigForm";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function NewAzureConnectorPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
  });
  // Create connector mutation
  const createConnectorMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/connectors", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Azure Blob Storage connector created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connectors"] });
      setLocation("/import-connectors");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create connector",
        variant: "destructive",
      });
    },
  });

  const handleSaveConfig = (config: any) => {
    // Validate connector name
    if (!formData.name) {
      toast({
        title: "Validation Error",
        description: "Connector name is required",
        variant: "destructive",
      });
      return;
    }

    // Create the connector with the API call
    createConnectorMutation.mutate({
      name: formData.name,
      description: formData.description,
      type: "azure-blob",
      config: config,
      status: "inactive",
    });
  };

  const handleTestConnection = () => {
    // Test connection will be called from the DataSourceConfigForm
    // The actual implementation would call an API endpoint
    toast({
      title: "Testing Connection",
      description: "This would test the connection with the current configuration",
    });
  };

  return (
    <div className="p-4 space-y-4">
      {/* Back Navigation */}
      <div className="flex items-center space-x-4">
        <Link href="/import-connectors">
          <Button variant="outline" size="sm" data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="p-3 bg-primary/10 rounded-lg">
          <Cloud className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">Azure Blob Storage Connector</h1>
          <p className="text-muted-foreground mt-1">
            Connect to Azure Blob Storage containers to import and process documents
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-4">
            {/* Basic Information */}
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>
                  Provide a name and description for this connector
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Connector Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Company Documents Azure"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                    data-testid="input-connector-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Optional description for this connector"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    data-testid="input-connector-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Azure Configuration */}
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Azure Blob Storage Configuration</CardTitle>
                <CardDescription>
                  Configure your Azure blob storage access and authentication
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <DataSourceConfigForm
                  dataSourceType="azure-blob"
                  onSave={handleSaveConfig}
                  onTestConnection={handleTestConnection}
                />
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary and Actions */}
          <div className="space-y-6">
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Configuration Summary</CardTitle>
                <CardDescription>
                  Review your connector settings
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="text-foreground font-medium">
                    {formData.name || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type:</span>
                  <span className="text-foreground font-medium">
                    Azure Blob Storage
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="text-foreground font-medium">
                    Not saved
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}