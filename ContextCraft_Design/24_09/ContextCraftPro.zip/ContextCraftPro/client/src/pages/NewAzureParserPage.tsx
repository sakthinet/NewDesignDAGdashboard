import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Cloud, Save } from "lucide-react";
import { Link } from "wouter";
import { ParserConfigForm } from "@/components/ParserConfigForm";
import { TestDocumentModal } from "@/components/TestDocumentModal";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function NewAzureParserPage() {
  const [, setLocation] = useLocation();
  const [parserName, setParserName] = useState("");
  const [parserDescription, setParserDescription] = useState("");
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [currentConfig, setCurrentConfig] = useState(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createParserMutation = useMutation({
    mutationFn: async (data: { name: string; type: string; config: any; description?: string }) => {
      return apiRequest("POST", "/api/parser-profiles", data);
    },
    onSuccess: () => {
      toast({
        title: "Parser profile created",
        description: "Azure Document AI parser has been configured successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/parser-profiles"] });
      setLocation("/parsers");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create parser profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveConfig = (config: any) => {
    if (!parserName.trim()) {
      toast({
        title: "Parser name required",
        description: "Please provide a name for this parser profile.",
        variant: "destructive",
      });
      return;
    }

    createParserMutation.mutate({
      name: parserName,
      type: "azure-ai",
      config,
      description: parserDescription,
    });
  };

  const handleTestParser = () => {
    setIsTestModalOpen(true);
  };

  return (
    <div className="p-4 space-y-4">
      {/* Back Navigation */}
      <div className="flex items-center space-x-4">
        <Link href="/parsers">
          <Button variant="outline" size="sm" data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </Link>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-3">
            {/* Basic Information */}
            <Card>
              <CardHeader className="p-4">
                <CardTitle className="flex items-center">
                  <Cloud className="w-5 h-5 mr-2 text-primary" />
                  Azure Document AI Parser
                </CardTitle>
                <CardDescription>
                  Configure Azure Document AI for advanced cloud-based document processing
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="parser-name">Parser Name *</Label>
                  <Input
                    id="parser-name"
                    placeholder="e.g., Financial Documents Azure AI"
                    value={parserName}
                    onChange={(e) => setParserName(e.target.value)}
                    required
                    data-testid="input-parser-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="parser-description">Description</Label>
                  <Textarea
                    id="parser-description"
                    placeholder="Optional description for this parser"
                    value={parserDescription}
                    onChange={(e) => setParserDescription(e.target.value)}
                    data-testid="input-parser-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Parser Configuration */}
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Parser Configuration</CardTitle>
                <CardDescription>
                  Configure your Azure Document AI service settings
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <ParserConfigForm
                  parserType="azure-ai"
                  onSave={handleSaveConfig}
                  onTestParser={handleTestParser}
                />
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary */}
          <div className="space-y-3">
            <Card>
              <CardHeader className="p-4">
                <CardTitle>Configuration Summary</CardTitle>
                <CardDescription>
                  Review your parser settings
                </CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Parser Type:</span>
                  <span className="text-foreground font-medium">Azure Document AI</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="text-foreground font-medium">
                    {parserName || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category:</span>
                  <span className="text-foreground font-medium">Cloud Parser</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Accuracy:</span>
                  <span className="text-foreground font-medium text-success">99%+</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-4">
                <CardTitle>Features</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-2 text-sm">
                <div className="flex items-center text-muted-foreground">
                  ✓ Advanced document intelligence
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Form and table extraction
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Multiple document types
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Cloud-based processing
                </div>
                <div className="flex items-center text-muted-foreground">
                  ✓ Pre-built models available
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Test Document Modal */}
      <TestDocumentModal
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        parserName={parserName || "Azure Document AI Parser"}
        parserType="azure-ai"
        config={currentConfig}
      />
    </div>
  );
}