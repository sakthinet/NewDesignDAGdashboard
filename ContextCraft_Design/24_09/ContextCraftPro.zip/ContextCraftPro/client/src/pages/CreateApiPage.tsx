import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Waypoints,
  Settings,
  Database,
  Shield,
  Zap,
  Save,
  Play,
  Eye,
  Copy,
  Globe,
} from "lucide-react";

export default function CreateApiPage() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    apiName: "",
    description: "",
    endpoint: "",
    vectorDatabase: "",
    searchModel: "",
    maxResults: "10",
    enableAuthentication: true,
    apiKey: "",
    rateLimitEnabled: true,
    rateLimit: "100",
    enableCors: true,
    allowedOrigins: "",
    responseFormat: "json",
    includeMetadata: true,
    enableLogging: true,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement API creation
    console.log("Creating API:", formData);
    setLocation("/");
  };

  const generateApiKey = () => {
    const key = "cc_" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    setFormData({ ...formData, apiKey: key });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-4 space-y-4 md:space-y-5">
      {/* Page Content */}

      <form onSubmit={handleSubmit} className="space-y-4 md:space-y-5">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-5">
          {/* Main Configuration */}
          <div className="lg:col-span-2 space-y-4">
            {/* Basic Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2 text-primary" />
                  Basic Configuration
                </CardTitle>
                <CardDescription>
                  Configure the basic settings for your search API
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="apiName">API Name *</Label>
                    <Input
                      id="apiName"
                      placeholder="e.g., Financial Search API"
                      value={formData.apiName}
                      onChange={(e) =>
                        setFormData({ ...formData, apiName: e.target.value })
                      }
                      required
                      data-testid="input-api-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endpoint">Endpoint Path *</Label>
                    <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-muted-foreground text-sm">
                        /api/
                      </span>
                      <Input
                        id="endpoint"
                        placeholder="search/financial"
                        value={formData.endpoint}
                        onChange={(e) =>
                          setFormData({ ...formData, endpoint: e.target.value })
                        }
                        className="rounded-l-none"
                        required
                        data-testid="input-endpoint"
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Brief description of this API's purpose and functionality"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    data-testid="input-description"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Vector Database Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="w-5 h-5 mr-2 text-primary" />
                  Vector Database Configuration
                </CardTitle>
                <CardDescription>
                  Select the vector database and search parameters
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="vectorDatabase">Vector Database *</Label>
                    <Select
                      value={formData.vectorDatabase}
                      onValueChange={(value) =>
                        setFormData({ ...formData, vectorDatabase: value })
                      }
                    >
                      <SelectTrigger data-testid="select-vector-database">
                        <SelectValue placeholder="Select database" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pinecone">Pinecone</SelectItem>
                        <SelectItem value="weaviate">Weaviate</SelectItem>
                        <SelectItem value="qdrant">Qdrant</SelectItem>
                        <SelectItem value="chroma">Chroma</SelectItem>
                        <SelectItem value="milvus">Milvus</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="searchModel">Search Model *</Label>
                    <Select
                      value={formData.searchModel}
                      onValueChange={(value) =>
                        setFormData({ ...formData, searchModel: value })
                      }
                    >
                      <SelectTrigger data-testid="select-search-model">
                        <SelectValue placeholder="Select model" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="openai-ada-002">OpenAI Ada 002</SelectItem>
                        <SelectItem value="openai-3-small">OpenAI 3 Small</SelectItem>
                        <SelectItem value="openai-3-large">OpenAI 3 Large</SelectItem>
                        <SelectItem value="cohere-embed">Cohere Embed</SelectItem>
                        <SelectItem value="sentence-transformers">Sentence Transformers</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="maxResults">Maximum Results</Label>
                    <Input
                      id="maxResults"
                      type="number"
                      min="1"
                      max="100"
                      value={formData.maxResults}
                      onChange={(e) =>
                        setFormData({ ...formData, maxResults: e.target.value })
                      }
                      data-testid="input-max-results"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="responseFormat">Response Format</Label>
                    <Select
                      value={formData.responseFormat}
                      onValueChange={(value) =>
                        setFormData({ ...formData, responseFormat: value })
                      }
                    >
                      <SelectTrigger data-testid="select-response-format">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="json">JSON</SelectItem>
                        <SelectItem value="xml">XML</SelectItem>
                        <SelectItem value="csv">CSV</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Include Metadata</Label>
                    <p className="text-sm text-muted-foreground">
                      Include document metadata in search results
                    </p>
                  </div>
                  <Switch
                    checked={formData.includeMetadata}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, includeMetadata: checked })
                    }
                    data-testid="switch-include-metadata"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Security & Access Control */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2 text-primary" />
                  Security & Access Control
                </CardTitle>
                <CardDescription>
                  Configure authentication, rate limiting, and CORS
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Authentication</Label>
                    <p className="text-sm text-muted-foreground">
                      Require API key for access
                    </p>
                  </div>
                  <Switch
                    checked={formData.enableAuthentication}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableAuthentication: checked })
                    }
                    data-testid="switch-authentication"
                  />
                </div>

                {formData.enableAuthentication && (
                  <div className="space-y-2">
                    <Label htmlFor="apiKey">API Key</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="apiKey"
                        type="password"
                        placeholder="Generated API key will appear here"
                        value={formData.apiKey}
                        onChange={(e) =>
                          setFormData({ ...formData, apiKey: e.target.value })
                        }
                        data-testid="input-api-key"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={generateApiKey}
                        data-testid="button-generate-key"
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Generate
                      </Button>
                      {formData.apiKey && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => copyToClipboard(formData.apiKey)}
                          data-testid="button-copy-key"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Rate Limiting</Label>
                      <p className="text-sm text-muted-foreground">
                        Limit requests per minute
                      </p>
                    </div>
                    <Switch
                      checked={formData.rateLimitEnabled}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, rateLimitEnabled: checked })
                      }
                      data-testid="switch-rate-limiting"
                    />
                  </div>
                  {formData.rateLimitEnabled && (
                    <div className="space-y-2">
                      <Label htmlFor="rateLimit">Requests per Minute</Label>
                      <Input
                        id="rateLimit"
                        type="number"
                        min="1"
                        max="1000"
                        value={formData.rateLimit}
                        onChange={(e) =>
                          setFormData({ ...formData, rateLimit: e.target.value })
                        }
                        data-testid="input-rate-limit"
                      />
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable CORS</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow cross-origin requests
                    </p>
                  </div>
                  <Switch
                    checked={formData.enableCors}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableCors: checked })
                    }
                    data-testid="switch-cors"
                  />
                </div>

                {formData.enableCors && (
                  <div className="space-y-2">
                    <Label htmlFor="allowedOrigins">Allowed Origins</Label>
                    <Input
                      id="allowedOrigins"
                      placeholder="https://example.com, https://app.example.com"
                      value={formData.allowedOrigins}
                      onChange={(e) =>
                        setFormData({ ...formData, allowedOrigins: e.target.value })
                      }
                      data-testid="input-allowed-origins"
                    />
                    <p className="text-xs text-muted-foreground">
                      Comma-separated list of allowed origins. Leave empty for all origins.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Configuration Summary & Actions */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="w-5 h-5 mr-2 text-primary" />
                  Configuration Summary
                </CardTitle>
                <CardDescription>
                  Review your API settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">API Name:</span>
                  <span className="text-foreground font-medium">
                    {formData.apiName || "Not specified"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Endpoint:</span>
                  <span className="text-foreground font-medium font-mono">
                    /api/{formData.endpoint || "..."}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Database:</span>
                  <span className="text-foreground font-medium">
                    {formData.vectorDatabase || "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Model:</span>
                  <span className="text-foreground font-medium">
                    {formData.searchModel || "Not selected"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Max Results:</span>
                  <span className="text-foreground font-medium">
                    {formData.maxResults}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Authentication:</span>
                  <span className="text-foreground font-medium">
                    {formData.enableAuthentication ? "Enabled" : "Disabled"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rate Limiting:</span>
                  <span className="text-foreground font-medium">
                    {formData.rateLimitEnabled ? `${formData.rateLimit}/min` : "Disabled"}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="w-5 h-5 mr-2 text-primary" />
                  Deployment
                </CardTitle>
                <CardDescription>
                  Deploy and test your API
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Logging</Label>
                    <p className="text-xs text-muted-foreground">
                      Log API requests and responses
                    </p>
                  </div>
                  <Switch
                    checked={formData.enableLogging}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableLogging: checked })
                    }
                    data-testid="switch-logging"
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  data-testid="button-validate-config"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Validate Configuration
                </Button>
                <Button
                  type="submit"
                  className="w-full"
                  disabled={!formData.apiName || !formData.endpoint || !formData.vectorDatabase}
                  data-testid="button-deploy-api"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Deploy API
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => setLocation("/test-api")}
                  data-testid="button-test-api"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Test API
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </form>
    </div>
  );
}
