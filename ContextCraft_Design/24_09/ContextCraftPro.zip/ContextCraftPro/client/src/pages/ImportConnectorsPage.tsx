import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/ui/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus,
  Search,
  Database,
  Cloud,
  HardDrive,
  Settings,
  Trash2,
  Filter,
  FolderOpen,
  Upload,
  AlertCircle,
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Connector } from "@shared/schema";

export default function ImportConnectorsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteConnectorId, setDeleteConnectorId] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch connectors from API
  const { data: connectors = [], isLoading, error } = useQuery<Connector[]>({
    queryKey: ["/api/connectors"],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/connectors/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connectors"] });
      toast({
        title: "Success",
        description: "Connector deleted successfully",
      });
      setDeleteConnectorId(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete connector: ${error.message}`,
        variant: "destructive",
      });
      setDeleteConnectorId(null);
    },
  });

  // Type to display name mapping
  const typeDisplayNames: Record<string, string> = {
    "s3": "AWS S3",
    "gcs": "Google Cloud Storage",
    "azure-blob": "Azure Blob Storage",
    "file-share": "File Shares",
    "google-drive": "Google Drive",
    "file-upload": "File Upload",
  };

  // Type to icon mapping
  const getIconForType = (type: string) => {
    switch (type) {
      case "s3":
      case "gcs":
      case "azure-blob":
        return Cloud;
      case "file-share":
        return HardDrive;
      case "google-drive":
        return FolderOpen;
      case "file-upload":
        return Upload;
      default:
        return Database;
    }
  };

  // All 6 connector types
  const connectorTypes = [
    {
      name: "AWS S3",
      description: "Connect to Amazon S3 buckets",
      icon: Cloud,
      href: "/import-connectors/new-s3",
    },
    {
      name: "Google Cloud Storage",
      description: "Connect to GCS buckets",
      icon: Cloud,
      href: "/import-connectors/new-gcs",
    },
    {
      name: "Azure Blob Storage",
      description: "Connect to Azure storage accounts",
      icon: Cloud,
      href: "/import-connectors/new-azure",
    },
    {
      name: "File Shares",
      description: "Connect to network drives and file shares",
      icon: HardDrive,
      href: "/import-connectors/new-fileshare",
    },
    {
      name: "Google Drive",
      description: "Connect to Google Drive folders",
      icon: FolderOpen,
      href: "/import-connectors/new-google-drive",
    },
    {
      name: "File Upload",
      description: "Upload files directly",
      icon: Upload,
      href: "/import-connectors/new-file-upload",
    },
  ];

  // Filter connectors based on search term
  const filteredConnectors = connectors.filter((connector) =>
    connector.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    typeDisplayNames[connector.type]?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Get status badge type
  const getStatusType = (status: string) => {
    switch (status) {
      case "active":
        return "success";
      case "inactive":
        return "pending";
      case "error":
        return "error";
      default:
        return "warning";
    }
  };

  // Format status for display
  const formatStatus = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const handleDelete = (id: string) => {
    setDeleteConnectorId(id);
  };

  const confirmDelete = () => {
    if (deleteConnectorId) {
      deleteMutation.mutate(deleteConnectorId);
    }
  };

  return (
    <div className="p-4 space-y-4 md:space-y-5">
      {/* Header Actions */}
      <div className="flex items-center justify-end mb-3 md:mb-4">
        <Button data-testid="button-new-connector">
          <Plus className="w-4 h-4 mr-2" />
          New Connector
        </Button>
      </div>

      {/* Quick Create Cards */}
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-3">
          Create New Connector
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {connectorTypes.map((type) => (
            <Link key={type.name} href={type.href}>
              <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
                <CardHeader className="text-center pb-3">
                  <div className="flex justify-center mb-3">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <type.icon className="w-8 h-8 text-primary" />
                    </div>
                  </div>
                  <CardTitle className="text-lg">{type.name}</CardTitle>
                  <CardDescription className="text-sm">
                    {type.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Saved Connectors */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2 text-primary" />
                Saved Connectors
              </CardTitle>
              <CardDescription>
                Manage your configured data source connections
              </CardDescription>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search connectors..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                  data-testid="input-search-connectors"
                />
              </div>
              <Button variant="outline" size="sm" data-testid="button-filter">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            // Loading state
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-12 w-12 rounded-lg" />
                  <Skeleton className="h-4 w-[250px]" />
                  <Skeleton className="h-4 w-[100px]" />
                  <Skeleton className="h-4 w-[100px]" />
                  <Skeleton className="h-4 w-[80px]" />
                  <Skeleton className="h-8 w-[180px]" />
                </div>
              ))}
            </div>
          ) : error ? (
            // Error state
            <div className="flex flex-col items-center justify-center py-12">
              <AlertCircle className="w-12 h-12 text-destructive mb-4" />
              <p className="text-lg font-medium mb-2">Failed to load connectors</p>
              <p className="text-sm text-muted-foreground">
                {error instanceof Error ? error.message : "An unexpected error occurred"}
              </p>
            </div>
          ) : filteredConnectors.length === 0 ? (
            // Empty state
            <div className="flex flex-col items-center justify-center py-12">
              <Database className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-2">
                {searchTerm ? "No connectors found" : "No saved connectors"}
              </p>
              <p className="text-sm text-muted-foreground">
                {searchTerm
                  ? "Try adjusting your search terms"
                  : "Create a new connector to get started"}
              </p>
            </div>
          ) : (
            // Table with data
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Sync</TableHead>
                    <TableHead>Documents</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredConnectors.map((connector) => {
                    const IconComponent = getIconForType(connector.type);
                    return (
                      <TableRow key={connector.id} data-testid={`connector-row-${connector.id}`}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-muted rounded-lg">
                              <IconComponent className="w-4 h-4 text-muted-foreground" />
                            </div>
                            <span className="font-medium">{connector.name}</span>
                          </div>
                        </TableCell>
                        <TableCell data-testid={`type-${connector.id}`}>
                          {typeDisplayNames[connector.type] || connector.type}
                        </TableCell>
                        <TableCell>
                          <StatusBadge
                            status={getStatusType(connector.status)}
                            data-testid={`status-${connector.id}`}
                          >
                            {formatStatus(connector.status)}
                          </StatusBadge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground" data-testid={`last-sync-${connector.id}`}>
                          {connector.lastSync || "Never"}
                        </TableCell>
                        <TableCell className="font-mono text-sm" data-testid={`documents-${connector.id}`}>
                          {connector.documentsCount.toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`configure-connector-${connector.id}`}
                            >
                              <Settings className="w-4 h-4 mr-1" />
                              Configure
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleDelete(connector.id)}
                              disabled={deleteMutation.isPending}
                              data-testid={`delete-connector-${connector.id}`}
                            >
                              <Trash2 className="w-4 h-4 mr-1" />
                              Delete
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog
        open={!!deleteConnectorId}
        onOpenChange={(open) => !open && setDeleteConnectorId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the
              connector and all its associated configuration.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}