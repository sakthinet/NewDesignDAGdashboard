import { StatCard } from "@/components/ui/stat-card";
import { StatusBadge } from "@/components/ui/status-badge";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Waypoints,
  Activity,
  GitBranch,
  FileText,
  Server,
  Search,
  Database,
  Play,
  Settings,
  Trash2,
  Plus,
  Workflow,
  RefreshCw,
  Eye,
  Download,
  Square,
} from "lucide-react";
import { Link } from "wouter";

export default function DashboardPage() {
  // Mock data - in real implementation, this would come from API
  const stats = [
    {
      title: "Active APIs",
      value: "3",
      description: "APIs Deployed",
      trend: "+12% from last week",
      icon: Waypoints,
    },
    {
      title: "API Calls",
      value: "1,247",
      description: "Search requests",
      trend: "+8% from last week",
      icon: Activity,
    },
    {
      title: "Active Pipelines",
      value: "5",
      description: "In Progress",
      trend: "+3 new today",
      icon: GitBranch,
    },
    {
      title: "Documents Vectorized",
      value: "8,932",
      description: "Documents processed",
      trend: "+156 today",
      icon: FileText,
    },
  ];

  const apis = [
    {
      id: "1",
      name: "Financial Search API",
      url: "/api/financial/search",
      status: "active",
      lastUsed: "2 mins ago",
      icon: Search,
    },
    {
      id: "2",
      name: "Document Search API",
      url: "/api/documents/search",
      status: "active",
      lastUsed: "15 mins ago",
      icon: Database,
    },
  ];

  const dagRuns = [
    {
      runId: "dag_run_2024_01_15_001",
      dagId: "DataForGenAI",
      executionDate: "2024-01-15 14:30:25",
      startDate: "2024-01-15 14:30:30",
      duration: "5m 42s",
      status: "success",
    },
    {
      runId: "dag_run_2024_01_15_002",
      dagId: "DataForGenAI",
      executionDate: "2024-01-15 16:15:10",
      startDate: "2024-01-15 16:15:15",
      duration: "2m 18s",
      status: "error",
    },
    {
      runId: "dag_run_2024_01_15_003",
      dagId: "DataForGenAI",
      executionDate: "2024-01-15 18:45:33",
      startDate: "2024-01-15 18:45:38",
      duration: "Running...",
      status: "pending",
    },
  ];

  return (
    <div className="p-4">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4 dashboard-colorful-stats">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      {/* Active APIs Section */}
      <Card className="mb-4">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Server className="w-5 h-5 mr-2 text-primary" />
                Active APIs
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Manage your deployed search endpoints
              </p>
            </div>
            <Link href="/create-api">
              <Button data-testid="create-api-button">
                <Plus className="w-4 h-4 mr-2" />
                Create API
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {apis.map((api) => (
              <div
                key={api.id}
                className="flex items-center justify-between p-4 bg-muted/30 rounded-lg border border-border"
                data-testid={`api-item-${api.id}`}
              >
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <api.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{api.name}</h4>
                    <p className="text-sm text-muted-foreground">{api.url}</p>
                    <div className="flex items-center mt-1">
                      <StatusBadge status="success">Active</StatusBadge>
                      <span className="text-xs text-muted-foreground ml-2">
                        Last used {api.lastUsed}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Link href="/test-api">
                    <Button variant="outline" size="sm" data-testid={`test-api-${api.id}`}>
                      <Play className="w-4 h-4 mr-1" />
                      Test
                    </Button>
                  </Link>
                  <Button variant="outline" size="sm" data-testid={`configure-api-${api.id}`}>
                    <Settings className="w-4 h-4 mr-1" />
                    Configure
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    data-testid={`delete-api-${api.id}`}
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* DAG Runs Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <Workflow className="w-5 h-5 mr-2 text-primary" />
                DAG Runs: DataForGenAI
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Monitor pipeline execution status
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <Select defaultValue="all">
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="error">Failed</SelectItem>
                  <SelectItem value="pending">Running</SelectItem>
                  <SelectItem value="queued">Queued</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" data-testid="refresh-dag-runs">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Run ID</TableHead>
                  <TableHead>DAG ID</TableHead>
                  <TableHead>Execution Date</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dagRuns.map((run) => (
                  <TableRow key={run.runId} data-testid={`dag-run-${run.runId}`}>
                    <TableCell className="font-mono text-sm">{run.runId}</TableCell>
                    <TableCell>{run.dagId}</TableCell>
                    <TableCell>{run.executionDate}</TableCell>
                    <TableCell>{run.startDate}</TableCell>
                    <TableCell className="text-sm">
                      {run.status === "pending" ? (
                        <div className="flex items-center">
                          <LoadingSpinner size="sm" className="mr-2" />
                          {run.duration}
                        </div>
                      ) : (
                        run.duration
                      )}
                    </TableCell>
                    <TableCell>
                      <StatusBadge
                        status={run.status as "success" | "error" | "pending"}
                      >
                        {run.status === "success"
                          ? "Success"
                          : run.status === "error"
                          ? "Failed"
                          : "Running"}
                      </StatusBadge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          data-testid={`view-dag-${run.runId}`}
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                        {run.status === "pending" ? (
                          <Button
                            variant="destructive"
                            size="sm"
                            data-testid={`stop-dag-${run.runId}`}
                          >
                            <Square className="w-3 h-3 mr-1" />
                            Stop
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            data-testid={`logs-dag-${run.runId}`}
                          >
                            <Download className="w-3 h-3 mr-1" />
                            Logs
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
