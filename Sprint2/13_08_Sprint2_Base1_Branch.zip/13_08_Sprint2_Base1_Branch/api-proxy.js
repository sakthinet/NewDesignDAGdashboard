#!/usr/bin/env node

/**
 * Simple API Proxy Server
 * Minimal server to handle API calls when serving static files
 */

import express from 'express';
import { readFileSync } from 'fs';
import { resolve } from 'path';

const app = express();
const PORT = process.env.API_PORT || 3003;

// Load environment configuration
let config = {};
try {
  const envContent = readFileSync(resolve(process.cwd(), '.env'), 'utf8');
  const lines = envContent.split('\n');
  for (const line of lines) {
    const [key, value] = line.split('=');
    if (key && value && !key.startsWith('#')) {
      config[key.trim()] = value.trim();
    }
  }
} catch (error) {
  console.warn('⚠️ Could not load .env file, using defaults');
}

const AIRFLOW_CONFIG = {
  baseUrl: config.VITE_AIRFLOW_URL || 'http://10.73.88.101:8080',
  username: config.NETWORK_AIRFLOW_USERNAME || 'airflow',
  password: config.NETWORK_AIRFLOW_PASSWORD || 'airflow'
};

// Middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});
app.use(express.json());

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    mode: 'api-proxy',
    timestamp: new Date().toISOString(),
    config: {
      airflowUrl: AIRFLOW_CONFIG.baseUrl
    }
  });
});

// Airflow connection test
app.get('/api/test-airflow', async (req, res) => {
  try {
    console.log(`🔧 Testing Airflow connection to: ${AIRFLOW_CONFIG.baseUrl}`);

    // Authenticate with Airflow
    const authResponse = await fetch(`${AIRFLOW_CONFIG.baseUrl}/auth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: AIRFLOW_CONFIG.username,
        password: AIRFLOW_CONFIG.password
      })
    });

    if (!authResponse.ok) {
      const errorText = await authResponse.text();
      throw new Error(`Authentication failed: ${authResponse.status} - ${errorText}`);
    }

    const authData = await authResponse.json();
    const token = authData.access_token;

    if (!token) {
      throw new Error('No access token received from authentication');
    }

    // Test API access
    const versionResponse = await fetch(`${AIRFLOW_CONFIG.baseUrl}/api/v2/version`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!versionResponse.ok) {
      throw new Error(`Version check failed: ${versionResponse.status}`);
    }

    const versionData = await versionResponse.json();

    res.json({
      connected: true,
      status: versionData,
      url: AIRFLOW_CONFIG.baseUrl,
      token: '✓ Valid JWT Token',
      apiVersion: '/api/v2',
      authMethod: 'JWT Bearer Token (Airflow 3.x)'
    });

  } catch (error) {
    console.error('❌ Airflow connection test failed:', error.message);
    res.json({
      connected: false,
      error: error.message,
      url: AIRFLOW_CONFIG.baseUrl
    });
  }
});

// Get deployment configuration
app.get('/api/config/deployment', (req, res) => {
  res.json({
    deploymentMode: config.DEPLOYMENT_MODE || 'network',
    connection: {
      url: AIRFLOW_CONFIG.baseUrl
    },
    paths: {
      incomingCsvDir: config.VITE_AIRFLOW_INCOMING_CSV_DIR || '\\\\10.73.88.101\\data\\incomingcsv',
      processedCsvDir: config.VITE_AIRFLOW_PROCESSED_CSV_DIR || '\\\\10.73.88.101\\data\\processedcsv',
      reportsDir: config.VITE_AIRFLOW_REPORTS_DIR || '\\\\10.73.88.101\\reports',
      dagsDir: config.VITE_AIRFLOW_DAGS_DIR || '\\\\10.73.88.101\\dags',
      dataBaseDir: config.VITE_AIRFLOW_DATA_BASE_DIR || '\\\\10.73.88.101\\data'
    }
  });
});

// Catch-all for other API endpoints
app.all('/api/*', (req, res) => {
  res.status(503).json({
    error: 'Service Unavailable',
    message: 'This API endpoint is not available in proxy mode',
    suggestion: 'Use the full production server for complete functionality'
  });
});

app.listen(PORT, () => {
  console.log(`🚀 API Proxy Server running on http://localhost:${PORT}`);
  console.log(`🔗 Airflow URL: ${AIRFLOW_CONFIG.baseUrl}`);
  console.log(`📡 Available endpoints:`);
  console.log(`   • Health: http://localhost:${PORT}/api/health`);
  console.log(`   • Airflow Test: http://localhost:${PORT}/api/test-airflow`);
  console.log(`   • Config: http://localhost:${PORT}/api/config/deployment`);
  console.log('');
  console.log('💡 To use with static files:');
  console.log('   1. Serve your dist/public files on any web server');
  console.log('   2. Update client to use this proxy for API calls');
  console.log('   3. Or add reverse proxy rules to forward /api/* here');
});
