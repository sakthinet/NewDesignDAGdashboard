# Production Deployment Guide

## Problem Diagnosis
When you build the application and deploy only the static files (from `dist/public`), the Airflow connectivity fails because:

1. **Static Files Only**: The built `dist/public` folder contains only client-side files (HTML, CSS, JS)
2. **Missing API Server**: The API endpoints like `/api/test-airflow` require a Node.js server to handle requests
3. **Direct File Access**: Opening `index.html` directly in a browser bypasses the server entirely

## Solution Options

### Option 1: Full Production Server (Recommended)
Deploy both client files AND the Node.js server for complete functionality.

**Steps:**
1. Run the production build script:
   ```bash
   npm run start:production:network
   ```
   OR use the batch file:
   ```bash
   start-production.bat
   ```

2. This will:
   - Switch to network configuration
   - Build both client and server
   - Start production server on http://localhost:3000
   - Serve static files AND handle API calls

**File Structure After Build:**
```
dist/
  ├── public/          # Client files (HTML, CSS, JS)
  │   ├── index.html
  │   ├── assets/
  │   └── ...
  └── index.js         # Built server with API endpoints
production-server.js   # Production launcher
```

### Option 2: Static Files with API Proxy
If you must serve only static files, you need to configure the client to point to a running API server.

**For Apache/IIS/Static Hosting:**
1. Build the client files:
   ```bash
   npm run build:network
   ```

2. Deploy `dist/public/*` to your web server

3. Set up a reverse proxy to forward `/api/*` requests to a running instance of your Node.js server

4. Or modify the client to use absolute URLs for API calls

### Option 3: Containerized Deployment
Create a Docker container with both client and server.

## Quick Start (Recommended)

1. **For Network Deployment:**
   ```bash
   # Windows
   start-production.bat
   
   # Or manually
   npm run start:production:network
   ```

2. **For Local Development:**
   ```bash
   npm run dev
   ```

3. **Access the Application:**
   - Production: http://localhost:3000
   - Development: http://localhost:3002

## Configuration Files

- **Environment**: `.env` (auto-configured by config-switcher.cjs)
- **Network Config**: Uses `10.73.88.101:8080` for Airflow
- **Local Config**: Uses `localhost:8083` for Airflow

## Troubleshooting

### Airflow Not Loading in Production
**Symptom**: "Airflow Connection Issue" in production but works in development

**Cause**: Static files can't reach API endpoints

**Solution**: Use the production server (`production-server.js`) instead of serving static files directly

### Port Conflicts
**Symptom**: "Port already in use" error

**Solution**: Stop other services or modify the PORT in `production-server.js`

### Environment Variables Not Working
**Symptom**: Application uses wrong Airflow URL

**Solution**: 
1. Run `node config-switcher.cjs network` before building
2. Check `.env` file contains correct `DEPLOYMENT_MODE=network`
3. Rebuild with `npm run build`

## Files Created/Modified

- ✅ `production-server.js` - Production server launcher
- ✅ `start-production.bat` - Easy deployment script  
- ✅ Updated `package.json` with production scripts
- ✅ This deployment guide

## Next Steps

1. Test the production deployment: `start-production.bat`
2. Verify Airflow connectivity works in production
3. Deploy to your target environment using the same pattern
