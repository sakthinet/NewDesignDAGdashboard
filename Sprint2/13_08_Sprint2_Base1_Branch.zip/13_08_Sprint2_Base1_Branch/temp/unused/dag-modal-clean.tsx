import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TaskInstancesLive } from '@/components/task-instances-live';
import {
  X,
  Clock,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  RefreshCw,
  Activity,
  Database,
  GitBranch,
  Calendar,
  User,
  FileText,
  AlertCircle,
  TrendingUp,
  Code,
  Settings,
  Zap,
  ChevronRight,
  ChevronDown
} from 'lucide-react';

interface DAGModalProps {
  isOpen: boolean;
  onClose: () => void;
  dagId: string | null;
  darkMode: boolean;
  airflowApi: any;
}

interface DAGDetails {
  dag: any;
  runs: any[];
  tasks: any[];
}

interface DAGRun {
  dag_run_id: string;
  dag_id: string;
  execution_date: string;
  logical_date?: string;
  start_date: string;
  end_date: string;
  state: 'success' | 'running' | 'failed' | 'queued' | 'scheduled';
  external_trigger: boolean;
  run_type: string;
  conf: any;
}

const getStateColor = (state: string, darkMode: boolean): string => {
  const lightColors = {
    success: 'bg-cyan-100 text-cyan-800 border-cyan-200',
    running: 'bg-blue-100 text-blue-800 border-blue-200',
    failed: 'bg-red-100 text-red-800 border-red-200',
    queued: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    scheduled: 'bg-purple-100 text-purple-800 border-purple-200',
    up_for_retry: 'bg-orange-100 text-orange-800 border-orange-200',
    up_for_reschedule: 'bg-orange-100 text-orange-800 border-orange-200',
    upstream_failed: 'bg-red-50 text-red-600 border-red-200',
    skipped: 'bg-gray-100 text-gray-800 border-gray-200',
    none: 'bg-gray-50 text-gray-600 border-gray-200',
    paused: 'bg-orange-100 text-orange-800 border-orange-200'
  };

  const darkColors = {
    success: 'bg-cyan-900 text-cyan-300 border-cyan-700',
    running: 'bg-blue-900 text-blue-300 border-blue-700',
    failed: 'bg-red-900 text-red-300 border-red-700',
    queued: 'bg-yellow-900 text-yellow-300 border-yellow-700',
    scheduled: 'bg-purple-900 text-purple-300 border-purple-700',
    up_for_retry: 'bg-orange-900 text-orange-300 border-orange-700',
    up_for_reschedule: 'bg-orange-900 text-orange-300 border-orange-700',
    upstream_failed: 'bg-red-800 text-red-300 border-red-700',
    skipped: 'bg-gray-800 text-gray-300 border-gray-600',
    none: 'bg-gray-800 text-gray-400 border-gray-600',
    paused: 'bg-orange-900 text-orange-300 border-orange-700'
  };

  const colors = darkMode ? darkColors : lightColors;
  return colors[state as keyof typeof colors] || colors.none;
};

const getStateIcon = (state: string): JSX.Element => {
  const iconMap: Record<string, JSX.Element> = {
    success: <CheckCircle className="w-4 h-4" />,
    running: <RefreshCw className="w-4 h-4 animate-spin" />,
    failed: <XCircle className="w-4 h-4" />,
    queued: <Clock className="w-4 h-4" />,
    scheduled: <Calendar className="w-4 h-4" />,
    up_for_retry: <RefreshCw className="w-4 h-4" />,
    up_for_reschedule: <Clock className="w-4 h-4" />,
    upstream_failed: <AlertCircle className="w-4 h-4" />,
    skipped: <Play className="w-4 h-4" />,
    none: <Pause className="w-4 h-4" />
  };
  
  return iconMap[state] || iconMap.none;
};

const formatDate = (dateString: string | null): string => {
  if (!dateString) return 'N/A';
  try {
    return new Date(dateString).toLocaleString();
  } catch {
    return 'Invalid Date';
  }
};

const formatDuration = (startDate: string | null, endDate: string | null): string => {
  if (!startDate || !endDate) return 'N/A';
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const durationMs = end.getTime() - start.getTime();
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  } catch {
    return 'N/A';
  }
};

export default function DAGModal({ isOpen, onClose, dagId, darkMode, airflowApi }: DAGModalProps) {
  const [dagDetails, setDagDetails] = useState<DAGDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedRun, setSelectedRun] = useState<any>(null);
  const [showRunLogs, setShowRunLogs] = useState(false);
  const [runLogs, setRunLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const loadingRef = useRef(false);
  const mountedRef = useRef(true);

  // New state for DAG runs and task instances
  const [dagRuns, setDagRuns] = useState<DAGRun[]>([]);
  const [loadingRuns, setLoadingRuns] = useState(false);
  const [selectedRunId, setSelectedRunId] = useState<string | null>(null);
  const [expandedRuns, setExpandedRuns] = useState<Set<string>>(new Set());

  // Dragging state
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [modalPosition, setModalPosition] = useState({ x: 0, y: 0 });
  const modalRef = useRef<HTMLDivElement>(null);

  // Reset mounted ref when component mounts
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  // Drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (modalRef.current) {
      const rect = modalRef.current.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      setIsDragging(true);
    }
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging && modalRef.current) {
      const container = modalRef.current.parentElement;
      if (container) {
        const containerRect = container.getBoundingClientRect();
        const modalRect = modalRef.current.getBoundingClientRect();
        
        const newX = e.clientX - containerRect.left - dragOffset.x;
        const newY = e.clientY - containerRect.top - dragOffset.y;
        
        // Constrain within container bounds
        const maxX = containerRect.width - modalRect.width;
        const maxY = containerRect.height - modalRect.height;
        
        const constrainedX = Math.max(0, Math.min(maxX, newX));
        const constrainedY = Math.max(0, Math.min(maxY, newY));
        
        setModalPosition({ x: constrainedX, y: constrainedY });
      }
    }
  }, [isDragging, dragOffset]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  // Add global mouse event listeners
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  // Load DAG details when modal opens
  useEffect(() => {
    if (!isOpen || !dagId) {
      setDagDetails(null);
      setError(null);
      loadingRef.current = false;
      return;
    }

    // Prevent multiple simultaneous loads
    if (loadingRef.current) {
      console.log('⏭️ Load already in progress, skipping...');
      return;
    }

    const loadDagDetails = async () => {
      if (!mountedRef.current) return;
      
      loadingRef.current = true;
      setLoading(true);
      setError(null);

      try {
        console.log(`🔍 Loading details for DAG: ${dagId}`);
        
        // Add small delay to prevent rapid requests
        await new Promise(resolve => setTimeout(resolve, 100));
        
        if (!mountedRef.current) return;

        // Get DAG details, runs, and tasks in parallel
        const [dagResult, runsResult] = await Promise.allSettled([
          airflowApi.getDag(dagId, true), // Force refresh for modal
          airflowApi.getDagRuns(dagId, 10, 0, true)
        ]);

        if (!mountedRef.current) return;

        let dagData = null;
        let runsData = null;

        // Process DAG result
        if (dagResult.status === 'fulfilled' && dagResult.value) {
          dagData = dagResult.value;
        } else {
          console.error('Failed to load DAG details:', dagResult.status === 'rejected' ? dagResult.reason : 'No data');
        }

        // Process runs result  
        if (runsResult.status === 'fulfilled' && runsResult.value) {
          runsData = runsResult.value.runs || [];
          setDagRuns(runsData);
        } else {
          console.error('Failed to load DAG runs:', runsResult.status === 'rejected' ? runsResult.reason : 'No data');
          setDagRuns([]);
        }

        if (!mountedRef.current) return; // Don't update state if component unmounted

        let dag = null;
        let runs: any[] = [];
        let tasks: any[] = [];

        // Process DAG result
        if (dagResult.status === 'fulfilled' && dagResult.value) {
          dag = dagResult.value.dag;
          tasks = dagResult.value.tasks || [];
        }

        // Process runs result
        if (runsResult.status === 'fulfilled' && runsResult.value) {
          runs = runsResult.value.runs || [];
        }

        if (!dag) {
          throw new Error(`DAG ${dagId} not found or failed to load`);
        }

        if (mountedRef.current) {
          setDagDetails({ dag, runs, tasks });
          setDagRuns(runs); // Store runs separately for easier access
          console.log(`✅ Successfully loaded details for DAG: ${dagId}`);
        }
        
      } catch (err) {
        if (mountedRef.current) {
          console.error(`❌ Failed to load DAG details for ${dagId}:`, err);
          const errorMessage = err instanceof Error ? err.message : 'Failed to load DAG details';
          setError(errorMessage);
        }
      } finally {
        if (mountedRef.current) {
          setLoading(false);
        }
        loadingRef.current = false;
      }
    };

    loadDagDetails();
  }, [isOpen, dagId]); // Only depend on isOpen and dagId

  // Load individual run logs
  const loadRunLogs = async (runId: string) => {
    if (!dagId || !runId) return;
    
    setLoadingLogs(true);
    setRunLogs([]);
    
    try {
      console.log(`🔍 Loading logs for run: ${runId}`);
      
      // Get task instances for this run
      const result = await airflowApi.getTaskInstances(dagId, runId, true);
      
      if (result && result.task_instances) {
        setRunLogs(result.task_instances);
        console.log(`✅ Loaded ${result.task_instances.length} task instances`);
      } else {
        // Create mock logs if no data available
        setRunLogs([
          {
            task_id: 'start_task',
            state: 'success',
            start_date: new Date().toISOString(),
            end_date: new Date().toISOString(),
            duration: 1.2,
            try_number: 1,
            log_url: '#'
          }
        ]);
      }
    } catch (err) {
      console.error('Failed to load run logs:', err);
      // Create fallback logs
      setRunLogs([
        {
          task_id: 'Error loading logs',
          state: 'failed',
          start_date: new Date().toISOString(),
          end_date: new Date().toISOString(),
          duration: 0,
          try_number: 1,
          log_url: '#',
          error: 'Failed to fetch task logs'
        }
      ]);
    } finally {
      setLoadingLogs(false);
    }
  };

  // Handle run expansion toggle
  const toggleRunExpansion = useCallback((runId: string) => {
    setExpandedRuns(prev => {
      const newExpanded = new Set(prev);
      if (newExpanded.has(runId)) {
        newExpanded.delete(runId);
      } else {
        newExpanded.add(runId);
      }
      return newExpanded;
    });
  }, []);

  // Handle run selection for task instances view
  const handleRunSelection = useCallback((runId: string) => {
    setSelectedRunId(runId);
    setActiveTab('task-instances'); // Switch to task instances tab
  }, []);

  // Load DAG runs separately
  const loadDagRuns = useCallback(async (forceRefresh = false) => {
    if (!dagId) return;
    
    setLoadingRuns(true);
    try {
      const result = await airflowApi.getDagRuns(dagId, 20, 0, forceRefresh);
      if (result && result.runs) {
        setDagRuns(result.runs);
      }
    } catch (error) {
      console.error('Failed to load DAG runs:', error);
    } finally {
      setLoadingRuns(false);
    }
  }, [dagId, airflowApi]);

  // Load DAG runs when modal opens
  useEffect(() => {
    if (isOpen && dagId) {
      loadDagRuns(false);
    }
  }, [isOpen, dagId, loadDagRuns]);

  // Handle run click
  const handleRunClick = async (run: any) => {
    setSelectedRun(run);
    setShowRunLogs(true);
    await loadRunLogs(run.dag_run_id);
  };

  // Calculate statistics
  const statistics = useMemo(() => {
    if (!dagDetails?.runs) return null;
    
    const { runs } = dagDetails;
    const total = runs.length;
    const successful = runs.filter(run => run.state === 'success').length;
    const failed = runs.filter(run => run.state === 'failed').length;
    const running = runs.filter(run => run.state === 'running').length;
    const successRate = total > 0 ? Math.round((successful / total) * 100) : 0;
    
    // Calculate average duration
    const completedRuns = runs.filter(run => run.start_date && run.end_date);
    let avgDuration = 0;
    if (completedRuns.length > 0) {
      const totalDuration = completedRuns.reduce((sum, run) => {
        const start = new Date(run.start_date);
        const end = new Date(run.end_date);
        return sum + (end.getTime() - start.getTime());
      }, 0);
      avgDuration = Math.round(totalDuration / completedRuns.length / 1000); // in seconds
    }
    
    return { total, successful, failed, running, successRate, avgDuration };
  }, [dagDetails]);

  const handleClose = () => {
    setActiveTab('overview'); // Reset to overview tab
    setDagDetails(null); // Clear previous data
    setError(null); // Clear any errors
    setLoading(false); // Stop loading
    setShowRunLogs(false); // Close logs modal
    setSelectedRun(null); // Clear selected run
    loadingRef.current = false; // Reset loading ref
    
    // Reset modal position
    setModalPosition({ x: 0, y: 0 });
    setIsDragging(false);
    
    onClose();
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  if (!isOpen || !dagId) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none"
      onClick={handleBackdropClick}
    >
      <div 
        ref={modalRef}
        className={`relative w-full max-w-4xl max-h-[80vh] overflow-y-auto rounded-lg shadow-2xl border-2 pointer-events-auto ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-300'
        } ${isDragging ? 'cursor-grabbing' : ''}`}
        style={{
          left: modalPosition.x,
          top: modalPosition.y,
          transform: modalPosition.x === 0 && modalPosition.y === 0 ? 'none' : 'none',
          marginLeft: modalPosition.x === 0 && modalPosition.y === 0 ? 0 : 0,
        }}
      >
        {/* Header */}
        <div 
          className={`flex items-center justify-between p-6 border-b cursor-grab select-none ${
            isDragging ? 'cursor-grabbing' : 'cursor-grab'
          } ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}
          onMouseDown={handleMouseDown}
        >
          <div className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            <div className="flex items-center space-x-2">
              <Database className="w-5 h-5" />
              <span>DAG Details: {dagId}</span>
              <div className="flex items-center space-x-1 ml-4 opacity-50">
                <div className="w-1 h-1 bg-current rounded-full"></div>
                <div className="w-1 h-1 bg-current rounded-full"></div>
                <div className="w-1 h-1 bg-current rounded-full"></div>
                <div className="w-1 h-1 bg-current rounded-full"></div>
              </div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClose}
            onMouseDown={(e) => e.stopPropagation()} // Prevent drag when clicking close
            className={`${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6">
          {loading && (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
                <p className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  Loading DAG details...
                </p>
              </div>
            </div>
          )}

          {error && (
            <Card className="border-red-200 bg-red-50 mb-6">
              <CardContent className="p-4">
                <div className="flex items-start">
                  <XCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-red-800">Error Loading DAG Details</h3>
                    <p className="mt-1 text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {dagDetails && !loading && (
            <div className="space-y-4">
              {/* Custom Tab Navigation */}
              <div className={`flex space-x-1 p-1 rounded-lg overflow-x-auto ${
                darkMode ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                {[
                  { id: 'overview', label: 'Overview', icon: GitBranch },
                  { id: 'dag-runs', label: `Runs (${dagRuns.length})`, icon: Calendar },
                  { id: 'task-instances', label: selectedRunId ? `Task Instances (${selectedRunId})` : 'Task Instances', icon: Activity }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1 whitespace-nowrap ${
                      activeTab === tab.id
                        ? (darkMode ? 'bg-blue-500 text-white' : 'bg-blue-400 text-white')
                        : (darkMode ? 'text-gray-300 hover:text-white hover:bg-gray-600' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200')
                    }`}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* DAG Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <GitBranch className="w-4 h-4 mr-2" />
                        Workflow Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Status
                        </label>
                        <div className="mt-1">
                          <Badge className={getStateColor(
                            dagDetails.dag.is_paused ? 'paused' : dagDetails.dag.is_active ? 'success' : 'none',
                            darkMode
                          )}>
                            {dagDetails.dag.is_paused ? 'Paused' : dagDetails.dag.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                      </div>
                      
                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Description
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.description || 'No description available'}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Schedule Interval
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.schedule_interval_display || 'None'}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Max Active Runs
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.max_active_runs || 0}
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  {/* File Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FileText className="w-4 h-4 mr-2" />
                        File Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          File Location
                        </label>
                        <p className={`mt-1 text-xs font-mono break-all ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.fileloc || 'N/A'}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Last Parsed
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {formatDate(dagDetails.dag.last_parsed_time)}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Owners
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.owners?.join(', ') || 'None'}
                        </p>
                      </div>

                      {dagDetails.dag.tag_names && dagDetails.dag.tag_names.length > 0 && (
                        <div>
                          <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Tags
                          </label>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {dagDetails.dag.tag_names.map((tag: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* DAG Runs Tab - Enhanced with Airflow API data */}
              {activeTab === 'dag-runs' && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Calendar className="w-5 h-5 mr-2" />
                          DAG Runs ({dagRuns.length})
                        </div>
                        <Button
                          onClick={() => loadDagRuns(true)}
                          disabled={loadingRuns}
                          size="sm"
                          variant="outline"
                        >
                          {loadingRuns ? (
                            <RefreshCw className="w-4 h-4 animate-spin" />
                          ) : (
                            <RefreshCw className="w-4 h-4" />
                          )}
                          Refresh
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {loadingRuns ? (
                        <div className="flex items-center justify-center py-8">
                          <RefreshCw className="w-6 h-6 animate-spin mr-2" />
                          Loading DAG runs...
                        </div>
                      ) : dagRuns.length > 0 ? (
                        <div className="space-y-2">
                          {dagRuns.map((run) => (
                            <div
                              key={run.dag_run_id}
                              className={`border rounded-lg p-3 ${
                                darkMode ? 'border-gray-600 hover:bg-gray-700' : 'border-gray-200 hover:bg-gray-50'
                              } transition-colors cursor-pointer`}
                              onClick={() => handleRunSelection(run.dag_run_id)}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                  <div className="flex items-center">
                                    {getStateIcon(run.state)}
                                    <Badge className={`ml-2 ${getStateColor(run.state, darkMode)}`}>
                                      {run.state}
                                    </Badge>
                                  </div>
                                  <div>
                                    <div className="font-medium">{run.dag_run_id}</div>
                                    <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                      {formatDate(run.execution_date)}
                                    </div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                    Duration: {formatDuration(run.start_date, run.end_date)}
                                  </div>
                                  <div className={`text-xs ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>
                                    Started: {formatDate(run.start_date)}
                                  </div>
                                </div>
                              </div>
                              
                              {expandedRuns.has(run.dag_run_id) && (
                                <div className="mt-3 pt-3 border-t">
                                  <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div>
                                      <span className="font-medium">Run Type:</span> {run.run_type}
                                    </div>
                                    <div>
                                      <span className="font-medium">External Trigger:</span> {run.external_trigger ? 'Yes' : 'No'}
                                    </div>
                                    {run.conf && Object.keys(run.conf).length > 0 && (
                                      <div className="col-span-2">
                                        <span className="font-medium">Configuration:</span>
                                        <pre className="mt-1 text-xs bg-gray-100 p-2 rounded overflow-x-auto">
                                          {JSON.stringify(run.conf, null, 2)}
                                        </pre>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                          <p className={`${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            No DAG runs found
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Task Instances Tab - Live task instances for selected run */}
              {activeTab === 'task-instances' && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Activity className="w-5 h-5 mr-2" />
                          Task Instances
                          {selectedRunId && (
                            <span className="ml-2 text-sm font-normal text-gray-500">
                              for run: {selectedRunId}
                            </span>
                          )}
                        </div>
                        {selectedRunId && (
                          <Button
                            onClick={() => setSelectedRunId(null)}
                            size="sm"
                            variant="outline"
                          >
                            Clear Selection
                          </Button>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {!selectedRunId ? (
                        <div className="text-center py-8">
                          <Activity className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                          <p className={`${darkMode ? 'text-gray-400' : 'text-gray-500'} mb-4`}>
                            Select a Workflow run to view its task instances
                          </p>
                          <Button
                            onClick={() => setActiveTab('dag-runs')}
                            variant="outline"
                            size="sm"
                          >
                            Go to DAG Runs
                          </Button>
                        </div>
                      ) : (
                        <div className="border rounded-lg">
                          <TaskInstancesLive
                            dagId={dagId!}
                            runId={selectedRunId}
                            autoRefresh={true}
                            refreshInterval={15000}
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
