import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  ArrowRight, 
  Database, 
  FileText, 
  Save,
  Loader2,
  Settings,
  CheckCircle,
  AlertCircle,
  Play,
  RefreshCw,
  X,
  Edit3,
  Plus,
  Trash2,
  FolderOpen,
  BugPlay
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useWorkflow } from "@/contexts/WorkflowContext";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { apiRequest } from "@/lib/queryClient";
import { JsonDebugDialog } from "./json-debug-dialog";
import { useClientConfig } from "@/hooks/use-client-config";

// API request function has been moved to @/lib/queryClient

// Types for the schema configuration
export interface SchemaConfiguration {
  applicationName: string;
  defaultSchemaName: string;
  locale: string;
  schemaName: string;
}

export interface JsonDataItem {
  id: string;
  tableName: string;
  columnName: string;
  dataType: string;
  recordCount: number;
  fileName: string;
  isNullable: boolean;
  description: string;
}

interface EditableSchemaGeneratorProps {
  uploadedFiles: any[];
  onNext: () => void;
  onPrev: () => void;
  onFinalize: () => void;
}

const DATA_TYPE_OPTIONS = [
  'VARCHAR(50)',
  'VARCHAR(100)',
  'VARCHAR(255)',
  'TEXT',
  'INT',
  'BIGINT',
  'DECIMAL(10,2)',
  'DATE',
  'DATETIME',
  'TIMESTAMP',
  'BOOLEAN',
  'FLOAT',
  'DOUBLE'
];

export function EditableSchemaGenerator({ 
  uploadedFiles, 
  onNext, 
  onPrev, 
  onFinalize 
}: EditableSchemaGeneratorProps) {
  
  const workflow = useWorkflow();
  const { toast } = useToast();
  const { triggerDag, loading: dagLoading, error: dagError } = useAirflowApi();

  // Use schema configuration from workflow context or fallback to defaults
  const schemaConfig = workflow.schemaConfig || {
    applicationName: 'InfoArchive_Application',
    defaultSchemaName: 'DefaultSchema',
    locale: 'en-US',
    schemaName: 'DataArchival_Schema'
  };

  // Get client configuration for deployment mode-aware paths
  const clientConfig = useClientConfig();

  // JSON file management state
  const [availableJsonFiles, setAvailableJsonFiles] = useState<string[]>([]);
  const [selectedJsonFile, setSelectedJsonFile] = useState<string>('');
  const [jsonData, setJsonData] = useState<JsonDataItem[]>([]);
  const [editingTable, setEditingTable] = useState<string>('');
  const [tableNames, setTableNames] = useState<string[]>([]);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [actualNetworkPaths, setActualNetworkPaths] = useState<{
    incomingCsv: string;
    reports: string;
    processedCsv: string;
    dataBase: string;
  }>({
    incomingCsv: clientConfig.incomingCsvDir,
    reports: clientConfig.reportsDir,
    processedCsv: clientConfig.processedCsvDir,
    dataBase: clientConfig.dataBaseDir
  });
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [isLoadingJson, setIsLoadingJson] = useState(false);
  const [isSavingJson, setIsSavingJson] = useState(false);
  const [isFinalizing, setIsFinalizing] = useState(false);
  const [isDebugDialogOpen, setIsDebugDialogOpen] = useState(false);

  // Load available JSON files from the network path
  const loadAvailableJsonFiles = async () => {
    setIsLoadingFiles(true);
    try {
      console.log('🔍 Loading available JSON files from network path...');
      const response = await apiRequest('GET', '/api/list-incoming-json');
      
      if (response.ok) {
        const result = await response.json();
        if (result.success && result.files) {
          // Store the full API response for file type information
          localStorage.setItem('lastApiResponse', JSON.stringify(result));
          
          // Extract file names from the file objects
          const fileNames = result.files.map((file: any) => file.name);
          
          // Sort files: prioritize schema type files, then by name
          const sortedFiles = fileNames.sort((a: string, b: string) => {
            const fileA = result.files.find((f: any) => f.name === a);
            const fileB = result.files.find((f: any) => f.name === b);
            
            // Prioritize schema files over data files
            if (fileA?.fileType === 'schema' && fileB?.fileType !== 'schema') return -1;
            if (fileB?.fileType === 'schema' && fileA?.fileType !== 'schema') return 1;
            
            // Within same type, sort alphabetically (with preference for newer)
            return b.localeCompare(a);
          });
          
          setAvailableJsonFiles(sortedFiles || []);
          
          // Store search results for debugging and path display
          if (result.searchResults) {
            setSearchResults(result.searchResults);
            
            // Extract actual paths being used from client config
            const networkPaths = {
              incomingCsv: clientConfig.incomingCsvDir,
              reports: clientConfig.reportsDir,
              processedCsv: clientConfig.processedCsvDir,
              dataBase: clientConfig.dataBaseDir
            };
            
            // Check if target paths are accessible (network or local depending on deployment mode)
            const targetAccessible = result.searchResults.some((sr: any) => 
              sr.path.includes(clientConfig.incomingCsvDir.replace(/\\\\/g, '\\')) && sr.success && sr.files.length > 0
            );
            
            if (!targetAccessible) {
              // Update with local fallback paths being used
              const localPaths = result.searchResults.filter((sr: any) => 
                sr.success && sr.files.length > 0
              );
              if (localPaths.length > 0) {
                console.log('⚠️ Network paths not accessible, using local paths:', localPaths);
              }
            }
            
            setActualNetworkPaths(networkPaths);
          }
          
          // Auto-select the latest JSON file
          if (sortedFiles.length > 0) {
            setSelectedJsonFile(sortedFiles[0]);
            await loadJsonFile(sortedFiles[0]);
          }
          
          toast({
            title: "✅ Files Loaded",
            description: `Found ${sortedFiles.length} JSON files${result.searchResults ? ` from ${result.totalDirectoriesSearched} directories` : ''}`,
            duration: 100,
          });
        } else {
          console.error('Failed to load JSON files:', result.message);
          toast({
            title: "⚠️ Load Failed",
            description: result.message || "Failed to load JSON files",
            variant: "destructive",
          });
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error loading JSON files:', error);
      toast({
        title: "❌ Error Loading Files",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsLoadingFiles(false);
    }
  };

  // Load a specific JSON file
  const loadJsonFile = async (fileName: string) => {
    if (!fileName) return;
    
    setIsLoadingJson(true);
    try {
      console.log(`📄 Loading JSON file: ${fileName}`);
      
      // Add timestamp to prevent caching
      const response = await apiRequest('POST', '/api/load-json-file-from-network', {
        fileName: fileName,
        timestamp: Date.now() // Add timestamp to prevent caching
      });
      
      console.log(`Response status: ${response.status} ${response.statusText}`);
      
      let responseText;
      try {
        // First get response as text to inspect for potential issues
        responseText = await response.text();
        console.log(`Response preview: ${responseText.substring(0, 200)}`);
      } catch (textError) {
        console.error('Error getting response text:', textError);
        throw new Error('Failed to read response data');
      }
      
      // Check if response is valid JSON
      let result;
      try {
        result = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Failed to parse response as JSON:', parseError);
        console.error('Response text:', responseText.substring(0, 500));
        throw new Error(`Response is not valid JSON: ${parseError instanceof Error ? parseError.message : 'Parse error'}`);
      }
      
      if (response.ok) {
        if (result.success) {
          console.log('Success loading JSON file:', result);
          
          // Extract the JSON data from the response
          const loadedData = result.jsonData;
          
          if (!loadedData) {
            throw new Error('No data received from server');
          }
          
          // Process the loaded data
          console.log('Processing loaded JSON data:', loadedData);
          
          // Extract schema data based on the structure
          let processedData = [];
          
          if (Array.isArray(loadedData)) {
            // Already in the right format
            processedData = loadedData;
          } else if (loadedData.tables && Array.isArray(loadedData.tables)) {
            // Extract tables array
            processedData = loadedData.tables;
          } else if (typeof loadedData === 'object') {
            // Convert object to array format if needed
            processedData = [loadedData];
          }
          
          setJsonData(processedData);
          
          // Extract unique table names from the data
          const uniqueTables = Array.from(
            new Set(
              processedData.map((item: any) => 
                item.tableName || item.table_name || item.name || 'DefaultTable'
              )
            )
          ) as string[];
          
          console.log('Extracted table names:', uniqueTables);
          setTableNames(uniqueTables);
          
          // Set the first table as editing table
          if (uniqueTables.length > 0) {
            setEditingTable(uniqueTables[0]);
          }
          
          toast({
            title: "✅ JSON File Loaded",
            description: `Successfully loaded ${fileName} with ${processedData.length} records`,
            duration: 100,
          });
        } else {
          console.error('Server reported error:', result.message);
          throw new Error(result.message || 'Failed to load JSON file');
        }
      } else {
        console.error(`HTTP Error ${response.status}: ${response.statusText}`);
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error loading JSON file:', error);
      toast({
        title: "❌ Error Loading JSON",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
        duration: 100,
      });
    } finally {
      setIsLoadingJson(false);
    }
  };

  // Save the JSON file
  const saveJsonFile = async () => {
    if (!selectedJsonFile || jsonData.length === 0) {
      toast({
        title: "⚠️ Nothing to Save",
        description: "No data to save or no file selected",
        variant: "destructive",
      });
      return;
    }
    
    setIsSavingJson(true);
    try {
      console.log(`💾 Saving JSON file: ${selectedJsonFile}`);
      const response = await apiRequest('POST', '/api/save-json-file-to-network', {
        fileName: selectedJsonFile,
        data: jsonData
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          toast({
            title: "✅ JSON File Saved",
            description: `Successfully saved ${selectedJsonFile}`,
            duration: 100,
          });
        } else {
          throw new Error(result.message || 'Failed to save JSON file');
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error saving JSON file:', error);
      toast({
        title: "❌ Error Saving JSON",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsSavingJson(false);
    }
  };

  // Update table data
  const updateTableData = (recordId: string, fieldName: string, newValue: any) => {
    const updatedData = jsonData.map(item => {
      if (item.id === recordId) {
        return {
          ...item,
          [fieldName]: newValue
        };
      }
      return item;
    });
    setJsonData(updatedData);
  };

  // Add new record to table
  const addNewRecord = (tableName: string) => {
    const newRecord: JsonDataItem = {
      id: `new_${Date.now()}`,
      tableName: tableName,
      columnName: 'New Column',
      dataType: 'VARCHAR(255)',
      recordCount: 0,
      fileName: selectedJsonFile,
      isNullable: false,
      description: ''
    };
    setJsonData([...jsonData, newRecord]);
  };

  // Remove record from table
  const removeRecord = (recordId: string) => {
    setJsonData(jsonData.filter(item => item.id !== recordId));
  };

  // Filter data by table name
  const getTableData = (tableName: string) => {
    return jsonData.filter(item => item.tableName === tableName);
  };

  // Load JSON files when component mounts
  useEffect(() => {
    loadAvailableJsonFiles();
  }, []);

  // Show warning if no schema configuration from workflow
  useEffect(() => {
    if (!workflow.schemaConfig) {
      toast({
        title: "⚠️ Schema Configuration Missing",
        description: "Using default schema configuration. Please ensure Step 2 was completed properly.",
        variant: "destructive",
        duration: 100,
      });
    } else {
      // Mark schema step as completed
      workflow.markStepCompleted('configure');
    }
  }, [workflow.schemaConfig]);

  // Handle DAG Run 2 (Finalize and Generate IA Schema)
  const handleDAGRun2 = async () => {
    if (jsonData.length === 0) {
      toast({
        title: "⚠️ No Data to Process",
        description: "Please load and edit JSON data before finalizing",
        variant: "destructive",
      });
      return;
    }

    setIsFinalizing(true);
    try {
      // Save the current JSON data before triggering DAG
      await saveJsonFile();
      
      // Prepare the DAG configuration with schema configuration and table data
      const dagConfig = {
        "Application Name": schemaConfig.applicationName,
        "Default Schema Name": schemaConfig.defaultSchemaName,
        "Locale": schemaConfig.locale,
        "Schema Name": schemaConfig.schemaName,
        "JSON File": selectedJsonFile,
        "Table Data": jsonData.map((row: JsonDataItem) => ({
          tableName: row.tableName || "DefaultTable",
          columnName: row.columnName || "DefaultColumn",
          dataType: row.dataType || "VARCHAR(255)",
          recordCount: row.recordCount || 0,
          fileName: row.fileName || selectedJsonFile,
          isNullable: row.isNullable || false,
          description: row.description || ""
        }))
      };

      console.log('=== DAG RUN 2 TRIGGERED ===');
      console.log('DAG Configuration:', dagConfig);

      // Trigger the specific DAG: IA_XML_Generator
      const result = await triggerDag('IA_XML_Generator', dagConfig);

      if (result && result.success) {
        toast({
          title: "🚀 IA XML Generator Triggered Successfully!",
          description: `DAG 'IA_XML_Generator' executed successfully. DAG Run ID: ${result.dag_run?.dag_run_id || 'Unknown'}`,
          duration: 100,
        });
        
        // Mark this step as completed and navigate to next step
        workflow.markStepCompleted('editable-schema');
        onFinalize();
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
    } catch (error) {
      console.error('Error in DAG Run 2:', error);
      toast({
        title: "❌ DAG Run 2 Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsFinalizing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Validate and Finalize Schema</h2>
          <p className="text-sm text-gray-600 mt-1">
            Configure schema settings and validate table information for InfoArchive processing from JSON files
          </p>
        </div>
        <div className="flex flex-col items-end space-y-1 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>Step 2.1 of 5</span>
          </div>
          <div className="text-xs">Validate & Finalize Schema</div>
        </div>
      </div>

      {/* Schema Configuration (Non-Editable) */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Schema Configuration
            <Badge variant="outline" className="ml-2 text-red-600 border-red-200">
              Non-Editable
            </Badge>
            {workflow.schemaConfig && (
              <Badge variant="outline" className="ml-2 text-green-600 border-green-200">
                From Step 2
              </Badge>
            )}
          </CardTitle>
          {workflow.schemaConfig && (
            <p className="text-sm text-green-600 mt-1">
              ✅ Schema configuration successfully loaded from Generate IA Table Schema
            </p>
          )}
          {!workflow.schemaConfig && (
            <p className="text-sm text-orange-600 mt-1">
              ⚠️ Using default schema configuration. Please ensure Step 2 was completed properly.
            </p>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-medium text-gray-700">
                Application Name
              </Label>
              <Input
                value={schemaConfig.applicationName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                Default Schema Name
              </Label>
              <Input
                value={schemaConfig.defaultSchemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                Locale
              </Label>
              <Input
                value={schemaConfig.locale}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                Schema Name
              </Label>
              <Input
                value={schemaConfig.schemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* JSON File Management */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <FolderOpen className="mr-2 h-5 w-5" />
            JSON File Management
            <Badge variant="outline" className="ml-2 text-blue-600 border-blue-200">
              Editable
            </Badge>
          </CardTitle>
          <div className="text-sm text-gray-600 mt-1 space-y-1">
            <p>Loading JSON files from target directory</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Network Status Indicator */}
          {searchResults.length > 0 && (
            <div className="bg-white border border-gray-200 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Target Directory Status</span>
                <Badge variant={searchResults.some(sr => sr.path.includes(clientConfig.incomingCsvDir.replace(/\\\\/g, '\\')) && sr.success) ? "default" : "secondary"}>
                  {searchResults.some(sr => sr.path.includes(clientConfig.incomingCsvDir.replace(/\\\\/g, '\\')) && sr.success) ? "Target Connected" : "Fallback Mode"}
                </Badge>
              </div>
              <div className="text-xs">
                {searchResults.filter(sr => sr.success && sr.files.length > 0).map((sr, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${sr.isNetworkPath ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                    <span className="font-mono text-gray-600 truncate">{sr.path}</span>
                    <span className="text-blue-600">({sr.files.length} files)</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="flex items-center space-x-4">
            <Button
              onClick={loadAvailableJsonFiles}
              disabled={isLoadingFiles}
              className="flex items-center space-x-2"
            >
              {isLoadingFiles ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              <span>Refresh Files</span>
            </Button>
            
            <Select value={selectedJsonFile} onValueChange={setSelectedJsonFile}>
              <SelectTrigger className="w-80">
                <SelectValue placeholder="Select JSON file" />
              </SelectTrigger>
              <SelectContent>
                {availableJsonFiles.map((file, index) => {
                  const fileInfo = searchResults.length > 0 ? 
                    searchResults.flatMap(sr => sr.files).find(f => f === file) : null;
                  const fileData = searchResults.length > 0 ?
                    (() => {
                      // Find the file data from the API response
                      const allFiles = [...(JSON.parse(localStorage.getItem('lastApiResponse') || '{"files":[]}').files || [])];
                      return allFiles.find((f: any) => f.name === file);
                    })() : null;
                  
                  return (
                    <SelectItem key={index} value={file}>
                      <div className="flex items-center gap-2">
                        <Database className="h-4 w-4" />
                        <span>{file}</span>
                        {index === 0 && <Badge variant="outline" className="text-xs">Latest</Badge>}
                        {fileData?.fileType === 'schema' && 
                          <Badge variant="default" className="text-xs bg-blue-500">Schema</Badge>}
                        {fileData?.fileType === 'data_array' && 
                          <Badge variant="outline" className="text-xs text-green-600">Data Array</Badge>}
                        {fileData?.fileType === 'data_object' && 
                          <Badge variant="outline" className="text-xs text-orange-600">Data Object</Badge>}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            
            <Button
              onClick={() => loadJsonFile(selectedJsonFile)}
              disabled={!selectedJsonFile || isLoadingJson}
              variant="outline"
            >
              {isLoadingJson ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <FileText className="h-4 w-4 mr-2" />
              )}
              Load JSON
            </Button>
            
            <Button
              onClick={() => setIsDebugDialogOpen(true)}
              variant="outline"
              className="ml-1"
              title="Debug JSON file loading issues"
            >
              <BugPlay className="h-4 w-4 mr-2" />
              Debug
            </Button>
            
            <Button
              onClick={saveJsonFile}
              disabled={!selectedJsonFile || jsonData.length === 0 || isSavingJson}
              variant="outline"
            >
              {isSavingJson ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Save JSON
            </Button>
          </div>

          {availableJsonFiles.length === 0 && !isLoadingFiles && (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p>No JSON files found in the network path</p>
              <p className="text-sm">Click "Refresh Files" to check for new files</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Table Selector */}
      {tableNames.length > 0 && (
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
              <Database className="mr-2 h-5 w-5" />
              Table Selection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <Label className="text-sm font-medium text-gray-700">
                Select Table to Edit:
              </Label>
              <Select value={editingTable} onValueChange={setEditingTable}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Select table" />
                </SelectTrigger>
                <SelectContent>
                  {tableNames.map((tableName, index) => (
                    <SelectItem key={index} value={tableName}>
                      {tableName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Badge variant="outline" className="text-blue-600 border-blue-200">
                {getTableData(editingTable).length} records
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Table Data Editor */}
      {editingTable && (
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
              <Edit3 className="mr-2 h-5 w-5" />
              Table Data Editor: {editingTable}
              <Button
                onClick={() => addNewRecord(editingTable)}
                size="sm"
                className="ml-auto"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Record
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Column Name</TableHead>
                    <TableHead>Data Type</TableHead>
                    <TableHead>Record Count</TableHead>
                    <TableHead>Nullable</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {getTableData(editingTable).map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>
                        <Input
                          value={record.columnName}
                          onChange={(e) => updateTableData(record.id, 'columnName', e.target.value)}
                          className="h-8"
                        />
                      </TableCell>
                      <TableCell>
                        <Select
                          value={record.dataType}
                          onValueChange={(value) => updateTableData(record.id, 'dataType', value)}
                        >
                          <SelectTrigger className="h-8 data-type-cell" style={{ backgroundColor: 'white', color: '#1f2937', borderColor: '#d1d5db' }}>
                            <SelectValue style={{ backgroundColor: 'white', color: '#1f2937' }} />
                          </SelectTrigger>
                          <SelectContent className="bg-white border border-gray-300 shadow-lg">
                            {DATA_TYPE_OPTIONS.map((type) => (
                              <SelectItem key={type} value={type} className="bg-white hover:bg-gray-100 text-gray-900 cursor-pointer">
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={record.recordCount}
                          onChange={(e) => updateTableData(record.id, 'recordCount', parseInt(e.target.value) || 0)}
                          className="h-8"
                        />
                      </TableCell>
                      <TableCell>
                        <Select
                          value={record.isNullable ? 'true' : 'false'}
                          onValueChange={(value) => updateTableData(record.id, 'isNullable', value === 'true')}
                        >
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="false">No</SelectItem>
                            <SelectItem value="true">Yes</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input
                          value={record.description}
                          onChange={(e) => updateTableData(record.id, 'description', e.target.value)}
                          className="h-8"
                          placeholder="Description..."
                        />
                      </TableCell>
                      <TableCell>
                        <Button
                          onClick={() => removeRecord(record.id)}
                          size="sm"
                          variant="destructive"
                          className="remove-button bg-red-600 hover:bg-red-700 text-white border-red-600"
                          style={{ backgroundColor: '#dc2626', color: 'white', borderColor: '#dc2626' }}
                        >
                          <Trash2 className="h-4 w-4" style={{ color: 'white' }} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-6">
        <Button
          onClick={onPrev}
          variant="outline"
          disabled={isFinalizing}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Step 2</span>
        </Button>

        <div className="flex space-x-3">
          <Button
            onClick={handleDAGRun2}
            disabled={isFinalizing || jsonData.length === 0}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
          >
            {isFinalizing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            <span>Generate IA Schema</span>
          </Button>
        </div>
      </div>
      
      {/* JSON Debug Dialog */}
      <JsonDebugDialog 
        open={isDebugDialogOpen} 
        onOpenChange={setIsDebugDialogOpen} 
      />
    </div>
  );
}
