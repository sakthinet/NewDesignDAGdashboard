# InfoArchive (IA) Script Metrics Implementation

## Overview

This implementation provides a dedicated metrics dashboard for monitoring InfoArchive script execution data stored in your local/network PostgreSQL database. This system is separate from the previous Airflow-focused metrics and is specifically designed to track IA script performance.

## Key Features

### ✅ **Replaced Airflow Metrics with IA Script Metrics**
- Removed DAG run metrics logic
- Implemented IA script execution tracking
- Updated dashboard to show script-specific data
- Changed API endpoints from `/api/metrics/*` to `/api/ia-metrics/*`

### ✅ **Database Configuration**
- Uses existing local/network PostgreSQL configuration
- **Network Mode**: `10.73.88.101:5432` (database: `RND`)
- **Local Mode**: `localhost:5432` (database: `RND`)
- Automatic deployment mode detection

### ✅ **New Dashboard Tabs**
1. **Overview**: High-level IA script execution statistics
2. **Executions**: Detailed table of recent script executions
3. **Scripts**: Performance analysis by script name

## Database Schema

### Uses Existing Table: `dag_run_metrics`

The IA metrics dashboard uses your existing `dag_run_metrics` table with smart column mapping:

```sql
-- Your existing table structure (no changes needed)
public.dag_run_metrics:
- id -> id
- dag_id -> script_name (mapped)
- run_id -> execution_id (mapped) 
- execution_date -> execution_date
- records_processed -> files_processed (mapped)
- records_failed -> files_failed (mapped)
```

**✅ No table creation needed** - Uses your existing PostgreSQL table structure

### Column Mapping Logic:
- **Script Name**: `dag_id` field represents your IA script names
- **Execution ID**: `run_id` field represents unique execution instances
- **Files Processed**: `records_processed` field represents files successfully processed
- **Files Failed**: `records_failed` field represents files that failed
- **Status**: Calculated based on success/failure ratio
- **Total Records**: Calculated as `records_processed + records_failed`

## API Endpoints

### **IA Metrics API** (`/api/ia-metrics/*`)

#### 1. Test Connection
```http
GET /api/ia-metrics/test-connection
```
**Response:**
```json
{
  "success": true,
  "config": {
    "host": "10.73.88.101",
    "database": "RND",
    "deploymentMode": "network"
  },
  "timing": {
    "duration": 150
  }
}
```

#### 2. Get IA Executions
```http
GET /api/ia-metrics/executions
```
**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "script_name": "customer_data_ingest",        // mapped from dag_id
      "execution_id": "exec_001_1234567890",       // mapped from run_id
      "execution_date": "2025-01-30T10:30:00Z",
      "status": "success",                          // calculated from records_processed/failed
      "files_processed": 150,                      // mapped from records_processed
      "files_failed": 2,                           // mapped from records_failed
      "total_records": 152,                        // calculated sum
      "execution_time_ms": 0,                      // placeholder (not in existing table)
      "error_message": null                        // calculated based on failures
    }
  ],
  "summary": {
    "totalExecutions": 25,
    "totalFilesProcessed": 1250,
    "totalFilesFailed": 15,
    "successRate": "92.00%",
    "avgExecutionTime": 52000,
    "avgFilesPerExecution": 50
  },
  "scriptSummary": [
    {
      "scriptName": "customer_data_ingest",
      "totalExecutions": 8,
      "totalFilesProcessed": 456,
      "totalFilesFailed": 5,
      "avgExecutionTime": 45000,
      "successRate": "87.50%",
      "lastExecution": "2025-01-30T10:30:00Z"
    }
  ]
}
```

#### 3. Get Configuration
```http
GET /api/ia-metrics/config
```

## Frontend Implementation

### **Updated Component**: `metrics-dashboard-enhanced.tsx`

#### **Key Changes:**
1. **Data Types**: Replaced Airflow types with IA-specific interfaces
2. **API Calls**: Changed to `/api/ia-metrics/executions`
3. **Dashboard Tabs**: Overview, Executions, Scripts (removed Trends)
4. **Metrics Display**: Files processed, execution time, script performance

#### **New Features:**
- **Status Tracking**: success, failed, running, pending
- **Execution Time**: Formatted display (ms, seconds, minutes)
- **Script Performance**: Per-script analytics and comparison
- **File Processing**: Track files processed vs failed
- **Error Handling**: Display error messages for failed executions

## Configuration

### **Environment Variables** (already configured)
```bash
# Network PostgreSQL
NETWORK_POSTGRES_HOST=10.73.88.101
NETWORK_POSTGRES_DATABASE=RND
NETWORK_POSTGRES_USER=postgres
NETWORK_POSTGRES_PASSWORD=postgres

# Local PostgreSQL
LOCAL_POSTGRES_HOST=localhost
LOCAL_POSTGRES_DATABASE=RND
LOCAL_POSTGRES_USER=postgres
LOCAL_POSTGRES_PASSWORD=admin@12345
```

### **Deployment Mode**
Set in `.env`:
```bash
DEPLOYMENT_MODE=network  # or 'local'
```

## Usage Instructions

### 1. **No Database Setup Required**
✅ **Uses your existing `dag_run_metrics` table** - No additional setup needed!

### 2. **Access Dashboard**
1. Navigate to: `http://localhost:3002` (local) or `http://10.73.90.19:3002` (network)
2. Go to: **Management Console → Metrics**
3. Test database connection
4. View IA script execution data (mapped from existing DAG data)

### 3. **Data Population**
Your existing data in `dag_run_metrics` will appear as IA script metrics:
- `dag_id` shows as script names
- `run_id` shows as execution IDs  
- `records_processed` shows as files processed
- `records_failed` shows as files failed

## Data Integration

### **From Your Existing Data**
The dashboard automatically reads from your existing `dag_run_metrics` table:
- Each row represents an IA script execution
- `dag_id` is interpreted as the script name
- `run_id` is interpreted as the execution instance
- `records_processed/failed` are shown as files processed/failed

### **Future Data Updates**
Continue using your existing data insertion process for `dag_run_metrics`:
```sql
INSERT INTO public.dag_run_metrics (
    dag_id,           -- Your IA script name
    run_id,           -- Unique execution identifier  
    execution_date,   -- When the script ran
    records_processed, -- Files successfully processed
    records_failed    -- Files that failed processing
) VALUES (
    'customer_data_ingest',
    'exec_' || extract(epoch from now()),
    NOW(),
    150,
    2
);
```

## Key Differences from Previous Implementation

| Aspect | Old (Airflow) | New (IA Scripts) |
|--------|---------------|------------------|
| **API Endpoints** | `/api/metrics/*` | `/api/ia-metrics/*` |
| **Table** | `dag_run_metrics` | `dag_run_metrics` (same table, different interpretation) |
| **Focus** | DAG runs, records | Script executions, files |
| **Status** | Success/failure rate | success/failed/running/pending (calculated) |
| **Metrics** | Records processed/failed | Files processed/failed (same data, different labels) |
| **Dashboard Tabs** | Overview/Details/Trends | Overview/Executions/Scripts |
| **Data Source** | Direct table read | Smart column mapping from same table |

## Performance Features

### **Auto-Refresh**
- Dashboard updates every 2 minutes
- Connection status monitoring
- Real-time status updates

### **Pagination & Sorting**
- 25 records per page
- Sortable columns
- Responsive table design

### **Charts & Visualizations**
- Execution status distribution (pie chart)
- Script performance comparison (bar chart)
- Files processed vs execution time
- Script-specific analytics

## Troubleshooting

### **Common Issues**

#### 1. **Table Not Found**
```
Error: relation "public.ia_script_executions" does not exist
```
**Solution**: Run the table creation script from `database/ia_script_executions_table.sql`

#### 2. **Connection Failed**
**Check**: Database connectivity, credentials, deployment mode

#### 3. **No Data Displayed**
**Verify**: Table exists, has data, user permissions

### **Helpful Commands**
```sql
-- Check if existing table has data
SELECT COUNT(*) FROM public.dag_run_metrics;

-- View recent executions (as IA metrics)
SELECT 
    dag_id as script_name,
    run_id as execution_id,
    execution_date,
    records_processed as files_processed,
    records_failed as files_failed
FROM public.dag_run_metrics 
ORDER BY execution_date DESC LIMIT 10;

-- Check script performance
SELECT 
    dag_id as script_name,
    COUNT(*) as total_executions,
    SUM(records_processed) as total_files_processed,
    SUM(records_failed) as total_files_failed,
    AVG(records_processed) as avg_files_per_execution
FROM public.dag_run_metrics 
GROUP BY dag_id
ORDER BY total_files_processed DESC;
```

## Next Steps

1. **✅ No database setup required** - Uses your existing `dag_run_metrics` table
2. **Test the connection** via the dashboard at `/api/ia-metrics/test-connection`
3. **View your existing data** as IA script metrics with smart column mapping
4. **Continue using your current process** - New data in `dag_run_metrics` will automatically appear
5. **Customize labels** if needed for your specific IA script requirements

---

*This IA-focused metrics system provides a new view of your existing data in `dag_run_metrics`, interpreting it as InfoArchive script execution metrics without requiring any database changes.*
