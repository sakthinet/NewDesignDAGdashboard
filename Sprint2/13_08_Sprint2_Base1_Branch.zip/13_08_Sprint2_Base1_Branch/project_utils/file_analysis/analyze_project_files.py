#!/usr/bin/env python3
"""
Project File Analysis Script
Analyzes all used/referenced files in the InfoArchive project and generates an Excel report
"""

import os
import json
import re
import pandas as pd
from pathlib import Path
from typing import Dict, List, Set, Tuple
import ast

# Project configuration
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
INCLUDE_FOLDERS = ["client", "server", "shared", "project_utils"]
ROOT_FILES = [
    "package.json", "vite.config.ts", "tsconfig.json", "tailwind.config.ts",
    "drizzle.config.ts", "postcss.config.js", "components.json", 
    "config-switcher.cjs", "validate-implementation.cjs"
]

# File extensions to analyze
EXTENSIONS = {
    '.ts', '.tsx', '.js', '.jsx', '.json', '.css', '.md', '.html', '.cjs'
}

class ProjectAnalyzer:
    def __init__(self):
        self.files_data = []
        self.import_relationships = {}
        self.component_counts = {}
        
    def count_lines(self, file_path: str) -> Tuple[int, int, int]:
        """Count total lines, code lines, and comment lines"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
            
            total_lines = len(lines)
            code_lines = 0
            comment_lines = 0
            
            for line in lines:
                stripped = line.strip()
                if not stripped:
                    continue
                elif stripped.startswith('//') or stripped.startswith('/*') or stripped.startswith('*') or stripped.startswith('#'):
                    comment_lines += 1
                else:
                    code_lines += 1
                    
            return total_lines, code_lines, comment_lines
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            return 0, 0, 0

    def extract_imports_exports(self, file_path: str) -> Tuple[List[str], List[str]]:
        """Extract import and export statements from a file"""
        imports = []
        exports = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Extract imports (various patterns)
            import_patterns = [
                r'import\s+.*?from\s+["\']([^"\']+)["\']',
                r'import\s+["\']([^"\']+)["\']',
                r'require\s*\(\s*["\']([^"\']+)["\']\s*\)',
                r'from\s+["\']([^"\']+)["\']\s+import',
            ]
            
            for pattern in import_patterns:
                matches = re.findall(pattern, content, re.MULTILINE)
                imports.extend(matches)
            
            # Extract exports
            export_patterns = [
                r'export\s+.*?from\s+["\']([^"\']+)["\']',
                r'module\.exports\s*=',
                r'export\s+(?:default\s+)?(?:class|function|const|let|var)\s+(\w+)',
                r'export\s*\{\s*([^}]+)\s*\}',
            ]
            
            for pattern in export_patterns:
                matches = re.findall(pattern, content, re.MULTILINE)
                if matches:
                    exports.extend([m for m in matches if isinstance(m, str)])
                    
        except Exception as e:
            print(f"Error extracting imports/exports from {file_path}: {e}")
            
        return imports, exports

    def get_file_category(self, file_path: str) -> str:
        """Categorize file based on its location and type"""
        rel_path = os.path.relpath(file_path, PROJECT_ROOT)
        
        if rel_path in ROOT_FILES:
            return "Root Configuration"
        elif rel_path.startswith("client\\src\\components\\ui"):
            return "UI Components"
        elif rel_path.startswith("client\\src\\components"):
            return "Business Components"
        elif rel_path.startswith("client\\src\\hooks"):
            return "React Hooks"
        elif rel_path.startswith("client\\src\\contexts"):
            return "React Contexts"
        elif rel_path.startswith("client\\src\\pages"):
            return "Pages"
        elif rel_path.startswith("client\\src\\lib"):
            return "Client Libraries"
        elif rel_path.startswith("client\\src\\utils"):
            return "Client Utils"
        elif rel_path.startswith("client\\src\\styles"):
            return "Styles"
        elif rel_path.startswith("client\\src\\types"):
            return "Type Definitions"
        elif rel_path.startswith("client"):
            return "Client Root"
        elif rel_path.startswith("server"):
            return "Server"
        elif rel_path.startswith("shared"):
            return "Shared"
        elif rel_path.startswith("project_utils"):
            return "Project Documentation"
        else:
            return "Other"

    def analyze_file(self, file_path: str):
        """Analyze a single file and extract metadata"""
        file_info = {}
        
        # Basic file info
        file_info['file_path'] = file_path
        file_info['relative_path'] = os.path.relpath(file_path, PROJECT_ROOT)
        file_info['filename'] = os.path.basename(file_path)
        file_info['extension'] = os.path.splitext(file_path)[1]
        file_info['category'] = self.get_file_category(file_path)
        
        # File size
        try:
            file_info['size_bytes'] = os.path.getsize(file_path)
        except:
            file_info['size_bytes'] = 0
        
        # Line counts
        total_lines, code_lines, comment_lines = self.count_lines(file_path)
        file_info['total_lines'] = total_lines
        file_info['code_lines'] = code_lines
        file_info['comment_lines'] = comment_lines
        
        # Import/Export analysis
        imports, exports = self.extract_imports_exports(file_path)
        file_info['imports'] = imports
        file_info['exports'] = exports
        file_info['import_count'] = len(imports)
        file_info['export_count'] = len(exports)
        
        # Last modified
        try:
            file_info['last_modified'] = os.path.getmtime(file_path)
        except:
            file_info['last_modified'] = 0
            
        return file_info

    def scan_project(self):
        """Scan the entire project for used files"""
        print("Starting project analysis...")
        
        # Add root files
        for root_file in ROOT_FILES:
            file_path = os.path.join(PROJECT_ROOT, root_file)
            if os.path.exists(file_path):
                file_info = self.analyze_file(file_path)
                self.files_data.append(file_info)
                print(f"Analyzed root file: {root_file}")
        
        # Scan included folders
        for folder in INCLUDE_FOLDERS:
            folder_path = os.path.join(PROJECT_ROOT, folder)
            if os.path.exists(folder_path):
                print(f"Scanning folder: {folder}")
                for root, dirs, files in os.walk(folder_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        ext = os.path.splitext(file)[1].lower()
                        
                        if ext in EXTENSIONS:
                            file_info = self.analyze_file(file_path)
                            self.files_data.append(file_info)
                            
        print(f"Analysis complete. Found {len(self.files_data)} files.")

    def create_summary_stats(self) -> Dict:
        """Create summary statistics"""
        df = pd.DataFrame(self.files_data)
        
        summary = {
            'total_files': len(self.files_data),
            'total_lines': df['total_lines'].sum(),
            'total_code_lines': df['code_lines'].sum(),
            'total_comment_lines': df['comment_lines'].sum(),
            'total_size_kb': round(df['size_bytes'].sum() / 1024, 2),
            'by_category': df.groupby('category').agg({
                'filename': 'count',
                'total_lines': 'sum',
                'code_lines': 'sum'
            }).to_dict(),
            'by_extension': df.groupby('extension').agg({
                'filename': 'count',
                'total_lines': 'sum',
                'code_lines': 'sum'
            }).to_dict()
        }
        
        return summary

    def generate_excel_report(self, output_file: str = "project_analysis.xlsx"):
        """Generate Excel report with multiple sheets"""
        print(f"Generating Excel report: {output_file}")
        
        # Create DataFrame
        df = pd.DataFrame(self.files_data)
        
        # Clean up data for Excel
        df_excel = df.copy()
        df_excel['imports'] = df_excel['imports'].apply(lambda x: '; '.join(x) if x else '')
        df_excel['exports'] = df_excel['exports'].apply(lambda x: '; '.join(x) if x else '')
        df_excel['size_kb'] = df_excel['size_bytes'] / 1024
        
        # Reorder columns for better readability
        columns_order = [
            'relative_path', 'filename', 'category', 'extension', 
            'total_lines', 'code_lines', 'comment_lines', 'size_kb',
            'import_count', 'export_count', 'imports', 'exports'
        ]
        df_excel = df_excel[columns_order]
        
        # Create Excel writer
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            # Main file list
            df_excel.to_excel(writer, sheet_name='All Files', index=False)
            
            # Summary by category
            category_summary = df.groupby('category').agg({
                'filename': 'count',
                'total_lines': 'sum',
                'code_lines': 'sum',
                'comment_lines': 'sum',
                'size_bytes': 'sum'
            }).reset_index()
            category_summary.columns = ['Category', 'File Count', 'Total Lines', 'Code Lines', 'Comment Lines', 'Size (Bytes)']
            category_summary['Size (KB)'] = category_summary['Size (Bytes)'] / 1024
            category_summary.to_excel(writer, sheet_name='By Category', index=False)
            
            # Summary by extension
            ext_summary = df.groupby('extension').agg({
                'filename': 'count',
                'total_lines': 'sum',
                'code_lines': 'sum',
                'comment_lines': 'sum',
                'size_bytes': 'sum'
            }).reset_index()
            ext_summary.columns = ['Extension', 'File Count', 'Total Lines', 'Code Lines', 'Comment Lines', 'Size (Bytes)']
            ext_summary['Size (KB)'] = ext_summary['Size (Bytes)'] / 1024
            ext_summary.to_excel(writer, sheet_name='By Extension', index=False)
            
            # Component analysis (React components only)
            react_files = df[df['extension'].isin(['.tsx', '.jsx'])].copy()
            if not react_files.empty:
                react_files.to_excel(writer, sheet_name='React Components', index=False)
            
            # Large files (top 20 by line count)
            large_files = df.nlargest(20, 'total_lines')[['relative_path', 'filename', 'category', 'total_lines', 'code_lines']].copy()
            large_files.to_excel(writer, sheet_name='Largest Files', index=False)
            
            # Import analysis
            import_analysis = []
            for _, row in df.iterrows():
                for imp in row['imports']:
                    import_analysis.append({
                        'File': row['relative_path'],
                        'Category': row['category'],
                        'Import': imp
                    })
            
            if import_analysis:
                import_df = pd.DataFrame(import_analysis)
                # Count most common imports
                import_counts = import_df['Import'].value_counts().head(20).reset_index()
                import_counts.columns = ['Import', 'Usage Count']
                import_counts.to_excel(writer, sheet_name='Popular Imports', index=False)
        
        print(f"Excel report generated: {output_file}")

    def print_summary(self):
        """Print a summary of the analysis"""
        summary = self.create_summary_stats()
        
        print("\n" + "="*60)
        print("PROJECT ANALYSIS SUMMARY")
        print("="*60)
        print(f"Total Files: {summary['total_files']}")
        print(f"Total Lines: {summary['total_lines']:,}")
        print(f"Code Lines: {summary['total_code_lines']:,}")
        print(f"Comment Lines: {summary['total_comment_lines']:,}")
        print(f"Total Size: {summary['total_size_kb']:,.2f} KB")
        
        print("\nFiles by Category:")
        for category, stats in summary['by_category']['filename'].items():
            lines = summary['by_category']['total_lines'][category]
            print(f"  {category}: {stats} files, {lines:,} lines")
        
        print("\nFiles by Extension:")
        for ext, stats in summary['by_extension']['filename'].items():
            lines = summary['by_extension']['total_lines'][ext]
            print(f"  {ext}: {stats} files, {lines:,} lines")

def main():
    """Main execution function"""
    os.chdir(PROJECT_ROOT)
    
    analyzer = ProjectAnalyzer()
    analyzer.scan_project()
    analyzer.print_summary()
    analyzer.generate_excel_report("InfoArchive_Project_Analysis.xlsx")
    
    print(f"\nAnalysis complete! Excel report saved as 'InfoArchive_Project_Analysis.xlsx'")

if __name__ == "__main__":
    main()
