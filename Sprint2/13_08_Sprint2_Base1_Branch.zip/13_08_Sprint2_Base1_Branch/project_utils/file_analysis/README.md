# File Analysis Tools

This folder contains tools and reports for analyzing the InfoArchive project files and code metrics.

## Files in this folder:

### Analysis Scripts
- **`simple_file_analysis.py`** - Simple script that generates Excel file with individual files and their code line counts
- **`analyze_project_files.py`** - Comprehensive analysis script that generates detailed project metrics
- **`open_report.py`** - Utility script to open Excel reports with default application

### Generated Reports
- **`Project_Files_CodeLines.xlsx`** - Simple Excel file with all files and their code line counts
- **`InfoArchive_Project_Analysis.xlsx`** - Comprehensive Excel report with multiple analysis sheets
- **`PROJECT_ANALYSIS_SUMMARY.md`** - Detailed written summary of the project analysis

## How to Use

### Simple Analysis (Individual Files + Code Lines)
```bash
# From project root directory
cd "d:\Programming\Reactjs\InfoArchive_project\Sprint2\28_07_Sprint2_Base_Branch"
C:/Python313/python.exe "project_utils\file_analysis\simple_file_analysis.py"
```

### Comprehensive Analysis
```bash
# From project root directory  
cd "d:\Programming\Reactjs\InfoArchive_project\Sprint2\28_07_Sprint2_Base_Branch"
C:/Python313/python.exe "project_utils\file_analysis\analyze_project_files.py"
```

### Open Reports
```bash
# From project root directory
cd "d:\Programming\Reactjs\InfoArchive_project\Sprint2\28_07_Sprint2_Base_Branch"
C:/Python313/python.exe "project_utils\file_analysis\open_report.py"
```

## Analysis Scope

The analysis includes files from:
- **Root folder**: Configuration files (package.json, vite.config.ts, etc.)
- **client/** folder: React components, hooks, pages, styles, utilities
- **server/** folder: API routes, server configuration
- **shared/** folder: Shared utilities and configuration
- **project_utils/** folder: Documentation and utilities

### Excluded folders:
- `temp/` (cleanup and unused files)
- `node_modules/` (dependencies)
- `uploads/`, `data/` (runtime data)
- `.git/` (version control)

## Dependencies

The scripts require:
- Python 3.7+
- pandas library: `pip install pandas`
- openpyxl library: `pip install openpyxl`

## Project Statistics (Last Analysis)

- **Total Files**: 135 files
- **Total Code Lines**: 28,238 lines
- **Largest Components**: 
  - server\routes.ts: 2,476 lines
  - editable-schema-generator-new.tsx: 1,315 lines
  - use-airflow-api.ts: 1,104 lines

## File Categories

1. **Business Components** (16 files, 11,324 lines)
2. **UI Components** (49 files, 4,889 lines)  
3. **Server** (10 files, 6,219 lines)
4. **Project Documentation** (23 files, 4,252 lines)
5. **Shared** (6 files, 1,750 lines)
6. **Styles** (3 files, 1,850 lines)
7. **React Hooks** (4 files, 1,632 lines)
8. **Others** (24 files, 3,073 lines)

---

*Generated on: July 25, 2025*  
*Last Updated: Analysis reflects project state after client-side cleanup*
