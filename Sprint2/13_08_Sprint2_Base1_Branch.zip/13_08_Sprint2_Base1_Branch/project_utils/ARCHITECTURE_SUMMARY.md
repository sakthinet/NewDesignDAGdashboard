# InfoArchive DAG Generator - Architecture Summary

## Project Overview

The **InfoArchive DAG Generator** is a comprehensive web application designed to create and manage Apache Airflow DAGs for InfoArchive data processing workflows. This application bridges the gap between CSV data sources and InfoArchive document management system through automated workflow generation.

## Modified Architecture Components

### Frontend Layer (React Application)
- **DAG Dashboard**: Real-time monitoring of Airflow workflows
- **File Upload Studio**: Multi-file CSV processing with batch capabilities
- **DAG Configuration**: InfoArchive-specific workflow parameter setup
- **IA Schema Generator**: InfoArchive table schema and XML metadata creation
- **Editable Schema Designer**: Visual field mapping and transformation rules
- **Script Generator**: Automated Python DAG generation for InfoArchive workflows
- **XML Schema Viewer**: Interactive XML schema management
- **Reports & Analytics**: Workflow performance insights and data visualizations
- **AI Assistant (Buddy)**: InfoArchive workflow guidance and troubleshooting

### API Communication Layer
- **Centralized HTTP Client**: Enhanced with retry logic and error handling
- **Airflow Integration Hook**: JWT-authenticated API v2 communication
- **TanStack Query Cache**: Advanced caching with synchronization
- **Toast Notifications**: Real-time workflow status updates
- **Configuration Manager**: Unified system supporting local/network deployments

### Backend Services (Express.js)
- **File Upload API**: Multi-file CSV processing and validation
- **DAG Generation API**: InfoArchive-specific Python script generation
- **Airflow Deployment API**: Auto-refreshing DAG deployment
- **Schema Management API**: InfoArchive XML schema creation and management
- **File Management API**: XML file discovery and path management
- **Reports API**: Analytics generation from JSON data
- **Chatbot API**: AI assistance with Hugging Face integration
- **Testing & Validation API**: DAG syntax and deployment validation

### External Integrations
- **Apache Airflow**: Core workflow orchestration with Docker deployment
- **Hugging Face LLM**: Remote AI model for intelligent assistance
- **Dual File System**: Local development and network UNC path support
- **SQLite Database**: Persistent storage with Drizzle ORM
- **InfoArchive System**: Target document management platform
- **Multi-Environment Support**: Local dev and production configurations

## Key Differences from Original Architecture

### 1. InfoArchive-Specific Features
- Specialized schema generation for InfoArchive table structures
- XML metadata creation for InfoArchive document types
- InfoArchive-specific DAG templates and workflows

### 2. Enhanced File Management
- Multi-file upload capabilities
- Dual-mode file system (local/network UNC paths)
- XML file discovery and management
- Comprehensive path resolution system

### 3. Advanced Technology Stack
- **TanStack Query** instead of basic React Query
- **TanStack Table** for data grid functionality
- **Drizzle ORM** for database operations
- **Radix UI** component library
- **Recharts** for data visualization
- **Framer Motion** for animations

### 4. Production-Ready Features
- JWT authentication for Airflow API
- Multi-environment configuration
- Docker containerization support
- Comprehensive error handling and retry logic
- Real-time monitoring and notifications

## Data Flow: CSV → InfoArchive Integration

1. **CSV Upload & Analysis**
   - Users upload CSV files through drag-and-drop interface
   - System analyzes file structure and generates previews
   - Multiple file handling with batch processing

2. **Schema Generation**
   - InfoArchive table schema automatically created
   - XML metadata generated for document types
   - Field mapping and transformation rules configured

3. **DAG Creation**
   - Python DAG scripts generated with InfoArchive tasks
   - Airflow workflow configured for data processing
   - Deployment packages created with dependencies

4. **Deployment & Monitoring**
   - DAGs deployed to Airflow with auto-refresh
   - InfoArchive workflows executed and monitored
   - Real-time status updates and error handling

## Development Environment

### Local Development
- Uses local file paths (`./data/`, `./dags/`, `./reports/`)
- SQLite database for configuration storage
- Development-friendly error messages and debugging

### Production Environment
- Network UNC paths for shared storage
- Docker-based Airflow deployment
- Production-optimized caching and performance

## Configuration System

The application supports a unified configuration system that can operate in:
- **Local Mode**: For development with local file paths
- **Network Mode**: For production with UNC network paths
- **Hybrid Mode**: Fallback capabilities between local and network storage

## API Endpoints Summary

| Endpoint | Purpose | InfoArchive Integration |
|----------|---------|------------------------|
| `/api/upload-csv` | Multi-file CSV upload | ✅ Schema analysis |
| `/api/generate-dag` | DAG script generation | ✅ InfoArchive tasks |
| `/api/ia-table-schema` | Schema management | ✅ XML metadata |
| `/api/xml-files/*` | File management | ✅ Schema downloads |
| `/api/reports` | Analytics | ✅ Workflow metrics |
| `/api/chatbot/query` | AI assistance | ✅ InfoArchive guidance |

## Additional Information Needed

To complete the architecture documentation, the following information would be helpful:

1. **InfoArchive Server Details**
   - Version and API specifications
   - Authentication requirements
   - Document type configurations

2. **Network Infrastructure**
   - UNC path structures and permissions
   - Network security requirements
   - File sharing protocols

3. **Deployment Specifications**
   - Docker compose configurations
   - Environment variable requirements
   - Scaling considerations

4. **Security Requirements**
   - Authentication mechanisms
   - Data encryption needs
   - Access control policies

5. **Performance Requirements**
   - Expected file sizes and volumes
   - Concurrent user limits
   - Response time expectations

## Interactive Architecture Viewer

The updated `tcs_ecm_architecture.html` file now accurately reflects your InfoArchive DAG Generator project. Open it in a web browser to see:

- Interactive component visualization
- Click-to-highlight functionality
- Detailed technology stack breakdown
- Data flow diagrams
- Communication patterns

The architecture document provides a comprehensive view of your sophisticated InfoArchive integration platform with modern React frontend, robust Express.js backend, and seamless Airflow orchestration.
