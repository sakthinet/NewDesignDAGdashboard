# PostgreSQL Metrics Implementation

## Overview

This implementation provides a comprehensive metrics dashboard for monitoring PostgreSQL database-based DAG run metrics. The system supports both local and network deployment modes and displays real-time analytics.

## Implementation Details

### Backend Components

#### 1. Metrics Routes (`server/metrics-routes.ts`)
- **Database Configuration**: Automatically switches between local and network PostgreSQL configurations
  - **Network Mode**: `host: 10.73.88.101`, `user: postgres`, `password: postgres`
  - **Local Mode**: `host: localhost`, `user: postgres`, `password: admin@12345`
- **Database**: `RND` on port `5432`

#### 2. SQL Query Implementation
```sql
SELECT id, dag_id as ProcessName, run_id as InstanceId, 
       execution_date, records_processed, records_failed
FROM public.dag_run_metrics
ORDER BY execution_date DESC
```

#### 3. API Endpoints
- **GET `/api/metrics/test-connection`**: Test database connectivity
- **GET `/api/metrics/dag-runs`**: Fetch DAG run metrics with summary statistics
- **GET `/api/metrics/summary`**: Get comprehensive analytics and trends
- **GET `/api/metrics/config`**: Get current database configuration

### Frontend Components

#### 1. Metrics Dashboard (`client/src/components/metrics-dashboard.tsx`)
- **Three-tab interface**:
  - **Overview**: Summary cards and key metrics
  - **Process Details**: Detailed process performance and charts
  - **Trends & Analytics**: Hourly/daily patterns and top processes

#### 2. Chart Visualizations
- **Bar Charts**: Process performance comparison
- **Area Charts**: Hourly activity trends
- **Pie Charts**: Top performing processes distribution
- **Line Charts**: Time-series data visualization

#### 3. Real-time Features
- **Auto-refresh**: Every 5 minutes
- **Connection testing**: Real-time database connectivity status
- **Live updates**: Immediate feedback on data changes

## Database Schema Requirements

The implementation expects a PostgreSQL table with the following structure:

```sql
CREATE TABLE public.dag_run_metrics (
    id SERIAL PRIMARY KEY,
    dag_id VARCHAR(255) NOT NULL,
    run_id VARCHAR(255) NOT NULL,
    execution_date TIMESTAMP NOT NULL,
    records_processed INTEGER DEFAULT 0,
    records_failed INTEGER DEFAULT 0
);
```

## Configuration

### Network Deployment
- **Host**: `10.73.88.101` (same as Airflow network configuration)
- **Database**: `RND`
- **User**: `postgres`
- **Password**: `postgres`

### Local Deployment
- **Host**: `localhost`
- **Database**: `RND`
- **User**: `postgres`
- **Password**: `admin@12345`

## Features

### Dashboard Overview
1. **Summary Cards**:
   - Total Runs
   - Records Processed
   - Success Rate
   - Average Records per Run

2. **Process Performance**:
   - Individual process metrics
   - Success rate per process
   - Average processing volumes

3. **Trends Analysis**:
   - Hourly activity patterns
   - Daily processing volumes
   - Peak usage identification

### Data Processing
- **Mock Data**: Implementation includes realistic sample data for demonstration
- **Error Handling**: Comprehensive error handling for connection failures
- **Caching**: Efficient data retrieval and caching mechanisms

## Usage Instructions

### 1. Navigate to Metrics
1. Open the application at `http://localhost:3002` (or `http://10.73.90.19:3002` for network access)
2. Click on the sidebar: **Management Console → Metrics**

### 2. Test Database Connection
1. Click the **"Test Connection"** button in the Database Connection card
2. Verify the connection status indicator shows green for success

### 3. View Metrics Data
1. Use the **"Refresh Data"** button to manually update metrics
2. Navigate between tabs:
   - **Overview**: High-level summary
   - **Process Details**: Detailed breakdowns
   - **Trends & Analytics**: Historical patterns

### 4. Monitor Real-time Updates
- The dashboard auto-refreshes every 5 minutes
- Connection status is continuously monitored
- Toast notifications provide feedback on operations

## Error Handling

### Connection Failures
- Red connection indicator with error message
- Retry connection functionality
- Graceful degradation with mock data

### Data Loading Issues
- Loading states with spinners
- Error toast notifications
- Empty state handling

## Technical Architecture

### Data Flow
1. **Frontend Request** → API endpoint (`/api/metrics/*`)
2. **Backend Processing** → Database configuration selection
3. **Database Query** → PostgreSQL connection and query execution
4. **Data Processing** → Summary calculations and analytics
5. **Response** → JSON response with metrics data
6. **Frontend Rendering** → Chart visualization and table display

### Performance Optimizations
- **Parallel API calls** for faster loading
- **Client-side caching** for chart data
- **Efficient SQL queries** with proper indexing expectations
- **Responsive design** for various screen sizes

## Dependencies

### Backend
- `pg8000`: PostgreSQL database adapter
- `express`: Web framework for API routes

### Frontend
- `recharts`: Chart visualization library
- `lucide-react`: Icon components
- `shadcn/ui`: UI component library

## Future Enhancements

### Planned Features
1. **Real-time WebSocket updates** for live metrics
2. **Advanced filtering** by date range and process
3. **Export functionality** for reports
4. **Alert system** for threshold breaches
5. **Historical data analysis** with longer time ranges

### Database Optimizations
1. **Indexed queries** for better performance
2. **Partitioned tables** for large datasets
3. **Stored procedures** for complex analytics
4. **Connection pooling** for high-load scenarios

## Troubleshooting

### Common Issues

#### 1. Database Connection Failed
- **Check network connectivity** to `10.73.88.101`
- **Verify PostgreSQL service** is running
- **Confirm credentials** and database name
- **Test port accessibility** (5432)

#### 2. No Data Displayed
- **Verify table exists**: `public.dag_run_metrics`
- **Check table permissions** for the user
- **Confirm data exists** in the table
- **Review server logs** for SQL errors

#### 3. Charts Not Loading
- **Check browser console** for JavaScript errors
- **Verify recharts dependency** is installed
- **Test with mock data** to isolate issues
- **Clear browser cache** if needed

### Logs and Debugging
- **Server logs**: Check terminal output for API errors
- **Browser console**: Monitor for frontend errors
- **Network tab**: Verify API calls are successful
- **Database logs**: Check PostgreSQL logs for connection issues

## Sample Data Structure

The implementation includes mock data that matches the expected PostgreSQL schema:

```json
{
  "id": 1,
  "processname": "customer_data_processing",
  "instanceid": "run_2024_01_15_001",
  "execution_date": "2024-01-15T10:30:00Z",
  "records_processed": 15420,
  "records_failed": 23
}
```

This comprehensive implementation provides a robust foundation for PostgreSQL-based metrics monitoring with room for future enhancements and customizations.
