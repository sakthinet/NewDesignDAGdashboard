#!/usr/bin/env node

/**
 * Configuration Switcher Utility
 * Easily switch between local and network deployment modes
 */

const { readFileSync, writeFileSync, existsSync } = require('fs');
const { resolve } = require('path');

const ENV_FILE = resolve(process.cwd(), '.env');
const UNIFIED_ENV_FILE = resolve(process.cwd(), '.env.unified');

/**
 * Set or update VITE environment variables in the content
 */
function setViteVariables(content, viteVars) {
  let updatedContent = content;
  
  // Find the VITE section or create it
  const viteSection = '# CLIENT-SIDE VARIABLES (VITE) - Auto-configured based on DEPLOYMENT_MODE';
  
  Object.entries(viteVars).forEach(([key, value]) => {
    const regex = new RegExp(`^${key}=.*`, 'm');
    const newLine = `${key}=${value}`;
    
    if (regex.test(updatedContent)) {
      // Update existing variable
      updatedContent = updatedContent.replace(regex, newLine);
    } else {
      // Add new variable in the VITE section
      const viteSectionIndex = updatedContent.indexOf(viteSection);
      if (viteSectionIndex !== -1) {
        const insertionPoint = updatedContent.indexOf('\n', viteSectionIndex) + 1;
        updatedContent = updatedContent.slice(0, insertionPoint) + 
                        newLine + '\n' + 
                        updatedContent.slice(insertionPoint);
      } else {
        // If VITE section doesn't exist, add it at the end
        updatedContent += `\n\n${viteSection}\n${newLine}\n`;
      }
    }
  });
  
  return updatedContent;
}

/**
 * Switch deployment mode in .env file
 */
function switchDeploymentMode(options) {
  const { mode, backup = true, verbose = false } = options;
  
  if (verbose) {
    console.log(`🔄 Switching to ${mode} deployment mode...`);
  }
  
  // Check if unified config exists
  if (!existsSync(UNIFIED_ENV_FILE)) {
    console.error('❌ .env.unified file not found. Please ensure unified configuration is set up.');
    process.exit(1);
  }
  
  // Backup current .env if requested
  if (backup && existsSync(ENV_FILE)) {
    const backupFile = `${ENV_FILE}.backup.${Date.now()}`;
    const currentContent = readFileSync(ENV_FILE, 'utf8');
    writeFileSync(backupFile, currentContent);
    
    if (verbose) {
      console.log(`📦 Backed up current .env to: ${backupFile}`);
    }
  }
  
  // Read unified config
  const unifiedContent = readFileSync(UNIFIED_ENV_FILE, 'utf8');
  
  // Update deployment mode
  let updatedContent = unifiedContent.replace(
    /^DEPLOYMENT_MODE=.*/m,
    `DEPLOYMENT_MODE=${mode}`
  );
  
  // Update backward compatibility variables based on mode
  if (mode === 'local') {
    updatedContent = updatedContent.replace(
      /^AIRFLOW_URL=.*/m,
      'AIRFLOW_URL=http://localhost:8083'
    ).replace(
      /^AIRFLOW_USERNAME=.*/m,
      'AIRFLOW_USERNAME=admin'
    ).replace(
      /^AIRFLOW_PASSWORD=.*/m,
      'AIRFLOW_PASSWORD=admin123'
    ).replace(
      /^AIRFLOW_INCOMING_CSV_DIR=.*/m,
      'AIRFLOW_INCOMING_CSV_DIR=C:\\\\Docker\\\\airflow3x2\\\\data\\\\incomingcsv'
    ).replace(
      /^AIRFLOW_PROCESSED_CSV_DIR=.*/m,
      'AIRFLOW_PROCESSED_CSV_DIR=C:\\\\Docker\\\\airflow3x2\\\\data\\\\processedcsv'
    ).replace(
      /^AIRFLOW_REPORTS_DIR=.*/m,
      'AIRFLOW_REPORTS_DIR=C:\\\\Docker\\\\airflow3x2\\\\reports'
    ).replace(
      /^AIRFLOW_DAGS_DIR=.*/m,
      'AIRFLOW_DAGS_DIR=C:\\\\Docker\\\\airflow3x2\\\\dags'
    );
    
    // Update VITE environment variables for local mode
    updatedContent = setViteVariables(updatedContent, {
      VITE_AIRFLOW_URL: 'http://localhost:8083',
      VITE_AIRFLOW_INCOMING_CSV_DIR: 'C:\\\\Docker\\\\airflow3x2\\\\data\\\\incomingcsv',
      VITE_AIRFLOW_PROCESSED_CSV_DIR: 'C:\\\\Docker\\\\airflow3x2\\\\data\\\\processedcsv',
      VITE_AIRFLOW_REPORTS_DIR: 'C:\\\\Docker\\\\airflow3x2\\\\reports',
      VITE_AIRFLOW_DAGS_DIR: 'C:\\\\Docker\\\\airflow3x2\\\\dags',
      VITE_AIRFLOW_DATA_BASE_DIR: 'C:\\\\Docker\\\\airflow3x2\\\\data',
      VITE_DEPLOYMENT_MODE: 'local'
    });
  } else {
    updatedContent = updatedContent.replace(
      /^AIRFLOW_URL=.*/m,
      'AIRFLOW_URL=http://10.73.88.101:8080'
    ).replace(
      /^AIRFLOW_USERNAME=.*/m,
      'AIRFLOW_USERNAME=airflow'
    ).replace(
      /^AIRFLOW_PASSWORD=.*/m,
      'AIRFLOW_PASSWORD=airflow'
    ).replace(
      /^AIRFLOW_INCOMING_CSV_DIR=.*/m,
      'AIRFLOW_INCOMING_CSV_DIR=\\\\\\\\10.73.88.101\\\\data\\\\incomingcsv'
    ).replace(
      /^AIRFLOW_PROCESSED_CSV_DIR=.*/m,
      'AIRFLOW_PROCESSED_CSV_DIR=\\\\\\\\10.73.88.101\\\\data\\\\processedcsv'
    ).replace(
      /^AIRFLOW_REPORTS_DIR=.*/m,
      'AIRFLOW_REPORTS_DIR=\\\\\\\\10.73.88.101\\\\reports'
    ).replace(
      /^AIRFLOW_DAGS_DIR=.*/m,
      'AIRFLOW_DAGS_DIR=\\\\\\\\10.73.88.101\\\\dags'
    );
    
    // Update VITE environment variables for network mode
    updatedContent = setViteVariables(updatedContent, {
      VITE_AIRFLOW_URL: 'http://10.73.88.101:8080',
      VITE_AIRFLOW_INCOMING_CSV_DIR: '\\\\\\\\10.73.88.101\\\\data\\\\incomingcsv',
      VITE_AIRFLOW_PROCESSED_CSV_DIR: '\\\\\\\\10.73.88.101\\\\data\\\\processedcsv',
      VITE_AIRFLOW_REPORTS_DIR: '\\\\\\\\10.73.88.101\\\\reports',
      VITE_AIRFLOW_DAGS_DIR: '\\\\\\\\10.73.88.101\\\\dags',
      VITE_AIRFLOW_DATA_BASE_DIR: '\\\\\\\\10.73.88.101\\\\data',
      VITE_DEPLOYMENT_MODE: 'network'
    });
  }
  
  // Write to .env
  writeFileSync(ENV_FILE, updatedContent);
  
  if (verbose) {
    console.log(`✅ Successfully switched to ${mode} mode`);
    console.log(`📁 Configuration saved to: ${ENV_FILE}`);
    
    // Show active configuration
    showActiveConfiguration(mode);
  }
}

/**
 * Show active configuration based on mode
 */
function showActiveConfiguration(mode) {
  console.log(`\n🔧 Active Configuration (${mode.toUpperCase()} mode):`);
  
  if (mode === 'local') {
    console.log(`🔗 Airflow URL: http://localhost:8083`);
    console.log(`👤 Username: admin`);
    console.log(`📁 Paths: C:\\Docker\\airflow3x2\\data\\*`);
    console.log(`\n📱 VITE Variables (Client-Side):`);
    console.log(`   VITE_AIRFLOW_URL=http://localhost:8083`);
    console.log(`   VITE_DEPLOYMENT_MODE=local`);
    console.log(`   VITE_AIRFLOW_INCOMING_CSV_DIR=C:\\\\Docker\\\\airflow3x2\\\\data\\\\incomingcsv`);
  } else {
    console.log(`🔗 Airflow URL: http://10.73.88.101:8080`);
    console.log(`👤 Username: airflow`);
    console.log(`📁 Paths: \\\\10.73.88.101\\data\\*`);
    console.log(`\n📱 VITE Variables (Client-Side):`);
    console.log(`   VITE_AIRFLOW_URL=http://10.73.88.101:8080`);
    console.log(`   VITE_DEPLOYMENT_MODE=network`);
    console.log(`   VITE_AIRFLOW_INCOMING_CSV_DIR=\\\\\\\\10.73.88.101\\\\data\\\\incomingcsv`);
  }
  
  console.log(`\n💡 Tip: Restart your application to apply changes`);
  console.log(`🔨 Build Tip: Run 'npm run build' to rebuild with new configuration`);
}

/**
 * CLI interface
 */
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    console.log(`
🔧 Configuration Switcher for Airflow Application

Usage:
  node config-switcher.cjs <mode> [options]

Modes:
  local    - Use local Docker Airflow (localhost:8083)
  network  - Use network shared Airflow (10.73.88.101:8080)

Options:
  --no-backup    Skip backing up current .env file
  --verbose, -v  Show detailed output
  --help, -h     Show this help message

Examples:
  node config-switcher.cjs local              # Switch to local mode
  node config-switcher.cjs network --verbose  # Switch to network mode with details
  node config-switcher.cjs local --no-backup  # Switch without backup
`);
    return;
  }
  
  const mode = args[0];
  
  if (mode !== 'local' && mode !== 'network') {
    console.error('❌ Invalid mode. Use "local" or "network"');
    process.exit(1);
  }
  
  const options = {
    mode,
    backup: !args.includes('--no-backup'),
    verbose: args.includes('--verbose') || args.includes('-v')
  };
  
  try {
    switchDeploymentMode(options);
  } catch (error) {
    console.error('❌ Error switching configuration:', error.message);
    process.exit(1);
  }
}

// Export for programmatic use
module.exports = { switchDeploymentMode, showActiveConfiguration };

// Run CLI if this file is executed directly
if (require.main === module) {
  main();
}
