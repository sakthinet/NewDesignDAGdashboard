/**
 * Client-side configuration hook for React components
 * This avoids runtime access to process.env which is not available in the browser
 * Enhanced to fetch server configuration for production deployments
 */

import { useMemo, useState, useEffect } from 'react';

interface ClientConfig {
  airflowUrl: string;
  dataBaseDir: string;
  incomingCsvDir: string;
  processedCsvDir: string;
  reportsDir: string;
  dagsDir: string;
  deploymentMode?: string;
}

interface ServerConfig {
  deploymentMode: string;
  paths: {
    incomingCsvDir: string;
    processedCsvDir: string;
    reportsDir: string;
    dagsDir: string;
    dataBaseDir: string;
  };
  connection: {
    url: string;
  };
}

/**
 * Static configuration for client-side use (from build-time environment variables)
 * This provides fallback values when server configuration is not available
 */
export const CLIENT_CONFIG: ClientConfig = {
  airflowUrl: import.meta.env.VITE_AIRFLOW_URL || 'http://localhost:8080',
  dataBaseDir: import.meta.env.VITE_AIRFLOW_DATA_BASE_DIR || './data',
  incomingCsvDir: import.meta.env.VITE_AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv',
  processedCsvDir: import.meta.env.VITE_AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv',
  reportsDir: import.meta.env.VITE_AIRFLOW_REPORTS_DIR || './reports',
  dagsDir: import.meta.env.VITE_AIRFLOW_DAGS_DIR || './dags',
  deploymentMode: import.meta.env.VITE_DEPLOYMENT_MODE || 'local',
};

/**
 * Enhanced React hook for accessing client-side configuration
 * Fetches live configuration from server API for production builds
 */
export function useClientConfig(): ClientConfig {
  const [serverConfig, setServerConfig] = useState<ServerConfig | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch server configuration on mount
  useEffect(() => {
    const fetchServerConfig = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('/api/config/deployment');
        if (response.ok) {
          const config = await response.json();
          setServerConfig(config);
          console.log('📡 Fetched server configuration:', config.deploymentMode);
        }
      } catch (error) {
        console.warn('Failed to fetch server configuration, using build-time config:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchServerConfig();
  }, []);

  return useMemo(() => {
    // If we have server config, use it (production mode with live server data)
    if (serverConfig) {
      return {
        airflowUrl: serverConfig.connection.url,
        dataBaseDir: serverConfig.paths.dataBaseDir,
        incomingCsvDir: serverConfig.paths.incomingCsvDir,
        processedCsvDir: serverConfig.paths.processedCsvDir,
        reportsDir: serverConfig.paths.reportsDir,
        dagsDir: serverConfig.paths.dagsDir,
        deploymentMode: serverConfig.deploymentMode,
      };
    }
    
    // Fallback to build-time config (development mode or server unavailable)
    return CLIENT_CONFIG;
  }, [serverConfig]);
}

/**
 * Get Airflow URL for client-side use
 * Enhanced to support both build-time and runtime configuration
 */
export function getAirflowUrl(): string {
  // For immediate use without React hooks, return build-time config
  // Components should use useClientConfig() for live server config
  return CLIENT_CONFIG.airflowUrl;
}

/**
 * Get data directories for client-side use
 */
export function getDataDirectories() {
  return {
    base: CLIENT_CONFIG.dataBaseDir,
    incoming: CLIENT_CONFIG.incomingCsvDir,
    processed: CLIENT_CONFIG.processedCsvDir,
    reports: CLIENT_CONFIG.reportsDir,
    dags: CLIENT_CONFIG.dagsDir,
  };
}

/**
 * Get runtime configuration directly (for use outside React components)
 * This fetches the latest server configuration
 */
export async function getRuntimeConfig(): Promise<ClientConfig> {
  try {
    const response = await fetch('/api/config/deployment');
    if (response.ok) {
      const serverConfig = await response.json();
      return {
        airflowUrl: serverConfig.connection.url,
        dataBaseDir: serverConfig.paths.dataBaseDir,
        incomingCsvDir: serverConfig.paths.incomingCsvDir,
        processedCsvDir: serverConfig.paths.processedCsvDir,
        reportsDir: serverConfig.paths.reportsDir,
        dagsDir: serverConfig.paths.dagsDir,
        deploymentMode: serverConfig.deploymentMode,
      };
    }
  } catch (error) {
    console.warn('Failed to fetch runtime configuration, using fallback:', error);
  }
  
  // Fallback to build-time configuration
  return CLIENT_CONFIG;
}
