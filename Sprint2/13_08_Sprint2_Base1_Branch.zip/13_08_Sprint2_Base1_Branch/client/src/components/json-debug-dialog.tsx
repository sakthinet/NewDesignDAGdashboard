import { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Loader2, FileJson, AlertCircle, CheckCircle2 } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { apiRequest } from "@/lib/queryClient";

interface JsonDebugDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function JsonDebugDialog({ open, onOpenChange }: JsonDebugDialogProps) {
  const [filePath, setFilePath] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [debugResult, setDebugResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const checkFile = async () => {
    if (!filePath) return;

    setIsLoading(true);
    setError(null);
    setDebugResult(null);

    try {
      const response = await apiRequest('POST', '/api/debug-file-content', {
        filePath: filePath
      });

      const result = await response.json();
      if (response.ok) {
        if (result.success) {
          setDebugResult(result);
        } else {
          setError(result.message || 'Failed to debug file');
        }
      } else {
        setError(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>JSON File Debugger</DialogTitle>
          <DialogDescription>
            Analyze file content and check for JSON validity. Enter a full file path to check.
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex items-end gap-2 my-4">
          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="filePath">File Path</Label>
            <Input
              id="filePath"
              placeholder="Enter full file path (e.g., \\server\share\file.json or C:\path\to\file.json)"
              value={filePath}
              onChange={(e) => setFilePath(e.target.value)}
            />
          </div>
          <Button 
            onClick={checkFile} 
            disabled={isLoading || !filePath}
            className="ml-2 whitespace-nowrap"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <FileJson className="mr-2 h-4 w-4" />
                Check File
              </>
            )}
          </Button>
        </div>

        {error && (
          <Alert variant="destructive" className="my-2">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {debugResult && (
          <ScrollArea className="flex-1 mt-2">
            <Tabs defaultValue="summary" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="summary">Summary</TabsTrigger>
                <TabsTrigger value="preview">Content Preview</TabsTrigger>
                <TabsTrigger value="json">JSON View</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
              </TabsList>
              
              <TabsContent value="summary" className="space-y-4">
                <div className="border rounded-md p-4 space-y-2">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">File Analysis</h3>
                    {debugResult.isValidJson ? (
                      <span className="text-green-500 flex items-center">
                        <CheckCircle2 className="h-4 w-4 mr-1" />
                        Valid JSON
                      </span>
                    ) : (
                      <span className="text-red-500 flex items-center">
                        <AlertCircle className="h-4 w-4 mr-1" />
                        Invalid JSON
                      </span>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="font-medium">File Path:</div>
                    <div className="font-mono text-xs break-all">{debugResult.filePath}</div>
                    
                    <div className="font-medium">File Size:</div>
                    <div>{debugResult.fileSize} bytes</div>
                    
                    <div className="font-medium">File Type:</div>
                    <div>{debugResult.fileType}</div>
                    
                    {debugResult.jsonParseError && (
                      <>
                        <div className="font-medium text-red-500">Parse Error:</div>
                        <div className="font-mono text-xs text-red-500">{debugResult.jsonParseError}</div>
                      </>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="preview">
                <div className="border rounded-md p-2">
                  <ScrollArea className="h-[300px]">
                    <pre className="text-xs font-mono whitespace-pre-wrap break-all p-2">
                      {debugResult.contentPreview || 'No content preview available'}
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="json">
                <div className="border rounded-md p-2">
                  <ScrollArea className="h-[300px]">
                    {debugResult.isValidJson ? (
                      <pre className="text-xs font-mono whitespace-pre-wrap p-2">
                        {debugResult.jsonPreview || 'No JSON preview available'}
                      </pre>
                    ) : (
                      <div className="p-4 text-center text-red-500">
                        <AlertCircle className="h-16 w-16 mx-auto mb-2" />
                        <p className="font-medium">Not valid JSON</p>
                        {debugResult.jsonParseError && (
                          <p className="text-sm mt-2">{debugResult.jsonParseError}</p>
                        )}
                      </div>
                    )}
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="details">
                <div className="border rounded-md p-2">
                  <ScrollArea className="h-[300px]">
                    <pre className="text-xs font-mono whitespace-pre-wrap p-2">
                      {JSON.stringify(debugResult, null, 2)}
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
            </Tabs>
          </ScrollArea>
        )}

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
