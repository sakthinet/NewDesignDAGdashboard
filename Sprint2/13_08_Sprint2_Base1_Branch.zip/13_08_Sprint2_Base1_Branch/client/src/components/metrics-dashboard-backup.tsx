import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

  // Pagination and sorting logic
  const sortedData = useMemo(() => {
    let sortableData = [...metricsData];
    if (sortConfig !== null) {
      sortableData.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
          return 0;
        }
        
        const aStr = String(aValue).toLowerCase();
        const bStr = String(bValue).toLowerCase();
        if (aStr < bStr) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aStr > bStr) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableData;
  }, [metricsData, sortConfig]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(metricsData.length / itemsPerPage);

  const handleSort = (key: keyof MetricsData) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const getSortIcon = (columnKey: keyof MetricsData) => {
    if (!sortConfig || sortConfig.key !== columnKey) {
      return <MoreHorizontal className="w-4 h-4 opacity-0 group-hover:opacity-50" />;
    }
    return sortConfig.direction === 'asc' ? 
      <TrendingUp className="w-4 h-4" /> : 
      <TrendingDown className="w-4 h-4" />;
  };

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart
} from 'recharts';
import {
  Database,
  Activity,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  BarChart3,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  Settings,
  Server,
  Calendar,
  Users,
  Target,
  AlertTriangle,
  Zap,
  Globe,
  Info,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  MoreHorizontal
} from 'lucide-react';

interface MetricsData {
  id: number;
  processname: string;
  instanceid: string;
  execution_date: string;
  records_processed: number;
  records_failed: number;
}

interface MetricsSummary {
  totalRuns: number;
  totalRecordsProcessed: number;
  totalRecordsFailed: number;
  successRate: string;
  avgRecordsPerRun: number;
}

interface ProcessSummary {
  processName: string;
  totalRuns: number;
  totalProcessed: number;
  totalFailed: number;
  avgProcessed: number;
  successRate: string;
}

interface DatabaseConfig {
  host: string;
  database: string;
  deploymentMode: string;
}

interface MetricsResponse {
  success: boolean;
  data: MetricsData[];
  summary: MetricsSummary;
  processSummary: ProcessSummary[];
  databaseConfig: DatabaseConfig;
  timestamp: string;
  query: string;
}

interface TrendData {
  hourly: Array<{
    hour: number;
    runs: number;
    avgProcessed: number;
    avgFailed: number;
  }>;
  daily: Array<{
    day: string;
    dayNumber: number;
    runs: number;
    avgProcessed: number;
    totalProcessed: number;
  }>;
}

interface SummaryResponse {
  success: boolean;
  summary: {
    totalProcesses: number;
    totalRuns: number;
    totalRecordsProcessed: number;
    totalRecordsFailed: number;
    avgRunsPerDay: number;
    peakHour: { hour: number; runs: number };
  };
  trends: TrendData;
  topProcesses: Array<{
    name: string;
    runs: number;
    totalProcessed: number;
    totalFailed: number;
  }>;
  databaseInfo: DatabaseConfig;
  timestamp: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF7C7C'];

export function MetricsDashboard() {
  const [metricsData, setMetricsData] = useState<MetricsData[]>([]);
  const [summary, setSummary] = useState<MetricsSummary | null>(null);
  const [processSummary, setProcessSummary] = useState<ProcessSummary[]>([]);
  const [summaryData, setSummaryData] = useState<SummaryResponse | null>(null);
  const [databaseConfig, setDatabaseConfig] = useState<DatabaseConfig | null>(null);
  const [loading, setLoading] = useState(false);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(25);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof MetricsData;
    direction: 'asc' | 'desc';
  } | null>(null);
  
  const [connectionStatus, setConnectionStatus] = useState<{
    connected: boolean;
    testing: boolean;
    error?: string;
  }>({ connected: false, testing: false });
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'details' | 'trends'>('overview');

  const { toast } = useToast();

  const testDatabaseConnection = async () => {
    setConnectionStatus({ connected: false, testing: true });
    
    try {
      const response = await fetch('/api/metrics/test-connection');
      const result = await response.json();
      
      if (result.success) {
        setConnectionStatus({ connected: true, testing: false });
        toast({
          title: '✅ Database Connected',
          description: `Successfully connected to PostgreSQL database`,
        });
      } else {
        setConnectionStatus({ 
          connected: false, 
          testing: false, 
          error: result.error 
        });
        toast({
          title: '❌ Database Connection Failed',
          description: result.error || 'Unable to connect to PostgreSQL',
          variant: 'destructive',
        });
      }
    } catch (error) {
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Connection test failed'
      });
      toast({
        title: '❌ Connection Error',
        description: 'Failed to test database connection',
        variant: 'destructive',
      });
    }
  };

  const fetchMetrics = async () => {
    setLoading(true);
    
    try {
      // Fetch both DAG runs and summary data in parallel
      const [dagRunsResponse, summaryResponse] = await Promise.all([
        fetch('/api/metrics/dag-runs'),
        fetch('/api/metrics/summary')
      ]);

      if (dagRunsResponse.ok && summaryResponse.ok) {
        const dagRunsData: MetricsResponse = await dagRunsResponse.json();
        const summaryData: SummaryResponse = await summaryResponse.json();

        if (dagRunsData.success && summaryData.success) {
          setMetricsData(dagRunsData.data);
          setSummary(dagRunsData.summary);
          setProcessSummary(dagRunsData.processSummary);
          setSummaryData(summaryData);
          setDatabaseConfig(dagRunsData.databaseConfig);
          setLastRefresh(new Date());
          setConnectionStatus({ connected: true, testing: false });

          toast({
            title: '📊 Metrics Updated',
            description: `Loaded ${dagRunsData.data.length} records from PostgreSQL`,
          });
        } else {
          throw new Error(dagRunsData.error || summaryData.error || 'Failed to fetch metrics');
        }
      } else {
        throw new Error('Failed to fetch metrics data');
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
      toast({
        title: '❌ Metrics Error',
        description: error instanceof Error ? error.message : 'Failed to load metrics',
        variant: 'destructive',
      });
      setConnectionStatus({ connected: false, testing: false });
    } finally {
      setLoading(false);
    }
  };

  const refreshMetrics = async () => {
    await fetchMetrics();
  };

  useEffect(() => {
    // Test connection and fetch initial data
    const initialize = async () => {
      await testDatabaseConnection();
      await fetchMetrics();
    };
    
    initialize();
  }, []);

  // Auto-refresh every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      if (!loading) {
        fetchMetrics();
      }
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [loading]);

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getSuccessRateColor = (rate: string) => {
    const numRate = parseFloat(rate);
    if (numRate >= 95) return 'text-green-600';
    if (numRate >= 85) return 'text-yellow-600';
    return 'text-red-600';
  };

  // Pagination and sorting logic
  const sortedData = useMemo(() => {
    let sortableData = [...metricsData];
    if (sortConfig !== null) {
      sortableData.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
          return 0;
        }
        
        const aStr = String(aValue).toLowerCase();
        const bStr = String(bValue).toLowerCase();
        if (aStr < bStr) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aStr > bStr) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableData;
  }, [metricsData, sortConfig]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(metricsData.length / itemsPerPage);

  const handleSort = (key: keyof MetricsData) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const getSortIcon = (columnKey: keyof MetricsData) => {
    if (!sortConfig || sortConfig.key !== columnKey) {
      return <MoreHorizontal className="w-4 h-4 opacity-0 group-hover:opacity-50" />;
    }
    return sortConfig.direction === 'asc' ? 
      <TrendingUp className="w-4 h-4" /> : 
      <TrendingDown className="w-4 h-4" />;
  };

  const ConnectionStatusCard = () => (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center text-lg">
            <Database className="w-5 h-5 mr-2" />
            Database Connection
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={testDatabaseConnection}
            disabled={connectionStatus.testing}
          >
            {connectionStatus.testing ? (
              <RefreshCw className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-2" />
            )}
            Test Connection
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`w-3 h-3 rounded-full ${
              connectionStatus.testing ? 'bg-yellow-500 animate-pulse' :
              connectionStatus.connected ? 'bg-green-500' : 'bg-red-500'
            }`} />
            <div>
              <div className="font-medium">
                {connectionStatus.testing ? 'Testing Connection...' :
                 connectionStatus.connected ? 'Connected' : 'Disconnected'}
              </div>
              {databaseConfig && (
                <div className="text-sm text-muted-foreground">
                  {databaseConfig.host}:{databaseConfig.database} ({databaseConfig.deploymentMode})
                </div>
              )}
              {connectionStatus.error && (
                <div className="text-sm text-red-600 mt-1">
                  {connectionStatus.error}
                </div>
              )}
            </div>
          </div>
          {connectionStatus.connected && lastRefresh && (
            <div className="text-sm text-muted-foreground">
              Last refresh: {lastRefresh.toLocaleTimeString()}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  const TabNavigation = () => (
    <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6">
      {[
        { id: 'overview', label: 'Overview', icon: BarChart3 },
        { id: 'details', label: 'Process Details', icon: Database },
        { id: 'trends', label: 'Trends & Analytics', icon: LineChartIcon }
      ].map(tab => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id as typeof activeTab)}
          className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-all ${
            activeTab === tab.id 
              ? 'bg-background text-foreground shadow-sm' 
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          <tab.icon className="w-4 h-4" />
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );

  const OverviewTab = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {/* Summary Cards */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Runs</CardTitle>
          <Activity className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatNumber(summary?.totalRuns || 0)}</div>
          <p className="text-xs text-muted-foreground">
            Database executions
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Records Processed</CardTitle>
          <CheckCircle className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatNumber(summary?.totalRecordsProcessed || 0)}</div>
          <p className="text-xs text-muted-foreground">
            Total data records
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold ${getSuccessRateColor(summary?.successRate || '0%')}`}>
            {summary?.successRate || '0%'}
          </div>
          <p className="text-xs text-muted-foreground">
            Processing success
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Avg Records/Run</CardTitle>
          <BarChart3 className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{formatNumber(summary?.avgRecordsPerRun || 0)}</div>
          <p className="text-xs text-muted-foreground">
            Per execution
          </p>
        </CardContent>
      </Card>
    </div>
  );

  const ProcessDetailsTab = () => (
    <div className="space-y-6">
      {/* Process Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Process Performance Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={processSummary}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="processName" 
                angle={-45}
                textAnchor="end"
                height={100}
                fontSize={12}
              />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="totalProcessed" fill="#8884d8" name="Records Processed" />
              <Bar dataKey="totalFailed" fill="#ff7c7c" name="Records Failed" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Process Summary Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="w-5 h-5 mr-2" />
            Detailed Process Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {processSummary.map((process, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-lg">{process.processName}</h3>
                  <Badge variant={parseFloat(process.successRate) >= 95 ? 'default' : 'destructive'}>
                    {process.successRate}% Success
                  </Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">Total Runs</div>
                    <div className="font-medium">{formatNumber(process.totalRuns)}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Records Processed</div>
                    <div className="font-medium">{formatNumber(process.totalProcessed)}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Records Failed</div>
                    <div className="font-medium text-red-600">{formatNumber(process.totalFailed)}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Avg Per Run</div>
                    <div className="font-medium">{formatNumber(process.avgProcessed)}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const TrendsTab = () => (
    <div className="space-y-6">
      {summaryData && (
        <>
          {/* Hourly Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                Hourly Activity Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={summaryData.trends.hourly}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="hour" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="runs" 
                    stackId="1" 
                    stroke="#8884d8" 
                    fill="#8884d8" 
                    name="Total Runs"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="avgProcessed" 
                    stackId="2" 
                    stroke="#82ca9d" 
                    fill="#82ca9d" 
                    name="Avg Records"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Daily Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                Weekly Activity Patterns
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={summaryData.trends.daily}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="runs" fill="#8884d8" name="Total Runs" />
                  <Bar dataKey="totalProcessed" fill="#82ca9d" name="Total Records" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Processes */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2" />
                Top Performing Processes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <PieChart>
                  <Pie
                    data={summaryData.topProcesses.slice(0, 8)}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${formatNumber(value)}`}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="totalProcessed"
                  >
                    {summaryData.topProcesses.slice(0, 8).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );

  return (
    <div className="space-y-6 pb-24 pr-4 lg:pr-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Metrics Dashboard</h1>
          <p className="text-muted-foreground">PostgreSQL DAG Run Metrics & Analytics</p>
        </div>
        <Button
          onClick={refreshMetrics}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {loading ? (
            <RefreshCw className="w-4 h-4 animate-spin mr-2" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Refresh Data
        </Button>
      </div>

      {/* Connection Status */}
      <ConnectionStatusCard />

      {/* Tab Navigation */}
      <TabNavigation />

      {/* Tab Content */}
      {activeTab === 'overview' && <OverviewTab />}
      {activeTab === 'details' && <ProcessDetailsTab />}
      {activeTab === 'trends' && <TrendsTab />}

      {/* Recent Activity Table */}
      {metricsData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              Recent DAG Executions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Table Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    Showing {Math.min((currentPage - 1) * itemsPerPage + 1, metricsData.length)} - {' '}
                    {Math.min(currentPage * itemsPerPage, metricsData.length)} of {metricsData.length} entries
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(1)}
                    disabled={currentPage === 1}
                    className="hidden sm:flex"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="hidden sm:inline ml-1">Previous</span>
                  </Button>
                  <span className="px-3 py-1 text-sm border rounded">
                    {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <span className="hidden sm:inline mr-1">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(totalPages)}
                    disabled={currentPage === totalPages}
                    className="hidden sm:flex"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Responsive Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse bg-white">
                    <thead className="bg-muted/50">
                      <tr>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('processname')}
                        >
                          <div className="flex items-center gap-2">
                            Process Name
                            {getSortIcon('processname')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden md:table-cell"
                          onClick={() => handleSort('instanceid')}
                        >
                          <div className="flex items-center gap-2">
                            Instance ID
                            {getSortIcon('instanceid')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden lg:table-cell"
                          onClick={() => handleSort('execution_date')}
                        >
                          <div className="flex items-center gap-2">
                            Execution Date
                            {getSortIcon('execution_date')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('records_processed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            <span className="hidden sm:inline">Records</span> Processed
                            {getSortIcon('records_processed')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('records_failed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            <span className="hidden sm:inline">Records</span> Failed
                            {getSortIcon('records_failed')}
                          </div>
                        </th>
                        <th className="text-right p-3 font-medium">Success Rate</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedData.map((row, index) => {
                        const successRate = row.records_processed > 0 
                          ? ((row.records_processed - row.records_failed) / row.records_processed * 100).toFixed(1)
                          : '0.0';
                        
                        return (
                          <tr 
                            key={row.id} 
                            className={`border-b hover:bg-muted/30 transition-colors ${
                              index % 2 === 0 ? 'bg-white' : 'bg-muted/10'
                            }`}
                          >
                            <td className="p-3">
                              <div className="font-medium text-sm lg:text-base">
                                {row.processname}
                              </div>
                              {/* Mobile: Show additional info */}
                              <div className="md:hidden mt-1 space-y-1">
                                <div className="text-xs text-muted-foreground">
                                  ID: {row.instanceid}
                                </div>
                                <div className="text-xs text-muted-foreground lg:hidden">
                                  {formatDate(row.execution_date)}
                                </div>
                              </div>
                            </td>
                            <td className="p-3 text-muted-foreground text-sm hidden md:table-cell">
                              {row.instanceid}
                            </td>
                            <td className="p-3 text-sm hidden lg:table-cell">
                              {formatDate(row.execution_date)}
                            </td>
                            <td className="p-3 text-right font-medium text-sm lg:text-base">
                              <div className="text-green-700">
                                {formatNumber(row.records_processed)}
                              </div>
                            </td>
                            <td className="p-3 text-right font-medium text-sm lg:text-base">
                              <div className="text-red-600">
                                {formatNumber(row.records_failed)}
                              </div>
                            </td>
                            <td className="p-3 text-right">
                              <Badge 
                                variant={parseFloat(successRate) >= 95 ? "default" : parseFloat(successRate) >= 85 ? "secondary" : "destructive"}
                                className="text-xs"
                              >
                                {successRate}%
                              </Badge>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Mobile Pagination */}
              <div className="flex justify-center sm:hidden">
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="px-3 py-1 text-sm">
                    {currentPage} / {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {!loading && (!connectionStatus.connected || metricsData.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Database className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Metrics Data</h3>
            <p className="text-muted-foreground text-center mb-4">
              {!connectionStatus.connected 
                ? 'Please establish a database connection to view metrics'
                : 'No DAG run metrics found in the database'
              }
            </p>
            <Button onClick={testDatabaseConnection} variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
