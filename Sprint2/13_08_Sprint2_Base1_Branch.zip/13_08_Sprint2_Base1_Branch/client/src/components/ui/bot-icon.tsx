import React from 'react';

interface BotIconProps {
  className?: string;
  size?: number;
}

export const BotIcon: React.FC<BotIconProps> = ({ className = "", size = 20 }) => {
  return (
    <div 
      className={`inline-flex items-center justify-center rounded-full ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Cute bot icon with proper round corners and better visibility */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="rounded-full"
      >
        {/* Round background */}
        <circle cx="12" cy="12" r="12" fill="currentColor" opacity="0.1"/>
        
        {/* Bot head - rounded rectangle */}
        <rect x="6" y="7" width="12" height="10" rx="3" ry="3" fill="currentColor" opacity="0.8"/>
        
        {/* Antenna */}
        <line x1="12" y1="4" x2="12" y2="7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <circle cx="12" cy="3.5" r="1" fill="currentColor"/>
        
        {/* Eyes */}
        <circle cx="9.5" cy="10.5" r="1" fill="white"/>
        <circle cx="14.5" cy="10.5" r="1" fill="white"/>
        
        {/* Smile */}
        <path d="M 9 13.5 Q 12 15.5 15 13.5" stroke="white" strokeWidth="1" fill="none" strokeLinecap="round"/>
      </svg>
    </div>
  );
};

export default BotIcon;
