import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { 
  Settings, 
  Upload, 
  Code, 
  FileCode, 
  X, 
  CheckCircle,
  XCircle,
  BarChart3,
  Database,
  Activity,
  FileText,
  TrendingUp,
  ChevronDown,
  ChevronRight,
  Menu,
  Workflow,
  Archive,
  Play,
  Pause,
  LineChart,
  FileSearch,
  Shield,
  Upload as UploadIcon,
  Settings as SettingsIcon,
  CheckSquare,
  Edit3,
  Home,
  Users,
  Bell,
  Search
} from "lucide-react";
import { Step } from "@/pages/dag-generator";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  currentStep: Step;
  onStepChange: (step: Step) => void;
  isOpen: boolean;
  onClose: () => void;
  connectionStatus: {
    connected: boolean;
    url: string;
  };
}

interface MenuSection {
  id: string;
  title: string;
  icon: any;
  isExpanded: boolean;
  children: MenuChild[];
  badge?: string;
}

interface MenuChild {
  id: string;
  label: string;
  icon: any;
  step?: Step;
  description?: string;
  isNew?: boolean;
}

export function Sidebar({ 
  currentStep, 
  onStepChange, 
  isOpen, 
  onClose, 
  connectionStatus 
}: SidebarProps) {
  // Helper function to determine which section should be expanded based on current step
  const getSectionForStep = (step: Step): string => {
    const managementConsoleSteps = ['dashboard', 'migration-workspace', 'migration-metrics', 'reports'];
    const structuredDataSteps = ['upload', 'configure', 'editable-schema', 'view-xml-schema', 'transform-csv-upload'];
    
    if (managementConsoleSteps.includes(step)) {
      return 'migration-orchestration';
    } else if (structuredDataSteps.includes(step)) {
      return 'structured-data';
    }
    return 'migration-orchestration'; // default
  };

  const [expandedSections, setExpandedSections] = useState<string[]>([getSectionForStep(currentStep)]);
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Auto-collapse on mobile when clicking outside
  // Determine which section should be expanded based on current step
  useEffect(() => {
    // Determine which section should be expanded
    const targetSection = getSectionForStep(currentStep);
    
    // Always update to ensure the correct section is expanded
    setExpandedSections(prev => {
      // If the target section is already the only expanded section, no change needed
      if (prev.length === 1 && prev[0] === targetSection) {
        return prev;
      }
      // Otherwise, set only the target section as expanded
      return [targetSection];
    });

    const handleResize = () => {
      if (window.innerWidth >= 1024) { // lg breakpoint
        setIsCollapsed(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [currentStep]);

  const toggleSection = (title: string) => {
    setExpandedSections(prev => {
      const isCurrentlyExpanded = prev.includes(title);
      
      // If the section is currently expanded, just collapse it (empty array)
      if (isCurrentlyExpanded) {
        return [];
      }
      
      // If expanding this section, return array with only this section
      return [title];
    });
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
    if (!isCollapsed) {
      setExpandedSections([]);
    }
  };

  const menuSections: MenuSection[] = [
    {
      id: 'migration-orchestration',
      title: 'Management Console',
      icon: Workflow,
      isExpanded: expandedSections.includes('migration-orchestration'),
      children: [
        {
          id: 'migration-dashboard',
          label: 'Dashboard',
          icon: BarChart3,
          step: 'dashboard',
          //description: 'Monitor migration progress and metrics'
        },
        {
          id: 'migration-workspace',
          label: 'Jobs',
          icon: Activity,
          step: 'migration-workspace',
         // description: 'Manage active migration tasks'
        },
        {
          id: 'migration-metrics',
          label: 'Metrics',
          icon: LineChart,
          step: 'migration-metrics',
          //description: 'Analyze performance data',
          isNew: true
        },
        {
          id: 'migration-reports',
          label: 'Reports',
          icon: FileText,
          step: 'reports',
          //description: 'View detailed reports'
        }
      ]
    },
    {
      id: 'structured-data',
      title: 'Structured Data Archival',
      icon: Archive,
      isExpanded: expandedSections.includes('structured-data'),
      children: [
        {
          id: 'prerequisites-upload',
          label: 'Prerequisites & Source Data Upload',
          icon: UploadIcon,
          step: 'upload',
         // description: 'Upload source data and prerequisites'
        },
        {
          id: 'generate-schema',
          label: 'Generate Schema for InfoArchive',
          icon: SettingsIcon,
          step: 'configure',
        //  description: 'Configure data schema settings'
        },
        {
          id: 'editable-schema',
          label: 'Validate and Finalize Schema',
          icon: Edit3,
          step: 'editable-schema',
          //description: 'Review and validate schema configuration'
        },
        {
          id: 'view-xml-schema',
          label: 'View Download IA Schema',
          icon: FileCode,
          step: 'view-xml-schema',
          //description: 'Preview generated XML schema'
        },
        {
          id: 'transform-csv-upload',
          label: 'Table Data Ingestion to InfoArchive',
          icon: Upload,
          step: 'transform-csv-upload',
          //description: 'Upload transformed data to InfoArchive'
        }
      ]
    }
  ];

  return (
    <TooltipProvider>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      <div className={cn(
        "fixed inset-y-0 left-0 z-50 flex flex-col transition-all duration-300 ease-in-out",
        "lg:translate-x-0 lg:static lg:inset-0",
        isOpen ? "translate-x-0" : "-translate-x-full",
        isCollapsed ? "w-16" : "w-72",
        "bg-gradient-to-b from-background via-muted/50 to-background",
        "dark:from-slate-900 dark:via-slate-800 dark:to-slate-900",
        "border-r border-border shadow-2xl backdrop-blur-xl"
      )}>
        {/* Header */}
        <div className={cn(
          "flex items-center h-16 px-4 border-b border-border",
          "bg-gradient-to-r from-blue-50/50 to-purple-50/50",
          "dark:from-blue-600/20 dark:to-purple-600/20"
        )}>
          <div className="flex items-center space-x-3 flex-1">
            {!isCollapsed && (
              <div className="flex-1 min-w-0">
                <h1 className="text-lg font-bold text-foreground tracking-wide">Data Transformer</h1>
                <p className="text-xs text-muted-foreground font-medium truncate">Data Transformer</p>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-1">
            {/* Collapse toggle for desktop */}
            <Button
              variant="ghost"
              size="sm"
              className="hidden lg:flex text-muted-foreground hover:text-foreground hover:bg-muted w-8 h-8 p-0"
              onClick={toggleCollapse}
            >
              <Menu className="h-4 w-4" />
            </Button>
            
            {/* Close button for mobile */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden text-muted-foreground hover:text-foreground hover:bg-muted w-8 h-8 p-0"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 overflow-hidden">
          <div className="h-full overflow-y-auto sidebar-scrollbar">
            <nav className="p-3 space-y-2">
              {/* Quick Stats */}
            

              {/* Navigation Menu */}
              <div className="space-y-1">
                {menuSections.map((section) => (
                  <div key={section.id} className="space-y-1">
                    {/* Section Header */}
                    <button
                      onClick={() => toggleSection(section.id)}
                      className={cn(
                        "w-full flex items-center justify-between p-3 text-left rounded-xl transition-all duration-200",
                        "hover:bg-muted hover:shadow-lg group",
                        "border border-transparent hover:border-border",
                        section.isExpanded && !isCollapsed && "bg-muted/50 border-border"
                      )}
                    >
                      <div className="flex items-center space-x-3 flex-1 min-w-0">
                        <div className="relative">
                          <section.icon className={cn(
                            "w-5 h-5 transition-colors",
                            section.isExpanded ? "text-primary" : "text-muted-foreground",
                            "group-hover:text-foreground"
                          )} />
                        </div>
                        {!isCollapsed && (
                          <div className="flex-1 min-w-0">
                            <span className={cn(
                              "text-sm font-semibold block truncate transition-colors",
                              section.isExpanded ? "text-foreground" : "text-muted-foreground",
                              "group-hover:text-foreground"
                            )}>
                              {section.title}
                            </span>
                          </div>
                        )}
                      </div>
                      {!isCollapsed && (
                        <div className="flex items-center space-x-2">
                          {section.isExpanded ? (
                            <ChevronDown className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                          )}
                        </div>
                      )}
                    </button>

                    {/* Section Items */}
                    {(section.isExpanded || isCollapsed) && (
                      <div className={cn(
                        "space-y-1 transition-all duration-200",
                        !isCollapsed && "ml-4 pl-4 border-l-2 border-border"
                      )}>
                        {section.children.map((child) => (
                          <Tooltip key={child.id}>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => child.step && onStepChange(child.step)}
                                className={cn(
                                  "w-full flex items-start p-3 text-left rounded-lg transition-all duration-200 group",
                                  "hover:bg-muted hover:shadow-md hover:translate-x-1",
                                  currentStep === child.step 
                                    ? "bg-gradient-to-r from-primary/10 to-primary/5 border-l-4 border-primary shadow-lg" 
                                    : "text-muted-foreground hover:text-foreground",
                                  isCollapsed && "justify-center"
                                )}
                              >
                                <div className="relative">
                                  <child.icon className={cn(
                                    "w-5 h-5 transition-colors",
                                    currentStep === child.step ? "text-primary" : "text-muted-foreground",
                                    "group-hover:text-foreground"
                                  )} />
                                  {child.isNew && (
                                    <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full"></div>
                                  )}
                                </div>
                                {!isCollapsed && (
                                  <div className="ml-3 flex-1 min-w-0">
                                    <div className={cn(
                                      "text-sm font-medium flex items-center gap-2",
                                      currentStep === child.step ? "text-foreground" : "text-muted-foreground group-hover:text-foreground"
                                    )}>
                                      <span className="truncate">{child.label}</span>
                                     
                                    </div>
                                    {child.description && (
                                      <div className="text-xs text-muted-foreground/70 mt-1 group-hover:text-muted-foreground">
                                        {child.description}
                                      </div>
                                    )}
                                  </div>
                                )}
                                {currentStep === child.step && !isCollapsed && (
                                  <div className="w-2 h-2 bg-primary rounded-full mt-2 shadow-lg"></div>
                                )}
                              </button>
                            </TooltipTrigger>
                            <TooltipContent side="right" className="ml-2">
                              <p className="text-sm font-medium">{child.label}</p>
                              {child.description && (
                                <p className="text-xs text-muted-foreground mt-1">{child.description}</p>
                              )}
                            </TooltipContent>
                          </Tooltip>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </nav>
          </div>
        </div>

        {/* Footer */}
        {connectionStatus.connected && (
          <div className="border-t border-border p-3 bg-gradient-to-r from-muted/50 to-muted/30">
            {!isCollapsed ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Quick Actions</span>
                  <div className="flex items-center space-x-1">
                    <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                    <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                    <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-xs border-primary/30 text-primary hover:bg-primary/10 hover:text-primary hover:border-primary bg-primary/5"
                    onClick={() => onStepChange('dashboard')}
                  >
                    <BarChart3 className="mr-1 h-3 w-3" />
                    Dashboard
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-xs border-purple-500/30 text-purple-600 dark:text-purple-400 hover:bg-purple-500/10 hover:text-purple-700 dark:hover:text-purple-300 hover:border-purple-400 bg-purple-500/5"
                    onClick={() => onStepChange('upload')}
                  >
                    <Upload className="mr-1 h-3 w-3" />
                    Upload
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col space-y-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full h-10 p-0 text-primary hover:bg-primary/10"
                  onClick={() => onStepChange('dashboard')}
                >
                  <BarChart3 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full h-10 p-0 text-purple-600 dark:text-purple-400 hover:bg-purple-500/10"
                  onClick={() => onStepChange('upload')}
                >
                  <Upload className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}