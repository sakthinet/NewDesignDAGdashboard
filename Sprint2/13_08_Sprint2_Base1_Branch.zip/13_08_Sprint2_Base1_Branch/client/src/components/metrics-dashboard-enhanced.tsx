import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  Database,
  Activity,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  BarChart3,
  Target,
  AlertTriangle,
  FileText,
  Play,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  MoreHorizontal
} from 'lucide-react';

// IA Script Execution Data Types
interface IAExecutionData {
  id: number;
  script_name: string;
  execution_id: string;
  execution_date: string;
  status: 'success' | 'failed' | 'running' | 'pending';
  files_processed: number;
  files_failed: number;
  total_records: number;
  execution_time_ms: number;
  error_message?: string;
}

interface IAMetricsSummary {
  totalExecutions: number;
  totalFilesProcessed: number;
  totalFilesFailed: number;
  successRate: string;
  avgExecutionTime: number;
  avgFilesPerExecution: number;
}

interface IAScriptSummary {
  scriptName: string;
  totalExecutions: number;
  totalFilesProcessed: number;
  totalFilesFailed: number;
  avgExecutionTime: number;
  successRate: string;
  lastExecution: string;
}

interface DatabaseConfig {
  host: string;
  database: string;
  deploymentMode: string;
}

interface IAMetricsResponse {
  success: boolean;
  data: IAExecutionData[];
  summary: IAMetricsSummary;
  scriptSummary: IAScriptSummary[];
  databaseConfig: DatabaseConfig;
  timestamp: string;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

export function MetricsDashboard() {
  const [executionData, setExecutionData] = useState<IAExecutionData[]>([]);
  const [summary, setSummary] = useState<IAMetricsSummary | null>(null);
  const [scriptSummary, setScriptSummary] = useState<IAScriptSummary[]>([]);
  const [databaseConfig, setDatabaseConfig] = useState<DatabaseConfig | null>(null);
  const [loading, setLoading] = useState(false);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(25);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof IAExecutionData;
    direction: 'asc' | 'desc';
  } | null>(null);
  
  const [connectionStatus, setConnectionStatus] = useState<{
    connected: boolean;
    testing: boolean;
    error?: string;
  }>({ connected: false, testing: false });

  const [activeTab, setActiveTab] = useState<'overview' | 'details' | 'scripts'>('overview');
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const { toast } = useToast();

  const testDatabaseConnection = async () => {
    setConnectionStatus({ connected: false, testing: true });
    
    try {
      const response = await fetch('/api/ia-metrics/test-connection');
      const result = await response.json();
      
      if (result.success) {
        setConnectionStatus({ connected: true, testing: false });
        toast({
          title: '✅ Database Connected',
          description: `Successfully connected to IA database`,
        });
      } else {
        setConnectionStatus({ 
          connected: false, 
          testing: false, 
          error: result.error 
        });
        toast({
          title: '❌ Database Connection Failed',
          description: result.error || 'Unable to connect to PostgreSQL',
          variant: 'destructive',
        });
      }
    } catch (error) {
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Connection test failed'
      });
      toast({
        title: '❌ Connection Error',
        description: 'Failed to test database connection',
        variant: 'destructive',
      });
    }
  };

  const fetchMetrics = async () => {
    setLoading(true);
    
    try {
      const response = await fetch('/api/ia-metrics/executions');

      if (response.ok) {
        const data: IAMetricsResponse = await response.json();

        if (data.success) {
          setExecutionData(data.data);
          setSummary(data.summary);
          setScriptSummary(data.scriptSummary);
          setDatabaseConfig(data.databaseConfig);
          setLastRefresh(new Date());
          setConnectionStatus({ connected: true, testing: false });

          toast({
            title: '📊 IA Metrics Updated',
            description: `Loaded ${data.data.length} execution records`,
          });
        } else {
          throw new Error('Failed to fetch IA metrics');
        }
      } else {
        throw new Error('Failed to fetch IA metrics data');
      }
    } catch (error) {
      console.error('Error fetching IA metrics:', error);
      toast({
        title: '❌ Failed to Load IA Metrics',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive',
      });
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch metrics'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (connectionStatus.connected && !loading) {
      fetchMetrics();
    }
  }, [connectionStatus.connected]);

  // Auto-refresh every 2 minutes for IA metrics
  useEffect(() => {
    if (!connectionStatus.connected || loading) return;

    const interval = setInterval(() => {
      if (!loading) {
        fetchMetrics();
      }
    }, 2 * 60 * 1000);

    return () => clearInterval(interval);
  }, [loading]);

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const formatExecutionTime = (timeMs: number) => {
    if (timeMs < 1000) return `${timeMs}ms`;
    if (timeMs < 60000) return `${(timeMs / 1000).toFixed(1)}s`;
    return `${(timeMs / 60000).toFixed(1)}m`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-600';
      case 'failed': return 'text-red-600';
      case 'running': return 'text-blue-600';
      case 'pending': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success': return 'default';
      case 'failed': return 'destructive';
      case 'running': return 'secondary';
      case 'pending': return 'outline';
      default: return 'secondary';
    }
  };

  // Pagination and sorting logic
  const sortedData = useMemo(() => {
    let sortableData = [...executionData];
    if (sortConfig !== null) {
      sortableData.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
          return 0;
        }
        
        const aStr = String(aValue).toLowerCase();
        const bStr = String(bValue).toLowerCase();
        if (aStr < bStr) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aStr > bStr) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableData;
  }, [executionData, sortConfig]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(executionData.length / itemsPerPage);

  const handleSort = (key: keyof IAExecutionData) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const getSortIcon = (columnKey: keyof IAExecutionData) => {
    if (!sortConfig || sortConfig.key !== columnKey) {
      return <MoreHorizontal className="w-4 h-4 opacity-0 group-hover:opacity-50" />;
    }
    return sortConfig.direction === 'asc' ? 
      <TrendingUp className="w-4 h-4" /> : 
      <TrendingDown className="w-4 h-4" />;
  };

  // Initialize connection test
  useEffect(() => {
    testDatabaseConnection();
  }, []);

  // Loading state
  if (loading && executionData.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <h3 className="text-lg font-semibold mb-2">Loading IA Metrics</h3>
          <p className="text-muted-foreground">Connecting to PostgreSQL database...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 pr-4 lg:pr-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">IA Script Metrics</h1>
          <p className="text-muted-foreground">InfoArchive Script Execution Analytics</p>
        </div>
        <Button
          onClick={fetchMetrics}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {loading ? (
            <RefreshCw className="w-4 h-4 animate-spin mr-2" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Database className="w-5 h-5 mr-2" />
              Database Connection
              {databaseConfig && (
                <Badge variant="outline" className="ml-2">
                  {databaseConfig.deploymentMode.toUpperCase()}
                </Badge>
              )}
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={testDatabaseConnection}
              disabled={connectionStatus.testing}
            >
              {connectionStatus.testing ? (
                <RefreshCw className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Test Connection
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${
                connectionStatus.testing ? 'bg-yellow-500 animate-pulse' :
                connectionStatus.connected ? 'bg-green-500' : 'bg-red-500'
              }`} />
              <span className="font-medium">
                {connectionStatus.testing ? 'Testing...' :
                 connectionStatus.connected ? 'Connected' : 'Disconnected'}
              </span>
              {databaseConfig && (
                <span className="text-muted-foreground">
                  PostgreSQL @ {databaseConfig.host}
                </span>
              )}
              {lastRefresh && (
                <span className="text-muted-foreground text-sm">
                  Last updated: {lastRefresh.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>
          {connectionStatus.error && (
            <div className="mt-2 text-sm text-red-600 bg-red-50 p-2 rounded">
              {connectionStatus.error}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tab Navigation */}
      {connectionStatus.connected && executionData.length > 0 && (
        <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6">
          <Button
            variant={activeTab === 'overview' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('overview')}
            className="flex-1"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Overview
          </Button>
          <Button
            variant={activeTab === 'details' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('details')}
            className="flex-1"
          >
            <Activity className="w-4 h-4 mr-2" />
            Executions
          </Button>
          <Button
            variant={activeTab === 'scripts' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('scripts')}
            className="flex-1"
          >
            <FileText className="w-4 h-4 mr-2" />
            Scripts
          </Button>
        </div>
      )}

      {/* Overview Tab */}
      {activeTab === 'overview' && connectionStatus.connected && summary && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Executions</p>
                    <div className="text-2xl font-bold">{formatNumber(summary?.totalExecutions || 0)}</div>
                  </div>
                  <Play className="h-8 w-8 text-blue-500 ml-auto" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Files Processed</p>
                    <div className="text-2xl font-bold">{formatNumber(summary?.totalFilesProcessed || 0)}</div>
                  </div>
                  <FileText className="h-8 w-8 text-green-500 ml-auto" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                    <div className={`text-2xl font-bold ${getStatusColor('success')}`}>
                      {summary?.successRate || '0%'}
                    </div>
                  </div>
                  <Target className="h-8 w-8 text-purple-500 ml-auto" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Execution Time</p>
                    <div className="text-2xl font-bold">{formatExecutionTime(summary?.avgExecutionTime || 0)}</div>
                  </div>
                  <Clock className="h-8 w-8 text-orange-500 ml-auto" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Execution Status Distribution */}
          {executionData && executionData.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Execution Status Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={Object.entries(
                            executionData.reduce((acc, exec) => {
                              acc[exec.status] = (acc[exec.status] || 0) + 1;
                              return acc;
                            }, {} as Record<string, number>)
                          ).map(([status, count]) => ({ name: status, value: count }))}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, value }) => `${name}: ${value}`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {Object.keys(
                            executionData.reduce((acc, exec) => {
                              acc[exec.status] = true;
                              return acc;
                            }, {} as Record<string, boolean>)
                          ).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Execution Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={executionData.slice(0, 10).reverse()}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="script_name" angle={-45} textAnchor="end" height={60} />
                        <YAxis />
                        <Tooltip 
                          formatter={(value, name) => [
                            name === 'execution_time_ms' ? formatExecutionTime(Number(value)) : formatNumber(Number(value)), 
                            name === 'execution_time_ms' ? 'Execution Time' : 'Files Processed'
                          ]}
                        />
                        <Legend />
                        <Bar dataKey="files_processed" fill="#8884d8" name="Files Processed" />
                        <Bar dataKey="execution_time_ms" fill="#82ca9d" name="Execution Time (ms)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}

      {/* Scripts Performance Tab */}
      {activeTab === 'scripts' && scriptSummary && (
        <div className="space-y-6">
          {/* Script Performance Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {scriptSummary.slice(0, 6).map((script, index) => (
              <Card key={index}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    {script.scriptName}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Executions:</span>
                    <span className="font-medium">{formatNumber(script.totalExecutions)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Files Processed:</span>
                    <span className="font-medium text-green-600">{formatNumber(script.totalFilesProcessed)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Files Failed:</span>
                    <span className="font-medium text-red-600">{formatNumber(script.totalFilesFailed)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Avg Time:</span>
                    <span className="font-medium">{formatExecutionTime(script.avgExecutionTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Success Rate:</span>
                    <Badge variant={parseFloat(script.successRate) >= 95 ? "default" : "secondary"}>
                      {script.successRate}%
                    </Badge>
                  </div>
                  <div className="pt-2 border-t">
                    <span className="text-xs text-muted-foreground">
                      Last: {formatDate(script.lastExecution)}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Script Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Script Performance Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={scriptSummary.slice(0, 10)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="scriptName" angle={-45} textAnchor="end" height={80} />
                    <YAxis yAxisId="files" orientation="left" />
                    <YAxis yAxisId="time" orientation="right" />
                    <Tooltip 
                      formatter={(value, name) => [
                        String(name).includes('Time') ? formatExecutionTime(Number(value)) : formatNumber(Number(value)), 
                        String(name).includes('Time') ? 'Execution Time' : name
                      ]}
                    />
                    <Legend />
                    <Bar yAxisId="files" dataKey="totalFilesProcessed" fill="#8884d8" name="Files Processed" />
                    <Bar yAxisId="files" dataKey="totalFilesFailed" fill="#ff7c7c" name="Files Failed" />
                    <Bar yAxisId="time" dataKey="avgExecutionTime" fill="#82ca9d" name="Avg Execution Time (ms)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Details Tab - IA Execution Records */}
      {activeTab === 'details' && connectionStatus.connected && executionData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              Recent IA Script Executions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Table Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    Showing {Math.min((currentPage - 1) * itemsPerPage + 1, executionData.length)} to{' '}
                    {Math.min(currentPage * itemsPerPage, executionData.length)} of {executionData.length} entries
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(1)}
                    disabled={currentPage === 1}
                    className="hidden sm:flex"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="hidden sm:inline ml-1">Previous</span>
                  </Button>
                  <span className="px-3 py-1 text-sm border rounded">
                    {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <span className="hidden sm:inline mr-1">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(totalPages)}
                    disabled={currentPage === totalPages}
                    className="hidden sm:flex"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Responsive Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse bg-white">
                    <thead className="bg-muted/50">
                      <tr>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('script_name')}
                        >
                          <div className="flex items-center gap-2">
                            Script Name
                            {getSortIcon('script_name')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden md:table-cell"
                          onClick={() => handleSort('execution_id')}
                        >
                          <div className="flex items-center gap-2">
                            Execution ID
                            {getSortIcon('execution_id')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden lg:table-cell"
                          onClick={() => handleSort('execution_date')}
                        >
                          <div className="flex items-center gap-2">
                            Execution Date
                            {getSortIcon('execution_date')}
                          </div>
                        </th>
                        <th className="text-center p-3 font-medium">Status</th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('files_processed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            <span className="hidden sm:inline">Files</span> Processed
                            {getSortIcon('files_processed')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('execution_time_ms')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            Duration
                            {getSortIcon('execution_time_ms')}
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedData.map((row, index) => (
                        <tr 
                          key={row.id} 
                          className={`border-b hover:bg-muted/30 transition-colors ${
                            index % 2 === 0 ? 'bg-white' : 'bg-muted/10'
                          }`}
                        >
                          <td className="p-3">
                            <div className="font-medium text-sm lg:text-base">
                              {row.script_name}
                            </div>
                            {/* Mobile: Show additional info */}
                            <div className="md:hidden mt-1 space-y-1">
                              <div className="text-xs text-muted-foreground">
                                ID: {row.execution_id}
                              </div>
                              <div className="text-xs text-muted-foreground lg:hidden">
                                {formatDate(row.execution_date)}
                              </div>
                            </div>
                          </td>
                          <td className="p-3 text-muted-foreground text-sm hidden md:table-cell">
                            {row.execution_id}
                          </td>
                          <td className="p-3 text-sm hidden lg:table-cell">
                            {formatDate(row.execution_date)}
                          </td>
                          <td className="p-3 text-center">
                            <Badge variant={getStatusBadge(row.status)}>
                              {row.status}
                            </Badge>
                          </td>
                          <td className="p-3 text-right font-medium text-sm lg:text-base">
                            <div className="text-green-700">
                              {formatNumber(row.files_processed)}
                            </div>
                            {row.files_failed > 0 && (
                              <div className="text-xs text-red-600">
                                {formatNumber(row.files_failed)} failed
                              </div>
                            )}
                          </td>
                          <td className="p-3 text-right font-medium text-sm lg:text-base">
                            <div className="text-blue-700">
                              {formatExecutionTime(row.execution_time_ms)}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Mobile Pagination */}
              <div className="flex justify-center sm:hidden">
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="px-3 py-1 text-sm">
                    {currentPage} / {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {!loading && (!connectionStatus.connected || executionData.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Database className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No IA Execution Data</h3>
            <p className="text-muted-foreground text-center mb-4">
              {!connectionStatus.connected 
                ? 'Please establish a database connection to view IA script metrics'
                : 'No InfoArchive script execution records found in the database'
              }
            </p>
            <Button onClick={testDatabaseConnection} variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
