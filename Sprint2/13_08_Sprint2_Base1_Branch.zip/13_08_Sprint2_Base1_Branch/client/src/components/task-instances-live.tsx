import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Activity, Clock, CheckCircle, XCircle, AlertCircle, Play, Pause } from "lucide-react";
import { useAirflowApi } from '@/hooks/use-airflow-api';
import { TaskInstance, DAGRun } from '@/hooks/use-airflow-api';
import { TaskInstanceState, DAGRunState } from '@/types/airflow';
import { getStateColor, getStateIcon, getStateDescription } from '@/utils/airflow-utils';

interface TaskInstancesLiveProps {
  dagId: string;
  runId?: string;
  autoRefresh?: boolean;
  refreshInterval?: number;
  onTaskClick?: (task: TaskInstance) => void;
  className?: string;
}

interface TaskInstanceDisplay extends TaskInstance {
  formattedDuration?: string;
  formattedStartDate?: string;
  formattedEndDate?: string;
  stateColor?: string;
  stateIcon?: React.ReactNode;
  stateDescription?: string;
  log_url?: string;
}

export function TaskInstancesLive({ 
  dagId, 
  runId, 
  autoRefresh = false, // Always disabled
  refreshInterval = 0, // Always disabled
  onTaskClick,
  className = ""
}: TaskInstancesLiveProps) {
  const [taskInstances, setTaskInstances] = useState<TaskInstanceDisplay[]>([]);
  const [dagRuns, setDagRuns] = useState<DAGRun[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string>(runId || '');
  const [isLoading, setIsLoading] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const airflowApi = useAirflowApi();
  const mountedRef = useRef(true);

  // Format task instance data for display
  const formatTaskInstance = useCallback((task: TaskInstance): TaskInstanceDisplay => {
    const formatDate = (dateStr: string) => {
      if (!dateStr) return 'N/A';
      try {
        return new Date(dateStr).toLocaleString();
      } catch {
        return dateStr;
      }
    };

    const formatDuration = (start: string, end: string) => {
      if (!start || !end) return 'N/A';
      try {
        const startTime = new Date(start).getTime();
        const endTime = new Date(end).getTime();
        const durationMs = endTime - startTime;
        const seconds = Math.floor(durationMs / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        
        if (hours > 0) {
          return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        } else if (minutes > 0) {
          return `${minutes}m ${seconds % 60}s`;
        } else {
          return `${seconds}s`;
        }
      } catch {
        return 'N/A';
      }
    };

    const stateColor = getStateColor(task.state as TaskInstanceState);
    const stateIcon = getStateIcon(task.state as TaskInstanceState);
    const stateDescription = getStateDescription(task.state as TaskInstanceState);

    return {
      ...task,
      formattedDuration: formatDuration(task.start_date, task.end_date),
      formattedStartDate: formatDate(task.start_date),
      formattedEndDate: formatDate(task.end_date),
      stateColor,
      stateIcon,
      stateDescription,
      log_url: `#/log?dag_id=${dagId}&task_id=${task.task_id}&execution_date=${task.execution_date}&try_number=${task.try_number || 1}`
    };
  }, [dagId]);

  // Fetch DAG runs
  const fetchDagRuns = useCallback(async () => {
    if (!dagId) return;
    
    try {
      const result = await airflowApi.getDagRuns(dagId, 10, 0, true);
      
      if (result && result.runs) {
        setDagRuns(result.runs);
        
        // Set the first run as selected if no run is specified
        if (!selectedRunId && result.runs.length > 0) {
          const firstRunId = result.runs[0].dag_run_id;
          setSelectedRunId(firstRunId);
        }
      }
    } catch (error) {
      console.error('Failed to fetch Workflow runs:', error);
      setError(`Failed to fetch Workflow runs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }, [dagId, selectedRunId, airflowApi]);

  // Fetch task instances for the selected run - MANUAL ONLY
  const fetchTaskInstances = useCallback(async (forceRefresh = false) => {
    if (!dagId || !selectedRunId) {
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await airflowApi.getTaskInstances(dagId, selectedRunId, forceRefresh);
      
      if (!mountedRef.current) return;
      
      if (result && result.task_instances) {
        const formattedTasks = result.task_instances.map(formatTaskInstance);
        setTaskInstances(formattedTasks);
        setLastRefresh(new Date());
      } else {
        setTaskInstances([]);
      }
    } catch (error) {
      console.error('Failed to fetch task instances:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(`Failed to fetch task instances: ${errorMessage}`);
    } finally {
      if (mountedRef.current) {
        setIsLoading(false);
      }
    }
  }, [dagId, selectedRunId, airflowApi, formatTaskInstance]);

  // Handle manual refresh
  const handleManualRefresh = useCallback(() => {
    setError(null);
    fetchTaskInstances(true);
  }, [fetchTaskInstances]);

  // Handle DAG run selection
  const handleRunChange = useCallback((newRunId: string) => {
    setSelectedRunId(newRunId);
    setTaskInstances([]); // Clear previous data
    setError(null);
  }, []);

  // Reset mounted ref when component mounts
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  // Initial data fetch - DAG runs only
  useEffect(() => {
    fetchDagRuns();
  }, [fetchDagRuns]);

  // Fetch task instances when selectedRunId changes - MANUAL ONLY
  useEffect(() => {
    if (selectedRunId) {
      fetchTaskInstances(false);
    }
  }, [selectedRunId]); // Remove fetchTaskInstances from dependencies to prevent loops

  // Component unmount cleanup
  useEffect(() => {
    return () => {
      mountedRef.current = false;
    };
  }, []);

  return (
    <div className={`space-y-4 ${className}`}>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <CardTitle>Task Instances</CardTitle>
              {selectedRunId && (
                <span className="text-sm text-gray-500">for run: {selectedRunId}</span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                disabled={isLoading || !selectedRunId}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
          <CardDescription>
            Real-time monitoring of task execution for DAG: {dagId}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* DAG Run Selection */}
          {dagRuns.length > 0 && (
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">DAG Run:</label>
              <select
                value={selectedRunId}
                onChange={(e) => handleRunChange(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md"
              >
                {dagRuns.map((run) => (
                  <option key={run.dag_run_id} value={run.dag_run_id}>
                    {run.dag_run_id} ({run.state}) - {new Date(run.execution_date).toLocaleString()}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Loading State */}
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin mr-2" />
              Loading task instances...
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <div className="flex items-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <span className="text-red-700">{error}</span>
              </div>
            </div>
          )}

          {/* Task Instances */}
          {!isLoading && !error && taskInstances.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                <span>Tasks: {taskInstances.length}</span>
                {lastRefresh && (
                  <span>Last updated: {lastRefresh.toLocaleTimeString()}</span>
                )}
              </div>

              <div className="space-y-2">
                {taskInstances.map((task) => (
                  <div
                    key={task.task_id}
                    className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                    onClick={() => onTaskClick?.(task)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center">
                          {task.stateIcon}
                          <Badge className={`ml-2 ${task.stateColor}`}>
                            {task.state}
                          </Badge>
                        </div>
                        <div>
                          <div className="font-medium">{task.task_id}</div>
                          <div className="text-sm text-gray-500">
                            Try {task.try_number || 1}
                          </div>
                        </div>
                      </div>
                      <div className="text-right text-sm">
                        <div>Duration: {task.formattedDuration}</div>
                        <div className="text-gray-500">
                          Started: {task.formattedStartDate}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* No Data State */}
          {!isLoading && !error && taskInstances.length === 0 && selectedRunId && (
            <div className="text-center py-8">
              <Activity className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500">No task instances found for this run</p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                className="mt-2"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          )}

          {/* No Run Selected */}
          {!selectedRunId && dagRuns.length === 0 && !isLoading && (
            <div className="text-center py-8">
              <Activity className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500">No DAG runs found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
