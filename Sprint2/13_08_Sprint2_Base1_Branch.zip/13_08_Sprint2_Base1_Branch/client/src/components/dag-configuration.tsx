import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  ArrowLeft, 
  ArrowRight, 
  Upload, 
  FileText, 
  Settings, 
  CheckCircle, 
  AlertCircle,
  FolderOpen,
  Folder,
  Database,
  Server,
  HardDrive,
  File,
  Zap,
  Loader2,
  XCircle,
  RefreshCw,
  FolderCheck
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// API request function - make sure this matches your actual API client
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

// Types
interface DagConfig {
  dagId: string;
  inputDirectory: string;
  outputDirectory: string;
  csvFileName: string;
  description: string;
  scheduleInterval: string;
  dagsDirectory: string;
  chunkSize: number;
}

interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

interface DagConfigurationProps {
  config: DagConfig;
  onConfigChange: (config: DagConfig) => void;
  onNext: () => void;
  onPrev: () => void;
  onGenerate: (script: string) => void;
  uploadedFile: UploadedFile | null;
}

// File move status type
type FileMoveStatus = 'idle' | 'moving' | 'success' | 'error';

export function DagConfiguration({ 
  config, 
  onConfigChange, 
  onNext, 
  onPrev, 
  onGenerate,
  uploadedFile 
}: DagConfigurationProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [isCheckingDuplicate, setIsCheckingDuplicate] = useState(false);
  const [dagIdExists, setDagIdExists] = useState(false);
  const [duplicateCheckMessage, setDuplicateCheckMessage] = useState<string>('');
  
  // Enhanced file move tracking
  const [fileMoveStatus, setFileMoveStatus] = useState<FileMoveStatus>('idle');
  const [fileMoveError, setFileMoveError] = useState<string>('');
  const [lastMovedFile, setLastMovedFile] = useState<string>('');
  const [currentFileLocation, setCurrentFileLocation] = useState<string>('');
  
  const { toast } = useToast();

  // Enhanced validation functions that match backend requirements
  const validateDagId = (dagId: string): { isValid: boolean; message?: string } => {
    if (!dagId || dagId.trim().length === 0) {
      return { isValid: false, message: "DAG ID is required" };
    }
    
    if (dagId.length < 3) {
      return { isValid: false, message: "DAG ID must be at least 3 characters long" };
    }

    // Must start with a letter (not underscore or number)
    if (!/^[a-zA-Z]/.test(dagId)) {
      return { isValid: false, message: "DAG ID must start with a letter" };
    }
    
    // Can only contain letters, numbers, and underscores
    if (!/^[a-zA-Z][a-zA-Z0-9_]*$/.test(dagId)) {
      return { isValid: false, message: "DAG ID can only contain letters, numbers, and underscores, and must start with a letter" };
    }

    // Should not end with underscore
    if (dagId.endsWith('_')) {
      return { isValid: false, message: "DAG ID should not end with an underscore" };
    }
    
    return { isValid: true };
  };

  const validatePaths = (inputDirectory: string, outputDirectory: string, dagsDirectory: string): { isValid: boolean; message?: string } => {
    if (!inputDirectory || !outputDirectory || !dagsDirectory) {
      return { isValid: false, message: "All directories are required" };
    }
    
    if (inputDirectory.trim() === outputDirectory.trim()) {
      // Input and output directories can be the same, but warn user
      console.log("Note: Input and output directories are the same");
    }

    // Basic path validation - should be valid directory paths
    const pathRegex = /^[a-zA-Z]:[\\\/]|^[\\\/]|^[a-zA-Z0-9]/;
    if (!pathRegex.test(inputDirectory)) {
      return { isValid: false, message: "Input directory path format is invalid" };
    }
    
    if (!pathRegex.test(outputDirectory)) {
      return { isValid: false, message: "Output directory path format is invalid" };
    }

    if (!pathRegex.test(dagsDirectory)) {
      return { isValid: false, message: "DAGs directory path format is invalid" };
    }
    
    return { isValid: true };
  };

  const validateScheduleInterval = (schedule: string): { isValid: boolean; message?: string } => {
    if (!schedule || schedule === 'None') {
      return { isValid: true };
    }

    const validPresets = ['@daily', '@hourly', '@weekly', '@monthly', '@yearly'];
    if (validPresets.includes(schedule)) {
      return { isValid: true };
    }

    // Basic cron validation (5 parts separated by spaces)
    const cronRegex = /^(\*|[0-9,\-\/\*]+)\s+(\*|[0-9,\-\/\*]+)\s+(\*|[0-9,\-\/\*]+)\s+(\*|[0-9,\-\/\*]+)\s+(\*|[0-9,\-\/\*]+)$/;
    if (!cronRegex.test(schedule)) {
      return { isValid: false, message: "Invalid schedule format. Use cron format (e.g., '0 9 * * *') or presets (@daily, @hourly, etc.)" };
    }
    
    return { isValid: true };
  };

  // DAG ID uniqueness check
  const checkDagIdUniqueness = useCallback(async (dagId: string) => {
    if (!dagId || dagId.trim().length === 0) {
      setDagIdExists(false);
      setDuplicateCheckMessage('');
      return;
    }

    // Only check if DAG ID format is valid
    const formatValidation = validateDagId(dagId);
    if (!formatValidation.isValid) {
      setDagIdExists(false);
      setDuplicateCheckMessage('');
      return;
    }

    setIsCheckingDuplicate(true);
    setDuplicateCheckMessage('Checking...');

    try {
      const response = await apiRequest('POST', '/api/check-dag-id', {
        dagId: dagId.trim()
      });

      if (response.ok) {
        const result = await response.json();
        
        if (result.isUnique === false) {
          setDagIdExists(true);
          setDuplicateCheckMessage(result.message || `DAG ID "${dagId}" already exists`);
        } else {
          setDagIdExists(false);
          setDuplicateCheckMessage('Available');
        }
      } else {
        // If API call fails, assume we can't check and allow it
        setDagIdExists(false);
        setDuplicateCheckMessage('Unable to verify');
      }
    } catch (error) {
      console.error('Failed to check DAG ID uniqueness:', error);
      setDagIdExists(false);
      setDuplicateCheckMessage('Unable to verify');
    } finally {
      setIsCheckingDuplicate(false);
    }
  }, []);

  // Debounced DAG ID uniqueness check
  useEffect(() => {
    const timer = setTimeout(() => {
      if (config.dagId && config.dagId.trim().length >= 3) {
        checkDagIdUniqueness(config.dagId);
      } else {
        setDagIdExists(false);
        setDuplicateCheckMessage('');
      }
    }, 800); // 800ms delay to avoid too many API calls

    return () => clearTimeout(timer);
  }, [config.dagId, checkDagIdUniqueness]);

  const isFormValid = (): boolean => {
    const requiredFields = [
      config.dagId,
      config.inputDirectory,
      config.outputDirectory,
      config.dagsDirectory
    ];

    const allFieldsFilled = requiredFields.every(field => 
      field && field.trim().length > 0
    );

    const dagIdValid = validateDagId(config.dagId).isValid;
    const pathsValid = validatePaths(config.inputDirectory, config.outputDirectory, config.dagsDirectory).isValid;
    const scheduleValid = validateScheduleInterval(config.scheduleInterval).isValid;
    const dagIdUnique = !dagIdExists; // DAG ID must be unique

    return allFieldsFilled && dagIdValid && pathsValid && scheduleValid && dagIdUnique;
  };

  const isFormValidDetailed = (): { isValid: boolean; errors: string[] } => {
    const errors: string[] = [];
    
    const dagIdValidation = validateDagId(config.dagId);
    if (!dagIdValidation.isValid && dagIdValidation.message) {
      errors.push(dagIdValidation.message);
    }

    // Add duplicate check to validation errors
    if (dagIdExists) {
      errors.push(duplicateCheckMessage || "DAG ID already exists");
    }
    
    const pathsValidation = validatePaths(config.inputDirectory, config.outputDirectory, config.dagsDirectory);
    if (!pathsValidation.isValid && pathsValidation.message) {
      errors.push(pathsValidation.message);
    }
    
    const scheduleValidation = validateScheduleInterval(config.scheduleInterval);
    if (!scheduleValidation.isValid && scheduleValidation.message) {
      errors.push(scheduleValidation.message);
    }
    
    return {
      isValid: errors.length === 0,
      errors
    };
  };

  // Auto-fix DAG ID to make it valid
  const autoFixDagId = (dagId: string): string => {
    if (!dagId) return '';
    
    // Remove leading non-letters
    let fixed = dagId.replace(/^[^a-zA-Z]+/, '');
    
    // If empty after removing leading non-letters, start with 'dag'
    if (!fixed) {
      fixed = 'dag_' + dagId.replace(/[^a-zA-Z0-9_]/g, '_');
    }
    
    // Replace invalid characters with underscores
    fixed = fixed.replace(/[^a-zA-Z0-9_]/g, '_');
    
    // Remove multiple consecutive underscores
    fixed = fixed.replace(/_+/g, '_');
    
    // Remove trailing underscores
    fixed = fixed.replace(/_+$/, '');
    
    // Ensure minimum length
    if (fixed.length < 3) {
      fixed = fixed + '_dag';
    }
    
    return fixed;
  };

  // Real-time validation
  useEffect(() => {
    const validation = isFormValidDetailed();
    setValidationErrors(validation.errors);
  }, [config, dagIdExists, duplicateCheckMessage]);

  const handleConfigChange = (field: keyof DagConfig, value: string | number) => {
    let processedValue = value;
    // Auto-fix DAG ID if needed
    if (field === 'dagId') {
      processedValue = value as string;
    }
    if (field === 'chunkSize') {
      processedValue = Number(value);
    }
    onConfigChange({
      ...config,
      [field]: processedValue
    });
  };

  // Default chunk size if not set
  useEffect(() => {
    if (typeof config.chunkSize !== 'number' || isNaN(config.chunkSize) || config.chunkSize < 1) {
      onConfigChange({
        ...config,
        chunkSize: 10
      });
    }
  }, []);

  const handleDagIdBlur = () => {
    if (config.dagId && !validateDagId(config.dagId).isValid) {
      const fixedDagId = autoFixDagId(config.dagId);
      if (fixedDagId !== config.dagId) {
        onConfigChange({
          ...config,
          dagId: fixedDagId
        });
        toast({
          title: "DAG ID auto-corrected",
          description: `Changed to: ${fixedDagId}`,
        });
      }
    }
  };

  // Auto-populate default paths on component mount
  useEffect(() => {
    const defaultDagsPath = "C:\\Docker\\airflow3x2\\dags";
    
    // Set default DAGs directory if not already set
    if (!config.dagsDirectory) {
      onConfigChange({
        ...config,
        dagsDirectory: defaultDagsPath
      });
    }
  }, []);

  // FIXED: Enhanced file move function that uses configured paths
  const moveFileToConfiguredDirectory = useCallback(async (
    targetFile: UploadedFile, 
    targetDirectory: string,
    showToastOnSuccess = true
  ): Promise<boolean> => {
    if (!targetFile || !targetDirectory) {
      console.warn('Cannot move file: missing file or target directory');
      return false;
    }

    // Skip if file is already in the correct location
    const expectedPath = `${targetDirectory}\\${targetFile.fileName}`;
    if (currentFileLocation === expectedPath) {
      console.log('File already in correct location:', expectedPath);
      return true;
    }

    setFileMoveStatus('moving');
    setFileMoveError('');
    
    try {
      console.log('=== MOVING FILE TO CONFIGURED DIRECTORY ===');
      console.log('Source file:', targetFile.fileName);
      console.log('Target directory:', targetDirectory);
      console.log('Full target path:', expectedPath);

      const movePayload = {
        fileName: targetFile.fileName,
        targetPath: expectedPath,
        createDirectoryIfNotExists: true
      };
      
      console.log('Move payload:', movePayload);

      const response = await apiRequest('POST', '/api/move-file-to-data', movePayload);

      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { message: errorText };
        }
        throw new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();

      if (result.success) {
        setFileMoveStatus('success');
        setLastMovedFile(targetFile.fileName);
        setCurrentFileLocation(expectedPath);
        
        if (showToastOnSuccess) {
          toast({
            title: "File moved successfully",
            description: `${targetFile.fileName} moved to ${targetDirectory}`,
          });
        }
        
        console.log('✅ File move successful:', result);
        return true;
      } else {
        throw new Error(result.message || 'Move operation reported failure');
      }

    } catch (error) {
      console.error('File move failed:', error);
      setFileMoveStatus('error');
      setFileMoveError(error instanceof Error ? error.message : String(error));
      
      toast({
        title: "File move failed",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive",
      });
      
      return false;
    }
  }, [toast, currentFileLocation]);

  // FIXED: Auto-setup paths when file is uploaded (but don't move file yet)
  useEffect(() => {
    if (uploadedFile) {
      console.log('=== FILE UPLOAD DETECTED ===');
      console.log('Uploaded file:', uploadedFile);
      
      const autoSetupPaths = () => {
        const defaultDataPath = "C:\\Docker\\airflow3x2\\data";
        const defaultDagsPath = "C:\\Docker\\airflow3x2\\dags";
        
        console.log('Setting up default paths:');
        console.log('CSV file:', uploadedFile.fileName);
        console.log('DAGs directory:', defaultDagsPath);

        // Set default paths if not already configured
        const newConfig = {
          ...config,
          csvFileName: uploadedFile.fileName,
          dagsDirectory: config.dagsDirectory || defaultDagsPath
        };

        // Only set default directories if they're completely empty
        if (!config.inputDirectory || config.inputDirectory.trim() === '') {
          newConfig.inputDirectory = defaultDataPath;
        }
        if (!config.outputDirectory || config.outputDirectory.trim() === '') {
          newConfig.outputDirectory = defaultDataPath;
        }

        onConfigChange(newConfig);
      };

      // Set up default paths first
      autoSetupPaths();
      
      // Reset file move status for new file
      setFileMoveStatus('idle');
      setFileMoveError('');
      setLastMovedFile('');
      setCurrentFileLocation('');
    }
  }, [uploadedFile]); // Only depend on uploadedFile

  // Manual file move function
  const handleManualMoveFile = async () => {
    if (!uploadedFile) {
      toast({
        title: "No file uploaded",
        description: "Please upload a CSV file first",
        variant: "destructive",
      });
      return;
    }

    if (!config.inputDirectory) {
      toast({
        title: "No target directory",
        description: "Please set the input directory first",
        variant: "destructive",
      });
      return;
    }

    await moveFileToConfiguredDirectory(uploadedFile, config.inputDirectory, true);
  };

  // File verification function
  const handleVerifyFile = async () => {
    if (!config.inputDirectory || !config.csvFileName) {
      toast({
        title: "Missing information",
        description: "Please set the input directory and CSV file name first",
        variant: "destructive",
      });
      return;
    }

    try {
      const filePath = `${config.inputDirectory}\\${config.csvFileName}`;
      const response = await apiRequest('POST', '/api/verify-file-exists', {
        filePath: filePath
      });

      const result = await response.json();

      if (result.exists) {
        setCurrentFileLocation(filePath);
        toast({
          title: "File verified",
          description: `File exists (${(result.fileSize / 1024).toFixed(1)} KB)`,
        });
      } else {
        toast({
          title: "File not found",
          description: "File does not exist at the specified path",
          variant: "destructive",
        });
      }

    } catch (error) {
      toast({
        title: "Verification failed",
        description: "Could not verify file existence",
        variant: "destructive",
      });
    }
  };

  // Debug function to check upload directories
  const handleDebugUploads = async () => {
    try {
      const response = await apiRequest('GET', '/api/debug-uploads');
      const result = await response.json();
      console.log('Upload directories debug:', result);
      
      toast({
        title: "Debug info logged",
        description: "Check browser console for upload directory details",
      });
    } catch (error) {
      console.error('Debug failed:', error);
    }
  };

  const handleGenerate = async () => {
    const validation = isFormValidDetailed();
    
    if (!validation.isValid) {
      const errorMessage = validation.errors.join(', ');
      toast({
        title: "Configuration incomplete",
        description: errorMessage,
        variant: "destructive",
      });
      return;
    }

    // Additional check for DAG ID uniqueness before generation
    if (dagIdExists) {
      toast({
        title: "DAG ID already exists",
        description: duplicateCheckMessage || "Please choose a different DAG ID",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    try {
      console.log('=== STARTING DAG GENERATION PROCESS ===');
      console.log('Config to use:', config);

      // FIXED: Move file to configured input directory before generating DAG
      if (uploadedFile && config.inputDirectory) {
        console.log('=== MOVING FILE TO CONFIGURED INPUT DIRECTORY ===');
        console.log('Moving file:', uploadedFile.fileName);
        console.log('To directory:', config.inputDirectory);
        
        const moveSuccess = await moveFileToConfiguredDirectory(
          uploadedFile, 
          config.inputDirectory, 
          true // Show toast on completion
        );
        
        if (!moveSuccess) {
          toast({
            title: "File move failed",
            description: "Cannot generate DAG without moving file to input directory",
            variant: "destructive",
          });
          return;
        }
        
        console.log('✅ File successfully moved to configured directory');
        
        // Small delay to ensure file system operations complete
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      console.log('Generating DAG with config:', config);
      
      // Generate the DAG
      const response = await apiRequest('POST', '/api/generate-dag', config);
      
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        
        try {
          const errorJson = JSON.parse(errorText);
          if (errorJson.message) {
            errorMessage = errorJson.message;
          }
          if (errorJson.errors && Array.isArray(errorJson.errors)) {
            const fieldErrors = errorJson.errors.map((err: any) => 
              `${err.field}: ${err.message}`
            ).join(', ');
            errorMessage = `Validation errors: ${fieldErrors}`;
          }
        } catch (parseError) {
          errorMessage = errorText || errorMessage;
        }
        
        throw new Error(errorMessage);
      }
      
      const result = await response.json();
      
      if (result.success && result.dagScript) {
        console.log('DAG script generated successfully');
        
        // Auto-save the generated DAG to directory
        try {
          const saveResponse = await apiRequest('POST', '/api/save-dag', {
            dagId: config.dagId,
            dagScript: result.dagScript,
            dagsDirectory: config.dagsDirectory
          });
          
          if (!saveResponse.ok) {
            throw new Error('Failed to save DAG');
          }
          
          const saveResult = await saveResponse.json();
          if (saveResult.success) {
            console.log('DAG auto-deployed successfully');
            toast({
              title: "DAG generated and deployed",
              description: `DAG script generated, file moved to ${config.inputDirectory}, and saved to Airflow directory`,
            });
          } else {
            console.warn('Auto-deployment failed:', saveResult.message);
            toast({
              title: "DAG generated",
              description: "DAG script generated and file moved, but auto-deployment failed. You can manually deploy it.",
            });
          }
        } catch (saveError) {
          console.error('Auto-deployment error:', saveError);
          toast({
            title: "DAG generated",
            description: "DAG script generated and file moved, but auto-deployment failed. You can manually deploy it.",
          });
        }
        
        onGenerate(result.dagScript);
      } else {
        throw new Error(result.message || 'Failed to generate DAG script');
      }
    } catch (error) {
      console.error('Generation failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to generate DAG';
      toast({
        title: "Generation failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const scheduleOptions = [
    { value: 'None', label: 'None (Manual trigger only)' },
    { value: '@daily', label: 'Daily' },
    { value: '@hourly', label: 'Hourly' },
    { value: '@weekly', label: 'Weekly' },
    { value: '@monthly', label: 'Monthly' },
    { value: '0 */6 * * *', label: 'Every 6 hours' },
    { value: '0 9 * * 1-5', label: 'Weekdays at 9 AM' },
    { value: '0 0 * * 0', label: 'Weekly on Sunday' },
  ];

  const suggestedDagId = config.dagId ? autoFixDagId(config.dagId) : '';
  const showDagIdSuggestion = config.dagId && !validateDagId(config.dagId).isValid && suggestedDagId !== config.dagId;

  // Helper to get file status display
  const getFileStatusDisplay = () => {
    if (!uploadedFile) return null;
    
    if (fileMoveStatus === 'moving') {
      return (
        <div className="flex items-center text-blue-600 text-xs">
          <Loader2 className="mr-1 h-3 w-3 animate-spin" />
          Moving file to configured directory...
        </div>
      );
    }
    
    if (fileMoveStatus === 'success') {
      return (
        <div className="flex items-center text-blue-600 text-xs">
          <FolderCheck className="mr-1 h-3 w-3" />
          File ready in: {config.inputDirectory}
        </div>
      );
    }
    
    if (fileMoveStatus === 'error') {
      return (
        <div className="flex items-center text-red-600 text-xs">
          <XCircle className="mr-1 h-3 w-3" />
          Move failed: {fileMoveError}
        </div>
      );
    }
    
    // Default state - file uploaded but not moved yet
    return (
      <div className="flex items-center text-orange-600 text-xs">
        <Upload className="mr-1 h-3 w-3" />
        File uploaded - will move to "{config.inputDirectory}" when DAG is generated
      </div>
    );
  };

  return (
    <div className="max-w-4xl">
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Configuration */}
        <div className="lg:col-span-2 space-y-6">
          {/* DAG Identity */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader className="flex flex-row items-center space-y-0 pb-4">
              <Settings className="mr-2 h-5 w-5 text-blue-600" />
              <CardTitle className="text-lg font-semibold text-slate-800">DAG Identity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="dagId" className="text-sm font-medium text-gray-700">
                  DAG ID <span className="text-red-500">*</span>
                </Label>
                <div className="relative">
                  <Input
                    id="dagId"
                    value={config.dagId}
                    onChange={(e) => handleConfigChange('dagId', e.target.value)}
                    onBlur={handleDagIdBlur}
                    placeholder="my_csv_to_xml_dag"
                    className={`mt-1 ${dagIdExists ? 'border-red-500' : ''}`}
                  />
                  {isCheckingDuplicate && (
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      <Loader2 className="h-4 w-4 animate-spin text-gray-400" />
                    </div>
                  )}
                </div>

                {/* DAG ID validation messages */}
                {config.dagId && !validateDagId(config.dagId).isValid && (
                  <div className="mt-1">
                    <p className="text-xs text-red-500">
                      {validateDagId(config.dagId).message}
                    </p>
                    {showDagIdSuggestion && (
                      <div className="mt-2 p-2 bg-blue-50 rounded border border-blue-200">
                        <p className="text-xs text-blue-700">
                          Suggested: <span className="font-mono">{suggestedDagId}</span>
                        </p>
                        <Button
                          size="sm"
                          variant="outline"
                          className="mt-1 text-xs h-6"
                          onClick={() => handleConfigChange('dagId', suggestedDagId)}
                        >
                          Use suggestion
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                {/* DAG ID uniqueness check result */}
                {config.dagId && validateDagId(config.dagId).isValid && duplicateCheckMessage && (
                  <div className={`mt-1 flex items-center text-xs ${
                    dagIdExists ? 'text-red-600' : 'text-blue-600'
                  }`}>
                    {dagIdExists ? (
                      <>
                        <XCircle className="mr-1 h-3 w-3" />
                        {duplicateCheckMessage}
                      </>
                    ) : (
                      <>
                        <CheckCircle className="mr-1 h-3 w-3" />
                        {duplicateCheckMessage}
                      </>
                    )}
                  </div>
                )}

                <p className="text-xs text-gray-500 mt-1">
                  Must start with a letter, contain only letters, numbers, and underscores
                </p>
              </div>

              <div>
                <Label htmlFor="description" className="text-sm font-medium text-gray-700">
                  Description
                </Label>
                <Textarea
                  id="description"
                  value={config.description}
                  onChange={(e) => handleConfigChange('description', e.target.value)}
                  placeholder="Convert CSV files to XML format for downstream processing"
                  className="mt-1"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="scheduleInterval" className="text-sm font-medium text-gray-700">
                  Schedule Interval
                </Label>
                <Select value={config.scheduleInterval} onValueChange={(value) => handleConfigChange('scheduleInterval', value)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select schedule" />
                  </SelectTrigger>
                  <SelectContent>
                    {scheduleOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {config.scheduleInterval && !validateScheduleInterval(config.scheduleInterval).isValid && (
                  <p className="text-xs text-red-500 mt-1">
                    {validateScheduleInterval(config.scheduleInterval).message}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* File Paths */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader className="flex flex-row items-center space-y-0 pb-4">
              <FolderOpen className="mr-2 h-5 w-5 text-blue-600" />
              <CardTitle className="text-lg font-semibold text-slate-800">File Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="inputDirectory" className="text-sm font-medium text-gray-700 flex items-center">
                    <Database className="mr-1 h-4 w-4" />
                    Input Directory <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="inputDirectory"
                    value={config.inputDirectory}
                    onChange={(e) => handleConfigChange('inputDirectory', e.target.value)}
                    placeholder="C:\Docker\airflow3x2\data"
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Directory containing CSV files
                  </p>
                  {/* ADDED: File status display */}
                  {uploadedFile && (
                    <div className="mt-2">
                      {getFileStatusDisplay()}
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="outputDirectory" className="text-sm font-medium text-gray-700 flex items-center">
                    <FileText className="mr-1 h-4 w-4" />
                    Output Directory <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="outputDirectory"
                    value={config.outputDirectory}
                    onChange={(e) => handleConfigChange('outputDirectory', e.target.value)}
                    placeholder="C:\Docker\airflow3x2\data"
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Directory for generated XML files
                  </p>
                </div>
              </div>

              <div>
                <Label htmlFor="csvFileName" className="text-sm font-medium text-gray-700 flex items-center">
                  <FileText className="mr-1 h-4 w-4" />
                  CSV File Pattern
                </Label>
                <Input
                  id="csvFileName"
                  value={config.csvFileName}
                  onChange={(e) => handleConfigChange('csvFileName', e.target.value)}
                  placeholder="*.csv (process all CSV files) or specific_file.csv"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Use *.csv to process all CSV files, or specify a particular file name
                </p>
                {config.csvFileName && (
                  <p className="text-xs text-blue-600 mt-1 flex items-center">
                    <CheckCircle className="mr-1 h-3 w-3" />
                    Will process: {config.csvFileName === '*.csv' || config.csvFileName === '' ? 'All CSV files in directory' : config.csvFileName}
                  </p>
                )}
              </div>

              <div>
                <Label htmlFor="dagsDirectory" className="text-sm font-medium text-gray-700 flex items-center">
                  <Folder className="mr-1 h-4 w-4" />
                  Airflow DAGs Directory <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="dagsDirectory"
                  value={config.dagsDirectory}
                  onChange={(e) => handleConfigChange('dagsDirectory', e.target.value)}
                  placeholder="C:\Docker\airflow3x2\dags"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Directory where DAG files are stored (auto-populated)
                </p>
              </div>

              {/* CHUNK_SIZE Option */}
              <div>
                <Label htmlFor="chunkSize" className="text-sm font-medium text-gray-700 flex items-center">
                  <Zap className="mr-1 h-4 w-4 text-yellow-600" />
                  Chunk Size <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="chunkSize"
                  type="number"
                  min={1}
                  value={config.chunkSize}
                  onChange={(e) => handleConfigChange('chunkSize', e.target.value)}
                  placeholder="5000"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Number of rows per chunk when processing CSV files (default: 5000)
                </p>
              </div>

              {/* ADDED: File management actions */}
              {uploadedFile && (
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between">
                    <div className="text-sm font-medium text-gray-700">
                      File Management Actions
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleManualMoveFile}
                        disabled={fileMoveStatus === 'moving' || !config.inputDirectory}
                      >
                        {fileMoveStatus === 'moving' ? (
                          <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                        ) : (
                          <RefreshCw className="mr-1 h-3 w-3" />
                        )}
                        Move File
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleVerifyFile}
                        disabled={!config.inputDirectory || !config.csvFileName}
                      >
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Verify
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Use these actions to manually move or verify your uploaded file
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Configuration Summary */}
        <div className="space-y-6">
          {/* Validation Status */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800 flex items-center">
                {validationErrors.length === 0 ? (
                  <CheckCircle className="mr-2 h-4 w-4 text-blue-600" />
                ) : (
                  <AlertCircle className="mr-2 h-4 w-4 text-red-600" />
                )}
                Validation Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              {validationErrors.length === 0 ? (
                <div className="flex items-center text-blue-600">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  <span className="text-sm">All validations passed</span>
                </div>
              ) : (
                <div className="space-y-2">
                  {validationErrors.map((error, index) => (
                    <div key={index} className="flex items-start text-red-600">
                      <AlertCircle className="mr-2 h-4 w-4 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{error}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Configuration Preview */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Configuration Preview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-xs space-y-2">
                <div>
                  <span className="font-medium text-gray-700">DAG ID:</span>
                  <div className={`text-gray-600 break-all font-mono ${dagIdExists ? 'text-red-600' : ''}`}>
                    {config.dagId || 'Not set'}
                    {dagIdExists && (
                      <span className="text-red-600 ml-2">(Already exists)</span>
                    )}
                  </div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Schedule:</span>
                  <div className="text-gray-600">{config.scheduleInterval || 'Not set'}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Input Directory:</span>
                  <div className="text-gray-600 break-all">{config.inputDirectory || 'Not set'}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Output Directory:</span>
                  <div className="text-gray-600 break-all">{config.outputDirectory || 'Not set'}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">CSV File:</span>
                  <div className="text-gray-600 break-all">{config.csvFileName || '*.csv (all files)'}</div>
                </div>
                {/* UPDATED: File status in preview */}
                {uploadedFile && (
                  <div>
                    <span className="font-medium text-gray-700">File Status:</span>
                    <div className="text-gray-600">
                      {fileMoveStatus === 'success' ? `Ready in ${config.inputDirectory}` :
                       fileMoveStatus === 'moving' ? 'Moving to input directory...' :
                       fileMoveStatus === 'error' ? 'Move failed - will retry on generate' :
                       `Uploaded - will move to input directory on generate`}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="shadow-sm border border-gray-200">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={handleGenerate}
                disabled={!isFormValid() || isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Generate & Deploy DAG
                  </>
                )}
              </Button>
              
              <div className="text-xs text-gray-500 text-center">
                {uploadedFile ? 
                  `This will move ${uploadedFile.fileName} to ${config.inputDirectory}, generate the DAG script, and deploy it to Airflow` :
                  'This will generate the DAG script and automatically deploy it to Airflow'
                }
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-between mt-8">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Upload
        </Button>
        <Button 
          onClick={onNext}
          disabled={!isFormValid()}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Review Configuration
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}