import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  Database,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  MoreHorizontal
} from 'lucide-react';

interface MetricsData {
  id: number;
  processname: string;
  instanceid: string;
  execution_date: string;
  records_processed: number;
  records_failed: number;
}

export function MetricsDashboard() {
  const [metricsData, setMetricsData] = useState<MetricsData[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(15);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof MetricsData;
    direction: 'asc' | 'desc';
  } | null>(null);
  
  const [connectionStatus, setConnectionStatus] = useState<{
    connected: boolean;
    testing: boolean;
    error?: string;
  }>({ connected: false, testing: false });

  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const { toast } = useToast();

  const testDatabaseConnection = async () => {
    setConnectionStatus({ connected: false, testing: true });
    
    try {
      const response = await fetch('/api/metrics/test-connection');
      const result = await response.json();
      
      if (result.success) {
        setConnectionStatus({ connected: true, testing: false });
        toast({
          title: '✅ Database Connected',
          description: `Successfully connected to PostgreSQL database`,
        });
      } else {
        setConnectionStatus({ 
          connected: false, 
          testing: false, 
          error: result.error 
        });
        toast({
          title: '❌ Database Connection Failed',
          description: result.error || 'Unable to connect to PostgreSQL',
          variant: 'destructive',
        });
      }
    } catch (error) {
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Connection test failed'
      });
      toast({
        title: '❌ Connection Error',
        description: 'Failed to test database connection',
        variant: 'destructive',
      });
    }
  };

  const fetchMetrics = async () => {
    setLoading(true);
    
    try {
      const response = await fetch('/api/metrics/dag-runs');

      if (response.ok) {
        const data = await response.json();

        if (data.success) {
          setMetricsData(data.data);
          setLastRefresh(new Date());
          setConnectionStatus({ connected: true, testing: false });

          toast({
            title: '📊 Metrics Updated',
            description: `Loaded ${data.data.length} records from public.dag_run_metrics`,
          });
        } else {
          throw new Error(data.error || 'Failed to fetch metrics');
        }
      } else {
        throw new Error('Failed to fetch metrics data');
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
      toast({
        title: '❌ Failed to Load Metrics',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive',
      });
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch metrics'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    testDatabaseConnection();
  }, []);

  useEffect(() => {
    if (connectionStatus.connected && !loading) {
      fetchMetrics();
    }
  }, [connectionStatus.connected]);

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // Pagination and sorting logic
  const sortedData = useMemo(() => {
    let sortableData = [...metricsData];
    if (sortConfig !== null) {
      sortableData.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
          return 0;
        }
        
        const aStr = String(aValue).toLowerCase();
        const bStr = String(bValue).toLowerCase();
        if (aStr < bStr) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aStr > bStr) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return sortableData;
  }, [metricsData, sortConfig]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(metricsData.length / itemsPerPage);

  const handleSort = (key: keyof MetricsData) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const getSortIcon = (columnKey: keyof MetricsData) => {
    if (!sortConfig || sortConfig.key !== columnKey) {
      return <MoreHorizontal className="w-4 h-4 opacity-0 group-hover:opacity-50" />;
    }
    return sortConfig.direction === 'asc' ? 
      <TrendingUp className="w-4 h-4" /> : 
      <TrendingDown className="w-4 h-4" />;
  };

  // Loading state
  if (loading && metricsData.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <h3 className="text-lg font-semibold mb-2">Loading Metrics</h3>
          <p className="text-muted-foreground">Connecting to PostgreSQL database...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 pr-4 lg:pr-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Metrics Dashboard</h1>
          <p className="text-muted-foreground">Metrics Table</p>
        </div>
        <Button
          onClick={fetchMetrics}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {loading ? (
            <RefreshCw className="w-4 h-4 animate-spin mr-2" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Database className="w-5 h-5 mr-2" />
              Database Connection
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={testDatabaseConnection}
              disabled={connectionStatus.testing}
            >
              {connectionStatus.testing ? (
                <RefreshCw className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Test Connection
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-3 h-3 rounded-full ${
                connectionStatus.testing ? 'bg-yellow-500 animate-pulse' :
                connectionStatus.connected ? 'bg-green-500' : 'bg-red-500'
              }`} />
              <span className="font-medium">
                {connectionStatus.testing ? 'Testing...' :
                 connectionStatus.connected ? 'Connected' : 'Disconnected'}
              </span>
              {lastRefresh && (
                <span className="text-muted-foreground text-sm">
                  Last updated: {lastRefresh.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>
          {connectionStatus.error && (
            <div className="mt-2 text-sm text-red-600 bg-red-50 p-2 rounded">
              {connectionStatus.error}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Table */}
      {connectionStatus.connected && metricsData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="w-5 h-5 mr-2" />
              Workspace Metrics Data
              <Badge variant="outline" className="ml-2">
                {metricsData.length} records
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Table Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    Showing {Math.min((currentPage - 1) * itemsPerPage + 1, metricsData.length)} - {' '}
                    {Math.min(currentPage * itemsPerPage, metricsData.length)} of {metricsData.length} entries
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(1)}
                    disabled={currentPage === 1}
                    className="hidden sm:flex"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="hidden sm:inline ml-1">Previous</span>
                  </Button>
                  <span className="px-3 py-1 text-sm border rounded">
                    {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <span className="hidden sm:inline mr-1">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(totalPages)}
                    disabled={currentPage === totalPages}
                    className="hidden sm:flex"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse bg-white">
                    <thead className="bg-muted/50">
                      <tr>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('id')}
                        >
                          <div className="flex items-center gap-2">
                            ID
                            {getSortIcon('id')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('processname')}
                        >
                          <div className="flex items-center gap-2">
                            Process Name
                            {getSortIcon('processname')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden md:table-cell"
                          onClick={() => handleSort('instanceid')}
                        >
                          <div className="flex items-center gap-2">
                            Instance ID
                            {getSortIcon('instanceid')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden lg:table-cell"
                          onClick={() => handleSort('execution_date')}
                        >
                          <div className="flex items-center gap-2">
                            Execution Date
                            {getSortIcon('execution_date')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('records_processed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            Records Processed
                            {getSortIcon('records_processed')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('records_failed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            Records Failed
                            {getSortIcon('records_failed')}
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedData.map((row, index) => (
                        <tr 
                          key={row.id} 
                          className={`border-b hover:bg-muted/30 transition-colors ${
                            index % 2 === 0 ? 'bg-white' : 'bg-muted/10'
                          }`}
                        >
                          <td className="p-3 font-medium">{row.id}</td>
                          <td className="p-3">
                            <div className="font-medium text-sm lg:text-base">
                              {row.processname}
                            </div>
                            {/* Mobile: Show additional info */}
                            <div className="md:hidden mt-1 space-y-1">
                              <div className="text-xs text-muted-foreground">
                                ID: {row.instanceid}
                              </div>
                              <div className="text-xs text-muted-foreground lg:hidden">
                                {formatDate(row.execution_date)}
                              </div>
                            </div>
                          </td>
                          <td className="p-3 text-muted-foreground text-sm hidden md:table-cell">
                            {row.instanceid}
                          </td>
                          <td className="p-3 text-sm hidden lg:table-cell">
                            {formatDate(row.execution_date)}
                          </td>
                          <td className="p-3 text-right font-medium text-sm lg:text-base">
                            <div className="text-green-700">
                              {formatNumber(row.records_processed)}
                            </div>
                          </td>
                          <td className="p-3 text-right font-medium text-sm lg:text-base">
                            <div className="text-red-600">
                              {formatNumber(row.records_failed)}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {!loading && (!connectionStatus.connected || metricsData.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Database className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Metrics Data</h3>
            <p className="text-muted-foreground text-center mb-4">
              {!connectionStatus.connected 
                ? 'Please establish a database connection to view metrics'
                : 'No DAG run metrics found in the database'
              }
            </p>
            <Button onClick={testDatabaseConnection} variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Test Connection
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
