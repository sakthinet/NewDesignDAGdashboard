// Modern font loader for the application
// Ensures the app uses consistent, modern fonts across all platforms

/**
 * Loads the Inter font from Google Fonts
 * Inter is a modern, clean font designed for UI interfaces
 */
export function loadModernFonts() {
  // Only run this in the browser
  if (typeof window === 'undefined') return;
  
  // Check if fonts are already loaded
  if (document.getElementById('modern-font-loader')) return;
  
  // Create link element for Google Fonts
  const fontLink = document.createElement('link');
  fontLink.id = 'modern-font-loader';
  fontLink.rel = 'stylesheet';
  fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
  
  // Add font link to head
  document.head.appendChild(fontLink);
  
  // Apply Inter font to body and root
  document.documentElement.style.fontFamily = 
    "'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif";
  document.body.style.fontFamily = 
    "'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif";
  
  console.log('🔤 Modern fonts loaded: Inter');
}

/**
 * Apply modern typography settings
 */
export function applyModernTypography() {
  // Apply modern typography settings
  document.documentElement.style.textRendering = 'optimizeLegibility';
  
  // Using CSS custom properties for webkit and moz prefixed properties
  document.documentElement.style.setProperty('-webkit-font-smoothing', 'antialiased');
  document.documentElement.style.setProperty('-moz-osx-font-smoothing', 'grayscale');
  
  // Adjust letter spacing for better readability
  document.documentElement.style.letterSpacing = '-0.011em';
  
  console.log('📝 Modern typography settings applied');
}

/**
 * Initialize modern fonts and typography
 */
export function initModernFonts() {
  loadModernFonts();
  applyModernTypography();
}

export default initModernFonts;
