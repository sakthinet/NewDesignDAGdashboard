#!/usr/bin/env node

/**
 * Production Server Launcher
 * Serves the built application with API endpoints
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS manually
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files from dist/public
app.use(express.static(path.join(__dirname, 'dist', 'public')));

// Import and use API routes from the built server
async function startServer() {
  try {
    console.log('🚀 Starting production server...');
    
    // Check if the built server exists
    const serverPath = path.join(__dirname, 'dist', 'index.js');
    
    try {
      // Import the built server routes
      const { default: serverApp } = await import('./dist/index.js');
      
      // Use the API routes from the built server
      // The built server should export the app with routes configured
      if (serverApp && typeof serverApp.handle === 'function') {
        app.use('/api', serverApp);
      } else {
        console.warn('⚠️ Built server not found, setting up basic API proxy...');
        setupBasicApiProxy();
      }
    } catch (error) {
      console.warn('⚠️ Could not load built server:', error.message);
      setupBasicApiProxy();
    }

    // Fallback: serve index.html for all non-API routes (SPA routing)
    app.get('*', (req, res) => {
      if (!req.path.startsWith('/api')) {
        res.sendFile(path.join(__dirname, 'dist', 'public', 'index.html'));
      } else {
        res.status(404).json({ error: 'API endpoint not found' });
      }
    });

    app.listen(PORT, () => {
      console.log(`✅ Production server running at http://localhost:${PORT}`);
      console.log(`📁 Serving static files from: ${path.join(__dirname, 'dist', 'public')}`);
      console.log(`🔗 API available at: http://localhost:${PORT}/api`);
      console.log('');
      console.log('🌐 Available endpoints:');
      console.log(`   • Application: http://localhost:${PORT}`);
      console.log(`   • Health Check: http://localhost:${PORT}/api/health`);
      console.log(`   • Airflow Test: http://localhost:${PORT}/api/test-airflow`);
    });

  } catch (error) {
    console.error('❌ Failed to start production server:', error);
    process.exit(1);
  }
}

function setupBasicApiProxy() {
  console.log('🔧 Setting up basic API proxy to development server...');
  
  // Basic health check
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      mode: 'production-proxy',
      timestamp: new Date().toISOString()
    });
  });

  // Proxy critical API calls to the actual Airflow instance
  app.get('/api/test-airflow', async (req, res) => {
    try {
      // Read environment configuration
      const config = {
        baseUrl: process.env.VITE_AIRFLOW_URL || 'http://10.73.88.101:8080',
        username: process.env.NETWORK_AIRFLOW_USERNAME || 'airflow',
        password: process.env.NETWORK_AIRFLOW_PASSWORD || 'airflow'
      };

      console.log(`🔧 Testing Airflow connection to: ${config.baseUrl}`);

      // Authenticate with Airflow
      const authResponse = await fetch(`${config.baseUrl}/auth/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: config.username,
          password: config.password
        })
      });

      if (!authResponse.ok) {
        throw new Error(`Authentication failed: ${authResponse.status}`);
      }

      const authData = await authResponse.json();
      const token = authData.access_token;

      // Test API access
      const versionResponse = await fetch(`${config.baseUrl}/api/v2/version`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!versionResponse.ok) {
        throw new Error(`Version check failed: ${versionResponse.status}`);
      }

      const versionData = await versionResponse.json();

      res.json({
        connected: true,
        status: versionData,
        url: config.baseUrl,
        token: '✓ Valid JWT Token',
        apiVersion: '/api/v2',
        authMethod: 'JWT Bearer Token (Airflow 3.x)'
      });

    } catch (error) {
      console.error('❌ Airflow connection test failed:', error);
      res.json({
        connected: false,
        error: error.message,
        url: process.env.VITE_AIRFLOW_URL || 'http://10.73.88.101:8080'
      });
    }
  });

  // Add other essential API endpoints as needed
  app.all('/api/*', (req, res) => {
    res.status(503).json({
      error: 'Service Unavailable',
      message: 'This API endpoint requires the full server. Please run with the complete build.',
      suggestion: 'Use "npm run start:network" for full functionality'
    });
  });
}

// Start the server
startServer();
