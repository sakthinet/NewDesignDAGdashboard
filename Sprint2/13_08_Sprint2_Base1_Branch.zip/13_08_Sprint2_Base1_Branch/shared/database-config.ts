/**
 * Database Configuration Management System
 * Centralized configuration for all database connections including PostgreSQL metrics
 */

import { getUnifiedServerConfig } from './config-unified';

export interface PostgreSQLConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
  ssl?: boolean;
  max?: number; // max connections in pool
  idleTimeoutMillis?: number;
  connectionTimeoutMillis?: number;
}

export interface DatabaseConfig {
  postgresql: {
    metrics: PostgreSQLConfig;
  };
  sqlite: {
    url: string;
  };
  configuration: {
    queryTimeout: number;
    cacheTimeout: number;
    retryAttempts: number;
    retryDelay: number;
  };
}

// Helper function to get environment variable with default
function getEnvVar(name: string, defaultValue: string): string {
  return process.env[name] || defaultValue;
}

// Helper function to get environment variable as number
function getEnvNumber(name: string, defaultValue: number): number {
  const value = process.env[name];
  return value ? parseInt(value, 10) : defaultValue;
}

// Helper function to get environment variable as boolean
function getEnvBoolean(name: string, defaultValue: boolean): boolean {
  const value = process.env[name]?.toLowerCase();
  if (value === undefined) return defaultValue;
  return value === 'true' || value === '1' || value === 'yes';
}

/**
 * Get PostgreSQL configuration based on deployment mode
 */
export function getPostgreSQLConfig(): PostgreSQLConfig {
  const { deploymentMode } = getUnifiedServerConfig();
  const isNetwork = deploymentMode === 'network';
  
  console.log(`🔧 Loading PostgreSQL config for ${deploymentMode} deployment mode`);
  
  const config: PostgreSQLConfig = {
    host: getEnvVar(
      isNetwork ? 'NETWORK_POSTGRES_HOST' : 'LOCAL_POSTGRES_HOST',
      isNetwork ? '10.73.88.101' : 'localhost'
    ),
    port: getEnvNumber(
      isNetwork ? 'NETWORK_POSTGRES_PORT' : 'LOCAL_POSTGRES_PORT',
      5432
    ),
    database: getEnvVar(
      isNetwork ? 'NETWORK_POSTGRES_DATABASE' : 'LOCAL_POSTGRES_DATABASE',
      'RND'
    ),
    user: getEnvVar(
      isNetwork ? 'NETWORK_POSTGRES_USER' : 'LOCAL_POSTGRES_USER',
      'postgres'
    ),
    password: getEnvVar(
      isNetwork ? 'NETWORK_POSTGRES_PASSWORD' : 'LOCAL_POSTGRES_PASSWORD',
      isNetwork ? 'postgres' : 'admin@12345'
    ),
    ssl: getEnvBoolean(
      isNetwork ? 'NETWORK_POSTGRES_SSL' : 'LOCAL_POSTGRES_SSL',
      isNetwork ? true : false
    ),
    max: getEnvNumber('POSTGRES_MAX_CONNECTIONS', 10),
    idleTimeoutMillis: getEnvNumber('POSTGRES_IDLE_TIMEOUT', 30000),
    connectionTimeoutMillis: getEnvNumber('POSTGRES_CONNECTION_TIMEOUT', 5000)
  };
  
  console.log(`📊 PostgreSQL Config:`, {
    host: config.host,
    port: config.port,
    database: config.database,
    user: config.user,
    deploymentMode,
    ssl: config.ssl
  });
  
  return config;
}

/**
 * Get complete database configuration
 */
export function getDatabaseConfig(): DatabaseConfig {
  const config: DatabaseConfig = {
    postgresql: {
      metrics: getPostgreSQLConfig()
    },
    sqlite: {
      url: getEnvVar('DATABASE_URL', 'sqlite:./local.db')
    },
    configuration: {
      queryTimeout: getEnvNumber('METRICS_QUERY_TIMEOUT', 30000),
      cacheTimeout: getEnvNumber('METRICS_CACHE_TTL', 300),
      retryAttempts: getEnvNumber('DB_RETRY_ATTEMPTS', 3),
      retryDelay: getEnvNumber('DB_RETRY_DELAY', 1000)
    }
  };
  
  return config;
}

/**
 * Create PostgreSQL connection string
 */
export function createPostgreSQLConnectionString(config?: PostgreSQLConfig): string {
  const pgConfig = config || getPostgreSQLConfig();
  
  const connectionString = `postgresql://${pgConfig.user}:${pgConfig.password}@${pgConfig.host}:${pgConfig.port}/${pgConfig.database}`;
  
  console.log(`🔗 PostgreSQL Connection String: postgresql://${pgConfig.user}:***@${pgConfig.host}:${pgConfig.port}/${pgConfig.database}`);
  
  return connectionString;
}

/**
 * Test database connection (simulation for now)
 */
export async function testDatabaseConnection(config?: PostgreSQLConfig): Promise<{
  success: boolean;
  config: PostgreSQLConfig;
  error?: string;
  timing?: {
    start: number;
    end: number;
    duration: number;
  };
}> {
  const pgConfig = config || getPostgreSQLConfig();
  const startTime = Date.now();
  
  try {
    console.log('🔍 Testing PostgreSQL connection...', {
      host: pgConfig.host,
      port: pgConfig.port,
      database: pgConfig.database,
      user: pgConfig.user
    });
    
    // Simulate connection test delay
    await new Promise(resolve => setTimeout(resolve, 100));
    
    const endTime = Date.now();
    const duration = endTime - startTime;
    
    console.log(`✅ PostgreSQL connection test passed in ${duration}ms`);
    
    return {
      success: true,
      config: pgConfig,
      timing: {
        start: startTime,
        end: endTime,
        duration
      }
    };
    
  } catch (error) {
    const endTime = Date.now();
    const duration = endTime - startTime;
    const errorMessage = error instanceof Error ? error.message : 'Unknown connection error';
    
    console.error(`❌ PostgreSQL connection test failed in ${duration}ms:`, errorMessage);
    
    return {
      success: false,
      config: pgConfig,
      error: errorMessage,
      timing: {
        start: startTime,
        end: endTime,
        duration
      }
    };
  }
}

/**
 * Get database configuration summary for logging/debugging
 */
export function getDatabaseConfigSummary(): {
  deploymentMode: string;
  postgresql: {
    host: string;
    port: number;
    database: string;
    user: string;
    ssl: boolean;
  };
  configuration: {
    queryTimeout: number;
    cacheTimeout: number;
  };
} {
  const config = getDatabaseConfig();
  const { deploymentMode } = getUnifiedServerConfig();
  
  return {
    deploymentMode,
    postgresql: {
      host: config.postgresql.metrics.host,
      port: config.postgresql.metrics.port,
      database: config.postgresql.metrics.database,
      user: config.postgresql.metrics.user,
      ssl: config.postgresql.metrics.ssl || false
    },
    configuration: {
      queryTimeout: config.configuration.queryTimeout,
      cacheTimeout: config.configuration.cacheTimeout
    }
  };
}

/**
 * Log database configuration on startup
 */
export function logDatabaseConfiguration(): void {
  const summary = getDatabaseConfigSummary();
  
  console.log('=== DATABASE CONFIGURATION ===');
  console.log(`🚀 Deployment Mode: ${summary.deploymentMode.toUpperCase()}`);
  console.log(`🐘 PostgreSQL Host: ${summary.postgresql.host}:${summary.postgresql.port}`);
  console.log(`📊 Database: ${summary.postgresql.database}`);
  console.log(`👤 User: ${summary.postgresql.user}`);
  console.log(`🔒 SSL: ${summary.postgresql.ssl ? 'Enabled' : 'Disabled'}`);
  console.log(`⏱️ Query Timeout: ${summary.configuration.queryTimeout}ms`);
  console.log(`💾 Cache TTL: ${summary.configuration.cacheTimeout}s`);
  console.log('===============================');
}

// Export default configuration getter for backward compatibility
export const getMetricsDbConfig = getPostgreSQLConfig;
