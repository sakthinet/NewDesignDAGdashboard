import React from 'react';
import * as LucideIcons from 'lucide-react';

// Define the allowed icon names (all icons from Lucide)
// Exclude special exports like 'createLucideIcon' or 'icons'
type IconName = keyof Omit<typeof LucideIcons, 'createLucideIcon' | 'icons'>;

interface IconProps {
  name: IconName;
  size?: number | string;
  color?: string;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Modern Icon component that unifies icon usage across the application
 * This component uses Lucide icons for a consistent look and feel
 */
export const Icon: React.FC<IconProps> = ({ 
  name, 
  size = 24, 
  color, 
  className = '', 
  style = {} 
}) => {
  // Get the icon component from Lucide
  const IconComponent = LucideIcons[name] as React.ComponentType<any>;
  
  // Default styling to make icons look consistent
  const combinedStyle = {
    verticalAlign: 'middle',
    display: 'inline-block',
    ...style
  };
  
  // Render the icon if it exists
  if (IconComponent) {
    return (
      <IconComponent 
        size={size} 
        color={color} 
        className={`modern-icon ${className}`}
        style={combinedStyle}
      />
    );
  }
  
  // Fallback
  console.warn(`Icon '${name}' not found in lucide-react`);
  return (
    <div 
      style={{ 
        width: size, 
        height: size, 
        display: 'inline-block',
        verticalAlign: 'middle'
      }}
      className={`modern-icon-placeholder ${className}`}
    />
  );
};

export default Icon;
