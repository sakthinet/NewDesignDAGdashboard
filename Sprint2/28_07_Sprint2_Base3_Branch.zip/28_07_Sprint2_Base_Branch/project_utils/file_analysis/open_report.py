#!/usr/bin/env python3
"""
Quick script to open the generated Excel analysis report
"""

import os
import subprocess
import sys

def open_excel_file():
    """Open the Excel file with the default application"""
    excel_file = "InfoArchive_Project_Analysis.xlsx"
    
    if not os.path.exists(excel_file):
        print(f"Error: {excel_file} not found!")
        return False
    
    try:
        # Windows
        if sys.platform.startswith('win'):
            os.startfile(excel_file)
        # macOS
        elif sys.platform.startswith('darwin'):
            subprocess.run(['open', excel_file])
        # Linux
        else:
            subprocess.run(['xdg-open', excel_file])
        
        print(f"Opening {excel_file}...")
        return True
        
    except Exception as e:
        print(f"Error opening file: {e}")
        return False

if __name__ == "__main__":
    open_excel_file()
