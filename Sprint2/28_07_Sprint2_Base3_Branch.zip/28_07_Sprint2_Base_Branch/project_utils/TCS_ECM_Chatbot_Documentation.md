# Data Transformer Airflow Assistant Chatbot - Complete Documentation

## Table of Contents
1. [Overview](#overview)
2. [Architecture & How It Works](#architecture--how-it-works)
3. [LLM Models & Setup](#llm-models--setup)
4. [Features & Capabilities](#features--capabilities)
5. [Technical Implementation](#technical-implementation)
6. [API Endpoints](#api-endpoints)
7. [Usage Examples](#usage-examples)
8. [Installation Guide](#installation-guide)
9. [Troubleshooting](#troubleshooting)
10. [Advanced Configuration](#advanced-configuration)

---

## Overview

The Data Transformer Airflow Assistant is an AI-powered chatbot integrated directly into your Airflow DAG Generator application. It provides intelligent assistance with dashboard insights, DAG management, workflow automation, and troubleshooting - all while maintaining full context awareness of your current Airflow environment.

### Key Benefits
- **Context-Aware**: Knows your DAG count, status, and recent activity in real-time
- **Multi-LLM Support**: Uses the best available AI model with intelligent fallbacks
- **Always Available**: Rule-based fallback ensures 100% uptime
- **Enterprise Ready**: Professional UI matching your Data Transformer branding
- **No Breaking Changes**: Completely additive to existing functionality

---

## Architecture & How It Works

### Multi-Tier LLM Approach

