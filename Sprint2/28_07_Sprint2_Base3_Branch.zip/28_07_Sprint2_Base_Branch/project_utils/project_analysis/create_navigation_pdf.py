#!/usr/bin/env python3
"""
PDF Generator for InfoArchive Navigation Guide
Converts the HTML navigation guide to a professional PDF document
"""

import os
import sys
from pathlib import Path

def create_pdf_guide():
    """Create PDF version of the navigation guide"""
    try:
        # Try importing weasyprint for HTML to PDF conversion
        import weasyprint
        
        # Get the current directory
        current_dir = Path(__file__).parent
        html_file = current_dir / "InfoArchive_Navigation_Guide.html"
        pdf_file = current_dir / "InfoArchive_Navigation_Guide.pdf"
        
        if not html_file.exists():
            print(f"❌ HTML file not found: {html_file}")
            return False
        
        print("🔄 Converting HTML to PDF...")
        
        # Convert HTML to PDF
        weasyprint.HTML(filename=str(html_file)).write_pdf(str(pdf_file))
        
        print(f"✅ PDF created successfully: {pdf_file}")
        print(f"📄 File size: {pdf_file.stat().st_size / 1024:.1f} KB")
        
        return True
        
    except ImportError:
        print("❌ WeasyPrint not installed. Installing now...")
        try:
            import subprocess
            subprocess.check_call([sys.executable, "-m", "pip", "install", "weasyprint"])
            print("✅ WeasyPrint installed successfully. Please run the script again.")
            return False
        except Exception as e:
            print(f"❌ Failed to install WeasyPrint: {e}")
            print("\n📋 Manual Installation Instructions:")
            print("1. Install WeasyPrint: pip install weasyprint")
            print("2. Or use online HTML-to-PDF converter")
            print("3. Or open the HTML file in browser and print to PDF")
            return False
    
    except Exception as e:
        print(f"❌ Error creating PDF: {e}")
        return False

def create_word_guide():
    """Create a Word document version using python-docx"""
    try:
        from docx import Document
        from docx.shared import Inches, Pt
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.enum.style import WD_STYLE_TYPE
        
        # Create new document
        doc = Document()
        
        # Add title
        title = doc.add_heading('InfoArchive Data Transformer', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        subtitle = doc.add_heading('Complete Navigation Guide for New Users', level=1)
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add table of contents
        doc.add_heading('Table of Contents', level=1)
        toc_items = [
            "1. Application Overview",
            "2. Getting Started",
            "3. Main Navigation Areas",
            "4. Step-by-Step Workflows",
            "5. Dashboard & Monitoring",
            "6. Reports & Analytics", 
            "7. Troubleshooting Guide",
            "8. Advanced Features",
            "9. Quick Reference",
            "10. Support & Resources"
        ]
        
        for item in toc_items:
            p = doc.add_paragraph(item)
            p.style = 'List Number'
        
        # Add main sections
        sections = [
            {
                'title': 'Application Overview',
                'content': 'The InfoArchive Data Transformer is a sophisticated enterprise application designed to automate the complex process of transforming CSV data into InfoArchive-compatible XML format. It seamlessly integrates with Apache Airflow 3.x for robust workflow orchestration.'
            },
            {
                'title': 'Getting Started',
                'content': 'To access the application, open your web browser and navigate to http://localhost:3002. Check the connection status in the top-right corner to ensure Airflow connectivity.'
            },
            {
                'title': 'Main Navigation Areas',
                'content': 'The application is organized into two primary sections: Management Console (for monitoring and analytics) and Structured Data Archival (for step-by-step data processing workflows).'
            },
            {
                'title': 'Step-by-Step Workflows',
                'content': 'The complete workflow consists of 5 main steps: 1) Upload CSV files, 2) Generate InfoArchive schema, 3) Validate and finalize schema, 4) Download schema files, 5) Transform and upload data.'
            },
            {
                'title': 'Dashboard & Monitoring',
                'content': 'The dashboard provides real-time overview of DAGs, performance metrics, recent activity, and quick actions. The Jobs section shows active workflow monitoring with detailed execution information.'
            },
            {
                'title': 'Reports & Analytics',
                'content': 'Comprehensive reporting includes Chart Reports (visual distributions), Table Reports (structured data), Metrics Reports (KPIs), and Raw Data Reports (complete exports).'
            },
            {
                'title': 'Troubleshooting Guide',
                'content': 'Common issues include connection problems (check Airflow status), file upload issues (verify CSV format), schema generation errors (validate headers), and transformation failures (check logs).'
            },
            {
                'title': 'Advanced Features',
                'content': 'Advanced capabilities include automatic theme switching, security authentication, performance optimization, intelligent caching, and comprehensive integration options.'
            }
        ]
        
        for section in sections:
            doc.add_heading(section['title'], level=1)
            doc.add_paragraph(section['content'])
            
            # Add placeholder for screenshots
            doc.add_paragraph('[SCREENSHOT PLACEHOLDER - ' + section['title'] + ']')
            doc.add_paragraph()
        
        # Add support information
        doc.add_heading('Support & Resources', level=1)
        doc.add_paragraph('Application URL: http://localhost:3002')
        doc.add_paragraph('Airflow URL: http://localhost:8083')
        doc.add_paragraph('For technical support, use the built-in AI assistant or help system.')
        
        # Save document
        current_dir = Path(__file__).parent
        word_file = current_dir / "InfoArchive_Navigation_Guide.docx"
        doc.save(str(word_file))
        
        print(f"✅ Word document created: {word_file}")
        return True
        
    except ImportError:
        print("❌ python-docx not installed. Installing now...")
        try:
            import subprocess
            subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx"])
            print("✅ python-docx installed successfully. Please run the script again.")
            return False
        except Exception as e:
            print(f"❌ Failed to install python-docx: {e}")
            return False
    
    except Exception as e:
        print(f"❌ Error creating Word document: {e}")
        return False

def main():
    """Main execution function"""
    print("📋 InfoArchive Navigation Guide - Document Generator")
    print("=" * 50)
    
    # Create HTML version (already exists)
    html_file = Path(__file__).parent / "InfoArchive_Navigation_Guide.html"
    if html_file.exists():
        print(f"✅ HTML guide available: {html_file}")
    
    # Try to create PDF
    print("\n🔄 Creating PDF version...")
    pdf_success = create_pdf_guide()
    
    # Try to create Word document
    print("\n🔄 Creating Word document version...")
    word_success = create_word_guide()
    
    print("\n" + "=" * 50)
    print("📋 Summary:")
    print(f"✅ HTML Guide: Available")
    print(f"{'✅' if pdf_success else '❌'} PDF Guide: {'Created' if pdf_success else 'Failed'}")
    print(f"{'✅' if word_success else '❌'} Word Guide: {'Created' if word_success else 'Failed'}")
    
    if not pdf_success and not word_success:
        print("\n💡 Alternative Options:")
        print("1. Open InfoArchive_Navigation_Guide.html in your browser")
        print("2. Print to PDF using browser print function")
        print("3. Use online HTML-to-PDF converter services")
        print("4. Copy content to Word document manually")

if __name__ == "__main__":
    main()
