#!/usr/bin/env python3
"""
Open InfoArchive Navigation Guide in browser for easy PDF printing
"""

import webbrowser
import os
from pathlib import Path

def open_guide_in_browser():
    """Open the HTML guide in the default browser"""
    try:
        current_dir = Path(__file__).parent
        html_file = current_dir / "InfoArchive_Navigation_Guide.html"
        
        if not html_file.exists():
            print(f"❌ HTML file not found: {html_file}")
            return False
        
        # Convert to absolute path and open in browser
        file_url = f"file:///{html_file.resolve()}"
        webbrowser.open(file_url)
        
        print("✅ Navigation guide opened in your default browser")
        print("\n📋 To create PDF:")
        print("1. In your browser, press Ctrl+P (or Cmd+P on Mac)")
        print("2. Select 'Save as PDF' as the destination")
        print("3. Adjust settings if needed (margins, scale, etc.)")
        print("4. Click 'Save' to create your PDF")
        
        return True
        
    except Exception as e:
        print(f"❌ Error opening browser: {e}")
        return False

def main():
    """Main execution"""
    print("🌐 Opening InfoArchive Navigation Guide in Browser")
    print("=" * 50)
    
    success = open_guide_in_browser()
    
    if not success:
        current_dir = Path(__file__).parent
        html_file = current_dir / "InfoArchive_Navigation_Guide.html"
        print(f"\n💡 Manual Option:")
        print(f"Open this file in your browser: {html_file}")

if __name__ == "__main__":
    main()
