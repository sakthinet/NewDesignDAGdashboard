# 🔄 Unified Configuration System - Local & Network Mode Support

## Overview

The unified configuration system allows you to easily switch between **local Docker Airflow** and **network shared Airflow** deployments with a single environment variable change.

## 🚀 Quick Start

### 1. Switch to Local Mode (Docker Airflow)
```bash
node config-switcher.cjs local --verbose
```

### 2. Switch to Network Mode (Shared Airflow)
```bash
node config-switcher.cjs network --verbose
```

### 3. Start Your Application
```bash
npm run dev
```

## 📁 Configuration Files

### `.env.unified` - Master Configuration
Contains all configuration for both local and network modes. This is the source of truth for all settings.

### `.env` - Active Configuration  
Generated automatically by the switcher based on your chosen deployment mode. **Do not edit manually.**

### Configuration Switcher (`config-switcher.cjs`)
Command-line utility to switch between deployment modes.

## 🔧 Deployment Modes

### Local Mode (`DEPLOYMENT_MODE=local`)
**Best for:** Development, testing, isolated environments

```env
# Connection Settings
AIRFLOW_URL=http://localhost:8083
AIRFLOW_USERNAME=admin
AIRFLOW_PASSWORD=admin123

# Local Windows Paths
AIRFLOW_INCOMING_CSV_DIR=C:\Docker\airflow3x2\data\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=C:\Docker\airflow3x2\data\processedcsv
AIRFLOW_DAGS_DIR=C:\Docker\airflow3x2\dags
AIRFLOW_REPORTS_DIR=C:\Docker\airflow3x2\reports
```

### Network Mode (`DEPLOYMENT_MODE=network`)
**Best for:** Production, shared environments, team collaboration

```env
# Connection Settings  
AIRFLOW_URL=http://10.73.88.101:8080
AIRFLOW_USERNAME=airflow
AIRFLOW_PASSWORD=airflow

# Network UNC Paths
AIRFLOW_INCOMING_CSV_DIR=\\10.73.88.101\data\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=\\10.73.88.101\data\processedcsv  
AIRFLOW_DAGS_DIR=\\10.73.88.101\dags
AIRFLOW_REPORTS_DIR=\\10.73.88.101\reports
```

## 🛠️ Usage Examples

### Development Workflow
```bash
# Start with local development
node config-switcher.cjs local
npm run dev

# Test against network (if available)
node config-switcher.cjs network
npm run dev

# Switch back to local for development
node config-switcher.cjs local
```

### Production Deployment
```bash
# Deploy to production with network mode
node config-switcher.cjs network --no-backup
npm run build
npm start
```

### Configuration Verification
```bash
# Check current configuration
node config-switcher.cjs --help

# View active configuration details
node config-switcher.cjs local --verbose
```

## 🔍 Configuration Details

### Automatic Path Resolution
The system automatically selects the correct paths based on deployment mode:

```typescript
// In your code - automatically resolved
const config = getUnifiedServerConfig();
console.log(config.deploymentMode); // 'local' or 'network'
console.log(config.paths.incomingCsvDir); // Correct path for current mode
```

### Client-Side Support
Frontend code automatically receives the correct configuration:

```typescript
import { getUnifiedClientConfig } from './shared/config-unified';

const clientConfig = getUnifiedClientConfig();
// Automatically configured for current deployment mode
```

### Health Monitoring
Access `/api/health` to verify configuration:

```json
{
  "status": "healthy",
  "deploymentMode": "local",
  "configuration": { "valid": true },
  "paths": {
    "incomingCsv": { "accessible": true, "isLocal": true }
  }
}
```

## 🔐 Security Features

- **Credentials Isolation**: Different credentials for local vs network
- **Path Validation**: Automatic validation of path accessibility  
- **Fallback Support**: Graceful degradation when network paths unavailable
- **Client Safety**: Credentials never exposed to frontend code

## 🚨 Migration from Old System

### From Existing `.env` Files

1. **Backup Current Configuration**:
   ```bash
   copy .env .env.old
   ```

2. **Switch to Unified System**:
   ```bash
   # Copy your current local paths to .env.unified if needed
   node config-switcher.cjs local --verbose
   ```

3. **Update Code Imports**:
   ```typescript
   // Old
   import { getServerConfig } from './shared/config-enhanced';
   
   // New (both work - backward compatible)
   import { getUnifiedServerConfig } from './shared/config-unified';
   // OR
   import { getServerConfig } from './shared/config-unified'; // Legacy alias
   ```

### Configuration Validation
```bash
# Test your configuration
npm run dev
# Check browser console and server logs for any configuration warnings
```

## 🎯 Benefits

### ✅ **Simplified Deployment**
- One command to switch entire application mode
- No manual .env file editing required
- Automatic backup of previous configuration

### ✅ **Enhanced Reliability**  
- Validation of all path configurations
- Automatic fallback when network unavailable
- Type-safe configuration throughout application

### ✅ **Developer Experience**
- Clear visual feedback on active configuration
- Detailed logging and health checks
- Easy switching between local development and production testing

### ✅ **Production Ready**
- Robust error handling and validation
- Automatic path accessibility checking
- Comprehensive monitoring and debugging tools

## 🐛 Troubleshooting

### Configuration Issues
```bash
# Verify configuration is valid
node -e "
const { validateUnifiedConfiguration } = require('./shared/config-unified.ts');
console.log(JSON.stringify(validateUnifiedConfiguration(), null, 2));
"
```

### Path Access Issues
```bash
# Test network connectivity (network mode)
ping 10.73.88.101
dir \\\\10.73.88.101\\data

# Test local paths (local mode)  
dir C:\\Docker\\airflow3x2\\data
```

### Application Health
```bash
# Check application health after switching
curl http://localhost:3001/api/health
```

### Common Issues

**Issue**: Configuration not updating after switch  
**Solution**: Restart your application after switching modes

**Issue**: Network paths not accessible  
**Solution**: Verify VPN connection, use local mode as fallback

**Issue**: Local Docker not running  
**Solution**: Start Docker Desktop, verify Airflow container is running

## 📚 API Reference

### Configuration Functions

```typescript
// Get current configuration
const config = getUnifiedServerConfig();

// Get client-side configuration  
const clientConfig = getUnifiedClientConfig();

// Validate configuration
const validation = validateUnifiedConfiguration();

// Get deployment info
const info = getDeploymentInfo();

// Switch mode programmatically
switchDeploymentMode('local');
```

### Environment Variables

| Variable | Description | Local Default | Network Default |
|----------|-------------|---------------|-----------------|
| `DEPLOYMENT_MODE` | Active mode | `local` | `network` |
| `LOCAL_AIRFLOW_URL` | Local Airflow URL | `http://localhost:8083` | - |
| `NETWORK_AIRFLOW_URL` | Network Airflow URL | - | `http://10.73.88.101:8080` |
| `LOCAL_AIRFLOW_INCOMING_CSV_DIR` | Local CSV path | `C:\Docker\airflow3x2\data\incomingcsv` | - |
| `NETWORK_AIRFLOW_INCOMING_CSV_DIR` | Network CSV path | - | `\\10.73.88.101\data\incomingcsv` |

## 🎉 Success Metrics

- ✅ **Zero-downtime switching** between deployment modes
- ✅ **Automatic path validation** prevents runtime errors  
- ✅ **Type-safe configuration** throughout the application
- ✅ **Backward compatibility** with existing code
- ✅ **Enhanced debugging** with detailed configuration logging

**Your application now supports seamless switching between local and network deployments!** 🚀
