import asyncpg
import asyncio

async def test_db():
    try:
        # URL encode @ as %40
        conn = await asyncpg.connect('postgresql://postgres:admin%4012345@localhost:5432/RND')
        print('Database connection successful!')
        await conn.close()
    except Exception as e:
        print(f'Database connection failed: {e}')

if __name__ == "__main__":
    asyncio.run(test_db())
