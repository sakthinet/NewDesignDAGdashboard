import time
import asyncpg
from fastapi import Request
from pydantic import BaseModel
import httpx
from qdrant_client import QdrantClient
from qdrant_client.models import SearchParams
from fastapi import APIRouter

router = APIRouter()

COLLECTION_NAME = "BFS"
TOP_K = 5
DISTANCE_METRIC = "cosine"
RETRIEVAL_MODE = "standard"
EMBEDDING_MODEL = "nomic-embed-text"
API_NAME = "COE"
DB_DSN = "postgresql://postgres:postgres@localhost:5432/RND"  # replace with real credentials
MAX_PAYLOAD_LENGTH = 500

qdrant = QdrantClient(host="localhost", port=6333)

class QueryInput(BaseModel):
    search_term: str

def truncate_payload(payload: dict, max_length: int) -> dict:
    truncated = {}
    for key, value in payload.items():
        if isinstance(value, str) and len(value) > max_length:
            truncated[key] = value[:max_length] + "..."
        else:
            truncated[key] = value
    return truncated

async def get_embedding_from_ollama(text: str):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://localhost:11434/api/embeddings",
            json={"model": EMBEDDING_MODEL, "prompt": text}
        )
        response.raise_for_status()
        return response.json()["embedding"]

@router.post("/api/COE/search")
async def search(input: QueryInput, request: Request):
    query_text = input.search_term
    caller_ip = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    source = request.headers.get("X-Source", "default")

    # Metrics placeholders
    status = True
    error_message = None
    response_time_ms = 0
    num_results = 0
    top_result_score = None

    try:
        start_time = time.time()
        vector = await get_embedding_from_ollama(query_text)
    except Exception as e:
        status = False
        error_message = f"Embedding failed: {str(e)}"
        vector = None

    hits = []
    if status:
        try:
            hits = qdrant.search(
                collection_name=COLLECTION_NAME,
                query_vector=vector,
                limit=TOP_K,
                search_params=SearchParams(hnsw_ef=128)
            )
            num_results = len(hits)
            if hits:
                top_result_score = hits[0].score
        except Exception as e:
            status = False
            error_message = f"Search failed: {str(e)}"

    response_time_ms = int((time.time() - start_time) * 1000)

    # Log to PostgreSQL
    try:
        conn = await asyncpg.connect(DB_DSN)
        await conn.execute("""
            INSERT INTO search_api_logs (
                api_name, collection_name, query_text,
                top_k, retrieval_mode, embedding_model,
                caller_ip, user_agent,
                num_results, top_result_score,
                is_success, error_message, response_time_ms, source
            )
            VALUES (
                $1, $2, $3,
                $4, $5, $6,
                $7, $8,
                $9, $10,
                $11, $12, $13, $14
            )
        """, API_NAME, COLLECTION_NAME, query_text,
             TOP_K, RETRIEVAL_MODE, EMBEDDING_MODEL,
             caller_ip, user_agent,
             num_results, top_result_score,
             status, error_message, response_time_ms, source)
        await conn.close()
    except Exception as db_err:
        print(f"Failed to log API call: {db_err}")

    if not status:
        return {"status": "error", "message": error_message}

    return {
        "status": "success",
        "query": query_text,
        "results": [
            {"id": hit.id, "score": hit.score, "payload": truncate_payload(hit.payload, MAX_PAYLOAD_LENGTH)}
            for hit in hits
        ]
    }