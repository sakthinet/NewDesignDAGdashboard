# app/auth/session.py
from itsdangerous import TimestampSigner, BadSignature, SignatureExpired
from fastapi import Request, HTTPException, Response
from typing import Optional

SECRET_KEY = "super-secret-key"  # 🔒 Replace with env var in production
SESSION_COOKIE = "contextcraft_session"
signer = TimestampSigner(SECRET_KEY)

def create_session_token(username: str) -> str:
    return signer.sign(username.encode()).decode()

def get_user_from_session(request: Request) -> Optional[str]:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        username = signer.unsign(token, max_age=86400).decode()
        return username
    except SignatureExpired:
        raise HTTPException(status_code=401, detail="Session expired")
    except BadSignature:
        raise HTTPException(status_code=401, detail="Invalid session")

def delete_session_cookie(response: Response):
    response.delete_cookie(SESSION_COOKIE)