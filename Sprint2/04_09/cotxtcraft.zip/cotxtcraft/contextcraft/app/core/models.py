from pydantic import BaseModel
from typing import Optional, Dict, Any
from typing import List, Optional

class SearchConfig(BaseModel):
    name: str
    collection: str
    metric: str
    top_k: int = 10
    filters: Optional[Dict[str, Any]] = None

class PipelineRequest(BaseModel):
    pipelineName: str
    sourceType: str
    uncPath: Optional[str] = None
    formats: List[str]
    parser: str
    preprocessing: List[str]
    targetLanguage: Optional[str] = None

    # Flattened chunking
    chunkingStrategy: str
    chunkSize: int
    chunkOverlap: int

    # Flattened embedding
    embeddingModel: str
    embeddingDimension: int

    # Flattened vector DB
    vectorDbType: str
    vectorCollection: str
    vectorMetric: str
