import importlib.util
from pathlib import Path

GENERATED_DIR = Path("app/generated_apis")

def load_router_for_config(cfg_name: str):
    file_path = GENERATED_DIR / f"{cfg_name}_router.py"
    module_name = f"{cfg_name}_router"
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.router
