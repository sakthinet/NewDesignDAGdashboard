from fastapi import FastAPI, APIRouter, HTTPException
from app.core.models import SearchConfig
from datetime import datetime, timezone
from app.core.template_engine import render_template_to_file
from app.core.router_loader import load_router_for_config
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
import os
import sys
from app.core.models import PipelineRequest
import requests
from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_async_session
from sqlalchemy import text
from fastapi import FastAPI, Request, Form, Depends
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from app.auth.session import (
    create_session_token,
    get_user_from_session,
    delete_session_cookie,
    SESSION_COOKIE
)
from dotenv import load_dotenv
import base64

# Load environment variables from .env file
load_dotenv()

app = FastAPI(title="ContextCraft")

# ✅ CORS middleware to allow frontend access from Vite dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173", 
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5174",
        "http://127.0.0.1:5174"
    ],  # Frontend origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

mounted_routers = {}

# Airflow Configuration
AIRFLOW_API_URL = os.getenv("AIRFLOW_API_URL", "http://localhost:8083/api/v2")
AIRFLOW_DAG_ID = os.getenv("AIRFLOW_DAG_ID", "DataForGenAI")
AIRFLOW_USERNAME = os.getenv("LOCAL_AIRFLOW_USERNAME", "admin")
AIRFLOW_PASSWORD = os.getenv("LOCAL_AIRFLOW_PASSWORD", "admin123")

# Create basic auth credentials for Airflow
def get_airflow_auth_header():
    credentials = f"{AIRFLOW_USERNAME}:{AIRFLOW_PASSWORD}"
    encoded_credentials = base64.b64encode(credentials.encode('utf-8')).decode('utf-8')
    return f"Basic {encoded_credentials}"

# Dummy login user/pass
VALID_USERS = {"admin": "password123","Abhishek":"Abhishek123"}

@app.post("/wizard/run-pipeline")
async def run_pipeline(cfg: PipelineRequest):
    dag_run_url = f"{AIRFLOW_API_URL}/dags/{AIRFLOW_DAG_ID}/dagRuns"

    # Flatten the config into individual variables for Airflow's `params`

    logical_date = datetime.now(timezone.utc).isoformat()

    conf_payload = {
        "PipelineName": cfg.pipelineName,
        "DataSource": cfg.sourceType,
        "Formats": ", ".join(cfg.formats),
        "DocumentParser": cfg.parser,
        "TextPreprocessing": ", ".join(cfg.preprocessing),
        "ChunkingStrategy": cfg.chunkingStrategy,
        "ChunkSize": str(cfg.chunkSize),
        "ChunkOverlap": str(cfg.chunkOverlap),
        "EmbeddingModel": cfg.embeddingModel,
        "EmbeddingDimension": str(cfg.embeddingDimension),
        "VectorDatabase": cfg.vectorDbType,
        "VectorDatabaseTable": cfg.vectorCollection,
        "SearchType": cfg.vectorMetric,
    }

    # Optional UNC path or translation language
    if cfg.sourceType == "File shares and network drives" and cfg.uncPath:
        conf_payload["UNCPath"] = cfg.uncPath

    if "Language Translation" in cfg.preprocessing and cfg.targetLanguage:
        conf_payload["TargetLanguage"] = cfg.targetLanguage

    payload = {"conf": conf_payload ,"logical_date": logical_date,}

    headers = {
        "Authorization": get_airflow_auth_header(),
        "Content-Type": "application/json",
    }

    response = requests.post(dag_run_url, headers=headers, json=payload)

    if response.status_code in [200, 201]:  # 201 = DAG run created
        return {"status": "success", "details": response.json()}
    else:
        return JSONResponse(status_code=response.status_code, content={
            "status": "error",
            "message": response.text
        })

@app.post("/login")
async def login(username: str = Form(...), password: str = Form(...)):
    if VALID_USERS.get(username) == password:
        token = create_session_token(username)
        response = JSONResponse(content={"message": "Login successful"})
        response.set_cookie(
            SESSION_COOKIE,
            token,
            httponly=True,
            secure=False,  # Set to True if using HTTPS
            samesite="Lax",
        )
        return response
    return JSONResponse(status_code=401, content={"message": "Invalid credentials"})


@app.get("/me")
async def get_current_user(user: str = Depends(get_user_from_session)):
    return {"user": user}


@app.post("/logout")
async def logout():
    response = JSONResponse(content={"message": "Logged out"})
    delete_session_cookie(response)
    return response

@app.post("/wizard/generate")
async def generate_router(cfg: SearchConfig):
    render_template_to_file(cfg)
    router = load_router_for_config(cfg.name)

    if cfg.name in mounted_routers:
        prefix = mounted_routers[cfg.name]["prefix"]
        app.router.routes = [
            r for r in app.router.routes
            if not (hasattr(r, "path") and r.path.startswith(prefix))
        ]
        del sys.modules[f"app.generated_apis.{cfg.name}_router"]

    prefix = f"/api/{cfg.name}"
    app.include_router(router, prefix=prefix)
    mounted_routers[cfg.name] = {"router": router, "prefix": prefix}
    print("✅ Mounted routes:")
    for route in app.routes:
        print(f"- {route.path}")
    return {"status": "mounted", "endpoint": f"{prefix}/search"}


@app.delete("/wizard/delete/{name}")
async def delete_router(name: str):
    if name not in mounted_routers:
        raise HTTPException(status_code=404, detail=f"API '{name}' not found")

    prefix = mounted_routers[name]["prefix"]
    app.router.routes = [
        r for r in app.router.routes
        if not (hasattr(r, "path") and r.path.startswith(prefix))
    ]

    mod_name = f"app.generated_apis.{name}_router"
    if mod_name in sys.modules:
        del sys.modules[mod_name]

    file_path = Path(f"app/generated_apis/{name}_router.py")
    if file_path.exists():
        os.remove(file_path)

    del mounted_routers[name]
    return {"status": "deleted", "message": f"API '{name}' removed."}


@app.get("/wizard/status")
async def check_status():
    routes_info = []
    for name, info in mounted_routers.items():
        endpoints = [
            route.path for route in app.routes
            if hasattr(route, "path") and route.path.startswith(info["prefix"])
        ]
        routes_info.append({
            "name": name,
            "prefix": info["prefix"],
            "endpoints": endpoints
        })

    # Find orphaned .py files not loaded
    generated_dir = Path("app/generated_apis")
    all_files = {p.stem.replace("_router", "") for p in generated_dir.glob("*_router.py")}
    mounted_names = set(mounted_routers.keys())
    orphaned_files = list(all_files - mounted_names)

    return {
        "status": "ok",
        "mounted_routers": routes_info,
        "orphaned_router_files": orphaned_files
    }

@app.get("/logs/count")
async def get_total_api_calls(session: AsyncSession = Depends(get_async_session)):
    result = await session.execute(text("SELECT COUNT(*) FROM search_api_logs"))
    total = result.scalar()
    return {"total_api_calls": total}

@app.get("/vectorized-documents/count")
async def vectorized_documents_count(session: AsyncSession = Depends(get_async_session)):
    result = await session.execute(text("SELECT COUNT(*) FROM vectorized_documents"))
    total = result.scalar()
    return {"total_vectorized_documents": total}

@app.get("/active-pipelines/count")
async def vectorized_documents_count(session: AsyncSession = Depends(get_async_session)):
    result = await session.execute(text("SELECT COUNT(*) FROM vectorized_documents where status != 'success'"))
    total = result.scalar()
    return {"total_vectorized_documents": total}

@app.get("/airflow/dag-runs/{dag_id}")
async def get_dag_runs(dag_id: str, request: Request):
    url = f"{AIRFLOW_API_URL}/dags/{dag_id}/dagRuns"
    headers = {
        "Authorization": get_airflow_auth_header(),
        "Content-Type": "application/json",
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            return JSONResponse(status_code=response.status_code, content={"error": response.text})

        data = response.json()
        runs = data.get("dag_runs", [])

        # Basic sanitization + formatting
        dag_runs = [
            {
                "run_id": run["dag_run_id"],
                "execution_date": run.get("execution_date"),
                "start_date": run.get("start_date"),
                "state": run.get("state"),
            }
            for run in runs
        ]

        return dag_runs

    except Exception as e:
        print(f"Error fetching DAG runs for {dag_id}: {e}")
        return JSONResponse(status_code=500, content={"error": "Failed to fetch DAG runs"})

# -------- Load on Startup --------
generated_dir = Path("app/generated_apis")
for pyfile in generated_dir.glob("*_router.py"):
    module_name = pyfile.stem.replace("_router", "")
    try:
        router = load_router_for_config(module_name)
        prefix = f"/api/{module_name}"
        app.include_router(router, prefix=prefix)
        mounted_routers[module_name] = {"router": router, "prefix": prefix}
    except Exception as e:
        print(f"❌ Failed to load {pyfile}: {e}")
