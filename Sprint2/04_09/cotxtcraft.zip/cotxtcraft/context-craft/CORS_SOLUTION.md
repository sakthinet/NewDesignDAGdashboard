# CORS Configuration Solution

## Problem
The frontend at `http://localhost:5175` cannot access the backend API at `http://localhost:8000` due to CORS (Cross-Origin Resource Sharing) policy violations.

## Root Cause
The backend server is missing the `Access-Control-Allow-Origin` header in its responses.

## Solution

### For FastAPI Backend (if using FastAPI):
```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5175", "http://localhost:3000"],  # Frontend URLs
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### For Express.js Backend (if using Express):
```javascript
const cors = require('cors');

app.use(cors({
  origin: ['http://localhost:5175', 'http://localhost:3000'],
  credentials: true
}));
```

### For Django Backend (if using Django):
```python
# settings.py
CORS_ALLOWED_ORIGINS = [
    "http://localhost:5175",
    "http://localhost:3000",
]
CORS_ALLOW_CREDENTIALS = True
```

## Quick Test
After configuring CORS, test with:
```bash
curl -H "Origin: http://localhost:5175" -i http://localhost:8000/wizard/status
```

You should see:
```
Access-Control-Allow-Origin: http://localhost:5175
```

## Alternative Workaround (Development Only)
If you cannot modify the backend, you can start Chrome with disabled security:
```bash
chrome.exe --user-data-dir="C:/temp" --disable-web-security --disable-features=VizDisplayCompositor
```

**⚠️ Warning:** Only use this for development, never in production!
