# Airflow JWT Token Validation Implementation

This implementation provides JWT token validation for Apache Airflow API calls, following the same pattern as the reference implementation in the `ref` folder.

## Architecture Overview

The implementation consists of three main components:

1. **AirflowApiService** (`src/services/airflowApiService.ts`) - Core service for authenticated API calls
2. **useAirflowApi Hook** (`src/hooks/useAirflowApi.ts`) - React hook for component integration
3. **JWT Utils** (`src/utils/airflowJwtUtils.ts`) - Utility functions for token management

## Key Features

### JWT Token Management
- Automatic token expiration checking (5-minute buffer)
- Automatic token refresh when expired
- Token caching with expiry management
- Authentication state tracking

### Error Handling & Retry Logic
- Automatic retry on authentication failures (401/403)
- Exponential backoff for failed requests
- Graceful fallback mechanisms
- Comprehensive error logging

### Caching
- Response caching with configurable TTL
- Cache invalidation by patterns/tags
- Ongoing request deduplication
- Performance optimization

## Configuration

### Environment Variables
```bash
VITE_AIRFLOW_URL=http://localhost:8083
VITE_AIRFLOW_USERNAME=admin
VITE_AIRFLOW_PASSWORD=admin
```

### Config File (`src/config.ts`)
```typescript
export const airflowDagId = "DataForGenAI";
export const airflowToken = "your-jwt-token-here";
export const airflowDagRunUrl = `http://localhost:8083/api/v2/dags/${airflowDagId}/dagRuns/list`;
```

## Usage Examples

### 1. Using the Service Directly

```typescript
import AirflowApiService from '@/services/airflowApiService';

// Test connection with JWT validation
const connectionStatus = await AirflowApiService.testConnection();
console.log('Connected:', connectionStatus.connected);

// Get DAGs with automatic token validation
const dags = await AirflowApiService.getDags();

// Trigger a DAG with configuration
const result = await AirflowApiService.triggerDag('my-dag-id', {
  param1: 'value1',
  param2: 'value2'
});
```

### 2. Using the React Hook

```typescript
import { useAirflowApi } from '@/hooks/useAirflowApi';

function MyComponent() {
  const {
    loading,
    error,
    getDags,
    triggerDag,
    testConnection,
    isAuthenticated,
    clearError
  } = useAirflowApi();

  useEffect(() => {
    const loadData = async () => {
      const status = await testConnection();
      if (status?.connected) {
        const dags = await getDags();
        console.log('DAGs loaded:', dags);
      }
    };
    loadData();
  }, [testConnection, getDags]);

  const handleTrigger = async () => {
    try {
      await triggerDag('my-dag-id', { source: 'ui' });
      // Handle success
    } catch (err) {
      // Handle error
    }
  };

  return (
    <div>
      {loading && <div>Loading...</div>}
      {error && <div>Error: {error}</div>}
      <button onClick={handleTrigger}>Trigger DAG</button>
    </div>
  );
}
```

### 3. Using JWT Utilities

```typescript
import {
  validateJwtToken,
  testAirflowConnection,
  refreshJwtTokenIfNeeded,
  makeAuthenticatedAirflowRequest
} from '@/utils/airflowJwtUtils';

// Check if current token is valid
const isValid = validateJwtToken();

// Test connection and get detailed status
const status = await testAirflowConnection();
console.log('Authenticated:', status.authenticated);
console.log('Token Valid:', status.tokenValid);

// Refresh token if needed
const refreshResult = await refreshJwtTokenIfNeeded();
if (refreshResult.refreshed) {
  console.log('Token was refreshed');
}

// Make authenticated request directly
const response = await makeAuthenticatedAirflowRequest('/dags');
```

## API Reference

### AirflowApiService Methods

| Method | Description | Parameters | Returns |
|--------|-------------|------------|---------|
| `testConnection()` | Test Airflow connection | None | Connection status object |
| `getDags()` | Get all DAGs | None | DAGs array |
| `getDag(dagId)` | Get specific DAG | `dagId: string` | DAG object |
| `getDagRuns(dagId, limit, offset)` | Get DAG runs | `dagId: string, limit?: number, offset?: number` | DAG runs array |
| `triggerDag(dagId, conf)` | Trigger DAG execution | `dagId: string, conf?: object` | Trigger result |
| `pauseUnpauseDag(dagId, isPaused)` | Pause/unpause DAG | `dagId: string, isPaused: boolean` | Update result |
| `getTaskInstances(dagId, runId)` | Get task instances | `dagId: string, runId: string` | Task instances |
| `getTaskLogs(dagId, runId, taskId, tryNumber)` | Get task logs | `dagId: string, runId: string, taskId: string, tryNumber?: number` | Logs |
| `deleteDagRun(dagId, runId)` | Delete DAG run | `dagId: string, runId: string` | Delete result |
| `getAirflowInfo()` | Get system info | None | System information |
| `clearToken()` | Clear JWT token | None | Void |
| `isAuthenticated()` | Check auth status | None | Boolean |

### useAirflowApi Hook Returns

```typescript
{
  // State
  loading: boolean;
  error: string | null;
  
  // API methods (same as service methods)
  getDags: () => Promise<any>;
  getDag: (dagId: string) => Promise<any>;
  triggerDag: (dagId: string, conf?: object) => Promise<any>;
  // ... other methods
  
  // Utility methods
  clearCache: () => void;
  invalidateDagCache: (dagId: string) => void;
  clearError: () => void;
  isAuthenticated: () => boolean;
  clearToken: () => void;
}
```

## JWT Token Flow

1. **Initial Authentication**: 
   - Uses static token from config if available
   - Otherwise authenticates with username/password

2. **Token Validation**:
   - Checks expiry before each request (5-minute buffer)
   - Automatically refreshes if expired

3. **Request Flow**:
   ```
   Request → Check Token → Expired? → Refresh → Make Request
                ↓              ↓         ↓
               Valid     Refresh Failed  Success
                ↓              ↓         ↓
           Make Request  → Throw Error   Return Response
   ```

4. **Error Handling**:
   - 401/403 responses trigger token refresh
   - Maximum 2 retries per request
   - Exponential backoff for failures

## Security Considerations

1. **Token Storage**: Tokens are stored in memory only, not persisted
2. **Expiry Management**: 5-minute buffer prevents expired token usage
3. **Automatic Cleanup**: Tokens are cleared on authentication failures
4. **Request Validation**: All requests include proper headers and validation

## Integration with Existing Code

The implementation seamlessly integrates with your existing dashboard:

1. **DashboardPage.tsx**: Shows Airflow connection status with JWT validation
2. **Config Integration**: Uses existing configuration values
3. **Fallback Support**: Falls back to existing API endpoints if needed
4. **Error Handling**: Provides user-friendly error messages

## Troubleshooting

### Common Issues

1. **Connection Failed**: Check `VITE_AIRFLOW_URL` configuration
2. **Authentication Failed**: Verify username/password in environment variables
3. **Token Expired**: Tokens refresh automatically, but check for network issues
4. **API Errors**: Check Airflow server logs for detailed error information

### Debugging

Enable debug logging by adding to your environment:
```bash
VITE_DEBUG_AIRFLOW=true
```

This will show detailed JWT token management and API request logs in the console.

## Best Practices

1. **Error Handling**: Always wrap API calls in try-catch blocks
2. **Loading States**: Use the `loading` state from the hook for UI feedback
3. **Cache Management**: Clear cache when data updates are expected
4. **Token Management**: Don't manually manage tokens, let the service handle it
5. **Performance**: Use caching appropriately to avoid unnecessary API calls

## Example Dashboard Integration

See `src/pages/DashboardPage.tsx` for a complete example of:
- Connection status monitoring
- JWT authentication status display
- DAG runs fetching with token validation
- Error handling and user feedback
- Automatic token refresh in background

This implementation provides a robust, production-ready solution for Airflow JWT token management that follows security best practices and provides excellent developer experience.
