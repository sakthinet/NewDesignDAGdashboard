import { useState, useCallback, useRef } from 'react';
import AirflowApiService from '@/services/airflowApiService';

// Simple cache implementation for React hook
class SimpleCache {
  private cache = new Map<string, { data: any; timestamp: number; expiry: number }>();

  set(key: string, data: any, ttlSeconds = 30): void {
    const expiry = Date.now() + (ttlSeconds * 1000);
    this.cache.set(key, { data, timestamp: Date.now(), expiry });
  }

  get(key: string): any | null {
    const entry = this.cache.get(key);
    if (!entry || Date.now() > entry.expiry) {
      this.cache.delete(key);
      return null;
    }
    return entry.data;
  }

  clear(): void {
    this.cache.clear();
  }

  invalidatePattern(pattern: string): void {
    const regex = new RegExp(pattern);
    for (const [key] of this.cache) {
      if (regex.test(key)) {
        this.cache.delete(key);
      }
    }
  }
}

// Custom hook for Airflow API operations
export function useAirflowApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Cache for storing API responses
  const cache = useRef(new SimpleCache()).current;
  
  // Track ongoing requests to prevent duplicate calls
  const ongoingRequests = useRef(new Map<string, Promise<any>>()).current;

  // Generic request handler with caching and error handling
  const handleRequest = useCallback(async <T>(
    requestFn: () => Promise<T>,
    cacheKey?: string,
    cacheTTL = 30,
    skipCache = false
  ): Promise<T | null> => {
    // Check cache first if not skipping cache
    if (!skipCache && cacheKey) {
      const cached = cache.get(cacheKey);
      if (cached) {
        return cached as T;
      }
    }

    // Check if request is already ongoing
    if (cacheKey && ongoingRequests.has(cacheKey)) {
      return ongoingRequests.get(cacheKey);
    }

    setLoading(true);
    setError(null);

    const requestPromise = (async () => {
      try {
        const result = await requestFn();
        
        // Cache successful responses
        if (!skipCache && cacheKey) {
          cache.set(cacheKey, result, cacheTTL);
        }
        
        return result as T;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
        setError(errorMessage);
        throw err;
      } finally {
        setLoading(false);
        if (cacheKey) {
          ongoingRequests.delete(cacheKey);
        }
      }
    })();

    // Track ongoing request
    if (cacheKey) {
      ongoingRequests.set(cacheKey, requestPromise);
    }

    try {
      return await requestPromise;
    } catch (err) {
      return null;
    }
  }, [cache, ongoingRequests]);

  // Test Airflow connection
  const testConnection = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'airflow_connection_test';
    
    return handleRequest<{
      connected: boolean;
      status?: any;
      url: string;
      token?: string;
      apiVersion?: string;
      authMethod?: string;
      error?: string;
    }>(
      () => AirflowApiService.testConnection(),
      cacheKey,
      forceRefresh ? 5 : 60, // Shorter cache on force refresh
      forceRefresh
    );
  }, [handleRequest]);

  // Get all DAGs
  const getDags = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'all_dags';
    
    return handleRequest<{ dags: any[]; total_entries: number }>(
      () => AirflowApiService.getDags(),
      cacheKey,
      forceRefresh ? 10 : 30, // Shorter cache on force refresh
      forceRefresh
    );
  }, [handleRequest]);

  // Get specific DAG
  const getDag = useCallback(async (dagId: string, forceRefresh = false) => {
    if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
      throw new Error('Invalid DAG ID provided');
    }

    const cacheKey = `dag_${dagId}`;
    
    return handleRequest<any>(
      () => AirflowApiService.getDag(dagId),
      cacheKey,
      30,
      forceRefresh
    );
  }, [handleRequest]);

  // Get DAG runs
  const getDagRuns = useCallback(async (dagId: string, limit = 10, offset = 0, forceRefresh = false) => {
    if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
      throw new Error('Invalid DAG ID provided');
    }

    const cacheKey = `dag_runs_${dagId}_${limit}_${offset}`;
    
    return handleRequest<{ dag_runs: any[]; total_entries: number }>(
      () => AirflowApiService.getDagRuns(dagId, limit, offset),
      cacheKey,
      30,
      forceRefresh
    );
  }, [handleRequest]);

  // Trigger DAG
  const triggerDag = useCallback(async (dagId: string, conf: any = {}) => {
    if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
      throw new Error('Invalid DAG ID provided');
    }
    
    const result = await handleRequest<any>(
      () => AirflowApiService.triggerDag(dagId, conf),
      undefined, // Don't cache trigger requests
      0,
      true // Skip cache
    );
    
    if (result) {
      // Invalidate related caches
      cache.invalidatePattern(`dag_runs_${dagId}`);
      cache.invalidatePattern('all_dags');
    }
    
    return result;
  }, [handleRequest, cache]);

  // Pause/Unpause DAG
  const pauseUnpauseDag = useCallback(async (dagId: string, isPaused: boolean) => {
    if (!dagId || typeof dagId !== 'string' || dagId.trim() === '') {
      throw new Error('Invalid DAG ID provided');
    }
    
    const result = await handleRequest<any>(
      () => AirflowApiService.pauseUnpauseDag(dagId, isPaused),
      undefined, // Don't cache update requests
      0,
      true // Skip cache
    );
    
    if (result) {
      // Invalidate related caches
      cache.invalidatePattern(`dag_${dagId}`);
      cache.invalidatePattern('all_dags');
    }
    
    return result;
  }, [handleRequest, cache]);

  // Pause DAG specifically
  const pauseDag = useCallback(async (dagId: string) => {
    return pauseUnpauseDag(dagId, true);
  }, [pauseUnpauseDag]);

  // Unpause DAG specifically
  const unpauseDag = useCallback(async (dagId: string) => {
    return pauseUnpauseDag(dagId, false);
  }, [pauseUnpauseDag]);

  // Get task instances
  const getTaskInstances = useCallback(async (dagId: string, runId: string, forceRefresh = false) => {
    if (!dagId || !runId || typeof dagId !== 'string' || typeof runId !== 'string') {
      throw new Error('Invalid DAG ID or Run ID provided');
    }

    const cacheKey = `task_instances_${dagId}_${runId}`;
    
    return handleRequest<{ task_instances: any[] }>(
      () => AirflowApiService.getTaskInstances(dagId, runId),
      cacheKey,
      60, // 1 minute cache for task instances
      forceRefresh
    );
  }, [handleRequest]);

  // Get task logs
  const getTaskLogs = useCallback(async (dagId: string, runId: string, taskId: string, tryNumber = 1) => {
    if (!dagId || !runId || !taskId) {
      console.error('Missing required parameters for getTaskLogs:', { dagId, runId, taskId });
      return null;
    }

    try {
      const result = await AirflowApiService.getTaskLogs(dagId, runId, taskId, tryNumber);
      return {
        success: true,
        logs: result.content || result.logs || "No logs available",
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error fetching task logs';
      console.error('Error fetching task logs:', errorMessage);
      return {
        success: false,
        logs: `Error: ${errorMessage}`,
      };
    }
  }, []);

  // Delete DAG run
  const deleteDagRun = useCallback(async (dagId: string, runId: string) => {
    if (!dagId || !runId || typeof dagId !== 'string' || typeof runId !== 'string') {
      throw new Error('Invalid DAG ID or Run ID provided');
    }
    
    const result = await handleRequest<any>(
      () => AirflowApiService.deleteDagRun(dagId, runId),
      undefined, // Don't cache delete requests
      0,
      true // Skip cache
    );
    
    if (result) {
      // Invalidate related caches
      cache.invalidatePattern(`dag_runs_${dagId}`);
    }
    
    return result;
  }, [handleRequest, cache]);

  // Get Airflow system info
  const getAirflowInfo = useCallback(async (forceRefresh = false) => {
    const cacheKey = 'airflow_info';
    
    return handleRequest<any>(
      () => AirflowApiService.getAirflowInfo(),
      cacheKey,
      300, // 5 minute cache for system info
      forceRefresh
    );
  }, [handleRequest]);

  // Clear cache
  const clearCache = useCallback(() => {
    cache.clear();
    ongoingRequests.clear();
    console.log('🗑️ Cache cleared');
  }, [cache, ongoingRequests]);

  // Invalidate specific DAG cache
  const invalidateDagCache = useCallback((dagId: string) => {
    cache.invalidatePattern(`dag_${dagId}`);
    cache.invalidatePattern(`dag_runs_${dagId}`);
    console.log(`🗑️ Invalidated cache for DAG: ${dagId}`);
  }, [cache]);

  // Clear error state
  const clearError = useCallback(() => setError(null), []);

  // Check if authenticated
  const isAuthenticated = useCallback(() => {
    return AirflowApiService.isAuthenticated();
  }, []);

  // Clear JWT token
  const clearToken = useCallback(() => {
    AirflowApiService.clearToken();
  }, []);

  // Return all API methods and state
  return {
    loading,
    error,
    
    // API methods
    getDags,
    getDag,
    triggerDag,
    pauseUnpauseDag,
    pauseDag,
    unpauseDag,
    getDagRuns,
    getTaskInstances,
    getTaskLogs,
    deleteDagRun,
    getAirflowInfo,
    testConnection,
    
    // Utility methods
    clearCache,
    invalidateDagCache,
    clearError,
    isAuthenticated,
    clearToken,
    
    // Error handling
    setError,
  };
}

export default useAirflowApi;
