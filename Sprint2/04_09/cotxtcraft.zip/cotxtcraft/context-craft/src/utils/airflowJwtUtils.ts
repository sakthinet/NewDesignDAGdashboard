import AirflowApiService from '@/services/airflowApiService';

/**
 * Utility functions for Airflow JWT token validation and management
 * These functions provide convenient access to JWT token operations
 */

// Check if the current JWT token is valid and not expired
export const validateJwtToken = (): boolean => {
  return AirflowApiService.isAuthenticated();
};

// Get current JWT token (for debugging or external use)
export const getCurrentJwtToken = (): string | null => {
  return AirflowApiService.getCurrentToken();
};

// Clear JWT token (for logout or re-authentication)
export const clearJwtToken = (): void => {
  AirflowApiService.clearToken();
};

// Test Airflow connection and JWT authentication
export const testAirflowConnection = async (): Promise<{
  success: boolean;
  authenticated: boolean;
  tokenValid: boolean;
  message: string;
  details?: any;
}> => {
  try {
    const connectionResult = await AirflowApiService.testConnection();
    
    return {
      success: connectionResult.connected,
      authenticated: !!connectionResult.token,
      tokenValid: validateJwtToken(),
      message: connectionResult.connected 
        ? 'Successfully connected to Airflow with valid JWT token'
        : connectionResult.error || 'Failed to connect to Airflow',
      details: connectionResult
    };
  } catch (error) {
    return {
      success: false,
      authenticated: false,
      tokenValid: false,
      message: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};

// Refresh JWT token if needed
export const refreshJwtTokenIfNeeded = async (): Promise<{
  success: boolean;
  refreshed: boolean;
  message: string;
}> => {
  try {
    const wasValid = validateJwtToken();
    
    if (wasValid) {
      return {
        success: true,
        refreshed: false,
        message: 'JWT token is still valid, no refresh needed'
      };
    }
    
    // Try to get a new token by making a test request
    const connectionResult = await AirflowApiService.testConnection();
    
    if (connectionResult.connected) {
      return {
        success: true,
        refreshed: true,
        message: 'JWT token refreshed successfully'
      };
    } else {
      return {
        success: false,
        refreshed: false,
        message: connectionResult.error || 'Failed to refresh JWT token'
      };
    }
  } catch (error) {
    return {
      success: false,
      refreshed: false,
      message: error instanceof Error ? error.message : 'Unknown error during token refresh'
    };
  }
};

// Utility to make authenticated requests with automatic token validation
export const makeAuthenticatedAirflowRequest = async (
  endpoint: string,
  options: RequestInit = {}
): Promise<any> => {
  try {
    // First check if token is valid
    if (!validateJwtToken()) {
      console.log('JWT token invalid, attempting to refresh...');
      const refreshResult = await refreshJwtTokenIfNeeded();
      
      if (!refreshResult.success) {
        throw new Error('Failed to authenticate with Airflow: ' + refreshResult.message);
      }
    }
    
    // Make the request using the service
    const response = await fetch(`${import.meta.env.VITE_AIRFLOW_URL || 'http://localhost:8083'}/api/v2${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${getCurrentJwtToken()}`,
        ...options.headers
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Authenticated request failed:', error);
    throw error;
  }
};

// Example usage function that demonstrates JWT validation
export const exampleAirflowOperations = {
  // Get DAGs with token validation
  async getDAGs() {
    return makeAuthenticatedAirflowRequest('/dags');
  },
  
  // Trigger a DAG with token validation
  async triggerDAG(dagId: string, conf: any = {}) {
    return makeAuthenticatedAirflowRequest(`/dags/${dagId}/dagRuns`, {
      method: 'POST',
      body: JSON.stringify({
        conf: conf,
        dag_run_id: null
      })
    });
  },
  
  // Get DAG runs with token validation
  async getDAGRuns(dagId: string, limit = 10) {
    return makeAuthenticatedAirflowRequest(`/dags/${dagId}/dagRuns?limit=${limit}&order_by=-logical_date`);
  }
};

export default {
  validateJwtToken,
  getCurrentJwtToken,
  clearJwtToken,
  testAirflowConnection,
  refreshJwtTokenIfNeeded,
  makeAuthenticatedAirflowRequest,
  exampleAirflowOperations
};
