import { API_BASE_URL } from '@/config';

interface ServiceStatus {
  service: string;
  url: string;
  status: 'online' | 'offline' | 'checking';
  lastChecked?: Date;
  error?: string;
}

export class ServiceHealthChecker {
  private static statusCache: Map<string, ServiceStatus> = new Map();
  
  static async checkBackendHealth(): Promise<ServiceStatus> {
    const service = 'backend';
    const url = `${API_BASE_URL}/health`;
    
    // Return cached status if checked recently (within 30 seconds)
    const cached = this.statusCache.get(service);
    if (cached && cached.lastChecked && (Date.now() - cached.lastChecked.getTime()) < 30000) {
      return cached;
    }
    
    const status: ServiceStatus = {
      service,
      url,
      status: 'checking',
      lastChecked: new Date()
    };
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000); // 3 second timeout
      
      const response = await fetch(url, {
        method: 'GET',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        status.status = 'online';
      } else {
        status.status = 'offline';
        status.error = `HTTP ${response.status}`;
      }
    } catch (error) {
      status.status = 'offline';
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          status.error = 'Timeout (3s)';
        } else {
          status.error = error.message;
        }
      } else {
        status.error = 'Unknown error';
      }
    }
    
    this.statusCache.set(service, status);
    return status;
  }
  
  static async checkAirflowHealth(): Promise<ServiceStatus> {
    const service = 'airflow';
    const url = `${import.meta.env.VITE_AIRFLOW_URL || 'http://localhost:8083'}/health`;
    
    // Return cached status if checked recently (within 30 seconds)
    const cached = this.statusCache.get(service);
    if (cached && cached.lastChecked && (Date.now() - cached.lastChecked.getTime()) < 30000) {
      return cached;
    }
    
    const status: ServiceStatus = {
      service,
      url,
      status: 'checking',
      lastChecked: new Date()
    };
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000); // 3 second timeout
      
      const response = await fetch(url, {
        method: 'GET',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        status.status = 'online';
      } else {
        status.status = 'offline';
        status.error = `HTTP ${response.status}`;
      }
    } catch (error) {
      status.status = 'offline';
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          status.error = 'Timeout (3s)';
        } else {
          status.error = error.message;
        }
      } else {
        status.error = 'Unknown error';
      }
    }
    
    this.statusCache.set(service, status);
    return status;
  }
  
  static async checkAllServices(): Promise<ServiceStatus[]> {
    const [backend, airflow] = await Promise.all([
      this.checkBackendHealth(),
      this.checkAirflowHealth()
    ]);
    
    return [backend, airflow];
  }
  
  static clearCache(): void {
    this.statusCache.clear();
  }
}

export default ServiceHealthChecker;
