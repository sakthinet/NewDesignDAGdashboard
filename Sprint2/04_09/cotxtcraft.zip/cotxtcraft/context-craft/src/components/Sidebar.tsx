import { NavLink } from "react-router-dom";
import { Home, FolderPlus, TestTube, Settings } from "lucide-react";

const navItems = [
  { label: "Dashboard", icon: <Home size={18} />, path: "/" },
  { label: "Create Pipeline", icon: <FolderPlus size={18} />, path: "/create-pipeline" },
  { label: "Create API", icon: <Settings size={18} />, path: "/create-api" },
  { label: "Test API", icon: <TestTube size={18} />, path: "/test-api" },
];

const Sidebar = () => (
  <aside className="w-64 h-screen bg-gray-900 text-white px-6 py-8 flex flex-col justify-between shadow-lg">
    <div>
      <h2 className="text-2xl font-bold mb-8 text-center tracking-wide">🧠 Context Craft</h2>
      <nav className="space-y-1">
        {navItems.map(({ label, icon, path }) => (
          <NavLink
            key={label}
            to={path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2 rounded-lg font-medium transition-colors ${
                isActive ? "bg-gray-700 text-blue-300" : "hover:bg-gray-800"
              }`
            }
          >
            {icon}
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
    <div className="text-xs text-gray-500 text-center">
      © {new Date().getFullYear()} Context Craft
    </div>
  </aside>
);

export default Sidebar;
