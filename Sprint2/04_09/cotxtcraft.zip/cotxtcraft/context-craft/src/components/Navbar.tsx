export default function Navbar() {
  return (
    <div className="bg-white shadow p-4 flex justify-between items-center rounded-xl mb-4">
      <div className="text-xl font-bold text-gray-800">Context Craft: Transform and Serve Unstructured data to GenAI</div>
    </div>
  );
}