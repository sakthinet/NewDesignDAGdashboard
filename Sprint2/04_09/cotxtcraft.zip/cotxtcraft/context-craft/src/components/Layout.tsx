import { Link, useLocation } from 'react-router-dom'

const Layout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation()

  const navItems = [
    { name: 'Pipelines', path: '/' },
    { name: 'APIs', path: '/apis' },
    { name: 'Test Console', path: '/test' },
  ]

  return (
    <div>
      <header className="bg-white shadow sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-bold text-blue-600"> Context Craft:Transform and Serve Unstructured data to GenAI</h1>
          <nav className="flex space-x-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`nav-link ${
                  location.pathname === item.path ? 'nav-link-active' : ''
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 py-6">{children}</main>
    </div>
  )
}

export default Layout