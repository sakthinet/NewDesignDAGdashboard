import { Outlet } from "react-router-dom";
import Sidebar from "./components/Sidebar";

export default function AppLayout() {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow px-6 py-4 flex justify-between items-center border-b">
          <h2 className="text-xl font-semibold">Transform & Deliver Unstructured Data To GenAI</h2>
        </header>
        <main className="p-6 bg-gray-50 flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}