// src/lib/use-toast.ts

import * as React from "react";

export type Toast = {
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
};

const ToastContext = React.createContext<{
  toast: (opts: Toast) => void;
} | null>(null);

export const useToast = () => {
  const context = React.useContext(ToastContext);
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return context;
};

// Optional: This is a minimal provider for testing
export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const toast = (opts: Toast) => {
    console.log("🔥 Toast: ", opts);
    alert(opts.title || "Toast!");
  };

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
    </ToastContext.Provider>
  );
};