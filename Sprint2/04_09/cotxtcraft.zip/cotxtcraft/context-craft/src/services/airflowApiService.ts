import { airflowToken } from '@/config';

// Airflow Configuration Interface
interface AirflowConfig {
  baseUrl: string;
  apiVersion: string;
  authEndpoint: string;
  defaultCredentials: {
    username: string;
    password: string;
  };
}

// JWT Token Management
let currentJwtToken: string | null = airflowToken || null;
let tokenExpiry: number | null = null;
let isAuthenticating = false;

// Function to get current Airflow configuration
const getAirflowConfig = (): AirflowConfig => {
  return {
    baseUrl: import.meta.env.VITE_AIRFLOW_URL || 'http://localhost:8083',
    apiVersion: '/api/v2',
    authEndpoint: '/auth/token',
    defaultCredentials: {
      username: import.meta.env.VITE_AIRFLOW_USERNAME || 'admin',
      password: import.meta.env.VITE_AIRFLOW_PASSWORD || 'admin'
    }
  };
};

// Get initial configuration
let AIRFLOW_CONFIG = getAirflowConfig();

// Helper function to check if token is expired
const isTokenExpired = (): boolean => {
  if (!currentJwtToken || !tokenExpiry) return true;
  const fiveMinutesFromNow = Date.now() + (5 * 60 * 1000);
  return tokenExpiry <= fiveMinutesFromNow;
};

// Function to authenticate and get JWT token
const authenticateAndGetToken = async (): Promise<string | null> => {
  if (isAuthenticating) {
    while (isAuthenticating) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return currentJwtToken;
  }

  isAuthenticating = true;
  
  try {
    console.log('🔐 Authenticating with Airflow API...');
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
    
    const response = await fetch(`${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.authEndpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        username: AIRFLOW_CONFIG.defaultCredentials.username,
        password: AIRFLOW_CONFIG.defaultCredentials.password
      }),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Authentication failed: HTTP ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    const token = data.access_token || data.token || data.accessToken;
    
    if (!token) {
      throw new Error('No access token received from authentication endpoint');
    }

    currentJwtToken = token;
    tokenExpiry = Date.now() + (50 * 60 * 1000); // 50 minutes expiry
    
    console.log('✅ Successfully authenticated with Airflow API');
    return currentJwtToken;
    
  } catch (error) {
    console.error('❌ Authentication failed:', error);
    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        console.error('Authentication request timed out');
      }
    }
    currentJwtToken = null;
    tokenExpiry = null;
    throw error;
  } finally {
    isAuthenticating = false;
  }
};

// Function to get valid JWT token
const getValidToken = async (): Promise<string> => {
  if (isTokenExpired()) {
    console.log('🔄 Token expired or missing, getting new token...');
    const token = await authenticateAndGetToken();
    if (!token) {
      throw new Error('Failed to authenticate with Airflow');
    }
    return token;
  }
  return currentJwtToken!;
};

// Helper function to make authenticated API requests with caching
const makeAuthenticatedRequest = async (
  endpoint: string, 
  options: RequestInit = {}
): Promise<any> => {
  const maxRetries = 2;
  let retryCount = 0;
  
  while (retryCount < maxRetries) {
    try {
      const token = await getValidToken();
      const url = `${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.apiVersion}${endpoint}`;
      
      const config: RequestInit = {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`,
          ...options.headers
        },
        ...options,
      };

      console.log(`📡 Making authenticated request to: ${url}`);
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorText = await response.text();
        if (response.status === 401 || response.status === 403) {
          console.log('🔐 Authentication error detected, clearing token...');
          currentJwtToken = null;
          tokenExpiry = null;
          if (retryCount === 0) {
            retryCount++;
            continue;
          }
        }
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const contentType = response.headers.get('content-type');
      let result;
      
      if (contentType && contentType.includes('application/json')) {
        result = await response.json();
      } else {
        result = await response.text();
      }
      
      return result;
      
    } catch (error) {
      if (retryCount < maxRetries && (error as Error).message.includes('401')) {
        retryCount++;
        continue;
      }
      throw error;
    }
  }
  
  throw new Error('Max retries exceeded');
};

// Airflow API Service
export class AirflowApiService {
  
  // Test connection to Airflow
  static async testConnection(): Promise<{
    connected: boolean;
    status?: any;
    url: string;
    token?: string;
    apiVersion?: string;
    authMethod?: string;
    error?: string;
  }> {
    try {
      const result = await makeAuthenticatedRequest('/version');
      return {
        connected: true,
        status: result,
        url: AIRFLOW_CONFIG.baseUrl,
        token: currentJwtToken || undefined,
        apiVersion: AIRFLOW_CONFIG.apiVersion,
        authMethod: 'JWT'
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      return {
        connected: false,
        url: AIRFLOW_CONFIG.baseUrl,
        error: errorMessage
      };
    }
  }

  // Get all DAGs
  static async getDags(): Promise<any> {
    try {
      return await makeAuthenticatedRequest('/dags');
    } catch (error) {
      console.error('Failed to fetch DAGs:', error);
      throw error;
    }
  }

  // Get specific DAG
  static async getDag(dagId: string): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}`);
    } catch (error) {
      console.error(`Failed to fetch DAG ${dagId}:`, error);
      throw error;
    }
  }

  // Get DAG runs
  static async getDagRuns(dagId: string, limit = 10, offset = 0): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}/dagRuns?limit=${limit}&offset=${offset}&order_by=-logical_date`);
    } catch (error) {
      console.error(`Failed to fetch DAG runs for ${dagId}:`, error);
      throw error;
    }
  }

  // Trigger DAG
  static async triggerDag(dagId: string, conf: any = {}): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}/dagRuns`, {
        method: 'POST',
        body: JSON.stringify({
          conf: conf,
          dag_run_id: null, // Let Airflow generate the ID
        })
      });
    } catch (error) {
      console.error(`Failed to trigger DAG ${dagId}:`, error);
      throw error;
    }
  }

  // Pause/Unpause DAG
  static async pauseUnpauseDag(dagId: string, isPaused: boolean): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}`, {
        method: 'PATCH',
        body: JSON.stringify({
          is_paused: isPaused
        })
      });
    } catch (error) {
      console.error(`Failed to ${isPaused ? 'pause' : 'unpause'} DAG ${dagId}:`, error);
      throw error;
    }
  }

  // Get task instances for a DAG run
  static async getTaskInstances(dagId: string, runId: string): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}/dagRuns/${encodeURIComponent(runId)}/taskInstances`);
    } catch (error) {
      console.error(`Failed to fetch task instances for ${dagId}/${runId}:`, error);
      throw error;
    }
  }

  // Get task logs
  static async getTaskLogs(dagId: string, runId: string, taskId: string, tryNumber = 1): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}/dagRuns/${encodeURIComponent(runId)}/taskInstances/${encodeURIComponent(taskId)}/logs/${tryNumber}`);
    } catch (error) {
      console.error(`Failed to fetch task logs for ${dagId}/${runId}/${taskId}:`, error);
      throw error;
    }
  }

  // Delete DAG run
  static async deleteDagRun(dagId: string, runId: string): Promise<any> {
    try {
      return await makeAuthenticatedRequest(`/dags/${encodeURIComponent(dagId)}/dagRuns/${encodeURIComponent(runId)}`, {
        method: 'DELETE'
      });
    } catch (error) {
      console.error(`Failed to delete DAG run ${dagId}/${runId}:`, error);
      throw error;
    }
  }

  // Get Airflow system info
  static async getAirflowInfo(): Promise<any> {
    try {
      return await makeAuthenticatedRequest('/version');
    } catch (error) {
      console.error('Failed to fetch Airflow info:', error);
      throw error;
    }
  }

  // Clear current JWT token (for logout/re-authentication)
  static clearToken(): void {
    currentJwtToken = null;
    tokenExpiry = null;
    console.log('🔓 JWT token cleared');
  }

  // Check if currently authenticated
  static isAuthenticated(): boolean {
    return !isTokenExpired();
  }

  // Get current token (for debugging purposes)
  static getCurrentToken(): string | null {
    return currentJwtToken;
  }
}

// Export default service instance
export default AirflowApiService;

// Export specific functions for backward compatibility
export {
  getAirflowConfig,
  isTokenExpired,
  authenticateAndGetToken,
  getValidToken,
  makeAuthenticatedRequest
};
