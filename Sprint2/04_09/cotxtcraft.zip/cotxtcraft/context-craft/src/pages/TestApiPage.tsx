import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { API_BASE_URL } from "@/config";

interface MountedApi {
  name: string;
  prefix: string;
  endpoints: string[];
}

export default function TestApiPage() {
  const location = useLocation();
  const initialApi = location.state?.apiUrl ?? "";
  const [apis, setApis] = useState<MountedApi[]>([]);
  const [selectedApi, setSelectedApi] = useState(initialApi);
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<any>(null);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [showRaw, setShowRaw] = useState(false);
  const [showRequest, setShowRequest] = useState(false);

  useEffect(() => {
    const fetchApis = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/wizard/status`);
        const data = await res.json();
        setApis(data.mounted_routers || []);
        if (!initialApi && data.mounted_routers.length > 0) {
          const first = data.mounted_routers[0]?.endpoints?.[0] ?? "";
          setSelectedApi(first);
        }
      } catch (err) {
        console.error("Failed to load APIs:", err);
      }
    };

    fetchApis();
  }, [initialApi]);

  const handleSearch = async () => {
    if (!selectedApi || !query) return;
    setLoading(true);
    setResult(null);
    setResponseStatus(null);
    try {
      const payload = { search_term: query };
      const res = await fetch(`${API_BASE_URL}${selectedApi}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      setResponseStatus(res.status);
      const json = await res.json();
      setResult(json);
      setShowRaw(false);
    } catch (err) {
      console.error("Search failed:", err);
      setResult({ error: "Search failed" });
    } finally {
      setLoading(false);
    }
  };

  const renderSummaryResults = () => {
    const items = result?.results || [];

    if (!Array.isArray(items) || items.length === 0) {
      return <p className="text-sm text-gray-500">No results found.</p>;
    }

    return (
      <ul className="space-y-4 text-sm leading-relaxed">
        {items.map((item: any, idx: number) => {
          const text = item.payload?.text || "[No text]";
          const source = item.payload?.source_file || "Unknown source";
          return (
            <li
              key={idx}
              className="p-3 border rounded-md bg-white shadow-sm"
            >
              {text}{" "}
              <span className="text-gray-500 italic">
                (source file: {source})
              </span>
            </li>
          );
        })}
      </ul>
    );
  };

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(result, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "search-results.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-semibold">Test Search API</h2>

      {/* API Selection */}
      <Card>
        <CardHeader>
          <CardTitle>API Selection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Label>Select Active API</Label>
          <Select value={selectedApi} onValueChange={setSelectedApi}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select an API" />
            </SelectTrigger>
            <SelectContent>
              {apis.map((api) =>
                api.endpoints.map((ep) => (
                  <SelectItem key={ep} value={ep}>
                    {api.name} → {ep}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Query Input */}
      <Card>
        <CardHeader>
          <CardTitle>Search Query</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="query">Query</Label>
            <Input
              id="query"
              placeholder="e.g., 'Find invoice summary for vendor X'"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <Button onClick={handleSearch} disabled={!selectedApi || loading}>
            {loading ? "Searching..." : "Search"}
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {result && (
        <Card>
          <CardHeader className="flex flex-row justify-between items-center space-x-2">
            <CardTitle>Search Results</CardTitle>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowRequest(!showRequest)}
                className="text-xs underline text-blue-600"
              >
                {showRequest ? "Hide Request" : "Request"}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowRaw(!showRaw)}
                className="text-xs underline text-purple-600"
              >
                {showRaw ? "Hide Response" : "Response"}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={downloadJson}
                className="text-xs underline text-green-600"
              >
                Download JSON
              </Button>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {!showRequest && !showRaw && renderSummaryResults()}

            {showRequest && (
              <div className="bg-gray-50 border p-4 rounded text-sm space-y-2 max-h-[400px] overflow-auto">
                <div><strong>Endpoint:</strong> {selectedApi}</div>
                <div><strong>Method:</strong> POST</div>
                <div><strong>Headers:</strong></div>
                <pre className="bg-gray-100 p-2 rounded text-xs">
{`Content-Type: application/json`}
                </pre>
                <div><strong>Payload:</strong></div>
                <pre className="bg-gray-100 p-2 rounded text-xs">
{JSON.stringify({ search_term: query }, null, 2)}
                </pre>
              </div>
            )}

            {showRaw && (
              <div className="space-y-2">
                {responseStatus && (
                  <p className="text-xs text-gray-600">
                    <strong>Status:</strong> {responseStatus}
                  </p>
                )}
                <pre className="whitespace-pre-wrap text-sm bg-gray-100 p-4 rounded-md overflow-auto max-h-[400px]">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}