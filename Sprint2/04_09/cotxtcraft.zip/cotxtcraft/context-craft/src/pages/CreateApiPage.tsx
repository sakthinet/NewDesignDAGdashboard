import { useState } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ENDPOINTS, DATABASE_TYPES, METRICS, QDRANT_URL } from "@/config";

export default function CreateApiPage() {
  const [name, setName] = useState("");
  const [databaseType, setDatabaseType] = useState("Qdrant");
  const [qdrantUrl, setQdrantUrl] = useState(QDRANT_URL);
  const [collections, setCollections] = useState<string[]>([]);
  const [selectedCollection, setSelectedCollection] = useState("");
  const [topK, setTopK] = useState("5");
  const [metric, setMetric] = useState("cosine");
  const [loadingCollections, setLoadingCollections] = useState(false);
  const [creating, setCreating] = useState(false);
  const [message, setMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleTestConnection = async () => {
    setLoadingCollections(true);
    setMessage("");

    if (!qdrantUrl.startsWith("http")) {
      setMessage("❌ Invalid URL format.");
      setLoadingCollections(false);
      return;
    }

    try {
      const res = await fetch(`${qdrantUrl}/collections`);
      if (!res.ok) throw new Error("Non-200 response");

      const data = await res.json();
      const found = data?.result?.collections?.map((c: any) => c.name) || [];
      setCollections(found);
      if (found.length > 0) setSelectedCollection(found[0]);
      setMessage(`✅ Found ${found.length} collections`);
    } catch (err) {
      console.error("Connection failed", err);
      setCollections([]);
      setSelectedCollection("");
      setMessage("❌ Failed to connect to Qdrant. Check URL or server status.");
    } finally {
      setLoadingCollections(false);
    }
  };

  const resetForm = () => {
    setName("");
    setQdrantUrl(QDRANT_URL);
    setCollections([]);
    setSelectedCollection("");
    setTopK("5");
    setMetric("cosine");
    setMessage("");
  };

  const handleCreateApi = async () => {
    if (!name || !selectedCollection) {
      setMessage("❌ Name and collection are required.");
      return;
    }

    setCreating(true);
    setMessage("");
    setSuccessMessage("");

    try {
      const payload = {
        name,
        collection: selectedCollection,
        metric,
        top_k: Number(topK),
      };

      const res = await fetch(ENDPOINTS.GENERATE_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const json = await res.json();

      if (json.status === "mounted") {
        const endpoint = `/api/${name}/search`;
        setSuccessMessage(`✅ API Created: POST ${endpoint}`);
        resetForm();
      } else {
        setMessage("❌ Failed to create API.");
      }
    } catch (err) {
      console.error("Error creating API", err);
      setMessage("❌ Error occurred while creating API.");
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-semibold">Create Search API</h2>

      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-800 px-4 py-2 rounded-md">
          {successMessage}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>API Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">API Name</Label>
            <Input
              id="name"
              placeholder="Unique name for this API"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div>
            <Label>Database Type</Label>
            <Select
              value={databaseType}
              onValueChange={(val) => setDatabaseType(val)}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select database" />
              </SelectTrigger>
              <SelectContent>
                {DATABASE_TYPES.map((db) => (
                  <SelectItem key={db} value={db}>
                    {db}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {databaseType === "Qdrant" && (
            <>
              <div>
                <Label htmlFor="qdrantUrl">Qdrant Connection URL</Label>
                <Input
                  id="qdrantUrl"
                  value={qdrantUrl}
                  onChange={(e) => setQdrantUrl(e.target.value)}
                />
                <Button
                  type="button"
                  className="mt-2"
                  onClick={handleTestConnection}
                  disabled={loadingCollections}
                >
                  {loadingCollections ? "Testing..." : "Test Connection"}
                </Button>
              </div>

              {collections.length > 0 && (
                <div>
                  <Label>Collection</Label>
                  <Select
                    value={selectedCollection}
                    onValueChange={(val) => setSelectedCollection(val)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select collection" />
                    </SelectTrigger>
                    <SelectContent>
                      {collections.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </>
          )}

          <div>
            <Label>Similarity Metric</Label>
            <Select value={metric} onValueChange={setMetric}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {METRICS.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="topK">Top K</Label>
            <Input
              id="topK"
              type="number"
              value={topK}
              onChange={(e) => setTopK(e.target.value)}
            />
          </div>

          <Button onClick={handleCreateApi} disabled={creating}>
            {creating ? "Creating..." : "Create API"}
          </Button>

          {message && <p className="text-sm mt-2 text-red-600">{message}</p>}
        </CardContent>
      </Card>
    </div>
  );
}