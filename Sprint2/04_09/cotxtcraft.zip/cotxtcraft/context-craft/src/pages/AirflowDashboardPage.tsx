import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAirflowApi } from '@/hooks/useAirflowApi';
import { airflowDagId } from '@/config';

export default function DashboardPage() {
  const {
    loading,
    error,
    getDags,
    getDagRuns,
    triggerDag,
    testConnection,
    isAuthenticated,
    clearError
  } = useAirflowApi();

  const [dags, setDags] = useState<any[]>([]);
  const [dagRuns, setDagRuns] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<any>(null);

  // Test connection on component mount
  useEffect(() => {
    const checkConnection = async () => {
      try {
        const status = await testConnection();
        setConnectionStatus(status);
        
        if (status?.connected) {
          // Load DAGs if connected
          loadDags();
          loadDagRuns();
        }
      } catch (err) {
        console.error('Failed to test connection:', err);
      }
    };

    checkConnection();
  }, [testConnection]);

  const loadDags = async () => {
    try {
      const response = await getDags();
      if (response?.dags) {
        setDags(response.dags);
      }
    } catch (err) {
      console.error('Failed to load DAGs:', err);
    }
  };

  const loadDagRuns = async () => {
    try {
      const response = await getDagRuns(airflowDagId, 10);
      if (response?.dag_runs) {
        setDagRuns(response.dag_runs);
      }
    } catch (err) {
      console.error('Failed to load DAG runs:', err);
    }
  };

  const handleTriggerDag = async () => {
    try {
      await triggerDag(airflowDagId, { trigger_source: 'dashboard' });
      // Reload DAG runs after triggering
      loadDagRuns();
    } catch (err) {
      console.error('Failed to trigger DAG:', err);
    }
  };

  const getStatusBadge = (state: string) => {
    const statusMap: { [key: string]: string } = {
      'success': 'bg-green-500',
      'failed': 'bg-red-500',
      'running': 'bg-blue-500',
      'queued': 'bg-yellow-500',
      'up_for_retry': 'bg-orange-500',
      'up_for_reschedule': 'bg-purple-500',
      'upstream_failed': 'bg-red-400',
      'skipped': 'bg-gray-500',
    };
    
    return (
      <Badge className={statusMap[state] || 'bg-gray-500'}>
        {state}
      </Badge>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Airflow Dashboard</h1>
          {error && (
            <div className="flex items-center space-x-2">
              <span className="text-red-500">{error}</span>
              <Button onClick={clearError} variant="outline" size="sm">
                Clear Error
              </Button>
            </div>
          )}
        </div>

        {/* Connection Status */}
        <Card>
          <CardHeader>
            <CardTitle>Connection Status</CardTitle>
            <CardDescription>Airflow API connection and authentication status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <span>Status:</span>
                <Badge className={connectionStatus?.connected ? 'bg-green-500' : 'bg-red-500'}>
                  {connectionStatus?.connected ? 'Connected' : 'Disconnected'}
                </Badge>
              </div>
              <div><strong>URL:</strong> {connectionStatus?.url}</div>
              <div><strong>API Version:</strong> {connectionStatus?.apiVersion}</div>
              <div><strong>Auth Method:</strong> {connectionStatus?.authMethod}</div>
              <div><strong>Authenticated:</strong> {isAuthenticated() ? 'Yes' : 'No'}</div>
              {connectionStatus?.error && (
                <div className="text-red-500"><strong>Error:</strong> {connectionStatus.error}</div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* DAGs Overview */}
        <Card>
          <CardHeader>
            <CardTitle>DAGs Overview</CardTitle>
            <CardDescription>Available DAGs in Airflow</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div>Loading DAGs...</div>
            ) : dags.length > 0 ? (
              <div className="space-y-2">
                {dags.slice(0, 5).map((dag: any) => (
                  <div key={dag.dag_id} className="flex justify-between items-center p-2 border rounded">
                    <div>
                      <span className="font-medium">{dag.dag_id}</span>
                      <p className="text-sm text-gray-600">{dag.description || 'No description'}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={dag.is_paused ? 'bg-red-500' : 'bg-green-500'}>
                        {dag.is_paused ? 'Paused' : 'Active'}
                      </Badge>
                    </div>
                  </div>
                ))}
                <div className="text-sm text-gray-500">
                  Showing {Math.min(5, dags.length)} of {dags.length} DAGs
                </div>
              </div>
            ) : (
              <div>No DAGs found</div>
            )}
          </CardContent>
        </Card>

        {/* DAG Runs */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Recent DAG Runs</CardTitle>
                <CardDescription>Latest runs for {airflowDagId}</CardDescription>
              </div>
              <Button 
                onClick={handleTriggerDag} 
                disabled={loading || !connectionStatus?.connected}
              >
                Trigger DAG
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div>Loading DAG runs...</div>
            ) : dagRuns.length > 0 ? (
              <div className="space-y-2">
                {dagRuns.slice(0, 10).map((run: any) => (
                  <div key={run.dag_run_id} className="flex justify-between items-center p-2 border rounded">
                    <div>
                      <span className="font-medium">{run.dag_run_id}</span>
                      <p className="text-sm text-gray-600">
                        Started: {new Date(run.logical_date || run.execution_date).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusBadge(run.state)}
                      {run.end_date && (
                        <span className="text-sm text-gray-500">
                          Ended: {new Date(run.end_date).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div>No DAG runs found</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
