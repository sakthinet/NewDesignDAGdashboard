import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./index.css";
import AppLayout from "./AppLayout";
import Dashboard from "./pages/DashboardPage";
import CreatePipeline from "./pages/VectorPipelinesPage";
import CreateAPI from "./pages/CreateApiPage";
import TestAPI from "./pages/TestApiPage";
import { Toaster } from "react-hot-toast";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Toaster position="top-right" />
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/create-pipeline" element={<CreatePipeline />} />
          <Route path="/create-api" element={<CreateAPI />} />
          <Route path="/test-api" element={<TestAPI />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);