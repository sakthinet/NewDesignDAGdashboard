Write-Host "🔍 Context Craft Service Health Check" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan

# Check Backend API
Write-Host "📡 Checking Backend API (http://localhost:8000)..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8000/wizard/status" -TimeoutSec 3 -ErrorAction Stop
    Write-Host "✅ Backend API: ONLINE" -ForegroundColor Green
} catch {
    Write-Host "❌ Backend API: OFFLINE" -ForegroundColor Red
    Write-Host "   💡 To start: uvicorn main:app --host localhost --port 8000" -ForegroundColor Gray
}

Write-Host ""

# Check Airflow
Write-Host "🌪️ Checking Airflow (http://localhost:8083)..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8083/" -TimeoutSec 3 -ErrorAction Stop
    Write-Host "✅ Airflow Web UI: ONLINE" -ForegroundColor Green
} catch {
    Write-Host "❌ Airflow Web UI: OFFLINE" -ForegroundColor Red
    Write-Host "   💡 To start: airflow webserver --port 8083" -ForegroundColor Gray
}

# Check Airflow API v2
Write-Host "🔌 Checking Airflow API v2..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8083/api/v2/dags" -TimeoutSec 3 -ErrorAction Stop
    Write-Host "✅ Airflow API v2: ONLINE (Status: $($response.StatusCode))" -ForegroundColor Green
} catch {
    if ($_.Exception.Message -like "*403*") {
        Write-Host "⚠️ Airflow API v2: Authentication Required (403)" -ForegroundColor Yellow
        Write-Host "   💡 Check JWT token in config.ts" -ForegroundColor Gray
    } else {
        Write-Host "❌ Airflow API v2: OFFLINE - $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""

# Check Frontend
Write-Host "🖥️ Checking Frontend (http://localhost:5175)..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:5175" -TimeoutSec 3 -ErrorAction Stop
    Write-Host "✅ Frontend: ONLINE" -ForegroundColor Green
} catch {
    Write-Host "❌ Frontend: OFFLINE" -ForegroundColor Red
    Write-Host "   💡 To start: npm run dev" -ForegroundColor Gray
}

Write-Host ""
Write-Host "📋 Summary:" -ForegroundColor Cyan
Write-Host "- Backend API provides data for dashboard stats"
Write-Host "- Airflow provides workflow management"  
Write-Host "- Frontend shows mock data when services are offline"
Write-Host ""
Write-Host "🚀 The application works with graceful fallbacks even when services are offline!" -ForegroundColor Green
