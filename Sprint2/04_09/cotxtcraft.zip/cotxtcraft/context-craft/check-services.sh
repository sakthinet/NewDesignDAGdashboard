#!/bin/bash

echo "🔍 Context Craft Service Health Check"
echo "======================================"

# Check Backend API
echo "📡 Checking Backend API (http://127.0.0.1:8000)..."
if curl -s --connect-timeout 3 http://127.0.0.1:8000/health >/dev/null 2>&1; then
    echo "✅ Backend API: ONLINE"
else
    echo "❌ Backend API: OFFLINE"
    echo "   💡 To start: uvicorn main:app --host 127.0.0.1 --port 8000"
fi

echo ""

# Check Airflow  
echo "🌪️ Checking Airflow (http://localhost:8083)..."
if curl -s --connect-timeout 3 http://localhost:8083/health >/dev/null 2>&1; then
    echo "✅ Airflow: ONLINE"
else
    echo "❌ Airflow: OFFLINE"
    echo "   💡 To start: airflow webserver --port 8083"
fi

echo ""

# Check Frontend
echo "🖥️ Checking Frontend (http://localhost:5175)..."
if curl -s --connect-timeout 3 http://localhost:5175 >/dev/null 2>&1; then
    echo "✅ Frontend: ONLINE"
else
    echo "❌ Frontend: OFFLINE"
    echo "   💡 To start: npm run dev"
fi

echo ""
echo "📋 Summary:"
echo "- Backend API provides data for dashboard stats"
echo "- Airflow provides workflow management"  
echo "- Frontend shows mock data when services are offline"
echo ""
echo "🚀 The application works with graceful fallbacks even when services are offline!"
