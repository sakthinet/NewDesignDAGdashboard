# Troubleshooting Guide - API and Airflow Connection Issues

## Current Issues Identified

Based on the browser console errors shown in the screenshot, here are the main issues and their solutions:

### 1. CORS Policy Violations ❌

**Problem:** Multiple API endpoints blocked due to CORS policy violations
```
Access to fetch at 'http://127.0.0.1:8000/...' from origin 'http://localhost:5175' has been blocked by CORS policy
```

**Root Cause:** Backend server at `http://127.0.0.1:8000` is not running or not configured for CORS

**Solutions:**

#### A. Start the Backend Server
The backend API server needs to be running on port 8000:
```bash
# If you have a Python backend
python main.py
# or
uvicorn main:app --host 127.0.0.1 --port 8000

# If you have a Node.js backend
npm start
# or
node server.js
```

#### B. Configure CORS on Backend
If using FastAPI (Python):
```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5175", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

If using Express.js (Node):
```javascript
const cors = require('cors');
app.use(cors({
  origin: ['http://localhost:5175', 'http://localhost:3000'],
  credentials: true
}));
```

### 2. Airflow Connection Issues ❌

**Problem:** Airflow API authentication failing
```
Status: Failed to authenticate with Airflow
```

**Root Cause:** Airflow server not running on expected port or incorrect credentials

**Solutions:**

#### A. Start Airflow Server
```bash
# Start Airflow webserver
airflow webserver --port 8083

# In another terminal, start scheduler
airflow scheduler
```

#### B. Check Airflow Configuration
Verify Airflow is accessible:
```bash
curl http://localhost:8083/health
```

#### C. Update Environment Variables
Create/update `.env.development`:
```env
VITE_AIRFLOW_URL=http://localhost:8083
VITE_AIRFLOW_USERNAME=admin
VITE_AIRFLOW_PASSWORD=admin
```

### 3. Backend API Endpoints Missing ❌

**Problem:** Multiple 404 errors for API endpoints

**Required Endpoints:**
- `GET /wizard/status` - API status
- `GET /logs/count` - API call count
- `GET /vectorized-documents/count` - Document count  
- `GET /active-pipelines/count` - Pipeline count
- `GET /airflow/dag-runs/DataForGenAI` - DAG runs

## Quick Fix Implementation ✅

I've implemented graceful fallbacks in the code that will:

1. **Show mock data** when backend is unavailable
2. **Display offline mode banner** to inform users
3. **Provide sample DAG runs** when Airflow is unavailable
4. **Handle timeouts** and connection errors gracefully

## Step-by-Step Resolution

### Step 1: Check Service Status
```bash
# Check if backend is running
curl http://127.0.0.1:8000/health

# Check if Airflow is running  
curl http://localhost:8083/health
```

### Step 2: Start Missing Services

#### Backend Server:
If you have the backend code, start it:
```bash
# Python FastAPI
uvicorn main:app --host 127.0.0.1 --port 8000 --reload

# Node.js Express
npm run dev
```

#### Airflow:
```bash
# Initialize Airflow (first time only)
airflow db init
airflow users create --username admin --password admin --firstname Admin --lastname User --role Admin --email admin@example.com

# Start services
airflow webserver --port 8083 &
airflow scheduler &
```

### Step 3: Verify Environment Configuration

Create `.env.development` file:
```env
VITE_AIRFLOW_URL=http://localhost:8083
VITE_AIRFLOW_USERNAME=admin  
VITE_AIRFLOW_PASSWORD=admin
VITE_API_BASE_URL=http://127.0.0.1:8000
VITE_DEBUG_AIRFLOW=true
```

### Step 4: Test Connections

Use the browser console to test:
```javascript
// Test backend
fetch('http://127.0.0.1:8000/wizard/status')
  .then(r => r.json())
  .then(console.log)
  .catch(console.error);

// Test Airflow
fetch('http://localhost:8083/health')
  .then(r => r.json()) 
  .then(console.log)
  .catch(console.error);
```

## Current Application State

With the fixes implemented, the application will now:

✅ **Load successfully** even without backend services  
✅ **Show informative status** about service availability  
✅ **Display mock data** for demonstration  
✅ **Handle errors gracefully** with user-friendly messages  
✅ **Automatically retry** connections when services come online  

## Production Deployment Notes

For production deployment, ensure:

1. **CORS is properly configured** on backend
2. **Environment variables** are set correctly
3. **Services are running** on expected ports
4. **Network connectivity** exists between frontend and backend
5. **Authentication tokens** are valid and not expired

## Need More Help?

If services are still not working:

1. **Check the specific error messages** in browser console
2. **Verify network connectivity** to backend services
3. **Check firewall settings** that might block connections
4. **Review backend logs** for detailed error information
5. **Test with curl** or Postman to isolate frontend vs backend issues

The application is now resilient and will provide a good user experience even when some services are unavailable.
