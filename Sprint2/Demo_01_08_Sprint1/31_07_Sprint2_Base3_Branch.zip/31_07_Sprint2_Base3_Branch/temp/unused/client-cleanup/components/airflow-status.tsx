import { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle, RefreshCw, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAirflow } from '@/hooks/use-airflow';

export function AirflowStatus() {
  const { connectionStatus, testConnection } = useAirflow();
  const [isChecking, setIsChecking] = useState(false);

  const handleRefresh = async () => {
    setIsChecking(true);
    await testConnection();
    setIsChecking(false);
  };

  useEffect(() => {
    testConnection();
  }, [testConnection]);

  const getStatusIcon = () => {
    if (isChecking) {
      return <RefreshCw className="h-4 w-4 animate-spin" />;
    }
    return connectionStatus.connected ? 
      <CheckCircle className="h-4 w-4 text-cyan-600" /> :
      <AlertCircle className="h-4 w-4 text-red-600" />;
  };

  const getStatusText = () => {
    if (isChecking) return "Checking connection...";
    return connectionStatus.connected ? "Connected" : "Disconnected";
  };

  const getStatusVariant = () => {
    return connectionStatus.connected ? "default" : "destructive";
  };

  return (
    <Alert variant={getStatusVariant()} className="mb-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          {getStatusIcon()}
          <div>
            <div className="font-medium">
              Airflow {getStatusText()}
            </div>
            <AlertDescription className="text-sm mt-1">
              {connectionStatus.connected ? (
                <>Connected to {connectionStatus.url}</>
              ) : (
                <>
                  {connectionStatus.error || "Unable to connect to Airflow"}
                  <div className="mt-2 text-xs">
                    Make sure Airflow is running on {connectionStatus.url}
                  </div>
                </>
              )}
            </AlertDescription>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={isChecking}
          >
            <RefreshCw className={`h-4 w-4 ${isChecking ? 'animate-spin' : ''}`} />
          </Button>
          {connectionStatus.connected && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open(connectionStatus.url, '_blank')}
            >
              <ExternalLink className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    </Alert>
  );
}