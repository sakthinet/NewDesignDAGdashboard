import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";
import { XmlDownloadButton } from "./xml-download-button";

interface ViewXmlSchemaProps {
  uploadedFile: UploadedFile | null;
  config: DagConfig;
  onPrev: () => void;
  onNext: () => void;
}

export function ViewXmlSchema({ uploadedFile, config, onPrev, onNext }: ViewXmlSchemaProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleRefresh = () => {
    setIsLoading(true);
    toast({
      title: "Schema Refreshed", 
      description: "Schema view has been refreshed.",
    });
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">
            Download IA Schema
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Download generated XML schema files
          </p>
        </div>
        <div className="flex space-x-2">
          <XmlDownloadButton 
            csvFileName={uploadedFile?.fileName || ''}
            variant="outline"
            size="default"
          />
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isLoading}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-6 border-t">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Previous</span>
        </Button>
        
        <Button
          onClick={onNext}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
        >
          <span>Next: Transform CSV Data</span>
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
