// Test script for PostgreSQL Metrics API endpoints
// Run this script to verify all endpoints are working correctly

const BASE_URL = 'http://localhost:3003';

async function testEndpoint(endpoint, description) {
  console.log(`\n🔍 Testing ${description}...`);
  console.log(`📡 Endpoint: ${endpoint}`);
  
  try {
    const response = await fetch(endpoint);
    const data = await response.json();
    
    if (response.ok) {
      console.log(`✅ SUCCESS: ${description}`);
      console.log(`📊 Response:`, JSON.stringify(data, null, 2).substring(0, 500) + '...');
    } else {
      console.log(`❌ FAILED: ${description}`);
      console.log(`🚨 Error:`, data);
    }
  } catch (error) {
    console.log(`💥 ERROR: ${description}`);
    console.log(`🚨 Exception:`, error.message);
  }
}

async function runTests() {
  console.log('🚀 Starting PostgreSQL Metrics API Tests');
  console.log('=' * 50);

  // Test connection endpoint
  await testEndpoint(
    `${BASE_URL}/api/metrics/test-connection`,
    'Database Connection Test'
  );

  // Test metrics configuration
  await testEndpoint(
    `${BASE_URL}/api/metrics/config`,
    'Metrics Configuration'
  );

  // Test DAG runs metrics
  await testEndpoint(
    `${BASE_URL}/api/metrics/dag-runs`,
    'DAG Runs Metrics'
  );

  // Test summary analytics
  await testEndpoint(
    `${BASE_URL}/api/metrics/summary`,
    'Summary Analytics'
  );

  console.log('\n🏁 Test Suite Completed');
  console.log('=' * 50);
}

// For Node.js environment
if (typeof module !== 'undefined' && module.exports) {
  const fetch = require('node-fetch');
  runTests();
}

// For browser environment
if (typeof window !== 'undefined') {
  window.testMetricsAPI = runTests;
  console.log('💡 Run testMetricsAPI() in the browser console to test the endpoints');
}
