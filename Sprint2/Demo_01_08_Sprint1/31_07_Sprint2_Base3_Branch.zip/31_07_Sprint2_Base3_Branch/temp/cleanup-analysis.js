#!/usr/bin/env node

/**
 * Code Cleanup and Standards Enforcement Script
 * Identifies and helps remove unused code, formats files, and enforces standards
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class CodeCleanupTool {
  constructor() {
    this.unusedFiles = [];
    this.duplicateCode = [];
    this.formattingIssues = [];
    this.warnings = [];
  }

  async analyzeProject() {
    console.log('🔍 Starting project analysis...\n');
    
    await this.identifyUnusedFiles();
    await this.findDuplicateCode();
    await this.checkCodeStandards();
    
    this.generateReport();
  }

  async identifyUnusedFiles() {
    console.log('📂 Identifying potentially unused files...');
    
    const suspiciousFiles = [
      // Backup and temporary files
      'server/routes.ts.backup',
      'server/routes_fixed.ts',
      'temp/editable-schema-generator.tsx',
      'temp/enhanced-json-table-viewer.tsx',
      'temp/ia-table-schema-generator.tsx',
      'temp/json-table-viewer.tsx',
      
      // Redundant configuration files
      'test-env.js',
      'test-schema-config.js',
      
      // Old route implementations
      'server/incoming-json-routes.ts', // Superseded by incoming-json-routes-fixed.ts
      
      // Test files that might not be needed
      'test-file-upload.bat',
    ];

    for (const file of suspiciousFiles) {
      const fullPath = path.join(process.cwd(), file);
      if (fs.existsSync(fullPath)) {
        const stats = fs.statSync(fullPath);
        this.unusedFiles.push({
          path: file,
          size: stats.size,
          modified: stats.mtime,
          reason: this.getUnusedReason(file)
        });
      }
    }
  }

  getUnusedReason(filename) {
    if (filename.includes('.backup')) return 'Backup file';
    if (filename.includes('temp/')) return 'Temporary file in temp directory';
    if (filename.includes('test-')) return 'Test file that may not be needed';
    if (filename.includes('_fixed')) return 'May be superseded by enhanced version';
    return 'Potentially unused';
  }

  async findDuplicateCode() {
    console.log('🔄 Checking for duplicate code patterns...');
    
    const duplicatePatterns = [
      {
        description: 'Path formatting functions',
        files: ['server/routes.ts', 'server/routes_fixed.ts', 'server/routes-enhanced.ts'],
        pattern: 'formatUNCPath|formatWSLPath'
      },
      {
        description: 'Airflow authentication logic',
        files: ['server/routes.ts', 'server/routes-enhanced.ts'],
        pattern: 'authenticateAirflow|makeAirflowRequest'
      },
      {
        description: 'Configuration loading',
        files: ['shared/config.ts', 'shared/config-enhanced.ts'],
        pattern: 'getServerConfig|getClientConfig'
      }
    ];

    for (const pattern of duplicatePatterns) {
      const existingFiles = pattern.files.filter(file => 
        fs.existsSync(path.join(process.cwd(), file))
      );
      
      if (existingFiles.length > 1) {
        this.duplicateCode.push({
          description: pattern.description,
          files: existingFiles,
          recommendation: `Consider consolidating ${pattern.description} into the enhanced version`
        });
      }
    }
  }

  async checkCodeStandards() {
    console.log('📏 Checking code standards compliance...');
    
    const filesToCheck = [
      'server/routes.ts',
      'server/incoming-json-routes.ts',
      'shared/config.ts'
    ];

    for (const file of filesToCheck) {
      const fullPath = path.join(process.cwd(), file);
      if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf-8');
        const issues = this.analyzeCodeStandards(content, file);
        if (issues.length > 0) {
          this.formattingIssues.push({ file, issues });
        }
      }
    }
  }

  analyzeCodeStandards(content, filename) {
    const issues = [];
    const lines = content.split('\n');

    lines.forEach((line, index) => {
      // Check for long lines (over 120 characters)
      if (line.length > 120) {
        issues.push(`Line ${index + 1}: Line too long (${line.length} chars)`);
      }

      // Check for console.log statements (should use proper logging)
      if (line.includes('console.log') && !line.includes('//')) {
        issues.push(`Line ${index + 1}: Use proper logging instead of console.log`);
      }

      // Check for hardcoded paths
      if (line.includes('C:\\') || line.includes('D:\\')) {
        issues.push(`Line ${index + 1}: Hardcoded Windows path detected`);
      }

      // Check for TODO comments
      if (line.includes('TODO') || line.includes('FIXME')) {
        issues.push(`Line ${index + 1}: Unresolved TODO/FIXME comment`);
      }
    });

    return issues;
  }

  generateReport() {
    console.log('\n📊 CLEANUP ANALYSIS REPORT');
    console.log('=====================================\n');

    // Unused Files Report
    if (this.unusedFiles.length > 0) {
      console.log('🗑️  POTENTIALLY UNUSED FILES:');
      this.unusedFiles.forEach(file => {
        console.log(`   📄 ${file.path}`);
        console.log(`      Reason: ${file.reason}`);
        console.log(`      Size: ${(file.size / 1024).toFixed(2)} KB`);
        console.log(`      Modified: ${file.modified.toDateString()}\n`);
      });
    } else {
      console.log('✅ No obviously unused files detected\n');
    }

    // Duplicate Code Report
    if (this.duplicateCode.length > 0) {
      console.log('📋 DUPLICATE CODE PATTERNS:');
      this.duplicateCode.forEach(dup => {
        console.log(`   🔄 ${dup.description}`);
        console.log(`      Files: ${dup.files.join(', ')}`);
        console.log(`      Recommendation: ${dup.recommendation}\n`);
      });
    } else {
      console.log('✅ No significant code duplication detected\n');
    }

    // Code Standards Report
    if (this.formattingIssues.length > 0) {
      console.log('📏 CODE STANDARDS ISSUES:');
      this.formattingIssues.forEach(fileIssue => {
        console.log(`   📄 ${fileIssue.file}:`);
        fileIssue.issues.slice(0, 5).forEach(issue => {
          console.log(`      ⚠️  ${issue}`);
        });
        if (fileIssue.issues.length > 5) {
          console.log(`      ... and ${fileIssue.issues.length - 5} more issues`);
        }
        console.log('');
      });
    } else {
      console.log('✅ No major code standards issues detected\n');
    }

    // Recommendations
    console.log('💡 RECOMMENDATIONS:');
    console.log('=====================================');
    
    if (this.unusedFiles.length > 0) {
      console.log('1. 🗑️  Remove or archive unused files:');
      console.log('   - Move backup files to a separate backup directory');
      console.log('   - Remove temporary files in /temp directory');
      console.log('   - Archive old implementations after testing new ones\n');
    }

    if (this.duplicateCode.length > 0) {
      console.log('2. 🔄 Consolidate duplicate code:');
      console.log('   - Use the enhanced versions of shared utilities');
      console.log('   - Remove old implementations after migration');
      console.log('   - Update imports to use centralized modules\n');
    }

    console.log('3. 📏 Enforce coding standards:');
    console.log('   - Run Prettier for code formatting');
    console.log('   - Configure ESLint for consistent style');
    console.log('   - Use TypeScript strict mode for better type safety\n');

    console.log('4. 🧹 General cleanup:');
    console.log('   - Remove hardcoded paths and use configuration');
    console.log('   - Replace console.log with proper logging');
    console.log('   - Add proper error handling where missing');
    console.log('   - Update documentation for changed APIs\n');

    // Generate cleanup script
    this.generateCleanupScript();
  }

  generateCleanupScript() {
    const script = `#!/bin/bash
# Automated cleanup script generated by code analysis
# Review each command before running!

echo "🧹 Starting automated cleanup..."

# Create backup directory
mkdir -p .backup/\$(date +%Y%m%d_%H%M%S)

# Move backup files
${this.unusedFiles
  .filter(f => f.path.includes('.backup'))
  .map(f => `mv "${f.path}" .backup/$(date +%Y%m%d_%H%M%S)/`)
  .join('\n')}

# Remove temporary files (review first!)
${this.unusedFiles
  .filter(f => f.path.includes('temp/') || f.path.includes('test-'))
  .map(f => `# rm "${f.path}"  # Uncomment after review`)
  .join('\n')}

# Format code with Prettier
npx prettier --write "**/*.{ts,tsx,js,jsx}"

# Run ESLint with auto-fix
npx eslint --fix "**/*.{ts,tsx,js,jsx}"

echo "✅ Cleanup completed!"
`;

    fs.writeFileSync('cleanup.sh', script);
    console.log('📜 Generated cleanup.sh script (review before running)');
  }
}

// Run the analysis
const cleanup = new CodeCleanupTool();
cleanup.analyzeProject().catch(console.error);
