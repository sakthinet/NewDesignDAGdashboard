import express from 'express';
import postgres from 'postgres';
import { 
  getDatabaseConfig, 
  testDatabaseConnection, 
  getDatabaseConfigSummary,
  getPostgreSQLConfig,
  type PostgreSQLConfig 
} from '../shared/database-config.js';

const router = express.Router();

// Type definition for IA script execution data (mapped from existing dag_run_metrics table)
interface IAExecutionData {
  id: number;
  script_name: string;       // mapped from dag_id
  execution_id: string;      // mapped from run_id
  execution_date: string;
  status: 'success' | 'failed' | 'running' | 'pending';
  files_processed: number;   // mapped from records_processed
  files_failed: number;      // mapped from records_failed
  total_records: number;     // calculated from records_processed + records_failed
  execution_time_ms: number; // will be 0 for now, can be added later
  error_message?: string;    // can be null for now
}

// PostgreSQL connection instance
let sql: any = null;

// Initialize PostgreSQL connection
async function initializeIADatabase() {
  if (!sql) {
    try {
      const config = getPostgreSQLConfig();
      console.log('🔌 Initializing IA PostgreSQL connection...');
      
      sql = postgres({
        host: config.host,
        port: config.port,
        database: config.database,
        username: config.user,
        password: config.password,
        ssl: config.ssl ? { rejectUnauthorized: false } : false,
        max: 10, // Maximum connections in pool
        idle_timeout: 20,
        connect_timeout: 10
      });
      
      // Test the connection
      await sql`SELECT 1 as test`;
      console.log('✅ IA PostgreSQL connection initialized successfully');
    } catch (error) {
      console.error('❌ Failed to initialize IA PostgreSQL connection:', error);
      throw error;
    }
  }
  return sql;
}

// Execute database query for IA metrics
async function executeIAQuery(query: string): Promise<IAExecutionData[]> {
  try {
    console.log('📊 Executing IA PostgreSQL query:', query);
    
    const db = await initializeIADatabase();
    
    // Execute the actual query
    const result = await db.unsafe(query);
    
    console.log(`✅ IA Query executed successfully, returned ${result.length} rows`);
    return result as IAExecutionData[];
  } catch (error) {
    console.error('❌ IA PostgreSQL query execution failed:', error);
    throw error;
  }
}

// GET /api/ia-metrics/test-connection - Test database connectivity
router.get('/test-connection', async (req, res) => {
  try {
    const result = await testDatabaseConnection();
    res.json(result);
  } catch (error) {
    console.error('IA Database connection test error:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'IA Database connection test failed'
    });
  }
});

// GET /api/ia-metrics/executions - Get IA script execution metrics
router.get('/executions', async (req, res) => {
  try {
    console.log('🔍 Fetching IA script execution metrics from PostgreSQL...');
    
    // Test database connection first
    const connectionTest = await testDatabaseConnection();
    if (!connectionTest.success) {
      return res.status(500).json({
        success: false,
        error: 'Database connection failed',
        details: connectionTest.error
      });
    }
    
    // Query for IA script execution data using existing dag_run_metrics table
    // Map the existing columns to IA-friendly names and add calculated fields
    const query = `
      SELECT 
        id,
        dag_id as script_name,
        run_id as execution_id,
        execution_date,
        CASE 
          WHEN records_failed = 0 THEN 'success'
          WHEN records_processed = 0 AND records_failed = 0 THEN 'pending'
          ELSE 'failed'
        END as status,
        records_processed as files_processed,
        records_failed as files_failed,
        (records_processed + records_failed) as total_records,
        0 as execution_time_ms,
        CASE 
          WHEN records_failed > 0 THEN 'Some records failed during processing'
          ELSE NULL
        END as error_message
      FROM public.dag_run_metrics
      ORDER BY execution_date DESC
      LIMIT 1000
    `;
    
    const data = await executeIAQuery(query);
    
    // Calculate summary statistics
    const totalExecutions = data.length;
    const totalFilesProcessed = data.reduce((sum, row) => sum + (row.files_processed || 0), 0);
    const totalFilesFailed = data.reduce((sum, row) => sum + (row.files_failed || 0), 0);
    const successfulExecutions = data.filter(row => row.status === 'success').length;
    const successRate = totalExecutions > 0 
      ? ((successfulExecutions / totalExecutions) * 100).toFixed(2)
      : '0.00';
    
    const totalExecutionTime = data.reduce((sum, row) => sum + (row.execution_time_ms || 0), 0);
    const avgExecutionTime = totalExecutions > 0 ? Math.round(totalExecutionTime / totalExecutions) : 0;
    const avgFilesPerExecution = totalExecutions > 0 ? Math.round(totalFilesProcessed / totalExecutions) : 0;

    // Script performance by script name (dag_id)
    const scriptSummary = data.reduce((acc: any, row) => {
      const scriptName = row.script_name;
      if (!acc[scriptName]) {
        acc[scriptName] = {
          scriptName,
          totalExecutions: 0,
          totalFilesProcessed: 0,
          totalFilesFailed: 0,
          totalExecutionTime: 0,
          successfulExecutions: 0,
          lastExecution: row.execution_date
        };
      }
      
      acc[scriptName].totalExecutions++;
      acc[scriptName].totalFilesProcessed += row.files_processed || 0;
      acc[scriptName].totalFilesFailed += row.files_failed || 0;
      acc[scriptName].totalExecutionTime += row.execution_time_ms || 0;
      
      if (row.status === 'success') {
        acc[scriptName].successfulExecutions++;
      }
      
      // Update last execution if this one is more recent
      if (new Date(row.execution_date) > new Date(acc[scriptName].lastExecution)) {
        acc[scriptName].lastExecution = row.execution_date;
      }
      
      return acc;
    }, {});
    
    // Calculate averages and success rates for scripts
    Object.values(scriptSummary).forEach((script: any) => {
      script.avgExecutionTime = script.totalExecutions > 0 
        ? Math.round(script.totalExecutionTime / script.totalExecutions) 
        : 0;
      script.successRate = script.totalExecutions > 0 
        ? ((script.successfulExecutions / script.totalExecutions) * 100).toFixed(2)
        : '0.00';
      delete script.totalExecutionTime; // Clean up temp field
      delete script.successfulExecutions; // Clean up temp field
    });
    
    const response = {
      success: true,
      data: data,
      summary: {
        totalExecutions,
        totalFilesProcessed,
        totalFilesFailed,
        successRate: `${successRate}%`,
        avgExecutionTime,
        avgFilesPerExecution
      },
      scriptSummary: Object.values(scriptSummary),
      databaseConfig: {
        host: connectionTest.config?.host,
        database: connectionTest.config?.database,
        deploymentMode: getDatabaseConfigSummary().deploymentMode
      },
      timestamp: new Date().toISOString()
    };
    
    console.log(`✅ Successfully fetched ${data.length} IA execution records`);
    res.json(response);
    
  } catch (error) {
    console.error('❌ Error fetching IA execution metrics:', error);
    
    // If table doesn't exist, provide helpful error message
    if (error instanceof Error && error.message.includes('relation "public.dag_run_metrics" does not exist')) {
      return res.status(404).json({
        success: false,
        error: 'DAG run metrics table not found',
        details: 'The table "public.dag_run_metrics" does not exist. Please check your database setup.',
        timestamp: new Date().toISOString()
      });
    }
    
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch IA metrics',
      timestamp: new Date().toISOString()
    });
  }
});

// GET /api/ia-metrics/config - Get current database configuration
router.get('/config', async (req, res) => {
  try {
    const summary = getDatabaseConfigSummary();
    res.json({
      success: true,
      config: summary,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error getting IA database config:', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to get IA database config'
    });
  }
});

export default router;
