import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import {
  Database,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  MoreHorizontal,
  Search
} from 'lucide-react';

interface MetricsData {
  id: number;
  processname: string;
  instanceid: string;
  execution_date: string;
  records_processed: number;
  records_failed: number;
}

export function MetricsDashboard() {
  const [metricsData, setMetricsData] = useState<MetricsData[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Search state
  const [processNameSearch, setProcessNameSearch] = useState('');
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(15);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof MetricsData;
    direction: 'asc' | 'desc';
  } | null>({ key: 'execution_date', direction: 'desc' }); // Default sort by execution_date DESC
  
  const [connectionStatus, setConnectionStatus] = useState<{
    connected: boolean;
    testing: boolean;
    error?: string;
  }>({ connected: false, testing: false });

  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const { toast } = useToast();

  const testDatabaseConnection = async () => {
    setConnectionStatus({ connected: false, testing: true });
    
    try {
      const response = await fetch('/api/metrics/test-connection');
      const result = await response.json();
      
      if (result.success) {
        setConnectionStatus({ connected: true, testing: false });
        toast({
          title: '✅ Database Connected',
          description: `Successfully connected to PostgreSQL database`,
        });
      } else {
        setConnectionStatus({ 
          connected: false, 
          testing: false, 
          error: result.error 
        });
        toast({
          title: '❌ Database Connection Failed',
          description: result.error || 'Unable to connect to PostgreSQL',
          variant: 'destructive',
        });
      }
    } catch (error) {
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Connection test failed'
      });
      toast({
        title: '❌ Connection Error',
        description: 'Failed to test database connection',
        variant: 'destructive',
      });
    }
  };

  const fetchMetrics = async () => {
    setLoading(true);
    
    try {
      // Add cache busting parameter to ensure fresh data
      const timestamp = new Date().getTime();
      const response = await fetch(`/api/metrics/dag-runs?t=${timestamp}`);

      if (response.ok) {
        const data = await response.json();

        if (data.success) {
          setMetricsData(data.data);
          setLastRefresh(new Date());
          setConnectionStatus({ connected: true, testing: false });

          toast({
            title: '📊 Metrics Refreshed',
            description: `Successfully loaded ${data.data.length} records from PostgreSQL database`,
            duration: 3000,
          });
        } else {
          throw new Error(data.error || 'Failed to fetch metrics');
        }
      } else {
        throw new Error(`HTTP ${response.status}: Failed to fetch metrics data`);
      }
    } catch (error) {
      console.error('Error fetching metrics:', error);
      toast({
        title: '❌ Failed to Refresh Metrics',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive',
        duration: 5000,
      });
      setConnectionStatus({ 
        connected: false, 
        testing: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch metrics'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    testDatabaseConnection();
    
    // Add keyboard shortcut for refresh (Ctrl+R or Cmd+R)
    const handleKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key === 'r') {
        event.preventDefault();
        if (!loading) {
          fetchMetrics();
        }
      }
      // Add keyboard shortcut for clearing search (Ctrl+K or Cmd+K)
      if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        setProcessNameSearch('');
      }
    };
    
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (connectionStatus.connected && !loading) {
      fetchMetrics();
    }
  }, [connectionStatus.connected]);

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // Filtering and sorting logic
  const filteredAndSortedData = useMemo(() => {
    // First filter by process name search
    let filteredData = metricsData.filter(item =>
      item.processname.toLowerCase().includes(processNameSearch.toLowerCase())
    );
    
    // Then sort the filtered data
    if (sortConfig !== null) {
      filteredData.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
          if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
          if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
          return 0;
        }
        
        const aStr = String(aValue).toLowerCase();
        const bStr = String(bValue).toLowerCase();
        if (aStr < bStr) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aStr > bStr) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return filteredData;
  }, [metricsData, sortConfig, processNameSearch]);

  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedData, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredAndSortedData.length / itemsPerPage);

  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [processNameSearch]);

  const handleSort = (key: keyof MetricsData) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  };

  const getSortIcon = (columnKey: keyof MetricsData) => {
    if (!sortConfig || sortConfig.key !== columnKey) {
      return <MoreHorizontal className="w-4 h-4 opacity-0 group-hover:opacity-50" />;
    }
    return sortConfig.direction === 'asc' ? 
      <TrendingUp className="w-4 h-4" /> : 
      <TrendingDown className="w-4 h-4" />;
  };

  // Loading state
  if (loading && metricsData.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <h3 className="text-lg font-semibold mb-2">Loading Metrics</h3>
          <p className="text-muted-foreground">Connecting to PostgreSQL database...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 pr-4 lg:pr-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Metrics Dashboard</h1>
          <p className="text-muted-foreground">
            {lastRefresh && (
              <span className="ml-2 text-xs bg-green-100 text-green-700 px-2 py-1 rounded">
                Last refreshed: {lastRefresh.toLocaleTimeString()}
              </span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {loading && (
            <div className="flex items-center text-sm text-muted-foreground">
              <RefreshCw className="w-4 h-4 animate-spin mr-1" />
              Fetching latest data...
            </div>
          )}
        </div>
      </div>

      {/* Data Table */}
      {connectionStatus.connected && metricsData.length > 0 && filteredAndSortedData.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2" />
                Workspace Metrics Data
                <Badge variant="outline" className="ml-2">
                  {filteredAndSortedData.length} of {metricsData.length} records
                  {processNameSearch && ` (filtered)`}
                </Badge>
                {lastRefresh && (
                  <Badge variant="secondary" className="ml-2">
                    Updated: {lastRefresh.toLocaleString()}
                  </Badge>
                )}
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={fetchMetrics}
                disabled={loading}
                className="flex items-center gap-1"
              >
                {loading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4" />
                )}
                {loading ? 'Updating...' : 'Refresh'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Search Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="relative max-w-sm">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search by process name..."
                    value={processNameSearch}
                    onChange={(e) => setProcessNameSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">
                    Showing {Math.min((currentPage - 1) * itemsPerPage + 1, filteredAndSortedData.length)} to{' '}
                    {Math.min(currentPage * itemsPerPage, filteredAndSortedData.length)} of {filteredAndSortedData.length} entries
                    {processNameSearch && ` (filtered from ${metricsData.length})`}
                  </span>
                </div>
              </div>

              {/* Table Controls */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-2">
                  {processNameSearch && (
                    <Badge variant="secondary" className="text-xs">
                      Filter: "{processNameSearch}"
                      <button
                        onClick={() => setProcessNameSearch('')}
                        className="ml-1 hover:text-destructive"
                      >
                        ×
                      </button>
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(1)}
                    disabled={currentPage === 1}
                    className="hidden sm:flex"
                  >
                    <ChevronsLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="hidden sm:inline ml-1">Previous</span>
                  </Button>
                  <span className="px-3 py-1 text-sm border rounded">
                    {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <span className="hidden sm:inline mr-1">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(totalPages)}
                    disabled={currentPage === totalPages}
                    className="hidden sm:flex"
                  >
                    <ChevronsRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse bg-white">
                    <thead className="bg-muted/50">
                      <tr>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('processname')}
                        >
                          <div className="flex items-center gap-2">
                            Process Name
                            {getSortIcon('processname')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden md:table-cell"
                          onClick={() => handleSort('instanceid')}
                        >
                          <div className="flex items-center gap-2">
                            Instance ID
                            {getSortIcon('instanceid')}
                          </div>
                        </th>
                        <th 
                          className="text-left p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors hidden lg:table-cell"
                          onClick={() => handleSort('execution_date')}
                        >
                          <div className="flex items-center gap-2">
                            Execution Date
                            {getSortIcon('execution_date')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('records_processed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            Records Processed
                            {getSortIcon('records_processed')}
                          </div>
                        </th>
                        <th 
                          className="text-right p-3 font-medium cursor-pointer group hover:bg-muted/70 transition-colors"
                          onClick={() => handleSort('records_failed')}
                        >
                          <div className="flex items-center justify-end gap-2">
                            Records Failed
                            {getSortIcon('records_failed')}
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedData.map((row, index) => (
                        <tr 
                          key={row.id} 
                          className={`border-b hover:bg-muted/30 transition-colors ${
                            index % 2 === 0 ? 'bg-white' : 'bg-muted/10'
                          }`}
                        >
                          <td className="p-3">
                            <div className="font-medium text-sm lg:text-base">
                              {row.processname}
                            </div>
                            {/* Mobile: Show additional info */}
                            <div className="md:hidden mt-1 space-y-1">
                              <div className="text-xs text-muted-foreground">
                                ID: {row.instanceid}
                              </div>
                              <div className="text-xs text-muted-foreground lg:hidden">
                                {formatDate(row.execution_date)}
                              </div>
                            </div>
                          </td>
                          <td className="p-3 text-muted-foreground text-sm hidden md:table-cell">
                            {row.instanceid}
                          </td>
                          <td className="p-3 text-sm hidden lg:table-cell">
                            {formatDate(row.execution_date)}
                          </td>
                          <td className="p-3 text-right font-medium text-sm lg:text-base">
                            <div className="text-green-700">
                              {formatNumber(row.records_processed)}
                            </div>
                          </td>
                          <td className="p-3 text-right font-medium text-sm lg:text-base">
                            <div className="text-red-600">
                              {formatNumber(row.records_failed)}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {!loading && (!connectionStatus.connected || filteredAndSortedData.length === 0) && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Database className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">
              {!connectionStatus.connected ? 'No Database Connection' : 
               metricsData.length === 0 ? 'No Metrics Data' : 'No Matching Results'}
            </h3>
            <p className="text-muted-foreground text-center mb-4">
              {!connectionStatus.connected 
                ? 'Unable to connect to the database. Please check your connection settings.'
                : metricsData.length === 0
                ? 'No DAG run metrics found in the database'
                : `No processes match your search "${processNameSearch}"`
              }
            </p>
            <div className="flex gap-2">
              {metricsData.length > 0 && filteredAndSortedData.length === 0 ? (
                <Button onClick={() => setProcessNameSearch('')} variant="outline">
                  Clear Search Filter
                </Button>
              ) : !connectionStatus.connected ? (
                <Button onClick={fetchMetrics} variant="outline">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Retry Connection
                </Button>
              ) : null}
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              Press Ctrl+R (or Cmd+R) to refresh data • Ctrl+K (or Cmd+K) to clear search
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
