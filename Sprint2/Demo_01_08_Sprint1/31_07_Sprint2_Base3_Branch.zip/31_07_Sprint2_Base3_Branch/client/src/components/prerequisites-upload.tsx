import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { 
  CloudUpload, 
  FileText, 
  ArrowRight, 
  CheckCircle, 
  Upload, 
  AlertCircle,
  Info,
  Database,
  HardDrive,
  FileCheck,
  Download,
  Trash2
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { UploadedFile } from "@/pages/dag-generator";
import { useClientConfig } from "@/hooks/use-client-config";

interface PrerequisitesUploadProps {
  onFileUploaded: (file: UploadedFile) => void;
  onMultipleFilesUploaded?: (files: UploadedFile[]) => void;
  onNext: () => void;
  uploadedFile: UploadedFile | null;
}

interface MultipleUploadedFile {
  id: string;
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
  uploadDate: Date;
  status: 'uploading' | 'completed' | 'error';
}

export function PrerequisitesUpload({ onFileUploaded, onMultipleFilesUploaded, onNext, uploadedFile }: PrerequisitesUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState<MultipleUploadedFile[]>([]);
  const [completedUploads, setCompletedUploads] = useState(0);
  const [totalUploads, setTotalUploads] = useState(0);
  const [uploadMessage, setUploadMessage] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const { toast } = useToast();
  const clientConfig = useClientConfig();

  // Auto-close upload message after 100ms for success messages
  useEffect(() => {
    if (uploadMessage && uploadMessage.type === 'success') {
      const timer = setTimeout(() => {
        setUploadMessage(null);
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [uploadMessage]);

  // Validate individual file
  const validateFile = (file: File): string | null => {
    const isCSV = file.name.toLowerCase().endsWith('.csv') || 
                 file.type === 'text/csv' || 
                 file.type === 'application/vnd.ms-excel';
    
    const isUnder2GB = file.size <= 2 * 1024 * 1024 * 1024;
    const isValidNameLength = file.name.length <= 32;
    
    if (!isCSV) return `${file.name} is not a CSV file`;
    if (!isUnder2GB) return `${file.name} exceeds 2GB limit`;
    if (!isValidNameLength) return `${file.name} filename must be 32 characters or less (currently ${file.name.length} characters)`;
    
    return null;
  };

  const handleFileUpload = useCallback(async (files: File[]) => {
    console.log('📁 Files selected:', files.length);
    setUploadMessage(null);
    
    // Validate files and collect errors
    const validFiles: File[] = [];
    const errorMessages: string[] = [];
    
    files.forEach(file => {
      console.log(`📄 Checking file: ${file.name} (${file.name.length} chars)`);
      
      const error = validateFile(file);
      if (error) {
        errorMessages.push(error);
      } else {
        validFiles.push(file);
        console.log(`  ✅ File valid: ${file.name}`);
      }
    });

    console.log('✅ Valid files:', validFiles.length);
    
    if (errorMessages.length > 0) {
      setUploadMessage({ 
        type: 'error', 
        message: errorMessages.join('; ') 
      });
    }

    if (validFiles.length === 0) return;

    setIsUploading(true);
    setUploadProgress(0);
    setCompletedUploads(0);
    setTotalUploads(validFiles.length);

    let successCount = 0;
    let failCount = 0;
    const successfulFiles: UploadedFile[] = [];

    try {
      for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];
        const fileId = `${Date.now()}-${i}-${Math.random()}`;
        
        console.log(`📤 Uploading file ${i + 1}/${validFiles.length}: ${file.name}`);
        
        // Add file with uploading status
        setUploadedFiles(prev => [...prev, {
          id: fileId,
          fileName: file.name,
          fileSize: file.size,
          headers: [],
          previewRows: [],
          uploadDate: new Date(),
          status: 'uploading'
        }]);

        try {
          const formData = new FormData();
          formData.append('csvFile', file);

          const response = await fetch('/api/upload-csv', {
            method: 'POST',
            body: formData,
          });

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }

          const result = await response.json();

          if (result.success) {
            // Update file status to completed
            setUploadedFiles(prev => prev.map(f => 
              f.id === fileId 
                ? { ...f, headers: result.headers, previewRows: result.previewRows, status: 'completed' }
                : f
            ));

            const uploadedFile: UploadedFile = {
              fileName: result.fileName,
              fileSize: result.fileSize,
              headers: result.headers,
              previewRows: result.previewRows
            };
            
            successfulFiles.push(uploadedFile);

            // Set first file as main uploaded file
            if (i === 0) {
              onFileUploaded(uploadedFile);
            }

            successCount++;
            console.log(`✅ File uploaded successfully: ${result.fileName}`);
          } else {
            throw new Error(result.error || 'Upload failed');
          }
        } catch (error) {
          console.error(`❌ Upload failed for ${file.name}:`, error);
          
          // Update file status to error
          setUploadedFiles(prev => prev.map(f => 
            f.id === fileId ? { ...f, status: 'error' } : f
          ));
          
          failCount++;
        }

        // Update progress
        setCompletedUploads(i + 1);
        setUploadProgress(((i + 1) / validFiles.length) * 100);
      }

      // Set final message
      if (successCount > 0) {
        setUploadMessage({ 
          type: 'success', 
          message: `${successCount} file(s) uploaded successfully${failCount > 0 ? `, ${failCount} failed` : ''}` 
        });
        
        if (onMultipleFilesUploaded && successfulFiles.length > 0) {
          console.log('🔄 Calling multiple files callback with:', successfulFiles.length, 'files');
          onMultipleFilesUploaded(successfulFiles);
        }
      } else {
        setUploadMessage({ type: 'error', message: 'All uploads failed' });
      }

    } catch (error) {
      console.error('Upload error:', error);
      setUploadMessage({ type: 'error', message: 'Failed to process files' });
    } finally {
      setIsUploading(false);
      setTimeout(() => setUploadProgress(0), 2000);
    }
  }, [onFileUploaded, onMultipleFilesUploaded]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      setUploadMessage(null);
      console.log('🎯 Files dropped:', files.length);
      handleFileUpload(files);
    }
  }, [handleFileUpload]);

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setUploadMessage(null);
      console.log('🎯 File input changed:', files.length);
      handleFileUpload(Array.from(files));
      e.target.value = '';
    }
  }, [handleFileUpload]);

  const handleRemoveFile = useCallback((fileId: string) => {
    const fileToRemove = uploadedFiles.find(f => f.id === fileId);
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
    setUploadMessage(null);
    
    // If we removed the main uploaded file, set the next completed file as main
    if (fileToRemove && uploadedFile && fileToRemove.fileName === uploadedFile.fileName) {
      const remainingFiles = uploadedFiles.filter(f => f.id !== fileId && f.status === 'completed');
      if (remainingFiles.length > 0) {
        const nextFile = remainingFiles[0];
        onFileUploaded({
          fileName: nextFile.fileName,
          fileSize: nextFile.fileSize,
          headers: nextFile.headers,
          previewRows: nextFile.previewRows
        });
      }
    }
  }, [uploadedFiles, uploadedFile, onFileUploaded]);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  // Move files to Airflow directory before proceeding
const handleProceedToSchemaGeneration = async () => {
  const completedFiles = uploadedFiles.filter(f => f.status === 'completed');
  
  if (completedFiles.length === 0) {
    setUploadMessage({
      type: 'error',
      message: "No files to process. Please upload some CSV files first"
    });
    return;
  }

  console.log('🚀 Moving files to Airflow directory...');
  
  setUploadMessage({ 
    type: 'success', 
    message: `Moving ${completedFiles.length} file(s) to Airflow directory...` 
  });

  try {
    let moveSuccessCount = 0;
    let moveFailCount = 0;

    // Use the configured target path for the current deployment mode (local or network)
    // This will automatically use local Docker paths in local mode and network paths in network mode
    const targetPath = clientConfig.incomingCsvDir;
    console.log(`📂 Using target path: ${targetPath}`);

    for (const file of completedFiles) {
      try {
        console.log(`📁 Moving ${file.fileName} to Airflow directory`);

        // Explicitly specify the network path rather than relying on server environment variables
        const response = await fetch('/api/move-file-to-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            fileName: file.fileName,
            targetPath: `${targetPath}\\${file.fileName}`, // Use deployment mode-aware target path
            createDirectoryIfNotExists: true
          }),
        });

        if (response.ok) {
          const result = await response.json();
          if (result.success) {
            moveSuccessCount++;
            console.log(`✅ Moved ${file.fileName} successfully`);
            console.log(`📍 Target location: ${result.targetPath}`);
          } else {
            moveFailCount++;
            console.error(`❌ Failed to move ${file.fileName}: ${result.message}`);
          }
        } else {
          moveFailCount++;
          let errorText = '';
          try {
            const errorJson = await response.json();
            errorText = JSON.stringify(errorJson);
            console.error('Error details:', errorJson);
          } catch {
            errorText = await response.text();
          }
          console.error(`❌ Failed to move ${file.fileName}: HTTP ${response.status} - ${errorText}`);
        }
      } catch (error) {
        moveFailCount++;
        console.error(`❌ Error moving ${file.fileName}:`, error);
      }
    }

    // Update message based on results
    if (moveSuccessCount > 0) {
      setUploadMessage({ 
        type: 'success', 
        message: `${moveSuccessCount} file(s) moved to Airflow directory${moveFailCount > 0 ? `, ${moveFailCount} failed` : ''}` 
      });
      
      // Proceed to next step
      setTimeout(() => {
        onNext();
      }, 1000);
    } else {
      setUploadMessage({ 
        type: 'error', 
        message: `Failed to move files to Airflow directory. Check console for details.` 
      });
    }

  } catch (error) {
    console.error('Error during file move process:', error);
    setUploadMessage({ 
      type: 'error', 
      message: `Error moving files: ${error instanceof Error ? error.message : 'Unknown error'}` 
    });
  }
};
  return (
    <div className="space-y-6 relative pr-0 md:pr-64 lg:pr-72">
      {/* Sticky Proceed Button - Right Corner */}
      {uploadedFiles.filter(f => f.status === 'completed').length > 0 && (
        <div className="fixed top-24 right-4 lg:right-6 z-50 hidden md:block">
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-300 rounded-xl shadow-xl p-3 w-56">
            <div className="text-center mb-3">
              <div className="text-sm text-blue-800 font-semibold">
                {uploadedFiles.filter(f => f.status === 'completed').length} file(s) ready
              </div>
              <div className="text-xs text-blue-600 mt-1">
                Ready for schema generation
              </div>
            </div>
            <Button 
              onClick={handleProceedToSchemaGeneration} 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 text-xs px-2 py-3 h-auto min-h-[40px]"
              size="sm"
            >
              <div className="flex flex-col items-center justify-center gap-1">
                <ArrowRight className="w-4 h-4" />
                <span className="font-medium text-center leading-tight">
                  Proceed to Schema Generation
                </span>
              </div>
            </Button>
          </div>
        </div>
      )}

      {/* Side by Side Layout: Prerequisites and File Upload */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Prerequisites Section - Compact Design */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Info className="w-5 h-5 text-blue-600" />
              Prerequisites and Source Data Upload
            </CardTitle>
          </CardHeader>
          <CardContent>
                   
            {/* Compact Prerequisites List */}
            <div className="bg-gradient-to-r from-blue-50 to-blue-25 rounded-lg p-4 border border-blue-200">
              <div className="grid grid-cols-1 gap-2 text-sm">
                <div className="flex items-center gap-2 py-1">
                  <div className="flex-shrink-0 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-medium">1</div>
                  <span className="text-gray-700">Creation of Archival Application in InfoArchive</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <div className="flex-shrink-0 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-medium">2</div>
                  <span className="text-gray-700">Creation of Database for Archival Application</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <div className="flex-shrink-0 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-medium">3</div>
                  <span className="text-gray-700">Creation of Space for Archival Application and Database</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <div className="flex-shrink-0 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-medium">4</div>
                  <span className="text-gray-700">Creation of Store for storing the content files</span>
                </div>
                <div className="flex items-center gap-2 py-1">
                  <div className="flex-shrink-0 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-medium">5</div>
                  <span className="text-gray-700">Extraction of Source table data in CSV format for the Archival Application</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* File Upload Section */}
        <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            Source Data Upload
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Upload Requirements */}
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Upload Requirements:</strong> Only CSV files are accepted. Multiple files can be uploaded simultaneously.
              </AlertDescription>
            </Alert>

            {/* Drag and Drop Area */}
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragging 
                  ? 'border-blue-400 bg-blue-50' 
                  : 'border-gray-300 hover:border-gray-400'
              }`}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setIsDragging(false);
              }}
              onDrop={handleDrop}
            >
              <input
                type="file"
                multiple
                accept=".csv,text/csv,application/vnd.ms-excel"
                onChange={handleFileInputChange}
                className="hidden"
                id="csv-upload"
                disabled={isUploading}
                aria-label="Upload CSV files"
              />
              
              <CloudUpload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              
              <div className="space-y-2">
                <h3 className="text-lg font-semibold">
                  {isDragging ? 'Drop CSV files here' : 'Upload CSV Files'}
                </h3>
                <p className="text-gray-600">
                  Drag and drop your CSV files here, or click to browse
                </p>
              </div>
              
              <Button 
                className="mt-4" 
                onClick={() => document.getElementById('csv-upload')?.click()}
                disabled={isUploading}
              >
                {isUploading ? 'Uploading...' : 'Select Files'}
              </Button>
            </div>

            {/* Upload Message */}
            {uploadMessage && (
              <div className={`p-3 rounded-lg border ${
                uploadMessage.type === 'success' 
                  ? 'bg-blue-50 border-blue-200 text-blue-800' 
                  : 'bg-red-50 border-red-200 text-red-800'
              }`}>
                <div className="flex items-center gap-2">
                  {uploadMessage.type === 'success' ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : (
                    <AlertCircle className="w-4 h-4" />
                  )}
                  <span className="font-medium">{uploadMessage.message}</span>
                </div>
              </div>
            )}

            {/* Upload Progress */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Uploading {totalUploads} file(s)...</span>
                  <span>{completedUploads} of {totalUploads} completed ({Math.round(uploadProgress)}%)</span>
                </div>
                <Progress value={uploadProgress} className="w-full" />
              </div>
            )}

            {/* Uploaded Files List */}
            {uploadedFiles.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Uploaded Files</h3>
                <div className="space-y-2">
                  {uploadedFiles.map((file) => (
                    <div key={file.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-blue-600" />
                        <div>
                          <p className="font-medium">{file.fileName}</p>
                          <p className="text-sm text-gray-500">
                            {formatFileSize(file.fileSize)} • {file.uploadDate.toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {file.status === 'uploading' && (
                          <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                        )}
                        {file.status === 'completed' && (
                          <CheckCircle className="w-5 h-5 text-blue-600" />
                        )}
                        {file.status === 'error' && (
                          <AlertCircle className="w-5 h-5 text-red-600" />
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveFile(file.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Next Step Button */}
            {uploadedFiles.filter(f => f.status === 'completed').length > 0 && (
              <div className="space-y-3">
                {/* Success indicator */}
                <div className="p-3 rounded-lg border bg-green-50 border-green-200">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <div>
                      <span className="font-medium text-green-800">
                        {uploadedFiles.filter(f => f.status === 'completed').length === 1 
                          ? "✅ File uploaded successfully" 
                          : `✅ ${uploadedFiles.filter(f => f.status === 'completed').length} files uploaded successfully`}
                      </span>
                      <p className="text-sm text-green-600 mt-1">
                        {uploadedFiles.filter(f => f.status === 'completed').length === 1
                          ? "1 file is ready for schema generation"
                          : `${uploadedFiles.filter(f => f.status === 'completed').length} files are ready for schema generation`}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button onClick={handleProceedToSchemaGeneration} className="flex items-center gap-2">
                    Proceed to Schema Generation
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      </div>
    </div>
  );
}