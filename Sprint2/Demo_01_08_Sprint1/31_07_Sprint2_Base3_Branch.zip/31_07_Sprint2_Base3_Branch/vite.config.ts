import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";

// Load environment variables and set up unified configuration
export default defineConfig(async ({ command, mode }) => {
  // Load env files
  const env = loadEnv(mode, process.cwd(), '');
  
  // Load and configure unified environment variables
  try {
    // Import dotenv to load .env file
    require('dotenv').config();
    
    // Import unified configuration to set VITE variables
    const { setViteEnvironmentVariables } = require('./shared/config-unified');
    setViteEnvironmentVariables();
  } catch (error: any) {
    console.warn('Warning: Could not load unified configuration:', error?.message || String(error));
  }

  return {
    plugins: [
      react(),
      runtimeErrorOverlay(),
      ...(process.env.NODE_ENV !== "production" &&
      process.env.REPL_ID !== undefined
        ? [
            await import("@replit/vite-plugin-cartographer").then((m) =>
              m.cartographer(),
            ),
          ]
        : []),
    ],
    resolve: {
      alias: {
        "@": path.resolve(import.meta.dirname, "client", "src"),
        "@shared": path.resolve(import.meta.dirname, "shared"),
        "@assets": path.resolve(import.meta.dirname, "attached_assets"),
      },
    },
    root: path.resolve(import.meta.dirname, "client"),
    build: {
      outDir: path.resolve(import.meta.dirname, "dist/public"),
      emptyOutDir: true,
    },
    server: {
      fs: {
        strict: true,
        deny: ["**/.*"],
      },
      host: "0.0.0.0", // Allow external connections
      port: parseInt(process.env.VITE_PORT || "5173"),
    },
    // Define additional environment variables that should be exposed to client
    define: {
      // Expose deployment mode to client at build time
      __DEPLOYMENT_MODE__: JSON.stringify(process.env.DEPLOYMENT_MODE || 'local'),
      __NETWORK_AVAILABLE__: JSON.stringify(process.env.DEPLOYMENT_MODE === 'network'),
      __BUILD_TIME__: JSON.stringify(new Date().toISOString()),
    },
    // Ensure all VITE_ environment variables are available
    envPrefix: ['VITE_', 'DEPLOYMENT_MODE'],
  };
});
