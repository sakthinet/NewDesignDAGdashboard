# 🌐 Network Deployment Guide - Static File Serving

## ✅ **SOLUTION: Your application is now accessible on the network!**

### 🎯 **Network URL (Ready to Share)**
```
http://10.73.90.19:3001
```

**Share this URL with anyone on your network to access the application.**

---

## 🚀 **Quick Deployment Options**

### Option 1: Full Build & Deploy (Recommended)
```bash
# Double-click this file or run from command prompt
deploy-network.bat
```

### Option 2: Just Serve (if already built)
```bash
# If you've already built, just serve the files
serve-network.bat
```

### Option 3: NPM Commands
```bash
# Build with network config and serve
npm run serve:network

# Or just serve existing build
npm run serve
```

---

## 🔧 **What These Commands Do**

### Full Deployment Process:
1. **Switch to Network Mode**: Sets paths to `\\10.73.88.101\data\*`
2. **Build Application**: Creates production files in `dist/public/`
3. **Serve Static Files**: Uses `npx serve` to make files accessible on network

### Network Serving:
- ✅ **Local Access**: `http://localhost:3001`
- ✅ **Network Access**: `http://10.73.90.19:3001`
- ✅ **External Access**: Anyone on your network can access this URL

---

## 📱 **Testing Network Access**

### From Another Computer/Device:
1. Connect to the same network
2. Open browser
3. Navigate to: `http://10.73.90.19:3001`
4. The application should load immediately

### Troubleshooting:
- **URL not loading**: Check Windows Firewall settings
- **Different IP**: The script will show the correct network IP
- **Port busy**: The script will find an available port

---

## 🔄 **Development vs Network Modes**

### For Development (Local):
```bash
node config-switcher.cjs local
npm run dev
# Access: http://localhost:3001 (local only)
```

### For Network Sharing:
```bash
deploy-network.bat
# Access: http://10.73.90.19:3001 (network accessible)
```

---

## 📊 **File Structure After Build**

```
dist/
├── public/          # ← Static files served by npx serve
│   ├── index.html   # Main application
│   └── assets/      # CSS, JS, and other assets
└── index.js         # Server file (not used for static serving)
```

---

## 🎯 **Benefits of This Approach**

1. **Simple Serving**: Uses `npx serve` - no complex server setup
2. **Network Accessible**: Automatically detects and shows network IP
3. **Fast Loading**: Serves optimized static files
4. **Easy Sharing**: One URL works for everyone on the network
5. **No Backend Needed**: Pure frontend deployment

---

## 🔐 **Network Configuration**

The application is configured to use:
- **Airflow**: `http://10.73.88.101:8080`
- **Data Paths**: `\\10.73.88.101\data\*`
- **Network Serving**: `http://10.73.90.19:3001`

---

## 🚨 **Important Notes**

1. **API Limitations**: This serves only the frontend. If your app needs backend APIs, you'll need to run the full server instead.

2. **Configuration**: The network paths are embedded during build time, so the application will correctly use network resources.

3. **Firewall**: Ensure Windows Firewall allows Node.js/npx through for network access.

---

## ⚡ **Quick Start Summary**

**To deploy for network access right now:**

1. Double-click: `deploy-network.bat`
2. Wait for build to complete
3. Share the URL shown: `http://10.73.90.19:3001`
4. Done! ✅

**The application is now accessible from any device on your network!**
