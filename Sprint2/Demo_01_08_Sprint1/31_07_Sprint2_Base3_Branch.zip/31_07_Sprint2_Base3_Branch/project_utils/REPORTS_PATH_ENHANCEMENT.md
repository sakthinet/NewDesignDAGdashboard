# Enhanced Reports Path Resolution - Reports Fix

## Overview

The Reports page has been enhanced to properly handle reports folder path resolution with robust fallback mechanisms. It now supports:

1. **Network paths** (UNC format: `\\server\share\reports`)
2. **Local paths** (Windows format: `C:\Docker\airflow3x2\reports`)  
3. **Project relative paths** (`./reports`)
4. **Intelligent fallback chain** when primary paths are not accessible

## Configuration

### Environment Variables

The reports path is configured through the unified configuration system using these environment variables:

```bash
# Network deployment
NETWORK_AIRFLOW_REPORTS_DIR=\\\\10.73.88.101\\reports

# Local deployment  
LOCAL_AIRFLOW_REPORTS_DIR=C:\\Docker\\airflow3x2\\reports

# Development fallback
FALLBACK_AIRFLOW_REPORTS_DIR=./reports
```

### Deployment Mode

The active reports path is determined by the `DEPLOYMENT_MODE` setting:

- `DEPLOYMENT_MODE=network` → Uses `NETWORK_AIRFLOW_REPORTS_DIR`
- `DEPLOYMENT_MODE=local` → Uses `LOCAL_AIRFLOW_REPORTS_DIR`

## Enhanced Path Resolution Logic

### 1. Primary Path Resolution

The system first attempts to use the configured reports directory based on the deployment mode:

```typescript
const rawReportsDirectory = config.paths.reportsDir;
const pathResolution = await pathManager.resolvePath(rawReportsDirectory, 'reports');
```

### 2. Fallback Chain

If the primary path fails, the system tries these fallback paths in order:

1. **Network fallback**: `config.networkPaths?.reportsDir`
2. **Local fallback**: `config.localPaths?.reportsDir`  
3. **Development fallback**: `config.fallbackPaths?.reportsDir`
4. **Project relative paths**: `./reports`, `./data`, `./input-files`, `./uploads`

### 3. Additional Fallback Search

If no JSON files are found in the resolved path, the system searches additional locations:

- `./data`
- `./input-files` 
- `./uploads`
- `./temp`

## Path Types Supported

### Network Paths (UNC)
```
\\\\10.73.88.101\\reports
\\\\server-name\\shared-folder\\reports
```

### Local Paths (Windows)
```
C:\\Docker\\airflow3x2\\reports
D:\\airflow\\reports
```

### Relative Paths
```
./reports
./data
../shared/reports
```

## API Response

The `/api/reports` endpoint now returns enhanced path information:

```json
{
  "success": true,
  "reports": [...],
  "message": "Found X report(s)",
  "dataPath": "C:\\Docker\\airflow3x2\\reports",
  "isLocal": true
}
```

## Error Handling

The enhanced system gracefully handles various failure scenarios:

1. **Network unavailable**: Falls back to local paths
2. **Permissions denied**: Tries alternative locations
3. **Path not found**: Creates directory if possible or uses fallback
4. **No JSON files**: Searches additional locations

## Testing

Run the test script to validate path resolution:

```bash
node test-reports-path.js
```

This will test:
- Current configuration
- Path resolution logic
- Fallback mechanisms
- Accessibility checks

## Migration Notes

### From Previous Implementation

The old implementation:
- Used hardcoded fallback logic in `/api/reports`
- Only supported basic network/local switching
- Limited error handling

The new implementation:
- Uses the enhanced `pathManager` for robust path resolution
- Supports complex fallback chains
- Better error handling and logging
- Maintains backward compatibility

### No Breaking Changes

The API response format remains the same, ensuring compatibility with the existing `ReportsViewer` component.

## Configuration Examples

### Production (Network Deployment)
```bash
DEPLOYMENT_MODE=network
NETWORK_AIRFLOW_REPORTS_DIR=\\\\production-server\\reports
LOCAL_AIRFLOW_REPORTS_DIR=C:\\Docker\\airflow3x2\\reports
FALLBACK_AIRFLOW_REPORTS_DIR=./reports
```

### Development (Local Deployment)
```bash
DEPLOYMENT_MODE=local
LOCAL_AIRFLOW_REPORTS_DIR=C:\\Docker\\airflow3x2\\reports
FALLBACK_AIRFLOW_REPORTS_DIR=./reports
```

### Standalone Development
```bash
DEPLOYMENT_MODE=local
LOCAL_AIRFLOW_REPORTS_DIR=./reports
FALLBACK_AIRFLOW_REPORTS_DIR=./data
```

## Troubleshooting

### Enable Debug Logging

Add to `.env`:
```bash
ENABLE_PATH_LOGGING=true
DEBUG_CONFIG_RESOLUTION=true
```

### Common Issues

1. **Network path not accessible**
   - Check network connectivity
   - Verify UNC path format
   - Ensure proper permissions
   - System falls back to local paths automatically

2. **No reports found**
   - Check if JSON files exist in the reports directory
   - Verify file permissions
   - System will search fallback locations automatically

3. **Permission denied**
   - Check write permissions for directory creation
   - Ensure user has access to the configured paths
   - System will try alternative locations

### Log Messages

Look for these log messages to understand path resolution:

- `📂 Primary path resolution: ...` - Shows the primary path being used
- `✅ Using fallback path: ...` - Indicates fallback path is being used
- `⚠️ No accessible reports directory found` - All paths failed, using default

## Future Enhancements

- Support for S3/cloud storage paths
- Configurable search patterns beyond `*.json`
- Advanced caching for network path accessibility
- Real-time path monitoring and automatic failover
