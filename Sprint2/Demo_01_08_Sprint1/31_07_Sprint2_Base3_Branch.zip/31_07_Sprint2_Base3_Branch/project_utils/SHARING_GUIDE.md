# 🚀 Application Sharing Guide

## Quick Setup for New Users

### Prerequisites
- **Node.js**: Version 18.0.0 or higher
- **Git**: For cloning the repository
- **Network Access**: To the shared Airflow server (10.73.88.101:8080)

### 1. Clone & Install
```powershell
# Clone the repository
git clone <your-repository-url>
cd <project-folder>

# Install dependencies
npm install
```

### 2. Configure Environment
```powershell
# The application comes with a unified configuration system
# Simply choose your deployment mode:

# For shared/production use (recommended):
node config-switcher.cjs network --verbose

# For local development:
node config-switcher.cjs local --verbose
```

### 3. Start Application
```powershell
# Development mode
npm run dev

# Production mode
npm run build
npm start
```

### 4. Access Application
- **Frontend**: http://localhost:3001
- **API**: http://localhost:3001/api

## 🔧 Configuration Modes

### Network Mode (Production/Shared)
```bash
DEPLOYMENT_MODE=network
```
**Uses:**
- Airflow URL: http://10.73.88.101:8080
- Shared network paths: \\\\10.73.88.101\\data\\*
- Username: airflow / Password: airflow

### Local Mode (Development)
```bash
DEPLOYMENT_MODE=local
```
**Uses:**
- Airflow URL: http://localhost:8083
- Local Docker paths: C:\\Docker\\airflow3x2\\data\\*
- Username: admin / Password: admin123

## 🎯 Switching Between Modes

```powershell
# Switch to network (shared) mode
node config-switcher.cjs network --verbose

# Switch to local (development) mode  
node config-switcher.cjs local --verbose

# Restart application after switching
```

## 📋 Team Distribution Checklist

### For New Team Members:
- [ ] Provide repository access
- [ ] Ensure network access to 10.73.88.101:8080
- [ ] Share this setup guide
- [ ] Verify Node.js version (18.0.0+)

### For Different Environments:
- [ ] **Development**: Use `local` mode with Docker Airflow
- [ ] **Testing/Staging**: Use `network` mode with shared Airflow
- [ ] **Production**: Use `network` mode with production Airflow

## 🔍 Troubleshooting

### Common Issues:

**Issue**: Application shows local paths instead of network paths
**Solution**: 
```powershell
node config-switcher.cjs network --verbose
# Restart the application
```

**Issue**: Cannot connect to Airflow
**Solution**: 
- Verify network access to 10.73.88.101:8080
- Check VPN connection if required
- Try switching to local mode for development

**Issue**: File operations fail
**Solution**:
- Verify network share access (\\\\10.73.88.101\\data)
- Check file permissions
- Ensure proper authentication

## 🌐 Network Requirements

### Firewall/Network Access:
- **Airflow Web UI**: Port 8080 (10.73.88.101:8080)
- **Network Shares**: SMB/CIFS access to \\\\10.73.88.101\\data
- **InfoArchive API**: Port 8765 (10.73.91.23:8765)

### VPN Requirements:
If users are accessing from outside the corporate network, ensure VPN access to:
- 10.73.88.101 (Airflow server)
- 10.73.91.23 (InfoArchive API server)

## 📚 Additional Resources

- **Configuration Files**: `.env.unified` contains all settings
- **Documentation**: Check the `/docs` folder for detailed guides
- **Support**: Contact system administrator for network access issues

---

**Last Updated**: January 2025  
**Version**: 1.0  
**Deployment Mode**: Network-ready
