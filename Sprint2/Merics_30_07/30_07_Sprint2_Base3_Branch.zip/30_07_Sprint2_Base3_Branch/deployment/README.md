# 🚀 Deployment Tools & Documentation

This folder contains all network deployment related files and documentation.

## 📁 Folder Structure

```
deployment/
├── scripts/           # Deployment automation scripts
│   ├── deploy-network.bat        # Main deployment script (RECOMMENDED)
│   ├── serve-network.bat         # Static file serving (frontend only)
│   ├── test-network.bat          # Network configuration testing
│   └── map-network-drive.bat     # Network drive mapping utility
├── docs/             # Deployment documentation
│   ├── NETWORK_DEPLOYMENT_FIX.md # Complete deployment guide
│   └── NETWORK_SERVE_GUIDE.md    # Static serving guide
└── README.md         # This file
```

## 🎯 Quick Start

### ✅ **For Production Network Deployment (RECOMMENDED)**
```bash
# Double-click or run from command prompt
deployment\scripts\deploy-network.bat
```

This will:
1. Switch to network mode configuration
2. Build the application with network paths
3. Start the full server with backend APIs
4. Make application accessible at: `http://10.73.90.19:3001`

### 🔧 **For Development/Testing**
```bash
# Test network configuration without full build
deployment\scripts\test-network.bat
```

### 📊 **Network Drive Access (Optional)**
```bash
# Map network drives for direct file system access
deployment\scripts\map-network-drive.bat
```

## 📖 Documentation

- **[NETWORK_DEPLOYMENT_FIX.md](docs/NETWORK_DEPLOYMENT_FIX.md)** - Complete technical guide
- **[NETWORK_SERVE_GUIDE.md](docs/NETWORK_SERVE_GUIDE.md)** - Static file serving guide

## 🌐 Network Access Information

**Application URL**: `http://10.73.90.19:3001`
**Airflow URL**: `http://10.73.88.101:8080`

## ⚙️ Configuration

The deployment scripts automatically handle:
- ✅ Network mode configuration switching
- ✅ Environment variable setup
- ✅ Build process with network paths
- ✅ Server startup with network access
- ✅ CORS configuration for external access

## 🛠️ Troubleshooting

If you encounter issues:
1. Check the detailed documentation in `docs/NETWORK_DEPLOYMENT_FIX.md`
2. Ensure both machines are on the same network
3. Verify Windows Firewall settings
4. Check that ports 3001 and 8080 are not blocked

---

*All deployment tools are now organized in this folder for easy access and maintenance.*
