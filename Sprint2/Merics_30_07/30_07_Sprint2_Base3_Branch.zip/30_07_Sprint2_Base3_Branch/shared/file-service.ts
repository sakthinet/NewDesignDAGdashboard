/**
 * Enhanced File Service
 * Centralized file operations with robust error handling and path management
 */

import { pathManager, PathOperationResult } from './path-manager';
import { getServerConfig } from './config-enhanced';
import { promises as fs } from 'fs';
import path from 'path';
import multer from 'multer';

export interface FileOperationResult {
  success: boolean;
  filePath?: string;
  fileName?: string;
  fileSize?: number;
  message?: string;
  error?: string;
  warnings?: string[];
  isLocalFallback?: boolean;
}

export interface FileUploadResult extends FileOperationResult {
  headers?: string[];
  previewRows?: string[][];
  metadata?: {
    recordCount?: number;
    encoding?: string;
    delimiter?: string;
  };
}

class FileService {
  private static instance: FileService;
  private config = getServerConfig();

  private constructor() {}

  static getInstance(): FileService {
    if (!FileService.instance) {
      FileService.instance = new FileService();
    }
    return FileService.instance;
  }

  /**
   * Configure multer with enhanced settings
   */
  getMulterConfig(): multer.Multer {
    return multer({
      dest: 'uploads/',
      limits: { 
        fileSize: this.config.application.maxFileSize,
        files: 10 // Allow up to 10 files
      },
      fileFilter: (req, file, cb) => {
        const allowedTypes = this.config.application.allowedFileTypes;
        const fileExtension = path.extname(file.originalname).toLowerCase();
        
        if (allowedTypes.includes(fileExtension) || 
            file.mimetype === 'text/csv' || 
            file.mimetype === 'application/vnd.ms-excel') {
          cb(null, true);
        } else {
          cb(new Error(`Only files with extensions ${allowedTypes.join(', ')} are allowed`));
        }
      }
    });
  }

  /**
   * Process uploaded CSV file with enhanced validation
   */
  async processUploadedFile(file: Express.Multer.File): Promise<FileUploadResult> {
    try {
      if (!file) {
        return {
          success: false,
          error: 'No file provided'
        };
      }

      // Validate file
      const validation = await this.validateCsvFile(file.path);
      if (!validation.success) {
        // Clean up uploaded file
        await this.safeDeleteFile(file.path);
        return validation;
      }

      // Read and parse CSV
      const content = await fs.readFile(file.path, 'utf-8');
      const parseResult = this.parseCSVContent(content);

      if (!parseResult.success) {
        await this.safeDeleteFile(file.path);
        return parseResult;
      }

      // Save to input-files directory
      const saveResult = await this.saveToInputFiles(file, content);
      if (!saveResult.success) {
        await this.safeDeleteFile(file.path);
        return saveResult;
      }

      // Clean up temporary file
      await this.safeDeleteFile(file.path);

      return {
        success: true,
        fileName: file.originalname,
        fileSize: file.size,
        filePath: saveResult.filePath,
        headers: parseResult.headers,
        previewRows: parseResult.previewRows,
        metadata: parseResult.metadata,
        message: `CSV file processed successfully: ${file.originalname}`
      };

    } catch (error) {
      // Clean up on error
      if (file?.path) {
        await this.safeDeleteFile(file.path);
      }
      
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error during file processing'
      };
    }
  }

  /**
   * Validate CSV file structure and content
   */
  private async validateCsvFile(filePath: string): Promise<FileOperationResult> {
    try {
      const stats = await fs.stat(filePath);
      
      // Check file size
      if (stats.size === 0) {
        return {
          success: false,
          error: 'CSV file is empty'
        };
      }

      if (stats.size > this.config.application.maxFileSize) {
        return {
          success: false,
          error: `File size (${this.formatFileSize(stats.size)}) exceeds maximum allowed size (${this.formatFileSize(this.config.application.maxFileSize)})`
        };
      }

      // Basic content validation
      const content = await fs.readFile(filePath, 'utf-8');
      const lines = content.trim().split('\n');
      
      if (lines.length < 2) {
        return {
          success: false,
          error: 'CSV file must contain at least a header row and one data row'
        };
      }

      return {
        success: true,
        message: 'File validation passed'
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'File validation failed'
      };
    }
  }

  /**
   * Parse CSV content with enhanced error handling
   */
  private parseCSVContent(content: string): FileUploadResult {
    try {
      const lines = content.trim().split('\n');
      
      if (lines.length === 0) {
        return {
          success: false,
          error: 'CSV file is empty'
        };
      }

      // Parse CSV line with proper quote handling
      const parseCSVLine = (line: string): string[] => {
        const result: string[] = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      };

      const headers = parseCSVLine(lines[0]);
      
      // Validate headers
      if (headers.length === 0 || headers.every(h => !h.trim())) {
        return {
          success: false,
          error: 'CSV file must have valid column headers'
        };
      }

      // Parse preview rows (up to 5)
      const maxPreviewRows = Math.min(5, lines.length - 1);
      const previewRows: string[][] = [];
      
      for (let i = 1; i <= maxPreviewRows; i++) {
        if (lines[i] && lines[i].trim()) {
          const row = parseCSVLine(lines[i]);
          previewRows.push(row);
        }
      }

      // Calculate metadata
      const totalRows = lines.length - 1; // Exclude header
      const nonEmptyRows = lines.slice(1).filter(line => line.trim()).length;
      
      return {
        success: true,
        headers,
        previewRows,
        metadata: {
          recordCount: nonEmptyRows,
          encoding: 'UTF-8',
          delimiter: ','
        }
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to parse CSV content'
      };
    }
  }

  /**
   * Save file to input-files directory
   */
  private async saveToInputFiles(file: Express.Multer.File, content: string): Promise<FileOperationResult> {
    try {
      const inputDir = path.join(process.cwd(), 'input-files');
      
      // Ensure directory exists
      const dirResult = await pathManager.ensureDirectory(inputDir);
      if (!dirResult.success) {
        return dirResult;
      }

      const filePath = path.join(inputDir, file.originalname);
      await fs.writeFile(filePath, content, 'utf-8');

      return {
        success: true,
        filePath,
        message: `File saved to input-files directory: ${file.originalname}`
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to save file to input-files directory'
      };
    }
  }

  /**
   * Move file to Airflow directory with enhanced path resolution
   */
  async moveFileToAirflow(fileName: string, targetPath?: string): Promise<FileOperationResult> {
    try {
      // Find source file
      const sourcePath = await pathManager.findFile(fileName);
      if (!sourcePath) {
        return {
          success: false,
          error: `Source file not found: ${fileName}. Checked: uploads/, input-files/, temp/, data/incomingcsv/`
        };
      }

      // Determine target path
      const finalTargetPath = targetPath || this.config.paths.incomingCsvDir;
      
      // Use path manager for robust copying
      const copyResult = await pathManager.copyFile(sourcePath, finalTargetPath, 'data');
      
      if (copyResult.success) {
        return {
          success: true,
          filePath: copyResult.path,
          fileName,
          message: copyResult.warnings?.length ? 
            `File moved to local fallback location due to network path issues` : 
            `File successfully moved to Airflow directory`,
          warnings: copyResult.warnings,
          isLocalFallback: copyResult.fallbackPath !== undefined
        };
      } else {
        return {
          success: false,
          error: copyResult.error || 'Failed to move file to Airflow directory'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred while moving file'
      };
    }
  }

  /**
   * Get file record count for large files
   */
  async getFileRecordCount(fileName: string): Promise<{ count: number; error?: string }> {
    try {
      const filePath = await pathManager.findFile(fileName);
      if (!filePath) {
        return { count: 0, error: `File not found: ${fileName}` };
      }

      const content = await fs.readFile(filePath, 'utf-8');
      const lines = content.trim().split('\n');
      
      // Subtract 1 for header row
      const recordCount = Math.max(0, lines.length - 1);
      
      return { count: recordCount };
    } catch (error) {
      return { 
        count: 0, 
        error: error instanceof Error ? error.message : 'Failed to count records' 
      };
    }
  }

  /**
   * Safely delete file without throwing errors
   */
  private async safeDeleteFile(filePath: string): Promise<void> {
    try {
      await fs.unlink(filePath);
    } catch (error) {
      // Log but don't throw - cleanup should not break the main flow
      console.warn(`Failed to delete temporary file: ${filePath}`, error);
    }
  }

  /**
   * Format file size for display
   */
  private formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * List files in directory with metadata
   */
  async listFiles(directoryPath: string): Promise<{
    files: Array<{
      name: string;
      size: number;
      modified: Date;
      isFile: boolean;
    }>;
    error?: string;
  }> {
    try {
      const resolution = await pathManager.resolvePath(directoryPath);
      const files = await fs.readdir(resolution.path);
      
      const fileStats = await Promise.all(
        files.map(async (name) => {
          try {
            const filePath = path.join(resolution.path, name);
            const stats = await fs.stat(filePath);
            return {
              name,
              size: stats.size,
              modified: stats.mtime,
              isFile: stats.isFile()
            };
          } catch (error) {
            return {
              name,
              size: 0,
              modified: new Date(),
              isFile: false
            };
          }
        })
      );

      return { files: fileStats };
    } catch (error) {
      return {
        files: [],
        error: error instanceof Error ? error.message : 'Failed to list files'
      };
    }
  }

  /**
   * Verify file exists at path
   */
  async verifyFile(fileName: string, directoryPath?: string): Promise<{
    exists: boolean;
    path?: string;
    size?: number;
    error?: string;
  }> {
    try {
      let filePath: string;
      
      if (directoryPath) {
        const resolution = await pathManager.resolvePath(directoryPath);
        filePath = path.join(resolution.path, fileName);
      } else {
        const foundPath = await pathManager.findFile(fileName);
        if (!foundPath) {
          return { exists: false };
        }
        filePath = foundPath;
      }

      const exists = await pathManager.fileExists(filePath);
      if (!exists) {
        return { exists: false };
      }

      const stats = await fs.stat(filePath);
      return {
        exists: true,
        path: filePath,
        size: stats.size
      };
    } catch (error) {
      return {
        exists: false,
        error: error instanceof Error ? error.message : 'Error verifying file'
      };
    }
  }
}

export const fileService = FileService.getInstance();
