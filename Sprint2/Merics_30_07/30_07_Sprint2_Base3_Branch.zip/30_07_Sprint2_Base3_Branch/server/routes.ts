// routes.ts - Optimized version with caching and batch operations

import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { dagConfigurationSchema, type DagConfigurationInput } from "@shared/schema";
import { getUnifiedServerConfig } from "@shared/config-unified";
import { pathManager } from "@shared/path-manager";
import { z } from "zod";
import fs from "fs/promises";
import path from "path";
import multer from "multer";
import { execSync } from "child_process";
import { registerChatbotRoutes } from "./chatbot-routes";
import { registerIncomingJsonRoutes } from "./incoming-json-routes-fixed";
import { metricsRoutes } from "./metrics-routes";
import iaMetricsRoutes from "./ia-metrics-routes";

// Get unified configuration
const config = getUnifiedServerConfig();

// Configure multer for file uploads
const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv') || file.mimetype === 'application/vnd.ms-excel') {
      cb(null, true);
    } else {
      cb(new Error('Only CSV files are allowed'));
    }
  }
});

// Cache configuration
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  expiry: number;
}

class SimpleCache {
  private cache = new Map<string, CacheEntry<any>>();
  
  set<T>(key: string, data: T, ttlSeconds = 30): void {
    const now = Date.now();
    this.cache.set(key, {
      data,
      timestamp: now,
      expiry: now + (ttlSeconds * 1000)
    });
  }
  
  get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;
    
    if (Date.now() > entry.expiry) {
      this.cache.delete(key);
      return null;
    }
    
    return entry.data;
  }
  
  clear(): void {
    this.cache.clear();
  }
  
  invalidatePattern(pattern: string): void {
    const keys = Array.from(this.cache.keys());
    for (const key of keys) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }
}

const cache = new SimpleCache();

// Function to get current Airflow configuration
const getAirflowConfig = () => {
  const currentConfig = getUnifiedServerConfig();
  return {
    baseUrl: currentConfig.connection.url,
    apiVersion: '/api/v2',
    authEndpoint: '/auth/token',
    defaultCredentials: {
      username: currentConfig.connection.username,
      password: currentConfig.connection.password
    }
  };
};

// Get initial configuration (will be reloaded when needed)
let AIRFLOW_CONFIG = getAirflowConfig();

// Global JWT token management
let currentJwtToken: string | null = null;
let tokenExpiry: number | null = null;
let isAuthenticating = false;

// Helper function to check if token is expired
const isTokenExpired = (): boolean => {
  if (!currentJwtToken || !tokenExpiry) return true;
  const fiveMinutesFromNow = Date.now() + (5 * 60 * 1000);
  return tokenExpiry <= fiveMinutesFromNow;
};

// Function to authenticate and get JWT token
const authenticateAndGetToken = async (): Promise<string | null> => {
  if (isAuthenticating) {
    while (isAuthenticating) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return currentJwtToken;
  }

  isAuthenticating = true;
  
  try {
    // console.log('🔐 Authenticating with Airflow 3.x API...');
    
    const response = await fetch(`${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.authEndpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        username: AIRFLOW_CONFIG.defaultCredentials.username,
        password: AIRFLOW_CONFIG.defaultCredentials.password
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Authentication failed: HTTP ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    const token = data.access_token || data.token || data.accessToken;
    
    if (!token) {
      throw new Error('No access token received from authentication endpoint');
    }

    currentJwtToken = token;
    tokenExpiry = Date.now() + (50 * 60 * 1000);
    
    // console.log('✅ Successfully authenticated with Airflow 3.x API');
    return currentJwtToken;
    
  } catch (error) {
    console.error('❌ Authentication failed:', error);
    currentJwtToken = null;
    tokenExpiry = null;
    throw error;
  } finally {
    isAuthenticating = false;
  }
};

// Function to get valid JWT token
const getValidToken = async (): Promise<string> => {
  if (isTokenExpired()) {
    // console.log('🔄 Token expired or missing, getting new token...');
    const token = await authenticateAndGetToken();
    if (!token) {
      throw new Error('Failed to authenticate with Airflow');
    }
    return token;
  }
  return currentJwtToken!;
};

// Helper function to make authenticated API requests with caching
const makeAuthenticatedRequest = async (
  endpoint: string, 
  options: RequestInit = {}, 
  cacheKey?: string, 
  cacheTTL = 30
): Promise<any> => {
  // Check cache first for GET requests
  if ((!options.method || options.method === 'GET') && cacheKey) {
    const cached = cache.get(cacheKey);
    if (cached) {
      console.log(`📦 Cache hit for: ${cacheKey}`);
      return cached;
    }
  }

  const maxRetries = 2;
  let retryCount = 0;
  
  while (retryCount < maxRetries) {
    try {
      const token = await getValidToken();
      const url = `${AIRFLOW_CONFIG.baseUrl}${AIRFLOW_CONFIG.apiVersion}${endpoint}`;
      
      const config: RequestInit = {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${token}`,
          ...options.headers
        },
        ...options,
      };

      // console.log(`📡 Making authenticated request to: ${url}`);
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorText = await response.text();
        if (response.status === 401 || response.status === 403) {
          console.log('🔐 Authentication error detected, clearing token...');
          currentJwtToken = null;
          tokenExpiry = null;
          if (retryCount === 0) {
            retryCount++;
            continue;
          }
        }
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const contentType = response.headers.get('content-type');
      let result;
      
      if (contentType && contentType.includes('application/json')) {
        result = await response.json();
      } else if (response.status === 204 || response.status === 200) {
        result = { success: true };
      } else {
        result = await response.text();
      }

      // Cache successful GET responses
      if ((!options.method || options.method === 'GET') && cacheKey) {
        cache.set(cacheKey, result, cacheTTL);
        console.log(`💾 Cached result for: ${cacheKey}`);
      }
      
      return result;
      
    } catch (error) {
      console.error(`API Request failed for ${endpoint} (attempt ${retryCount + 1}):`, error);
      
      if (retryCount >= maxRetries - 1) {
        throw error;
      }
      retryCount++;
    }
  }
};

// Helper function to fetch DAG runs with compatibility for different Airflow versions
const fetchDagRunsCompatible = async (dagId: string, limit: number = 5, offset: number = 0): Promise<any> => {
  const endpoints = [
    // Try Airflow 3.x format first
    `/dags/${dagId}/dagRuns?limit=${limit}&offset=${offset}&order_by=-logical_date`,
    // Fallback to Airflow 2.x format
    `/dags/${dagId}/dagRuns?limit=${limit}&offset=${offset}&order_by=-execution_date`,
    // Final fallback without ordering
    `/dags/${dagId}/dagRuns?limit=${limit}&offset=${offset}`
  ];

  for (const endpoint of endpoints) {
    try {
      // console.log(`Trying endpoint: ${endpoint}`);
      const result = await makeAuthenticatedRequest(endpoint, {}, undefined, 0);
      // console.log(`✅ Success with endpoint: ${endpoint}`);
      return result;
    } catch (error) {
      console.log(`❌ Failed with endpoint: ${endpoint}`);
      if (endpoint === endpoints[endpoints.length - 1]) {
        throw error; // Re-throw if it's the last attempt
      }
      continue;
    }
  }
};

// Batch function to get multiple DAG runs efficiently
const getBatchDagRuns = async (dagIds: string[], limit = 5): Promise<Record<string, any[]>> => {
  const cacheKey = `batch_runs_${dagIds.join(',')}_${limit}`;
  const cached = cache.get<Record<string, any[]>>(cacheKey);
  if (cached) {
    console.log('📦 Cache hit for batch DAG runs');
    return cached;
  }

  const runsMap: Record<string, any[]> = {};
  
  // Process in batches of 5 to avoid overwhelming the API
  const batchSize = 5;
  for (let i = 0; i < dagIds.length; i += batchSize) {
    const batch = dagIds.slice(i, i + batchSize);
    
    const batchPromises = batch.map(async (dagId) => {
      try {
        const runs = await fetchDagRunsCompatible(dagId, limit);
        return { dagId, runs: runs.dag_runs || [] };
      } catch (error) {
        console.error(`Failed to get runs for DAG ${dagId}:`, error);
        return { dagId, runs: [] };
      }
    });
    
    const batchResults = await Promise.all(batchPromises);
    
    batchResults.forEach(({ dagId, runs }) => {
      runsMap[dagId] = runs;
    });
  }
  
  // Cache the batch result
  cache.set(cacheKey, runsMap, 20);
  return runsMap;
};

// Helper function to try Windows path first, fallback to local if needed
const getTargetPath = async (targetPath: string, fallbackType: 'dags' | 'data' = 'dags'): Promise<{ path: string, isLocal: boolean }> => {
  // First, properly format the path to ensure UNC paths are correctly handled
  targetPath = formatUNCPath(targetPath);
  
  console.log(`Processing target path: ${targetPath}`);
  
  // Check for Windows absolute paths (C:\ format) or UNC network paths (\\server\share format)
  if (targetPath.includes(':\\') || targetPath.startsWith('\\\\')) {
    try {
      // For UNC paths, don't use path.dirname as it can cause issues
      let targetDir: string;
      if (targetPath.startsWith('\\\\')) {
        // UNC path - handle manually
        const parts = targetPath.split('\\').filter(p => p);
        targetDir = '\\\\' + parts.slice(0, -1).join('\\');
        console.log(`UNC path detected. Target directory: ${targetDir}`);
      } else {
        targetDir = path.dirname(targetPath);
      }
      
      // Check if network path is accessible
      if (targetPath.startsWith('\\\\')) {
        const networkParts = targetPath.split('\\').filter(p => p);
        if (networkParts.length >= 2) {
          const networkRoot = '\\\\' + networkParts.slice(0, 2).join('\\'); // \\server\share
          try {
            await fs.access(networkRoot);
            console.log(`✅ Network share accessible: ${networkRoot}`);
          } catch (networkError) {
            console.error(`❌ Network share not accessible: ${networkRoot}`, networkError);
            throw new Error(`Network share not accessible: ${networkRoot}`);
          }
        }
      }
      
      try {
        // Create directory if it doesn't exist
        await fs.mkdir(targetDir, { recursive: true });
        
        // Test write permissions
        const testFile = path.join(targetDir, '.write-test');
        await fs.writeFile(testFile, 'test');
        await fs.unlink(testFile);
      } catch (dirError) {
        console.error(`❌ Cannot create directory or write to: ${targetDir}`, dirError);
        throw new Error(`Cannot access or write to directory: ${targetDir}`);
      }
      
      console.log(`✓ Using network/Windows path: ${targetPath}`);
      return { path: targetPath, isLocal: false };
    } catch (error) {
      console.log(`⚠️ Cannot access network/Windows path ${targetPath}, falling back to local: ${error}`);
    }
  }
  
  const pathParts = targetPath.split(/[\\\/]/);
  const lastPart = pathParts[pathParts.length - 1];
  const localPath = `./${lastPart}`;
  
  console.log(`Using local fallback path: ${localPath}`);
  return { path: localPath, isLocal: true };
};

// Helper function to ensure directory exists
const ensureDirectory = async (dirPath: string): Promise<void> => {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (error) {
    console.error(`Failed to create directory ${dirPath}:`, error);
    throw error;
  }
};

// Helper function to find file in multiple locations
const findFile = async (fileName: string): Promise<string | null> => {
  // Try common directories where the file might be located
  const possiblePaths = [
    path.join(process.cwd(), 'uploads', fileName),
    path.join(process.cwd(), 'input-files', fileName),
    path.resolve('./uploads', fileName),
    path.resolve('./input-files', fileName),
    // Add temp directory
    path.join(process.cwd(), 'temp', fileName),
    // Try with the file hash (multer sometimes renames files)
    ...(await findFileByContent(fileName))
  ];

  console.log(`Looking for file ${fileName} in possible paths:`, possiblePaths);

  for (const filePath of possiblePaths) {
    try {
      await fs.access(filePath);
      console.log(`Found file at: ${filePath}`);
      return filePath;
    } catch (error) {
      // Continue to next path
    }
  }
  
  console.log(`File ${fileName} not found in any of the expected locations`);
  return null;
};

// Helper to find files by content in the uploads directory
const findFileByContent = async (originalName: string): Promise<string[]> => {
  try {
    const uploadsDir = path.join(process.cwd(), 'uploads');
    const files = await fs.readdir(uploadsDir);
    const results: string[] = [];
    
    // Return all paths in the uploads directory as possible matches
    // This is a fallback for when the file was renamed
    return files.map(file => path.join(uploadsDir, file));
  } catch (error) {
    console.error('Error reading uploads directory:', error);
    return [];
  }
};

// Function to generate DAG script (updated to match StructuredDataArchival.py)
function generateDagScript(config: any) {
  const inputDirectory = config.inputDirectory || path.dirname(config.inputPath || '');
  const outputDirectory = config.outputDirectory || path.dirname(config.outputPath || '');
  const description = config.description || 'Schema and Table Detection, CSV to XML Transformation, Export with IA';
  const scheduleInterval = config.scheduleInterval === 'None' ? 'None' : `'${config.scheduleInterval}'`;
  const owner = 'airflow';
  const retries = 1;
  const chunkSize = config.chunkSize || 5000;

  return `from airflow import DAG
from airflow.decorators import task
from datetime import datetime
import os, csv, requests, shutil
import xml.etree.ElementTree as ET

# Configs
WATCH_DIR = r'${inputDirectory}'
PROCESSED_DIR = r'${outputDirectory}'
CHUNK_SIZE = ${chunkSize}  # Configurable chunk size
BEARER_TOKEN = "<YOUR_BEARER_TOKEN_HERE>"  # Replace or inject as needed
EXPORT_URL_MAP = {
    # Example: 'TableName': 'http://your-export-url'
}

default_args = {"owner": "${owner}", "retries": ${retries}}

with DAG(
    dag_id='${config.dagId}',
    default_args=default_args,
    start_date=datetime(2024, 1, 1),
    schedule=${scheduleInterval},
    catchup=False,
    description='${description}',
    tags=['Schema & Table Detection','CSV to XML','Export to InfoArchive']
) as dag:

    @task
    def find_csv_file():
        for fname in os.listdir(WATCH_DIR):
            if fname.endswith(".csv"):
                full_path = os.path.join(WATCH_DIR, fname)
                lock_path = full_path + ".lock"
                if not os.path.exists(lock_path):
                    open(lock_path, 'w').close()  # create lock
                    return {"file": full_path, "lock": lock_path}
        raise FileNotFoundError("📁 No unprocessed CSV file found")

    @task
    def extract_metadata(context):
        path = context["file"]
        base = os.path.splitext(os.path.basename(path))[0]
        parts = base.split("_")
        schema = parts[0] if parts else "Schema"
        table = parts[1] if len(parts) > 1 else "Unknown"
        url = EXPORT_URL_MAP.get(table)
        if not url:
            raise ValueError(f"🚫 Unsupported table '{table}'")
        return {
            "file": path,
            "lock": context["lock"],
            "base": base,
            "schema": schema,
            "table": table,
            "url": url
        }

    @task
    def read_csv_chunks(metadata):
        chunks = []
        with open(metadata["file"], encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            chunk = []
            for row in reader:
                chunk.append(row)
                if len(chunk) >= CHUNK_SIZE:
                    chunks.append(chunk)
                    chunk = []
            if chunk:
                chunks.append(chunk)
        return {"metadata": metadata, "chunks": chunks}

    @task
    def export_chunks(context):
        metadata = context["metadata"]
        for idx, chunk in enumerate(context["chunks"]):
            # Convert chunk to XML
            root = ET.Element(metadata["schema"])
            middle = ET.SubElement(root, metadata["table"])
            for row in chunk:
                row_elem = ET.SubElement(middle, "ROW")
                for k, v in row.items():
                    child = ET.SubElement(row_elem, k.strip().replace(" ", "_"))
                    child.text = str(v) if v else ""
            xml_data = ET.tostring(root, encoding="utf-8")
            temp_file = os.path.join(WATCH_DIR, f"{metadata['base']}_chunk_{idx}.xml")
            with open(temp_file, "wb") as f:
                f.write(xml_data)

            # Export via POST
            with open(temp_file, "rb") as f:
                xml_content=f.read()
                response = requests.post(
                    url=metadata["url"],
                    headers={
                        "Authorization": f"Bearer {BEARER_TOKEN}",
                        "Content-Type": "application/xml"
                    },
                    data=xml_content
                )
            print(f"📤 Chunk {idx} exported | Status: {response.status_code}")
            print(f"⚠️ Response Status: {response.status_code}")
            print(f"📨 Response Text: {response.text}")
            os.remove(temp_file)

    @task
    def cleanup(context):
        shutil.move(context["metadata"]["file"], os.path.join(PROCESSED_DIR, os.path.basename(context["metadata"]["file"])))
        os.remove(context["metadata"]["lock"])
        print(f"✅ File moved and lock removed: {context['metadata']['file']}")

    # Chain execution
    file_context = find_csv_file()
    metadata_context = extract_metadata(file_context)
    chunks_context = read_csv_chunks(metadata_context)
    export_chunks(chunks_context) >> cleanup(chunks_context)
`
}

// Function to generate sample XML
const generateSampleXml = (headers: string[], sampleRows: string[][]): string => {
  const customerName = "SampleCorp";
  
  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<TICKETS>
    <${customerName}>`;

  sampleRows.forEach((row, index) => {
    xml += `
        <ROW>`;
    headers.forEach((header, headerIndex) => {
      const value = row[headerIndex] || '';
      xml += `
            <${header}>${value}</${header}>`;
    });
    xml += `
        </ROW>`;
  });

  xml += `
    </${customerName}>
</TICKETS>`;

  return xml;
};

// Enhanced function to generate template when source code is not available
const generateEnhancedTemplate = (dagDetails: any, tasks: any[] = []): string => {
  const dagId = dagDetails.dag_id || 'unknown_dag';
  const description = dagDetails.description || 'Auto-generated DAG template';
  const schedule = dagDetails.schedule_interval || 'None';
  
  // Create a more detailed template based on available information
  let template = `"""
Auto-generated template for DAG: ${dagId}
Description: ${description}
Generated on: ${new Date().toISOString()}

Note: This is a template generated from DAG metadata.
The actual source code may differ from this template.
"""

from airflow import DAG
from airflow.decorators import task
from datetime import datetime, timedelta

# Default arguments
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# DAG definition
with DAG(
    dag_id='${dagId}',
    default_args=default_args,
    description='${description}',
    schedule=${schedule === 'None' ? 'None' : `'${schedule}'`},
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['generated', 'template'],
) as dag:
`;

  // Add tasks based on metadata if available
  if (tasks && tasks.length > 0) {
    template += `
    # Tasks (reconstructed from metadata)
`;
    tasks.forEach((task, index) => {
      const taskId = task.task_id || `task_${index + 1}`;
      const operator = task.operator_name || 'PythonOperator';
      
      template += `
    @task(task_id='${taskId}')
    def ${taskId.replace(/[^a-zA-Z0-9_]/g, '_')}():
        \"\"\"
        Task: ${taskId}
        Operator: ${operator}
        \"\"\"
        print(f"Executing task: ${taskId}")
        # Add your task logic here
        pass
`;
    });
    
    // Add task dependencies if we can infer them
    template += `
    # Task dependencies (modify as needed)
`;
    tasks.forEach((task, index) => {
      if (index > 0) {
        const currentTask = task.task_id?.replace(/[^a-zA-Z0-9_]/g, '_') || `task_${index + 1}`;
        const previousTask = tasks[index - 1].task_id?.replace(/[^a-zA-Z0-9_]/g, '_') || `task_${index}`;
        template += `    ${currentTask}()\n`;
      } else {
        const currentTask = task.task_id?.replace(/[^a-zA-Z0-9_]/g, '_') || `task_${index + 1}`;
        template += `    ${currentTask}()\n`;
      }
    });
  } else {
    // Default template with a simple task
    template += `
    @task
    def example_task():
        \"\"\"
        Example task - replace with your actual task logic
        \"\"\"
        print("Hello from ${dagId}!")
        return "Task completed successfully"
    
    # Execute the task
    example_task()
`;
  }

  template += `
# Additional configuration and tasks can be added here
`;

  return template;
};

// Function to generate and deploy DAG with auto-setup
const generateAndDeployDagWithAutoSetup = async (config: DagConfigurationInput): Promise<{
  success: boolean;
  dagScript: string;
  filePath: string;
  message: string;
  autoUnpaused?: boolean;
}> => {
  try {
    console.log(`🏗️ Generating and deploying DAG: ${config.dagId}`);
    
    // Generate the DAG script
    const dagScript = generateDagScript(config);
    
    // Save to DAGs directory
    const { path: actualDagsDir, isLocal } = await getTargetPath(
      config.dagsDirectory || "C:\\Docker\\airflow3x2\\dags", 
      'dags'
    );
    const dagFilePath = path.join(actualDagsDir, `${config.dagId}.py`);
    
    await ensureDirectory(actualDagsDir);
    await fs.writeFile(dagFilePath, dagScript, 'utf-8');
    
    console.log(`✅ DAG script saved to: ${dagFilePath}`);
    
    // Return immediately - the frontend will handle the polling and auto-unpause
    return {
      success: true,
      dagScript,
      filePath: dagFilePath,
      message: `DAG script generated and saved. Airflow will scan and load it shortly.`,
      autoUnpaused: false // Will be handled by frontend polling
    };
    
  } catch (error) {
    console.error(`❌ Failed to generate and deploy DAG ${config.dagId}:`, error);
    throw error;
  }
};

// Helper function to auto-detect report type based on JSON structure
const detectReportType = (jsonData: any): string => {
  // Check for common patterns in the JSON structure
  
  // Pattern 1: labels + counts + percentages (charts)
  if (jsonData.labels && Array.isArray(jsonData.labels) && 
      jsonData.counts && Array.isArray(jsonData.counts) && 
      jsonData.percentages && Array.isArray(jsonData.percentages)) {
    return 'chart';
  }
  
  // Pattern 2: key-value pairs with numeric values (metrics)
  if (typeof jsonData === 'object' && !Array.isArray(jsonData)) {
    const values = Object.values(jsonData);
    const hasNumericValues = values.every(val => typeof val === 'number');
    if (hasNumericValues && values.length > 0) {
      return 'metrics';
    }
  }
  
  // Pattern 3: array of objects (table)
  if (Array.isArray(jsonData) && jsonData.length > 0 && 
      typeof jsonData[0] === 'object') {
    return 'table';
  }
  
  // Pattern 4: nested object with arrays (complex data)
  if (typeof jsonData === 'object' && !Array.isArray(jsonData)) {
    const hasArrays = Object.values(jsonData).some(val => Array.isArray(val));
    if (hasArrays) {
      return 'complex';
    }
  }
  
  // Default fallback
  return 'raw';
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Upload CSV file
  app.post("/api/upload-csv", upload.single('csvFile'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const filePath = req.file.path;
      const originalName = req.file.originalname;
      
      const fileContent = await fs.readFile(filePath, 'utf-8');
      const lines = fileContent.trim().split('\n');
      
      if (lines.length === 0) {
        await fs.unlink(filePath);
        return res.status(400).json({ message: "CSV file is empty" });
      }
      
      const parseCSVLine = (line: string) => {
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current.trim());
        return result;
      };
      
      const headers = parseCSVLine(lines[0]);
      const previewLines = lines.slice(1, 4);
      const rows = previewLines.filter(line => line.trim()).map(line => parseCSVLine(line));

      const inputDir = './input-files';
      await ensureDirectory(inputDir);
      const savedCsvPath = path.join(inputDir, originalName);
      await fs.copyFile(filePath, savedCsvPath);
      
      console.log(`File uploaded and saved: ${originalName}`);

      res.json({
        fileName: originalName,
        fileSize: req.file.size,
        headers,
        previewRows: rows,
        success: true,
        localCsvPath: savedCsvPath,
        uploadedPath: filePath,
        message: `CSV file uploaded and saved.`
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        message: "Failed to process uploaded file",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Move uploaded file to Airflow data directory
  app.post("/api/move-file-to-data", async (req, res) => {
    try {
      const { fileName, targetPath } = req.body;
      
      if (!fileName) {
        return res.status(400).json({ 
          success: false, 
          message: "fileName is required" 
        });
      }
      
      // Always use the configured network path if none provided
      const defaultPath = config.paths.incomingCsvDir;
      const userPath = targetPath || defaultPath;
      
      console.log(`Moving file: ${fileName} to ${userPath}`);
      
      // Format the target path properly for UNC paths
      const formattedTargetPath = formatUNCPath(userPath);
      console.log(`Formatted target path: ${formattedTargetPath}`);
      
      const sourcePath = await findFile(fileName);
      
      if (!sourcePath) {
        return res.status(404).json({
          success: false,
          message: `Source file not found: ${fileName}. Checked: uploads/, input-files/`
        });
      }
      
      try {
        // Attempt to ensure the network path exists
        if (formattedTargetPath.startsWith('\\\\')) {
          const pathParts = formattedTargetPath.split('\\').filter(p => p);
          if (pathParts.length >= 2) {
            // This is the network share root (e.g., \\server\share)
            const networkRoot = '\\\\' + pathParts.slice(0, 2).join('\\');
            try {
              await fs.access(networkRoot);
              console.log(`✅ Network share accessible: ${networkRoot}`);
            } catch (networkError) {
              console.error('Network share access error:', networkError);
              throw new Error(`Cannot access network share: ${networkRoot}`);
            }
          }
        }

        const { path: actualTargetPath, isLocal } = await getTargetPath(formattedTargetPath, 'data');
        const targetDir = path.dirname(actualTargetPath);
        
        await ensureDirectory(targetDir);
        
        // Always copy, never delete from input-files
        console.log(`Copying file from ${sourcePath} to ${actualTargetPath}`);
        await fs.copyFile(sourcePath, actualTargetPath);
        
        console.log(`File successfully copied from ${sourcePath} to: ${actualTargetPath}`);
        
        res.json({
          success: true,
          message: `File copied successfully to ${isLocal ? 'local' : 'Airflow'} data directory`,
          filePath: actualTargetPath,
          sourcePath: sourcePath,
          isLocal: isLocal,
          note: isLocal ? 
            "Could not access Windows Airflow directory, saved locally instead." : 
            "File copied to actual Airflow data directory."
        });
      } catch (error) {
        console.error('File move error details:', error);
        res.status(500).json({
          success: false,
          message: error instanceof Error ? error.message : 'Failed to move file',
          sourcePath: sourcePath,
          targetPath: formattedTargetPath
        });
      }
    } catch (error) {
      console.error('File move failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to move file'
      });
    }
  });

  // Specialized endpoint for IA Table Schema Generator to move files to Airflow incomingcsv directory
  app.post("/api/move-file-to-airflow", async (req, res) => {
    try {
      const { fileName } = req.body;
      
      if (!fileName) {
        return res.status(400).json({ 
          success: false, 
          message: "fileName is required" 
        });
      }
      
      // Use the unified configuration system - reload to ensure latest config
      const serverConfig = getUnifiedServerConfig();
      const deploymentMode = serverConfig.deploymentMode;
      const isLocalMode = deploymentMode === 'local';
      
      // Get the target path based on deployment mode
      let targetPath = serverConfig.paths.incomingCsvDir;
      
      console.log(`🔄 Moving file to Airflow directory (${deploymentMode} mode): ${fileName}`);
      console.log(`📁 Raw target path from config: ${targetPath}`);
      
      // Clean and format the path properly
      if (!isLocalMode && targetPath) {
        // Network mode - clean up excessive escaping
        targetPath = targetPath.replace(/\\\\\\\\/g, '\\\\'); // Convert \\\\\\\\ to \\\\
        if (!targetPath.startsWith('\\\\') && targetPath.includes('10.73.88.101')) {
          targetPath = '\\\\' + targetPath.replace(/^\\+/, ''); // Ensure UNC format
        }
      }
      
      console.log(`� Using ${isLocalMode ? 'local' : 'network'} path: ${targetPath}`);
      
      // Validate that we have a proper target path
      if (!targetPath || targetPath.trim() === '') {
        console.error('❌ Target path is empty or invalid');
        return res.status(500).json({
          success: false,
          message: `Target path is empty for ${deploymentMode} mode. Check configuration.`,
          deploymentMode,
          configPath: serverConfig.paths.incomingCsvDir
        });
      }
      
      const sourcePath = await findFile(fileName);
      
      if (!sourcePath) {
        return res.status(404).json({
          success: false,
          message: `Source file not found: ${fileName}. Checked: uploads/, input-files/`
        });
      }
      
      try {
        if (isLocalMode) {
          // Local mode - direct file copy to local path
          const targetFilePath = path.join(targetPath, fileName);
          
          console.log(`📁 Local mode: copying to ${targetFilePath}`);
          
          // Ensure directory exists
          await ensureDirectory(targetPath);
          
          // Copy the file directly
          console.log(`📁 Copying file from ${sourcePath} to ${targetFilePath}`);
          await fs.copyFile(sourcePath, targetFilePath);
          
          console.log(`✅ File successfully copied to local directory: ${targetFilePath}`);
          
          res.json({
            success: true,
            message: `File copied successfully to local Airflow data directory`,
            filePath: targetFilePath,
            sourcePath: sourcePath,
            isLocalFallback: false,
            deploymentMode: 'local'
          });
        } else {
          // Network mode - handle UNC paths with network accessibility checks
          const formattedTargetPath = formatUNCPath(targetPath);
          console.log(`🌐 Network mode: formatted path ${formattedTargetPath}`);
          
          // Check network path accessibility for UNC paths
          if (formattedTargetPath.startsWith('\\\\')) {
            const pathParts = formattedTargetPath.split('\\').filter(p => p);
            if (pathParts.length >= 2) {
              const networkRoot = '\\\\' + pathParts.slice(0, 2).join('\\');
              try {
                await fs.access(networkRoot);
                console.log(`✅ Network share accessible: ${networkRoot}`);
              } catch (networkError) {
                console.error('❌ Network share access error:', networkError);
                throw new Error(`Cannot access network share: ${networkRoot}`);
              }
            }
          }
          
          const targetFilePath = path.join(formattedTargetPath, fileName);
          
          // Create the directory if needed
          await ensureDirectory(formattedTargetPath);
          
          // Copy the file
          console.log(`🌐 Copying file from ${sourcePath} to ${targetFilePath}`);
          await fs.copyFile(sourcePath, targetFilePath);
          
          console.log(`✅ File successfully copied to network directory: ${targetFilePath}`);
          
          res.json({
            success: true,
            message: `File copied successfully to network Airflow data directory`,
            filePath: targetFilePath,
            sourcePath: sourcePath,
            isLocalFallback: false,
            deploymentMode: 'network'
          });
        }
      } catch (primaryError) {
        console.error(`❌ Error copying to ${isLocalMode ? 'local' : 'network'} path:`, primaryError);
        
        // Fallback to local copy if primary path fails
        try {
          const localTargetDir = path.join(process.cwd(), 'data', 'incomingcsv');
          await ensureDirectory(localTargetDir);
          
          const localTargetPath = path.join(localTargetDir, fileName);
          await fs.copyFile(sourcePath, localTargetPath);
          
          console.log(`⚠️ File copied to local fallback path: ${localTargetPath}`);
          
          res.json({
            success: true,
            message: `File copied to local data directory (${isLocalMode ? 'local path error' : 'network path unavailable'})`,
            filePath: localTargetPath,
            sourcePath: sourcePath,
            isLocalFallback: true,
            deploymentMode: deploymentMode,
            originalError: primaryError instanceof Error ? primaryError.message : 'Unknown error'
          });
        } catch (localError) {
          console.error('Local fallback also failed:', localError);
          throw localError;
        }
      }
    } catch (error) {
      console.error('IA Schema Generator file move failed:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to move file'
      });
    }
  });

  // Get CSV record count endpoint
  app.post("/api/get-csv-record-count", async (req, res) => {
    try {
      const { fileName } = req.body;
      
      if (!fileName) {
        return res.status(400).json({
          success: false,
          message: 'fileName is required'
        });
      }

      console.log(`📊 Getting record count for file: ${fileName}`);
      const config = getUnifiedServerConfig();
      
      // Get and clean the incoming CSV directory path
      let incomingCsvDir = config.paths.incomingCsvDir;
      
      // Clean up excessive escaping for network paths
      if (config.deploymentMode === 'network' && incomingCsvDir) {
        incomingCsvDir = incomingCsvDir.replace(/\\\\\\\\/g, '\\\\'); // Convert \\\\\\\\ to \\\\
        if (!incomingCsvDir.startsWith('\\\\') && incomingCsvDir.includes('10.73.88.101')) {
          incomingCsvDir = '\\\\' + incomingCsvDir.replace(/^\\+/, ''); // Ensure UNC format
        }
      }
      
      // Construct file path based on deployment mode
      const filePath = path.join(incomingCsvDir, fileName);
      
      console.log(`📂 Checking file at: ${filePath}`);
      
      // Check if file exists
      try {
        await fs.access(filePath);
      } catch (error) {
        console.error(`❌ File not found: ${filePath}`);
        return res.status(404).json({
          success: false,
          message: `File not found: ${fileName}`
        });
      }
      
      // Read and count records
      const fileContent = await fs.readFile(filePath, 'utf-8');
      const lines = fileContent.split('\n').filter(line => line.trim() !== '');
      const recordCount = Math.max(0, lines.length - 1); // Subtract header row
      
      console.log(`✅ File ${fileName} has ${recordCount} records`);
      
      res.json({
        success: true,
        recordCount,
        fileName
      });
    } catch (error) {
      console.error('❌ Record count error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to count records'
      });
    }
  });
  
  // Test DAG script for syntax and validation
  app.post("/api/test-dag", async (req, res) => {
    try {
      const { dagId, dagScript } = req.body;
      
      if (!dagId || !dagScript) {
        return res.status(400).json({ 
          success: false,
          message: "DAG ID and script are required" 
        });
      }

      console.log(`Testing DAG: ${dagId}`);
      
      // Basic syntax validation
      const syntaxErrors = [];
      
      // Check for required imports
      if (!dagScript.includes('from airflow import DAG')) {
        syntaxErrors.push('Missing required import: from airflow import DAG');
      }
      
      if (!dagScript.includes('from datetime import datetime')) {
        syntaxErrors.push('Missing required import: from datetime import datetime');
      }
      
      // Check for DAG definition
      if (!dagScript.includes('with DAG(')) {
        syntaxErrors.push('Missing DAG definition with DAG()');
      }
      
      // Check for DAG ID in script
      if (!dagScript.includes(`dag_id='${dagId}'`)) {
        syntaxErrors.push(`DAG ID '${dagId}' not found in script`);
      }
      
      // Check for task definition
      if (!dagScript.includes('@task') && !dagScript.includes('PythonOperator')) {
        syntaxErrors.push('No tasks found in DAG script');
      }
      
      // Try to save to temporary file and validate Python syntax
      const tempDir = './temp';
      await ensureDirectory(tempDir);
      const tempFilePath = path.join(tempDir, `${dagId}_test.py`);
      
      try {
        await fs.writeFile(tempFilePath, dagScript, 'utf-8');
        
        // Use Python to check syntax (if available)
        try {
          execSync(`python -m py_compile "${tempFilePath}"`, { stdio: 'pipe' });
          console.log('✅ Python syntax validation passed');
        } catch (pythonError) {
          console.log('⚠️ Python syntax check failed (this is optional)');
          // Don't add this as an error since Python might not be available
        }
        
        // Clean up temp file
        await fs.unlink(tempFilePath).catch(() => {});
      } catch (fileError) {
        console.warn('Could not create temp file for validation:', fileError);
      }
      
      const hasErrors = syntaxErrors.length > 0;
      
      res.json({
        success: !hasErrors,
        message: hasErrors ? 'DAG validation failed' : 'DAG validation passed successfully',
        errors: syntaxErrors,
        validation: {
          syntax: syntaxErrors.length === 0,
          hasRequiredImports: dagScript.includes('from airflow import DAG'),
          hasDagDefinition: dagScript.includes('with DAG('),
          hasTaskDefinition: dagScript.includes('@task') || dagScript.includes('PythonOperator'),
          dagIdMatches: dagScript.includes(`dag_id='${dagId}'`)
        }
      });
      
    } catch (error) {
      console.error('DAG test error:', error);
      res.status(500).json({ 
        success: false,
        message: "Failed to test DAG script",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Validate deployment endpoint
  app.post("/api/validate-deployment", async (req, res) => {
    try {
      const { dagId, inputDirectory, outputDirectory, dagsDirectory } = req.body;
      
      if (!dagId || !inputDirectory || !outputDirectory || !dagsDirectory) {
        return res.status(400).json({ 
          success: false,
          message: "All parameters are required" 
        });
      }

      const validation = {
        syntax: true,
        dagId: true,
        filePaths: true,
        dependencies: true,
        fileLocation: true
      };

      let hasErrors = false;

      // Check if DAG ID is unique
      try {
        const existingConfig = await storage.getDagConfigurationByDagId(dagId);
        if (existingConfig) {
          validation.dagId = false;
          hasErrors = true;
        }
      } catch (error) {
        console.warn('Could not check DAG uniqueness:', error);
      }

      // Check file paths
      try {
        const inputDir = path.dirname(inputDirectory);
        const outputDir = path.dirname(outputDirectory);
        
        // Try to access directories (don't fail validation if not accessible)
        try {
          await fs.access(inputDir);
          console.log(`✅ Input directory accessible: ${inputDir}`);
        } catch {
          console.log(`⚠️ Input directory not accessible: ${inputDir}`);
        }
        
        try {
          await fs.access(outputDir);
          console.log(`✅ Output directory accessible: ${outputDir}`);
        } catch {
          console.log(`⚠️ Output directory not accessible: ${outputDir}`);
        }
      } catch (error) {
        console.log('Directory check failed:', error);
      }

      // Check if DAGs directory exists
      try {
        const { path: actualDagsDir } = await getTargetPath(dagsDirectory, 'dags');
        await fs.access(actualDagsDir);
        console.log(`✅ DAGs directory accessible: ${actualDagsDir}`);
      } catch (error) {
        console.log('DAGs directory not accessible, will use local fallback');
      }

      res.json({
        success: !hasErrors,
        message: hasErrors ? 'Validation completed with some issues' : 'All validation checks passed',
        validation
      });
      
    } catch (error) {
      console.error('Validation error:', error);
      res.status(500).json({ 
        success: false,
        message: "Failed to validate deployment",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Check DAG ID uniqueness
  app.post("/api/check-dag-id", async (req, res) => {
    try {
      const { dagId } = req.body;
      if (!dagId) {
        return res.status(400).json({ message: "DAG ID is required" });
      }

      const existingConfig = await storage.getDagConfigurationByDagId(dagId);
      if (existingConfig) {
        return res.json({ isUnique: false, message: "DAG ID already exists in database" });
      }

      const dagsDir = process.env.AIRFLOW_DAGS_DIR || "C:\\Docker\\airflow3x2\\dags";
      const { path: actualDagsDir } = await getTargetPath(dagsDir, 'dags');
      
      try {
        const dagFilePath = path.join(actualDagsDir, `${dagId}.py`);
        await fs.access(dagFilePath);
        return res.json({ isUnique: false, message: "DAG file already exists in directory" });
      } catch {
        // File doesn't exist, which is good
      }
      
      try {
        const localDagFilePath = path.join('./dags', `${dagId}.py`);
        await fs.access(localDagFilePath);
        return res.json({ isUnique: false, message: "DAG file already exists in local directory" });
      } catch {
        // File doesn't exist, which is good
      }

      res.json({ isUnique: true, message: "DAG ID is available" });
    } catch (error) {
      console.error('DAG ID check error:', error);
      res.status(500).json({ message: "Failed to check DAG ID uniqueness" });
    }
  });

  // Enhanced DAG generation endpoint with auto-setup
  app.post("/api/generate-dag", async (req, res) => {
    try {
      console.log('Received enhanced DAG generation request:', req.body);
      
      const validatedData = dagConfigurationSchema.parse(req.body);
      console.log('Validated data:', validatedData);
      
      const configToSave = {
        dagId: validatedData.dagId,
        inputPath: validatedData.inputPath || '',
        outputPath: validatedData.outputPath || '',
        description: validatedData.description || null,
        scheduleInterval: validatedData.scheduleInterval || null,
        dagsDirectory: validatedData.dagsDirectory || null,
        chunkSize: validatedData.chunkSize || 5000,
      };
      
      // Save configuration to database
      const config = await storage.createDagConfiguration(configToSave);
      
      // Generate and deploy with enhanced setup
      const deployResult = await generateAndDeployDagWithAutoSetup(validatedData);

      res.json({
        config,
        dagScript: deployResult.dagScript,
        success: true,
        message: "DAG script generated and deployed successfully",
        filePath: deployResult.filePath,
        note: "DAG will be automatically scanned by Airflow. Frontend will monitor for availability."
      });
    } catch (error) {
      console.error('Enhanced DAG generation error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code
          }))
        });
      }
      
      res.status(500).json({ 
        message: "Failed to generate DAG script",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Save DAG to directory
  app.post("/api/save-dag", async (req, res) => {
    try {
      const { dagId, dagScript, dagsDirectory } = req.body;
      
      console.log('Save DAG request:', { dagId, dagsDirectory, scriptLength: dagScript?.length });
      
      if (!dagId || !dagScript) {
        return res.status(400).json({ message: "DAG ID and script are required" });
      }

      const { path: actualDagsDir, isLocal } = await getTargetPath(dagsDirectory || "C:\\Docker\\airflow3x2\\dags", 'dags');
      const dagFilePath = path.join(actualDagsDir, `${dagId}.py`);

      console.log('Attempting to save to:', dagFilePath);

      await ensureDirectory(actualDagsDir);
      console.log('Directory created/verified:', actualDagsDir);
      
      let fileExists = false;
      try {
        await fs.access(dagFilePath);
        fileExists = true;
      } catch (error) {
        // File doesn't exist, which is fine
      }
      
      await fs.writeFile(dagFilePath, dagScript, 'utf-8');
      console.log('File written successfully to:', dagFilePath);

      const stats = await fs.stat(dagFilePath);
      console.log('File stats:', { size: stats.size, created: stats.birthtime });

      const note = fileExists ? 'Existing DAG file updated.' : 'New DAG file created.';
      const locationNote = isLocal ? 
        "Could not access Windows Airflow directory, saved to local directory instead." : 
        "File saved to actual Airflow DAGs directory.";

      res.json({
        success: true,
        message: `DAG saved successfully to ${isLocal ? 'local' : 'Airflow'} directory`,
        filePath: dagFilePath,
        fileSize: stats.size,
        isLocal: isLocal,
        note: `${note} ${locationNote}`
      });
    } catch (error) {
      console.error('DAG save error:', error);
      res.status(500).json({ 
        message: "Failed to save DAG to directory",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get reports from Airflow reports folder with enhanced path management
  app.get("/api/reports", async (req, res) => {
    try {
      console.log('🔍 Fetching reports from configured reports folder...');
      
      // Get fresh configuration to ensure environment variables are loaded
      const freshConfig = getUnifiedServerConfig();
      
      // Use enhanced path resolution with proper fallback chain
      const rawReportsDirectory = freshConfig.paths.reportsDir;
      
      console.log(`📁 Configured reports directory: "${rawReportsDirectory}"`);
      console.log(`📋 Full config paths:`, {
        networkReports: freshConfig.networkPaths?.reportsDir,
        localReports: freshConfig.localPaths?.reportsDir,
        fallbackReports: freshConfig.fallbackPaths?.reportsDir,
        activeReports: freshConfig.paths.reportsDir,
        deploymentMode: freshConfig.deploymentMode
      });
      
      // Enhanced path resolution with proper reports handling
      let actualDataPath: string = '';
      let isLocal: boolean = true;
      let pathResolution;
      
      try {
        pathResolution = await pathManager.resolvePath(rawReportsDirectory, 'reports');
        actualDataPath = pathResolution.path;
        isLocal = pathResolution.isLocal;
        
        console.log(`� Primary path resolution: ${actualDataPath} (${isLocal ? 'LOCAL' : pathResolution.type.toUpperCase()})`);
        
        // Validate the resolved path
        if (!pathResolution.accessible) {
          throw new Error(`Primary path not accessible: ${actualDataPath}`);
        }
        
      } catch (primaryError) {
        const errorMessage = primaryError instanceof Error ? primaryError.message : 'Unknown error';
        console.warn(`⚠️ Primary reports path resolution failed: ${errorMessage}`);
        
        // Try fallback paths with enhanced logic
        const fallbackPaths = [
          // Network fallback if exists
          freshConfig.networkPaths?.reportsDir,
          freshConfig.localPaths?.reportsDir,
          freshConfig.fallbackPaths?.reportsDir,
          // Default local paths
          './reports',
          './data',
          './input-files', 
          './uploads'
        ].filter(Boolean);
        
        console.log(`🔄 Trying ${fallbackPaths.length} fallback paths...`);
        
        let fallbackFound = false;
        for (const fallbackPath of fallbackPaths) {
          try {
            console.log(`Trying fallback: ${fallbackPath}`);
            const fallbackResolution = await pathManager.resolvePath(fallbackPath!, 'reports');
            
            if (fallbackResolution.accessible) {
              actualDataPath = fallbackResolution.path;
              isLocal = fallbackResolution.isLocal;
              fallbackFound = true;
              console.log(`✅ Using fallback path: ${actualDataPath} (${isLocal ? 'LOCAL' : fallbackResolution.type.toUpperCase()})`);
              break;
            }
          } catch (fallbackError) {
            const fallbackErrorMessage = fallbackError instanceof Error ? fallbackError.message : 'Unknown error';
            console.log(`❌ Fallback ${fallbackPath} failed: ${fallbackErrorMessage}`);
            continue;
          }
        }
        
        if (!fallbackFound) {
          // Set default local path if no fallback found
          actualDataPath = './reports';
          isLocal = true;
          console.warn('⚠️ No accessible reports directory found, using default local path: ./reports');
        }
      }
      
      console.log(`📂 Final reports path: ${actualDataPath} (${isLocal ? 'LOCAL' : 'NETWORK'})`);
      console.log(`Looking for JSON files in: ${actualDataPath}`);
      
      // Ensure the directory exists
      try {
        await pathManager.ensureDirectory(actualDataPath);
      } catch (ensureError) {
        const ensureErrorMessage = ensureError instanceof Error ? ensureError.message : 'Unknown error';
        console.warn(`⚠️ Could not ensure directory exists: ${ensureErrorMessage}`);
      }
      
      // Find all JSON files in the reports directory
      const jsonFiles = await fs.readdir(actualDataPath).then(files => 
        files.filter(file => file.endsWith('.json'))
      ).catch(async (error) => {
        console.log(`Could not read from ${actualDataPath}, error: ${error.message}`);
        console.log(`🔄 Attempting additional local fallback paths...`);
        
        // Additional fallback search in common report locations
        const extraFallbackPaths = ['./data', './input-files', './uploads', './temp'];
        
        for (const extraPath of extraFallbackPaths) {
          try {
            console.log(`Trying extra fallback path: ${extraPath}`);
            const files = await fs.readdir(extraPath);
            const jsonFiles = files.filter(file => file.endsWith('.json'));
            if (jsonFiles.length > 0) {
              console.log(`✅ Found ${jsonFiles.length} JSON files in ${extraPath}: ${jsonFiles.join(', ')}`);
              actualDataPath = extraPath; // Update the actual path for file reading
              return jsonFiles;
            }
          } catch (extraError) {
            console.log(`❌ Extra fallback ${extraPath} failed: ${extraError instanceof Error ? extraError.message : 'Unknown error'}`);
            continue;
          }
        }
        
        console.log('All fallback paths exhausted, returning empty array');
        return [];
      });
      
      if (!jsonFiles || jsonFiles.length === 0) {
        return res.json({
          success: true,
          reports: [],
          message: "No JSON report files found in data directory",
          dataPath: actualDataPath,
          isLocal
        });
      }
      
      console.log(`Found ${jsonFiles.length} JSON files: ${jsonFiles.join(', ')}`);
      
      // Read and parse all JSON files
      const reports = [];
      
      for (const jsonFile of jsonFiles) {
        try {
          const filePath = path.join(actualDataPath, jsonFile);
          const fileContent = await fs.readFile(filePath, 'utf-8');
          const jsonData = JSON.parse(fileContent);
          
          // Auto-detect report type based on JSON structure
          const reportType = detectReportType(jsonData);
          
          reports.push({
            fileName: jsonFile,
            name: path.basename(jsonFile, '.json').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
            type: reportType,
            data: jsonData,
            lastModified: (await fs.stat(filePath)).mtime.getTime()
          });
          
          console.log(`✅ Processed report: ${jsonFile} (${reportType})`);
        } catch (fileError) {
          console.error(`❌ Error processing ${jsonFile}:`, fileError);
          // Continue with other files
        }
      }
      
      res.json({
        success: true,
        reports: reports.sort((a, b) => b.lastModified - a.lastModified), // Sort by newest first
        message: `Found ${reports.length} report(s)`,
        dataPath: actualDataPath,
        isLocal
      });
      
    } catch (error) {
      console.error('❌ Failed to fetch reports:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch reports',
        reports: []
      });
    }
  });

  // Clear cache endpoint
  app.post("/api/cache/clear", async (req, res) => {
    try {
      const { pattern } = req.body;
      
      if (pattern) {
        cache.invalidatePattern(pattern);
        res.json({ success: true, message: `Cache cleared for pattern: ${pattern}` });
      } else {
        cache.clear();
        res.json({ success: true, message: "All cache cleared" });
      }
    } catch (error) {
      console.error('Cache clear error:', error);
      res.status(500).json({ message: "Failed to clear cache" });
    }
  });

  // Get all DAG configurations
  app.get("/api/dag-configurations", async (req, res) => {
    try {
      const configs = await storage.getAllDagConfigurations();
      res.json(configs);
    } catch (error) {
      console.error('Get configurations error:', error);
      res.status(500).json({ message: "Failed to retrieve DAG configurations" });
    }
  });

  // Get current deployment configuration
  app.get("/api/config/deployment", async (req, res) => {
    try {
      const config = getUnifiedServerConfig();
      res.json({
        deploymentMode: config.deploymentMode,
        paths: {
          incomingCsvDir: config.paths.incomingCsvDir,
          processedCsvDir: config.paths.processedCsvDir,
          reportsDir: config.paths.reportsDir,
          dagsDir: config.paths.dagsDir,
          dataBaseDir: config.paths.dataBaseDir
        },
        connection: {
          url: config.connection.url
        }
      });
    } catch (error) {
      console.error('Get deployment config error:', error);
      res.status(500).json({ message: "Failed to retrieve deployment configuration" });
    }
  });

  // Test Airflow connection
  app.get("/api/test-airflow", async (req, res) => {
    try {
      // Reload configuration to ensure we have the latest environment variables
      AIRFLOW_CONFIG = getAirflowConfig();
      
      console.log(`🔧 Testing Airflow connection to: ${AIRFLOW_CONFIG.baseUrl}`);
      
      const token = await authenticateAndGetToken();
      const versionInfo = await makeAuthenticatedRequest('/version', {}, 'airflow_version', 60);
      
      res.json({ 
        connected: true, 
        status: versionInfo,
        url: AIRFLOW_CONFIG.baseUrl,
        token: token ? '✓ Valid JWT Token' : '✗ Invalid Token',
        apiVersion: AIRFLOW_CONFIG.apiVersion,
        authMethod: 'JWT Bearer Token (Airflow 3.x)'
      });
    } catch (error) {
      let errorMessage = "Connection failed";
      if (error instanceof Error) {
        if (error.message.includes('ECONNREFUSED')) {
          errorMessage = "Connection refused - Airflow is not running on this port";
        } else {
          errorMessage = error.message;
        }
      }
      
      res.json({ 
        connected: false, 
        error: errorMessage,
        url: AIRFLOW_CONFIG.baseUrl
      });
    }
  });

  // Generate sample XML
  app.post("/api/generate-sample-xml", async (req, res) => {
    try {
      const { headers, sampleRows } = req.body;
      
      if (!headers || !Array.isArray(headers)) {
        return res.status(400).json({ message: "Headers are required" });
      }

      const sampleXml = generateSampleXml(headers, sampleRows || []);
      
      res.json({
        xml: sampleXml,
        success: true
      });
    } catch (error) {
      console.error('XML generation error:', error);
      res.status(500).json({ message: "Failed to generate sample XML" });
    }
  });

  // AIRFLOW 3.x API ROUTES

  // Get all DAGs from Airflow 3.x with optimized batch loading
  app.get("/api/airflow/dags", async (req, res) => {
    try {
      const cacheKey = 'all_dags_enhanced';
      
      // Check cache first
      const cached = cache.get(cacheKey);
      if (cached) {
        console.log('📦 Returning cached DAGs data');
        return res.json(cached);
      }

      console.log('🔄 Loading fresh DAGs data...');
      
      // Get basic DAG info first
      const dags = await makeAuthenticatedRequest('/dags?limit=100', {}, 'basic_dags', 30);
      
      if (!dags.dags || dags.dags.length === 0) {
        const result = { dags: [], total: 0, success: true };
        cache.set(cacheKey, result, 30);
        return res.json(result);
      }

      const dagIds = dags.dags.map((dag: any) => dag.dag_id);
      
      // Get runs for all DAGs in batches
      const runsMap = await getBatchDagRuns(dagIds, 5);
      
      // Enhance DAGs with runs data
      const enhancedDags = dags.dags.map((dag: any) => ({
        ...dag,
        recent_runs: runsMap[dag.dag_id] || [],
        run_count: (runsMap[dag.dag_id] || []).length
      }));
      
      const result = {
        dags: enhancedDags,
        total: dags.total_entries || enhancedDags.length,
        success: true
      };
      
      // Cache the enhanced result
      cache.set(cacheKey, result, 30); // 30 second cache
      
      res.json(result);
    } catch (error) {
      console.error('Failed to fetch DAGs from Airflow:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch DAGs from Airflow'
      });
    }
  });

  // Get specific DAG details with caching
  app.get("/api/airflow/dags/:dagId", async (req, res) => {
    try {
      const { dagId } = req.params;
      const cacheKey = `dag_details_${dagId}`;
      
      // Check cache first
      const cached = cache.get(cacheKey);
      if (cached) {
        console.log(`📦 Returning cached DAG details for ${dagId}`);
        return res.json(cached);
      }
      
      console.log(`🔄 Fetching DAG details for: ${dagId}`);
      
      const [dag, runs, tasks] = await Promise.allSettled([
        makeAuthenticatedRequest(`/dags/${dagId}`, {}, `dag_${dagId}`, 60),
        fetchDagRunsCompatible(dagId, 10), // Use the compatible function
        makeAuthenticatedRequest(`/dags/${dagId}/tasks`, {}, `dag_tasks_${dagId}`, 300)
      ]);
      
      const result = {
        dag: dag.status === 'fulfilled' ? dag.value : null,
        runs: runs.status === 'fulfilled' ? (runs.value?.dag_runs || []) : [],
        tasks: tasks.status === 'fulfilled' ? (tasks.value?.tasks || []) : [],
        success: true
      };
      
      cache.set(cacheKey, result, 60); // 1 minute cache
      
      res.json(result);
    } catch (error) {
      console.error(`Failed to fetch DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch DAG details'
      });
    }
  });

  // New endpoint for auto-unpausing DAGs
  app.post("/api/airflow/dags/:dagId/auto-unpause", async (req, res) => {
    try {
      const { dagId } = req.params;
      
      if (!dagId) {
        return res.status(400).json({
          success: false,
          message: "DAG ID is required"
        });
      }
      
      console.log(`🔓 Auto-unpause request for DAG: ${dagId}`);
      
      // First check if DAG exists and is paused
      try {
        const dagInfo = await makeAuthenticatedRequest(`/dags/${dagId}`, {}, undefined, 0);
        
        if (!dagInfo) {
          return res.status(404).json({
            success: false,
            unpaused: false,
            message: 'DAG not found in Airflow',
            dagId: dagId
          });
        }
        
        if (!dagInfo.is_paused) {
          console.log(`✅ DAG ${dagId} is already unpaused`);
          return res.json({
            success: true,
            unpaused: false,
            message: 'DAG is already unpaused',
            dagId: dagId
          });
        }
        
        console.log(`🔓 DAG ${dagId} is paused, attempting to unpause...`);
        
        // Unpause the DAG
        const result = await makeAuthenticatedRequest(`/dags/${dagId}`, {
          method: 'PATCH',
          body: JSON.stringify({ is_paused: false })
        });
        
        if (result) {
          console.log(`✅ Successfully unpaused DAG ${dagId}`);
          
          // Invalidate caches
          cache.invalidatePattern(dagId);
          cache.invalidatePattern('all_dags');
          
          return res.json({
            success: true,
            unpaused: true,
            message: 'DAG successfully unpaused',
            dagId: dagId
          });
        } else {
          throw new Error('Unpause request failed');
        }
        
      } catch (airflowError) {
        console.error(`❌ Airflow API error for DAG ${dagId}:`, airflowError);
        return res.status(500).json({
          success: false,
          unpaused: false,
          message: airflowError instanceof Error ? airflowError.message : 'Airflow API error',
          dagId: dagId
        });
      }
      
    } catch (error) {
      console.error(`❌ Auto-unpause failed for DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        unpaused: false,
        message: error instanceof Error ? error.message : 'Failed to auto-unpause DAG',
        dagId: req.params.dagId
      });
    }
  });

  // Enhanced endpoint to check DAG status with unpause option
  app.get("/api/airflow/dags/:dagId/status", async (req, res) => {
    try {
      const { dagId } = req.params;
      const { auto_unpause } = req.query;
      
      console.log(`🔍 Checking status for DAG: ${dagId}`);
      
      const dagInfo = await makeAuthenticatedRequest(`/dags/${dagId}`, {}, `dag_status_${dagId}`, 10);
      
      if (!dagInfo) {
        return res.status(404).json({
          success: false,
          found: false,
          message: 'DAG not found in Airflow'
        });
      }
      
      let unpauseResult = null;
      
      // Auto-unpause if requested and DAG is paused
      if (auto_unpause === 'true' && dagInfo.is_paused) {
        console.log(`🔓 Auto-unpause requested for paused DAG: ${dagId}`);
        
        try {
          // Unpause the DAG
          const unpauseResponse = await makeAuthenticatedRequest(`/dags/${dagId}`, {
            method: 'PATCH',
            body: JSON.stringify({ is_paused: false })
          });
          
          if (unpauseResponse) {
            console.log(`✅ Successfully unpaused DAG ${dagId}`);
            unpauseResult = { unpaused: true, message: 'DAG successfully unpaused' };
            
            // Update the dagInfo to reflect the new state
            dagInfo.is_paused = false;
            
            // Invalidate caches
            cache.invalidatePattern(dagId);
            cache.invalidatePattern('all_dags');
          } else {
            unpauseResult = { unpaused: false, message: 'Failed to unpause DAG' };
          }
        } catch (unpauseError) {
          console.error(`❌ Failed to unpause DAG ${dagId}:`, unpauseError);
          unpauseResult = { 
            unpaused: false, 
            message: unpauseError instanceof Error ? unpauseError.message : 'Unknown unpause error' 
          };
        }
      }
      
      res.json({
        success: true,
        found: true,
        dag: dagInfo,
        is_paused: dagInfo.is_paused,
        is_active: dagInfo.is_active,
        unpauseResult: unpauseResult,
        message: unpauseResult?.unpaused ? 
          'DAG found and auto-unpaused successfully' : 
          'DAG found and status checked'
      });
      
    } catch (error) {
      console.error(`❌ Failed to check DAG status ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        found: false,
        message: error instanceof Error ? error.message : 'Failed to check DAG status'
      });
    }
  });

  // Trigger a DAG run (Airflow 3.x format) with cache invalidation
  app.post("/api/airflow/dags/:dagId/trigger", async (req, res) => {
    try {
      const { dagId } = req.params;
      const { conf = {} } = req.body;
      
      const triggerData = {
        conf: conf,
        dag_run_id: `manual_${Date.now()}`,
        logical_date: new Date().toISOString()
      };
      
      const result = await makeAuthenticatedRequest(`/dags/${dagId}/dagRuns`, {
        method: 'POST',
        body: JSON.stringify(triggerData)
      });
      
      // Invalidate related caches
      cache.invalidatePattern(dagId);
      cache.invalidatePattern('all_dags');
      
      res.json({
        success: true,
        message: `DAG ${dagId} triggered successfully`,
        dag_run: result
      });
    } catch (error) {
      console.error(`❌ Failed to trigger DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to trigger DAG'
      });
    }
  });

  // Enhanced pause/unpause endpoint with better feedback
  app.patch("/api/airflow/dags/:dagId", async (req, res) => {
    try {
      const { dagId } = req.params;
      const { is_paused } = req.body;
      
      console.log(`${is_paused ? 'Pausing' : 'Unpausing'} DAG: ${dagId}`);
      
      // First check if DAG exists
      const currentDag = await makeAuthenticatedRequest(`/dags/${dagId}`, {}, undefined, 0);
      if (!currentDag) {
        return res.status(404).json({
          success: false,
          message: `DAG ${dagId} not found in Airflow`
        });
      }
      
      // Check if already in desired state
      if (currentDag.is_paused === is_paused) {
        return res.json({
          success: true,
          message: `DAG ${dagId} is already ${is_paused ? 'paused' : 'unpaused'}`,
          dag: currentDag,
          changed: false
        });
      }
      
      // Apply the change
      const result = await makeAuthenticatedRequest(`/dags/${dagId}`, {
        method: 'PATCH',
        body: JSON.stringify({ is_paused })
      });
      
      // Invalidate related caches
      cache.invalidatePattern(dagId);
      cache.invalidatePattern('all_dags');
      
      res.json({
        success: true,
        message: `DAG ${dagId} ${is_paused ? 'paused' : 'unpaused'} successfully`,
        dag: result,
        changed: true,
        previous_state: currentDag.is_paused ? 'paused' : 'unpaused',
        new_state: is_paused ? 'paused' : 'unpaused'
      });
    } catch (error) {
      console.error(`Failed to update DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to update DAG'
      });
    }
  });

  // Get DAG source code
  app.get("/api/airflow/dags/:dagId/source", async (req, res) => {
    try {
      const { dagId } = req.params;
      const cacheKey = `dag_source_${dagId}`;
      
      console.log(`🔍 Fetching source code for DAG: ${dagId}`);
      
      // First get DAG details to find file location
      const dagDetails = await makeAuthenticatedRequest(`/dags/${dagId}`, {}, `dag_${dagId}`, 60);
      
      if (!dagDetails || !dagDetails.fileloc) {
        return res.status(404).json({
          success: false,
          message: "DAG file location not found"
        });
      }

      const filePath = dagDetails.fileloc;
      console.log(`📁 Reading file from: ${filePath}`);

      // Try to read the actual file
      let sourceCode = '';
      let readMethod = 'unknown';

      try {
        // Method 1: Try to read file directly (if accessible)
        if (filePath && (filePath.startsWith('/') || filePath.includes(':\\'))) {
          try {
            sourceCode = await fs.readFile(filePath, 'utf-8');
            readMethod = 'direct';
            console.log(`✅ Read source code directly from file: ${filePath}`);
          } catch (fileError) {
            console.log(`⚠️ Cannot read file directly: ${fileError instanceof Error ? fileError.message : 'Unknown error'}`);
          }
        }

        // Method 2: Try Airflow API endpoint for source (if available)
        if (!sourceCode) {
          try {
            const sourceResponse = await makeAuthenticatedRequest(`/dags/${dagId}/details`, {}, undefined, 0);
            if (sourceResponse && sourceResponse.source) {
              sourceCode = sourceResponse.source;
              readMethod = 'airflow_api';
              console.log(`✅ Read source code from Airflow API`);
            }
          } catch (apiError) {
            console.log(`⚠️ Airflow API source not available: ${apiError instanceof Error ? apiError.message : 'Unknown error'}`);
          }
        }

        // Method 3: Try reading from local dags directory
        if (!sourceCode) {
          const fileName = path.basename(filePath);
          const localPaths = [
            path.join('./dags', fileName),
            path.join(process.cwd(), 'dags', fileName),
            path.join('./input-files', fileName),
            path.join('./server/dags', fileName)
          ];

          for (const localPath of localPaths) {
            try {
              await fs.access(localPath);
              sourceCode = await fs.readFile(localPath, 'utf-8');
              readMethod = 'local';
              console.log(`✅ Read source code from local path: ${localPath}`);
              break;
            } catch (localError) {
              // Continue to next path
            }
          }
        }

        // Method 4: Fallback - create enhanced template based on DAG metadata
        if (!sourceCode) {
          console.log(`📝 Creating enhanced template for DAG: ${dagId}`);
          
          // Get additional DAG info for better template
          const [tasksResult] = await Promise.allSettled([
            makeAuthenticatedRequest(`/dags/${dagId}/tasks`, {}, `dag_tasks_${dagId}`, 300)
          ]);

          const tasks = tasksResult.status === 'fulfilled' ? (tasksResult.value?.tasks || []) : [];
          
          sourceCode = generateEnhancedTemplate(dagDetails, tasks);
          readMethod = 'template';
        }

      } catch (error) {
        console.error(`❌ Error reading source code: ${error}`);
        sourceCode = generateEnhancedTemplate(dagDetails, []);
        readMethod = 'fallback_template';
      }

      // Cache the result
      cache.set(cacheKey, { sourceCode, readMethod, filePath }, 300); // 5 minute cache

      res.json({
        success: true,
        sourceCode,
        filePath,
        readMethod,
        message: readMethod === 'direct' ? 'Actual source code' : 
                 readMethod === 'airflow_api' ? 'Source from Airflow API' :
                 readMethod === 'local' ? 'Source from local file' :
                 'Enhanced template based on DAG metadata'
      });

    } catch (error) {
      console.error(`❌ Failed to fetch source code for ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch source code'
      });
    }
  });

  // Get DAG runs for a specific DAG with caching
  app.get("/api/airflow/dags/:dagId/runs", async (req, res) => {
    try {
      const { dagId } = req.params;
      const { limit = 20, offset = 0 } = req.query;
      const cacheKey = `dag_runs_${dagId}_${limit}_${offset}`;
      
      // console.log(`🔄 Fetching DAG runs for: ${dagId}`);
      
      const runs = await fetchDagRunsCompatible(dagId, Number(limit), Number(offset));
      
      // Cache the result
      cache.set(cacheKey, runs, 30);
      
      res.json({
        runs: runs.dag_runs || [],
        total: runs.total_entries || 0,
        success: true
      });
    } catch (error) {
      console.error(`Failed to fetch runs for DAG ${req.params.dagId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch DAG runs'
      });
    }
  });

  // Get task instances for a DAG run
  app.get("/api/airflow/dags/:dagId/runs/:runId/tasks", async (req, res) => {
    try {
      const { dagId, runId } = req.params;
      const cacheKey = `task_instances_${dagId}_${runId}`;
      
      const taskInstances = await makeAuthenticatedRequest(
        `/dags/${dagId}/dagRuns/${runId}/taskInstances`,
        {},
        cacheKey,
        60 // 1 minute cache for task instances
      );
      
      res.json({
        task_instances: taskInstances.task_instances || [],
        success: true
      });
    } catch (error) {
      console.error(`Failed to fetch task instances for ${req.params.dagId}/${req.params.runId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch task instances'
      });
    }
  });

  // Get Airflow system information
  app.get("/api/airflow/info", async (req, res) => {
    try {
      const version = await makeAuthenticatedRequest('/version', {}, 'airflow_info', 300); // 5 minute cache
      
      res.json({
        version,
        config: {
          airflow_version: version.version || 'unknown',
          executor: 'unknown',
          api_version: AIRFLOW_CONFIG.apiVersion
        },
        success: true
      });
    } catch (error) {
      console.error('Failed to fetch Airflow info:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to fetch Airflow info'
      });
    }
  });

  // Delete a DAG run with cache invalidation
  app.delete("/api/airflow/dags/:dagId/runs/:runId", async (req, res) => {
    try {
      const { dagId, runId } = req.params;
      
      await makeAuthenticatedRequest(`/dags/${dagId}/dagRuns/${runId}`, {
        method: 'DELETE'
      });
      
      // Invalidate related caches
      cache.invalidatePattern(dagId);
      cache.invalidatePattern('all_dags');
      
      res.json({
        success: true,
        message: `DAG run ${runId} deleted successfully`
      });
    } catch (error) {
      console.error(`Failed to delete DAG run ${req.params.runId}:`, error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to delete DAG run'
      });
    }
  });

  // NEW: Force refresh Airflow DAGs endpoint
  app.post("/api/airflow/refresh-dags", async (req, res) => {
    try {
      console.log('🔄 Forcing Airflow DAGs refresh...');
      
      // Method 1: Try to trigger DAG file parsing via Airflow API
      try {
        const refreshResponse = await makeAuthenticatedRequest('/dagSources/refresh', {
          method: 'POST'
        });
        
        if (refreshResponse) {
          console.log('✅ Successfully triggered DAG refresh via API');
          
          // Clear our cache to force fresh data
          cache.invalidatePattern('all_dags');
          cache.invalidatePattern('dag_');
          
          return res.json({
            success: true,
            method: 'api',
            message: 'DAG refresh triggered successfully via Airflow API'
          });
        }
      } catch (apiError) {
        console.log('⚠️ DAG refresh API not available, trying alternative methods...');
      }
      
      // Method 2: Alternative - try to access the configuration endpoint that might trigger a refresh
      try {
        const configResponse = await makeAuthenticatedRequest('/config', {}, undefined, 0);
        if (configResponse) {
          console.log('✅ Accessed config endpoint to trigger potential refresh');
        }
      } catch (configError) {
        console.log('⚠️ Config endpoint access failed');
      }
      
      // Method 3: Clear all our caches and force re-fetch (this will definitely work)
      cache.clear();
      console.log('🧹 Cleared all caches to force fresh DAG data');
      
      // Force a fresh DAG list fetch
      const freshDags = await makeAuthenticatedRequest('/dags?limit=100', {}, undefined, 0);
      
      res.json({
        success: true,
        method: 'cache_refresh',
        message: 'Cache cleared and fresh DAG data fetched',
        dagCount: freshDags?.dags?.length || 0
      });
      
    } catch (error) {
      console.error('❌ Failed to refresh DAGs:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to refresh DAGs'
      });
    }
  });

  // NEW: Trigger Airflow file system refresh without container restart
  app.post("/api/airflow/trigger-file-scan", async (req, res) => {
    try {
      console.log('🔄 Triggering Airflow file system scan...');
      
      // Method 1: Try to trigger DAG processor refresh via API
      try {
        const refreshResponse = await makeAuthenticatedRequest('/dags/~/paused', {
          method: 'PATCH',
          body: JSON.stringify({ is_paused: false })
        });
        console.log('✅ Triggered DAG processor via bulk unpause');
      } catch (error) {
        console.log('⚠️ Bulk unpause method failed, trying alternatives...');
      }

      // Method 2: Try to access DAG source refresh endpoint
      try {
        const dagSourceResponse = await makeAuthenticatedRequest('/dagSources', {
          method: 'GET'
        });
        console.log('✅ Accessed DAG sources to trigger refresh');
      } catch (error) {
        console.log('⚠️ DAG sources access failed');
      }

      // Method 3: Force multiple rapid DAG list requests to trigger scanner
      for (let i = 0; i < 3; i++) {
        try {
          await makeAuthenticatedRequest('/dags?limit=100&offset=0', {}, undefined, 0);
          await new Promise(resolve => setTimeout(resolve, 500));
        } catch (error) {
          console.log(`Rapid request ${i + 1} failed`);
        }
      }

      // Clear all caches to force fresh data
      cache.clear();
      console.log('🧹 Cleared all caches');

      res.json({
        success: true,
        message: 'File scan triggered successfully',
        methods: ['dag_processor_refresh', 'cache_clear', 'rapid_requests']
      });

    } catch (error) {
      console.error('❌ Failed to trigger file scan:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to trigger file scan'
      });
    }
  });

  // Optional: Helper endpoint for container operations
  app.post("/api/airflow/restart-scheduler", async (req, res) => {
    try {
      console.log('🔄 Attempting to restart Airflow scheduler...');
      
      // This is a placeholder - you would need to implement actual container restart logic
      // based on your Docker setup. For now, we'll just clear caches and suggest manual restart
      
      cache.clear();
      
      res.json({
        success: true,
        message: 'Cache cleared. Please restart Airflow container manually using: docker-compose restart airflow-scheduler',
        suggestion: {
          command: 'docker-compose restart airflow-scheduler',
          alternative: 'docker restart <airflow-container-name>'
        }
      });
      
    } catch (error) {
      console.error('❌ Scheduler restart helper failed:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to restart scheduler'
      });
    }
  });

  // Verify file exists endpoint
  app.post("/api/verify-file-exists", async (req, res) => {
    try {
      const { filePath } = req.body;
      
      if (!filePath) {
        return res.status(400).json({ 
          success: false,
          message: "filePath is required" 
        });
      }
      
      try {
        const stats = await fs.stat(filePath);
        res.json({
          success: true,
          exists: true,
          fileSize: stats.size,
          lastModified: stats.mtime,
          filePath: filePath
        });
      } catch (error) {
        res.json({
          success: true,
          exists: false,
          filePath: filePath,
          error: error instanceof Error ? error.message : 'File not found'
        });
      }
      
    } catch (error) {
      console.error('File verification error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to verify file'
      });
    }
  });

  // Debug uploads endpoint
  app.get("/api/debug-uploads", async (req, res) => {
    try {
      const uploadDirs = ['./uploads', './input-files', './dags', './data'];
      const results = [];
      
      for (const dir of uploadDirs) {
        try {
          const files = await fs.readdir(dir);
          const stats = await Promise.all(
            files.map(async file => {
              const filePath = path.join(dir, file);
              const stat = await fs.stat(filePath);
              return {
                name: file,
                size: stat.size,
                modified: stat.mtime,
                isDirectory: stat.isDirectory()
              };
            })
          );
          
          results.push({
            directory: dir,
            exists: true,
            files: stats
          });
        } catch (error) {
          results.push({
            directory: dir,
            exists: false,
            error: error instanceof Error ? error.message : 'Access denied'
          });
        }
      }
      
      res.json({
        success: true,
        uploadDirectories: results,
        currentWorkingDirectory: process.cwd()
      });
      
    } catch (error) {
      console.error('Debug uploads error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to debug uploads'
      });
    }
  });

  // Register chatbot routes
  registerChatbotRoutes(app);

  // Register incoming JSON routes
  await registerIncomingJsonRoutes(app);

  // Register metrics routes
  app.use('/api/metrics', metricsRoutes);
  
  // Register IA metrics routes (for InfoArchive script execution data)
  app.use('/api/ia-metrics', iaMetricsRoutes);

  // XML File Download Endpoints for Step 3: Download IA Schema
  // Check if XML files exist for a given CSV file OR list all available XML files
  app.get("/api/xml-files/check/:fileName", async (req, res) => {
    try {
      const { fileName } = req.params;
      const { mode, all } = req.query; // 'related' for CSV-related files, 'all' for all XML files, 'all' param returns all files
      
      console.log(`🔍 Checking for XML files - Mode: ${mode || 'related'}, File: ${fileName}, Return All: ${all || 'false'}`);
      console.log(`🔧 Raw Query Parameters:`, req.query);
      console.log(`🔧 Parsed 'all' parameter: ${JSON.stringify(all)} (type: ${typeof all})`);
      
      // Use unified configuration system with deployment mode awareness
      const serverConfig = getUnifiedServerConfig();
      const deploymentMode = serverConfig.deploymentMode;
      const isLocalMode = deploymentMode === 'local';
      
      let incomingCsvDir = serverConfig.paths.incomingCsvDir;
      let processedCsvDir = serverConfig.paths.processedCsvDir;
      
      console.log(`🔧 Operating in ${deploymentMode} mode`);
      console.log(`📁 Raw incoming path: ${incomingCsvDir}`);
      console.log(`📁 Raw processed path: ${processedCsvDir}`);
      
      // Format paths based on deployment mode
      let formattedIncomingDir = incomingCsvDir;
      let formattedProcessedDir = processedCsvDir;
      
      if (!isLocalMode) {
        // Network mode - clean up excessive escaping and ensure UNC format
        formattedIncomingDir = incomingCsvDir.replace(/\\\\\\\\/g, '\\\\');
        formattedProcessedDir = processedCsvDir.replace(/\\\\\\\\/g, '\\\\');
        
        // Ensure UNC format for network paths
        if (!formattedIncomingDir.startsWith('\\\\') && formattedIncomingDir.includes('10.73.88.101')) {
          formattedIncomingDir = '\\\\' + formattedIncomingDir.replace(/^\\+/, '');
        }
        if (!formattedProcessedDir.startsWith('\\\\') && formattedProcessedDir.includes('10.73.88.101')) {
          formattedProcessedDir = '\\\\' + formattedProcessedDir.replace(/^\\+/, '');
        }
      }
      // For local mode, use paths as-is (no UNC formatting needed)
      
      console.log(`📂 Searching in directories (${deploymentMode} mode):`);
      console.log(`   - PRIMARY: Processed CSV: ${formattedProcessedDir}`);
      console.log(`   - SECONDARY: Incoming CSV: ${formattedIncomingDir}`);
      
      const foundFiles = [];
      
      // PRIORITIZE .ENV CONFIGURED PATHS (Airflow directories)
      const searchDirs = [
        { path: formattedProcessedDir, label: 'processed', priority: 1, source: 'env-config' },
        { path: formattedIncomingDir, label: 'incoming', priority: 2, source: 'env-config' }
      ];
      
      // Only add project folder fallbacks if .env paths are not accessible
      // This ensures we prioritize the actual Airflow directories specified in .env
      console.log(`🎯 PRIMARY SEARCH: Using .env configured Airflow paths only`);
      console.log(`   1️⃣ ${formattedProcessedDir} (processedcsv - where generated XML should be)`);
      console.log(`   2️⃣ ${formattedIncomingDir} (incomingcsv - secondary location)`);
      
      // Sort directories by priority (.env configured paths first)
      searchDirs.sort((a, b) => a.priority - b.priority);
      
      // Determine what XML files to look for
      let xmlFilesToSearch = [];
      
      if (mode === 'all' || !fileName || fileName === 'all') {
        // Mode: Find ALL XML files in the directories
        console.log('🔍 Searching for ALL XML files in directories');
        
        for (const dir of searchDirs) {
          console.log(`🔍 Scanning ${dir.label} directory: ${dir.path}`);
          try {
            // Check if directory exists first
            await fs.access(dir.path);
            
            // Read all files in directory and filter for XML files
            const allFiles = await fs.readdir(dir.path);
            const xmlFiles = allFiles.filter(file => file.toLowerCase().endsWith('.xml'));
            
            console.log(`📁 Found ${xmlFiles.length} XML files in ${dir.label}: ${xmlFiles.join(', ')}`);
            
            for (const xmlFile of xmlFiles) {
              const xmlPath = path.join(dir.path, xmlFile);
              try {
                const stats = await fs.stat(xmlPath);
                if (stats.isFile()) {
                  foundFiles.push({
                    fileName: xmlFile,
                    path: xmlPath,
                    size: stats.size,
                    modified: stats.mtime,
                    directory: dir.label,
                    deploymentMode: deploymentMode
                  });
                  console.log(`✅ Added XML file: ${xmlFile} from ${dir.label} directory`);
                }
              } catch (error) {
                console.log(`❌ Error reading XML file stats: ${xmlPath}`);
              }
            }
          } catch (dirError) {
            console.log(`❌ .env configured directory not accessible: ${dir.path} - ${dirError instanceof Error ? dirError.message : 'Unknown error'}`);
            
            // Only use project folder fallback if BOTH .env directories fail completely
            if (dir.label === 'processed' && foundFiles.length === 0) {
              console.log(`🔄 .env processedcsv directory failed, trying project folder as emergency fallback...`);
              
              const emergencyFallbackDirs = [
                { path: path.join(process.cwd(), 'data', 'processedcsv'), label: 'emergency-processed-fallback' },
                { path: path.join(process.cwd(), 'data', 'incomingcsv'), label: 'emergency-incoming-fallback' },
                { path: path.join(process.cwd(), 'input-files'), label: 'emergency-input-files-fallback' }
              ];
              
              for (const emergencyDir of emergencyFallbackDirs) {
                try {
                  await fs.access(emergencyDir.path);
                  console.log(`⚠️ EMERGENCY FALLBACK: ${emergencyDir.path}`);
                  
                  const fallbackFiles = await fs.readdir(emergencyDir.path);
                  const fallbackXmlFiles = fallbackFiles.filter(file => file.toLowerCase().endsWith('.xml'));
                  
                  console.log(`📁 Found ${fallbackXmlFiles.length} XML files in emergency fallback ${emergencyDir.label}: ${fallbackXmlFiles.join(', ')}`);
                  
                  for (const xmlFile of fallbackXmlFiles) {
                    const xmlPath = path.join(emergencyDir.path, xmlFile);
                    try {
                      const stats = await fs.stat(xmlPath);
                      if (stats.isFile()) {
                        foundFiles.push({
                          fileName: xmlFile,
                          path: xmlPath,
                          size: stats.size,
                          modified: stats.mtime,
                          directory: emergencyDir.label,
                          deploymentMode: 'emergency-fallback'
                        });
                        console.log(`🆘 EMERGENCY: Found XML file in project fallback: ${xmlFile} in ${emergencyDir.label}`);
                      }
                    } catch (localError) {
                      console.log(`❌ Error reading emergency fallback XML file: ${xmlPath}`);
                    }
                  }
                  
                  // Only use the first working emergency fallback directory
                  if (fallbackXmlFiles.length > 0) {
                    console.log(`🚨 Using emergency fallback - recommend checking .env configuration`);
                    break;
                  }
                } catch (localDirError) {
                  console.log(`❌ Emergency fallback directory not accessible: ${emergencyDir.path}`);
                }
              }
            }
          }
        }
      } else {
        // Mode: Find XML files related to specific CSV file (original logic)
        console.log(`🔍 Searching for XML files related to CSV: ${fileName}`);
        
        // Look for XML files related to the CSV file
        const baseName = fileName.replace(/\.[^.]+$/, ''); // Remove file extension
        xmlFilesToSearch = [
          `${baseName}.xml`,
          `${baseName}_schema.xml`,
          `${baseName}_transformed.xml`,
          `${baseName}_dbschema.xml`,
          `dbschema.xml` // Common name for XML schema files
        ];
        
        for (const dir of searchDirs) {
          console.log(`🔍 Searching in ${dir.label} directory: ${dir.path}`);
          try {
            // Check if directory exists first
            await fs.access(dir.path);
            
            for (const xmlFile of xmlFilesToSearch) {
              const xmlPath = path.join(dir.path, xmlFile);
              try {
                const stats = await fs.stat(xmlPath);
                if (stats.isFile()) {
                  foundFiles.push({
                    fileName: xmlFile,
                    path: xmlPath,
                    size: stats.size,
                    modified: stats.mtime,
                    directory: dir.label,
                    deploymentMode: deploymentMode
                  });
                  console.log(`✅ Found XML file: ${xmlFile} in ${dir.label} directory`);
                }
              } catch (error) {
                // File doesn't exist, continue
                console.log(`❌ File not found: ${xmlPath}`);
              }
            }
          } catch (dirError) {
            console.log(`❌ Directory not accessible: ${dir.path} - ${dirError instanceof Error ? dirError.message : 'Unknown error'}`);
            
            // For network mode, try local fallback if network directories fail
            if (!isLocalMode && (dir.label === 'incoming' || dir.label === 'processed')) {
              const localFallbackDirs = [
                { path: path.join(process.cwd(), 'data', 'incomingcsv'), label: 'local-incoming-fallback' },
                { path: path.join(process.cwd(), 'data', 'processedcsv'), label: 'local-processed-fallback' },
                { path: path.join(process.cwd(), 'input-files'), label: 'input-files-fallback' }
              ];
              
              for (const localDir of localFallbackDirs) {
                try {
                  await fs.access(localDir.path);
                  console.log(`⚠️ Trying local fallback: ${localDir.path}`);
                  
                  for (const xmlFile of xmlFilesToSearch) {
                    const xmlPath = path.join(localDir.path, xmlFile);
                    try {
                      const stats = await fs.stat(xmlPath);
                      if (stats.isFile()) {
                        foundFiles.push({
                          fileName: xmlFile,
                          path: xmlPath,
                          size: stats.size,
                          modified: stats.mtime,
                          directory: localDir.label,
                          deploymentMode: 'fallback'
                        });
                        console.log(`✅ Found XML file in fallback: ${xmlFile} in ${localDir.label}`);
                      }
                    } catch (localError) {
                      // Continue to next file
                    }
                  }
                } catch (localDirError) {
                  // Continue to next fallback directory
                }
              }
            }
          }
        }
      }
      
      // Filter to get only the latest XML file if multiple exist (unless 'all' parameter is true)
      let finalFiles = foundFiles;
      const shouldReturnAll = String(all).toLowerCase() === 'true'; // Handle both string and boolean values
      
      if (foundFiles.length > 1 && !shouldReturnAll) {
        console.log(`📅 Multiple XML files found (${foundFiles.length}), selecting latest by timestamp (all=${all}, shouldReturnAll=${shouldReturnAll})`);
        
        // Sort by modified date (newest first) and take only the first one
        foundFiles.sort((a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime());
        finalFiles = [foundFiles[0]]; // Keep only the latest file
        
        console.log(`✅ Selected latest XML file: ${finalFiles[0].fileName} (modified: ${new Date(finalFiles[0].modified).toLocaleString()})`);
        
        // Log the files that were filtered out
        const filteredOut = foundFiles.slice(1);
        if (filteredOut.length > 0) {
          console.log(`📋 Filtered out older XML files:`);
          filteredOut.forEach(file => {
            console.log(`   - ${file.fileName} (modified: ${new Date(file.modified).toLocaleString()})`);
          });
        }
      } else if (shouldReturnAll) {
        console.log(`✅ Returning all ${foundFiles.length} XML files as requested (all=${all})`);
        // Sort by modification date (newest first) but return all files
        finalFiles.sort((a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime());
      }
      
      res.json({
        success: true,
        files: finalFiles,
        totalFound: foundFiles.length,
        selectedLatest: foundFiles.length > 1 && !shouldReturnAll,
        returnedAll: shouldReturnAll,
        mode: mode || 'related',
        deploymentMode: deploymentMode,
        searchedDirectories: searchDirs.map(d => ({ label: d.label, path: d.path, source: d.source || 'unknown' })),
        message: finalFiles.length > 0 ? 
          (shouldReturnAll ? 
            `Found and returned all ${finalFiles.length} XML file(s) from .env configured paths in ${deploymentMode} mode` :
            foundFiles.length > 1 ? 
              `Found ${foundFiles.length} XML file(s), selected latest: ${finalFiles[0].fileName} from .env configured paths in ${deploymentMode} mode` :
              `Found ${finalFiles.length} XML file(s) from .env configured paths in ${deploymentMode} mode`) : 
          `No XML files found in .env configured paths for ${deploymentMode} mode`
      });
    } catch (error) {
      console.error('❌ Error checking XML files:', error);
      res.status(500).json({
        success: false,
        message: 'Error checking XML files',
        error: error instanceof Error ? error.message : 'Unknown error',
        deploymentMode: getUnifiedServerConfig().deploymentMode
      });
    }
  });

  // NEW: Get all available XML files endpoint (doesn't require CSV file name)
  app.get("/api/xml-files/list", async (req, res) => {
    try {
      console.log(`🔍 Listing all available XML files`);
      
      // Use unified configuration system with deployment mode awareness
      const serverConfig = getUnifiedServerConfig();
      const deploymentMode = serverConfig.deploymentMode;
      const isLocalMode = deploymentMode === 'local';
      
      let incomingCsvDir = serverConfig.paths.incomingCsvDir;
      let processedCsvDir = serverConfig.paths.processedCsvDir;
      
      console.log(`🔧 Operating in ${deploymentMode} mode`);
      console.log(`📁 Raw incoming path: ${incomingCsvDir}`);
      console.log(`📁 Raw processed path: ${processedCsvDir}`);
      
      // Format paths based on deployment mode
      let formattedIncomingDir = incomingCsvDir;
      let formattedProcessedDir = processedCsvDir;
      
      if (!isLocalMode) {
        // Network mode - clean up excessive escaping and ensure UNC format
        formattedIncomingDir = incomingCsvDir.replace(/\\\\\\\\/g, '\\\\');
        formattedProcessedDir = processedCsvDir.replace(/\\\\\\\\/g, '\\\\');
        
        // Ensure UNC format for network paths
        if (!formattedIncomingDir.startsWith('\\\\') && formattedIncomingDir.includes('10.73.88.101')) {
          formattedIncomingDir = '\\\\' + formattedIncomingDir.replace(/^\\+/, '');
        }
        if (!formattedProcessedDir.startsWith('\\\\') && formattedProcessedDir.includes('10.73.88.101')) {
          formattedProcessedDir = '\\\\' + formattedProcessedDir.replace(/^\\+/, '');
        }
      }
      // For local mode, use paths as-is (no UNC formatting needed)
      
      console.log(`📂 Searching for ALL XML files in directories (${deploymentMode} mode):`);
      console.log(`   - Incoming: ${formattedIncomingDir}`);
      console.log(`   - Processed: ${formattedProcessedDir}`);
      
      const foundFiles = [];
      const searchDirs = [
        { path: formattedIncomingDir, label: 'incoming' },
        { path: formattedProcessedDir, label: 'processed' }
      ];
      
      // Add local fallback directories for local mode
      if (isLocalMode) {
        searchDirs.push(
          { path: path.join(process.cwd(), 'data', 'incomingcsv'), label: 'local-incoming' },
          { path: path.join(process.cwd(), 'data', 'processedcsv'), label: 'local-processed' },
          { path: path.join(process.cwd(), 'input-files'), label: 'input-files' }
        );
      }
      
      // Scan all directories for XML files
      for (const dir of searchDirs) {
        console.log(`🔍 Scanning ${dir.label} directory: ${dir.path}`);
        try {
          // Check if directory exists first
          await fs.access(dir.path);
          
          // Read all files in directory and filter for XML files
          const allFiles = await fs.readdir(dir.path);
          const xmlFiles = allFiles.filter(file => file.toLowerCase().endsWith('.xml'));
          
          console.log(`📁 Found ${xmlFiles.length} XML files in ${dir.label}: ${xmlFiles.join(', ')}`);
          
          for (const xmlFile of xmlFiles) {
            const xmlPath = path.join(dir.path, xmlFile);
            try {
              const stats = await fs.stat(xmlPath);
              if (stats.isFile()) {
                foundFiles.push({
                  fileName: xmlFile,
                  path: xmlPath,
                  size: stats.size,
                  modified: stats.mtime,
                  directory: dir.label,
                  deploymentMode: deploymentMode,
                  fullPath: xmlPath
                });
                console.log(`✅ Added XML file: ${xmlFile} from ${dir.label} directory`);
              }
            } catch (error) {
              console.log(`❌ Error reading XML file stats: ${xmlPath}`);
            }
          }
        } catch (dirError) {
          console.log(`❌ Directory not accessible: ${dir.path} - ${dirError instanceof Error ? dirError.message : 'Unknown error'}`);
          
          // For network mode, try local fallback if network directories fail
          if (!isLocalMode && (dir.label === 'incoming' || dir.label === 'processed')) {
            const localFallbackDirs = [
              { path: path.join(process.cwd(), 'data', 'incomingcsv'), label: 'local-incoming-fallback' },
              { path: path.join(process.cwd(), 'data', 'processedcsv'), label: 'local-processed-fallback' },
              { path: path.join(process.cwd(), 'input-files'), label: 'input-files-fallback' }
            ];
            
            for (const localDir of localFallbackDirs) {
              try {
                await fs.access(localDir.path);
                console.log(`⚠️ Trying local fallback: ${localDir.path}`);
                
                const fallbackFiles = await fs.readdir(localDir.path);
                const fallbackXmlFiles = fallbackFiles.filter(file => file.toLowerCase().endsWith('.xml'));
                
                for (const xmlFile of fallbackXmlFiles) {
                  const xmlPath = path.join(localDir.path, xmlFile);
                  try {
                    const stats = await fs.stat(xmlPath);
                    if (stats.isFile()) {
                      foundFiles.push({
                        fileName: xmlFile,
                        path: xmlPath,
                        size: stats.size,
                        modified: stats.mtime,
                        directory: localDir.label,
                        deploymentMode: 'fallback',
                        fullPath: xmlPath
                      });
                      console.log(`✅ Found XML file in fallback: ${xmlFile} in ${localDir.label}`);
                    }
                  } catch (localError) {
                    // Continue to next file
                  }
                }
              } catch (localDirError) {
                // Continue to next fallback directory
              }
            }
          }
        }
      }
      
      // Sort files by modified date (newest first)
      foundFiles.sort((a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime());
      
      // Filter to get only the latest XML file if multiple exist
      let finalFiles = foundFiles;
      if (foundFiles.length > 1) {
        console.log(`📅 Multiple XML files found (${foundFiles.length}), selecting latest by timestamp`);
        
        // Keep only the first file (latest by timestamp)
        finalFiles = [foundFiles[0]];
        
        console.log(`✅ Selected latest XML file: ${finalFiles[0].fileName} (modified: ${new Date(finalFiles[0].modified).toLocaleString()})`);
        
        // Log the files that were filtered out
        const filteredOut = foundFiles.slice(1);
        if (filteredOut.length > 0) {
          console.log(`📋 Filtered out older XML files:`);
          filteredOut.forEach(file => {
            console.log(`   - ${file.fileName} (modified: ${new Date(file.modified).toLocaleString()})`);
          });
        }
      }
      
      res.json({
        success: true,
        files: finalFiles,
        count: finalFiles.length,
        totalFound: foundFiles.length,
        selectedLatest: foundFiles.length > 1,
        deploymentMode: deploymentMode,
        searchedDirectories: searchDirs.map(d => ({ label: d.label, path: d.path })),
        message: finalFiles.length > 0 ? 
          (foundFiles.length > 1 ? 
            `Found ${foundFiles.length} XML file(s), selected latest: ${finalFiles[0].fileName} in ${deploymentMode} mode` :
            `Found ${finalFiles.length} XML file(s) in ${deploymentMode} mode`) : 
          `No XML files found in ${deploymentMode} mode`
      });
    } catch (error) {
      console.error('❌ Error listing XML files:', error);
      res.status(500).json({
        success: false,
        message: 'Error listing XML files',
        error: error instanceof Error ? error.message : 'Unknown error',
        deploymentMode: getUnifiedServerConfig().deploymentMode
      });
    }
  });

  // Download XML files
  app.get("/api/xml-files/download/:fileName", async (req, res) => {
    try {
      const { fileName } = req.params;
      
      console.log(`📥 Downloading XML file: ${fileName}`);
      
      // Use unified configuration system with deployment mode awareness
      const serverConfig = getUnifiedServerConfig();
      const deploymentMode = serverConfig.deploymentMode;
      const isLocalMode = deploymentMode === 'local';
      
      let incomingCsvDir = serverConfig.paths.incomingCsvDir;
      let processedCsvDir = serverConfig.paths.processedCsvDir;
      
      console.log(`🔧 Download operating in ${deploymentMode} mode`);
      console.log(`📁 Raw incoming path: ${incomingCsvDir}`);
      console.log(`📁 Raw processed path: ${processedCsvDir}`);
      
      // Format paths based on deployment mode
      let formattedIncomingDir = incomingCsvDir;
      let formattedProcessedDir = processedCsvDir;
      
      if (!isLocalMode) {
        // Network mode - clean up excessive escaping and ensure UNC format
        formattedIncomingDir = incomingCsvDir.replace(/\\\\\\\\/g, '\\\\');
        formattedProcessedDir = processedCsvDir.replace(/\\\\\\\\/g, '\\\\');
        
        // Ensure UNC format for network paths
        if (!formattedIncomingDir.startsWith('\\\\') && formattedIncomingDir.includes('10.73.88.101')) {
          formattedIncomingDir = '\\\\' + formattedIncomingDir.replace(/^\\+/, '');
        }
        if (!formattedProcessedDir.startsWith('\\\\') && formattedProcessedDir.includes('10.73.88.101')) {
          formattedProcessedDir = '\\\\' + formattedProcessedDir.replace(/^\\+/, '');
        }
      }
      // For local mode, use paths as-is
      
      console.log(`📂 Searching for download in directories (${deploymentMode} mode):`);
      console.log(`   - Incoming: ${formattedIncomingDir}`);
      console.log(`   - Processed: ${formattedProcessedDir}`);
      
      const searchDirs = [
        { path: formattedIncomingDir, label: 'incoming' },
        { path: formattedProcessedDir, label: 'processed' }
      ];
      
      // Add local fallback directories for local mode
      if (isLocalMode) {
        searchDirs.push(
          { path: path.join(process.cwd(), 'data', 'incomingcsv'), label: 'local-incoming' },
          { path: path.join(process.cwd(), 'data', 'processedcsv'), label: 'local-processed' },
          { path: path.join(process.cwd(), 'input-files'), label: 'input-files' }
        );
      }
      
      let xmlPath = '';
      let stats = null;
      let foundInDirectory = '';
      
      // Try to find the file in configured directories first
      for (const dir of searchDirs) {
        const testPath = path.join(dir.path, fileName);
        try {
          console.log(`🔍 Checking: ${testPath}`);
          const testStats = await fs.stat(testPath);
          if (testStats.isFile()) {
            xmlPath = testPath;
            stats = testStats;
            foundInDirectory = dir.label;
            console.log(`✅ Found XML file: ${fileName} in ${dir.label} directory`);
            break;
          }
        } catch (error) {
          console.log(`❌ File not found in ${dir.label}: ${testPath}`);
          continue;
        }
      }
      
      // For network mode, try local fallback if network directories failed
      if (!xmlPath && !isLocalMode) {
        console.log(`⚠️ Network mode: trying local fallback directories...`);
        const localFallbackDirs = [
          { path: path.join(process.cwd(), 'data', 'incomingcsv'), label: 'local-incoming-fallback' },
          { path: path.join(process.cwd(), 'data', 'processedcsv'), label: 'local-processed-fallback' },
          { path: path.join(process.cwd(), 'input-files'), label: 'input-files-fallback' }
        ];
        
        for (const localDir of localFallbackDirs) {
          const testPath = path.join(localDir.path, fileName);
          try {
            console.log(`🔍 Checking fallback: ${testPath}`);
            const testStats = await fs.stat(testPath);
            if (testStats.isFile()) {
              xmlPath = testPath;
              stats = testStats;
              foundInDirectory = localDir.label;
              console.log(`✅ Found XML file in fallback: ${fileName} in ${localDir.label}`);
              break;
            }
          } catch (error) {
            console.log(`❌ File not found in fallback ${localDir.label}: ${testPath}`);
            continue;
          }
        }
      }
      
      if (!xmlPath || !stats) {
        console.error(`❌ XML file not found: ${fileName}`);
        return res.status(404).json({
          success: false,
          message: `XML file not found: ${fileName}. Check if the DAG has completed successfully and generated the XML files.`,
          deploymentMode: deploymentMode,
          searchedDirectories: searchDirs.map(d => ({ label: d.label, path: d.path }))
        });
      }
      
      // Set headers for file download
      res.setHeader('Content-Type', 'application/xml');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', stats.size);
      
      // Stream the file
      console.log(`📤 Streaming XML file: ${xmlPath} (${stats.size} bytes) from ${foundInDirectory} in ${deploymentMode} mode`);
      const fileStream = await fs.readFile(xmlPath);
      res.send(fileStream);
      
    } catch (error) {
      console.error('❌ Error downloading XML file:', error);
      res.status(500).json({
        success: false,
        message: 'Error downloading XML file',
        error: error instanceof Error ? error.message : 'Unknown error',
        deploymentMode: getUnifiedServerConfig().deploymentMode
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to properly format UNC paths for Windows
const formatUNCPath = (path: string): string => {
  // If path is already a valid UNC path (starts with \\), return as is
  if (path.startsWith('\\\\')) {
    return path;
  }
  
  // If path matches a Windows drive letter (e.g., C:\ or D:\), return as is
  if (/^[a-zA-Z]:\\/.test(path)) {
    return path;
  }
  
  // Handle network paths that might start with a single backslash or without backslashes
  if (path.match(/^\\?[^\\]/) && path.includes('\\')) {
    // This handles cases like \10.73.88.101\data\incomingcsv
    // Ensure it starts with double backslashes
    return path.startsWith('\\') ? '\\' + path : '\\\\' + path;
  }
  
  // Handle IP-based network paths without backslashes
  if (path.match(/^\d+\.\d+\.\d+\.\d+/)) {
    return '\\\\' + path;
  }
  
  // Otherwise, return as is
  return path;
};