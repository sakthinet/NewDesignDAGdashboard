// server/airflow-setup.ts
// Utility to ensure directory structure exists for DAG Generator

import fs from 'fs/promises';
import path from 'path';

export interface LocalDirectories {
  uploadsDirectory: string;
  inputFilesDirectory: string;
  dagsDirectory: string;
  dataDirectory: string;
  tempDirectory: string;
}

export const DEFAULT_LOCAL_PATHS: LocalDirectories = {
  uploadsDirectory: './uploads',
  inputFilesDirectory: './input-files',
  dagsDirectory: './dags',
  dataDirectory: './data',
  tempDirectory: './temp'
};

/**
 * Ensures all required local directories exist for development
 */
export async function ensureLocalDirectories(directories: LocalDirectories = DEFAULT_LOCAL_PATHS): Promise<void> {
  console.log('🔧 Setting up local directory structure for DAG Generator...');
  
  const dirsToCreate = [
    { name: 'Uploads Directory', path: directories.uploadsDirectory, description: 'Temporary file uploads' },
    { name: 'Input Files Directory', path: directories.inputFilesDirectory, description: 'Processed CSV files' },
    { name: 'DAGs Directory', path: directories.dagsDirectory, description: 'Generated DAG Python scripts' },
    { name: 'Data Directory', path: directories.dataDirectory, description: 'CSV inputs and XML outputs' },
    { name: 'Temp Directory', path: directories.tempDirectory, description: 'Temporary processing files' }
  ];

  for (const dir of dirsToCreate) {
    try {
      await fs.mkdir(dir.path, { recursive: true });
      console.log(`✓ ${dir.name}: ${dir.path} (${dir.description})`);
    } catch (error) {
      console.error(`✗ Failed to create ${dir.name}: ${dir.path}`, error);
      throw error;
    }
  }
  
  console.log('✅ Local directory structure setup complete!');
}

/**
 * Validates that all required directories exist and are writable
 */
export async function validateLocalDirectories(directories: LocalDirectories = DEFAULT_LOCAL_PATHS): Promise<boolean> {
  console.log('🔍 Validating local directory structure...');
  
  const dirsToCheck = Object.entries(directories);
  let allValid = true;

  for (const [name, dirPath] of dirsToCheck) {
    try {
      // Check if directory exists
      await fs.access(dirPath);
      
      // Test write permissions by creating a test file
      const testFile = path.join(dirPath, '.write-test');
      await fs.writeFile(testFile, 'test');
      await fs.unlink(testFile);
      
      console.log(`✓ ${name}: ${dirPath} (accessible and writable)`);
    } catch (error) {
      console.error(`✗ ${name}: ${dirPath} (not accessible or writable)`);
      allValid = false;
    }
  }
  
  return allValid;
}

/**
 * Gets information about the local directories
 */
export async function getDirectoryInfo(directories: LocalDirectories = DEFAULT_LOCAL_PATHS) {
  const info = {
    uploads: { path: directories.uploadsDirectory, exists: false, fileCount: 0 },
    inputFiles: { path: directories.inputFilesDirectory, exists: false, fileCount: 0 },
    dags: { path: directories.dagsDirectory, exists: false, fileCount: 0 },
    data: { path: directories.dataDirectory, exists: false, fileCount: 0 },
    temp: { path: directories.tempDirectory, exists: false, fileCount: 0 }
  };

  // Check each directory
  for (const [key, dirInfo] of Object.entries(info)) {
    try {
      await fs.access(dirInfo.path);
      dirInfo.exists = true;
      const files = await fs.readdir(dirInfo.path);
      
      // Filter for relevant files based on directory type
      if (key === 'dags') {
        dirInfo.fileCount = files.filter(f => f.endsWith('.py')).length;
      } else if (key === 'inputFiles' || key === 'data') {
        dirInfo.fileCount = files.filter(f => f.endsWith('.csv') || f.endsWith('.xml')).length;
      } else {
        dirInfo.fileCount = files.length;
      }
    } catch (error) {
      // Directory doesn't exist
    }
  }

  return info;
}

/**
 * Creates a README file with setup instructions
 */
export async function createSetupReadme(): Promise<void> {
  const readmeContent = `# Airflow DAG Generator - Local Development Setup

## Directory Structure

This application uses the following local directories for development:

### Local Directories:
- \`./uploads/\` - Temporary file uploads from the web interface
- \`./input-files/\` - Processed CSV files ready for use
- \`./dags/\` - Generated DAG Python scripts
- \`./data/\` - CSV input files and XML output files
- \`./temp/\` - Temporary files for testing and validation

### Production Airflow Directories (Windows):
- \`C:\\Docker\\airflow3x2\\dags\\\` - Copy generated DAG scripts here
- \`C:\\Docker\\airflow3x2\\data\\\` - Copy CSV files here for processing

## Usage Instructions:

1. **Upload CSV**: Use the web interface to upload your CSV file
2. **Configure DAG**: Set up your DAG parameters and file paths
3. **Generate Script**: The DAG script is automatically generated and saved to \`./dags/\`
4. **Deploy**: Copy the generated script to your Airflow DAGs directory
5. **Process Data**: Copy your CSV files to the Airflow data directory

## File Workflow:

1. CSV uploaded → \`./uploads/\` → \`./input-files/\` → \`./data/\` → \`C:\\Docker\\airflow3x2\\data\\\`
2. DAG generated → \`./dags/\` → \`C:\\Docker\\airflow3x2\\dags\\\`
3. XML output ← \`C:\\Docker\\airflow3x2\\data\\\`

## Notes:

- In development, Windows paths are automatically converted to local paths
- Files are saved locally and need to be manually copied to production Airflow directories
- The application handles both Linux and Windows path formats
`;

  try {
    await fs.writeFile('./project_utils/README-SETUP.md', readmeContent);
    console.log('📝 Setup README created: ./project_utils/README-SETUP.md');
  } catch (error) {
    console.error('Failed to create setup README:', error);
  }
}

/**
 * Initialize local setup for DAG Generator
 */
export async function initializeAirflowSetup(): Promise<void> {
  console.log('🚀 Initializing Airflow DAG Generator local setup...');
  
  try {
    // Ensure directories exist
    await ensureLocalDirectories();
    
    // Validate they're accessible
    const isValid = await validateLocalDirectories();
    
    if (isValid) {
      console.log('✅ Local setup completed successfully!');
      
      // Log directory info
      const info = await getDirectoryInfo();
      console.log('📊 Directory Status:');
      console.log(`   Uploads: ${info.uploads.fileCount} files in ${info.uploads.path}`);
      console.log(`   Input Files: ${info.inputFiles.fileCount} files in ${info.inputFiles.path}`);
      console.log(`   DAGs: ${info.dags.fileCount} Python files in ${info.dags.path}`);
      console.log(`   Data: ${info.data.fileCount} files in ${info.data.path}`);
      console.log(`   Temp: ${info.temp.fileCount} files in ${info.temp.path}`);
      
      // Create setup instructions
      await createSetupReadme();
      
      console.log('💡 Tip: Check project_utils/README-SETUP.md for detailed setup instructions');
    } else {
      console.error('❌ Local setup validation failed. Some directories may not be accessible.');
    }
  } catch (error) {
    console.error('❌ Failed to initialize local setup:', error);
    throw error;
  }
}

/**
 * Clean up temporary files
 */
export async function cleanupTempFiles(): Promise<void> {
  const directories = DEFAULT_LOCAL_PATHS;
  
  try {
    // Clean uploads directory (files older than 1 hour)
    const uploadsDir = directories.uploadsDirectory;
    const uploadFiles = await fs.readdir(uploadsDir);
    const now = Date.now();
    
    for (const file of uploadFiles) {
      if (file.startsWith('.')) continue; // Skip hidden files
      
      const filePath = path.join(uploadsDir, file);
      const stats = await fs.stat(filePath);
      const age = now - stats.mtime.getTime();
      
      // Delete files older than 1 hour (3600000 ms)
      if (age > 3600000) {
        await fs.unlink(filePath);
        console.log(`🗑️ Cleaned up old upload: ${file}`);
      }
    }
    
    // Clean temp directory
    const tempDir = directories.tempDirectory;
    const tempFiles = await fs.readdir(tempDir);
    
    for (const file of tempFiles) {
      if (file.startsWith('.')) continue; // Skip hidden files
      
      const filePath = path.join(tempDir, file);
      await fs.unlink(filePath);
      console.log(`🗑️ Cleaned up temp file: ${file}`);
    }
    
  } catch (error) {
    console.error('Cleanup error:', error);
  }
}