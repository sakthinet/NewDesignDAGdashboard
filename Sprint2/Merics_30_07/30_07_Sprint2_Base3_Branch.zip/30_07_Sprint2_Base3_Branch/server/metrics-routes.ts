import { Router } from 'express';
import { Pool } from 'pg';
import dotenv from 'dotenv';
import path from 'path';
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const router = Router();

function getPostgresConfig() {
  // Set defaults in case environment variables are not loaded
  const mode = process.env.DEPLOYMENT_MODE || 'local';
  console.log(`Using deployment mode: ${mode}`);
  
  if (mode === 'local') {
    // Default values for local
    const host = process.env.LOCAL_POSTGRES_HOST || 'localhost';
    const port = Number(process.env.LOCAL_POSTGRES_PORT || 5432);
    const database = process.env.LOCAL_POSTGRES_DATABASE || 'RND';
    const user = process.env.LOCAL_POSTGRES_USER || 'postgres';
    const password = process.env.LOCAL_POSTGRES_PASSWORD || 'admin@12345';
    const ssl = process.env.LOCAL_POSTGRES_SSL === 'true';
    
    console.log(`Connecting to LOCAL PostgreSQL: ${host}:${port} (SSL: ${ssl})`);
    
    return {
      host,
      port,
      database,
      user,
      password,
      ssl,
      // Connection pool settings for better reliability
      max: Number(process.env.POSTGRES_MAX_CONNECTIONS || 10),
      idleTimeoutMillis: Number(process.env.POSTGRES_IDLE_TIMEOUT || 30000),
      connectionTimeoutMillis: Number(process.env.POSTGRES_CONNECTION_TIMEOUT || 5000),
      // Query timeout
      query_timeout: Number(process.env.METRICS_QUERY_TIMEOUT || 30000),
    };
  } else {
    // Default values for network
    const host = process.env.NETWORK_POSTGRES_HOST || '10.73.88.101';
    const port = Number(process.env.NETWORK_POSTGRES_PORT || 5432);
    const database = process.env.NETWORK_POSTGRES_DATABASE || 'RND';
    const user = process.env.NETWORK_POSTGRES_USER || 'postgres';
    const password = process.env.NETWORK_POSTGRES_PASSWORD || 'postgres';
    const ssl = process.env.NETWORK_POSTGRES_SSL === 'true';
    
    console.log(`Connecting to NETWORK PostgreSQL: ${host}:${port} (SSL: ${ssl})`);
    
    return {
      host,
      port,
      database,
      user,
      password,
      ssl,
      // Enhanced connection pool settings for network reliability
      max: Number(process.env.POSTGRES_MAX_CONNECTIONS || 20), // More connections for network
      idleTimeoutMillis: Number(process.env.POSTGRES_IDLE_TIMEOUT || 30000),
      connectionTimeoutMillis: Number(process.env.POSTGRES_CONNECTION_TIMEOUT || 10000), // Longer timeout for network
      // Query timeout
      query_timeout: Number(process.env.METRICS_QUERY_TIMEOUT || 30000),
      // Network-specific settings
      keepAlive: true,
      keepAliveInitialDelayMillis: 10000,
      // Retry settings for network resilience
      application_name: 'InfoArchive_Metrics_Dashboard',
    };
  }
}

// Helper function to provide error suggestions
function getErrorSuggestions(errorType: string): string[] {
  switch (errorType) {
    case 'connection_error':
      return [
        'Check if PostgreSQL server is running on the network',
        'Verify network connectivity to the database host',
        'Ensure firewall allows database connections'
      ];
    case 'timeout_error':
      return [
        'Try increasing the query timeout value',
        'Check network latency to the database',
        'Consider optimizing the query or adding indexes'
      ];
    case 'auth_error':
      return [
        'Verify PostgreSQL username and password',
        'Check if user has access to the database',
        'Ensure user has SELECT permissions on dag_run_metrics table'
      ];
    default:
      return [
        'Check PostgreSQL server logs for more details',
        'Verify database configuration in .env file',
        'Test database connection manually'
      ];
  }
}

const pool = new Pool(getPostgresConfig());

router.get('/dag-runs', async (req, res) => {
  try {
    console.log(`📊 Executing query on public.dag_run_metrics table - ${new Date().toISOString()}`);
    
    // Execute the exact SQL query with lowercase aliases to match frontend expectations
    // Order by id ASC to show records in sequential order
    const query = `
      SELECT 
        id, 
        dag_id as processname, 
        run_id as instanceid, 
        execution_date, 
        records_processed, 
        records_failed
      FROM public.dag_run_metrics
      ORDER BY id ASC
    `;
    
    // Execute query with proper typing
    const result = await pool.query(query);
    
    console.log(`✅ Successfully fetched ${result.rows.length} records from dag_run_metrics table at ${new Date().toISOString()}`);
    
    res.json({ 
      success: true, 
      data: result.rows,
      timestamp: new Date().toISOString(),
      count: result.rows.length,
      deploymentMode: process.env.DEPLOYMENT_MODE || 'local'
    });
  } catch (error) {
    console.error('❌ PostgreSQL query failed:', error);
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    
    // Enhanced error handling for network issues
    let errorType = 'database_error';
    if (errMsg.includes('timeout')) {
      errorType = 'timeout_error';
    } else if (errMsg.includes('ECONNREFUSED') || errMsg.includes('ENOTFOUND')) {
      errorType = 'connection_error';
    } else if (errMsg.includes('authentication')) {
      errorType = 'auth_error';
    }
    
    res.status(500).json({ 
      success: false, 
      error: errMsg,
      errorType: errorType,
      details: 'Failed to fetch data from public.dag_run_metrics table',
      timestamp: new Date().toISOString(),
      deploymentMode: process.env.DEPLOYMENT_MODE || 'local',
      suggestions: getErrorSuggestions(errorType)
    });
  }
});

router.get('/test-connection', async (req, res) => {
  try {
    console.log('🔍 Testing PostgreSQL connection...');
    const config = getPostgresConfig();
    console.log(`📍 Testing connection to: ${config.host}:${config.port}/${config.database}`);
    
    // Test basic connection with timeout
    const startTime = Date.now();
    await pool.query('SELECT 1 as test');
    const connectionTime = Date.now() - startTime;
    
    // Test if the dag_run_metrics table exists and has data
    const countQuery = `SELECT COUNT(*) as record_count FROM public.dag_run_metrics`;
    const countResult = await pool.query(countQuery);
    const recordCount = countResult.rows[0]?.record_count || 0;
    
    // Test table structure
    const structureQuery = `
      SELECT column_name, data_type 
      FROM information_schema.columns 
      WHERE table_name = 'dag_run_metrics' 
      AND table_schema = 'public'
      ORDER BY ordinal_position
    `;
    const structureResult = await pool.query(structureQuery);
    
    console.log(`✅ PostgreSQL connection successful. Table public.dag_run_metrics has ${recordCount} records.`);
    console.log(`⚡ Connection time: ${connectionTime}ms`);
    
    res.json({ 
      success: true,
      config: {
        host: config.host,
        port: config.port,
        database: config.database,
        deploymentMode: process.env.DEPLOYMENT_MODE || 'local',
        ssl: config.ssl,
        applicationName: config.application_name || 'InfoArchive_Metrics_Dashboard'
      },
      metrics: {
        connectionTime: `${connectionTime}ms`,
        recordCount: parseInt(recordCount),
        tableExists: structureResult.rows.length > 0,
        tableColumns: structureResult.rows.map(row => ({
          name: row.column_name,
          type: row.data_type
        }))
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ PostgreSQL connection test failed:', error);
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    
    // Enhanced error analysis
    let errorType = 'database_error';
    if (errMsg.includes('timeout')) {
      errorType = 'timeout_error';
    } else if (errMsg.includes('ECONNREFUSED') || errMsg.includes('ENOTFOUND')) {
      errorType = 'connection_error';
    } else if (errMsg.includes('authentication') || errMsg.includes('password')) {
      errorType = 'auth_error';
    } else if (errMsg.includes('does not exist')) {
      errorType = 'table_error';
    }
    
    res.status(500).json({ 
      success: false, 
      error: errMsg,
      errorType: errorType,
      details: 'Failed to connect to PostgreSQL database or access public.dag_run_metrics table',
      config: {
        host: process.env[`${process.env.DEPLOYMENT_MODE?.toUpperCase() || 'LOCAL'}_POSTGRES_HOST`],
        port: process.env[`${process.env.DEPLOYMENT_MODE?.toUpperCase() || 'LOCAL'}_POSTGRES_PORT`],
        database: process.env[`${process.env.DEPLOYMENT_MODE?.toUpperCase() || 'LOCAL'}_POSTGRES_DATABASE`],
        deploymentMode: process.env.DEPLOYMENT_MODE || 'local'
      },
      suggestions: getErrorSuggestions(errorType),
      timestamp: new Date().toISOString()
    });
  }
});

router.get('/network-diagnostics', async (req, res) => {
  try {
    const deploymentMode = process.env.DEPLOYMENT_MODE || 'local';
    const config = getPostgresConfig();
    
    console.log('🔧 Running network diagnostics...');
    
    const diagnostics = {
      deploymentMode,
      timestamp: new Date().toISOString(),
      environment: {
        nodeEnv: process.env.NODE_ENV,
        deploymentMode: process.env.DEPLOYMENT_MODE
      },
      postgres: {
        host: config.host,
        port: config.port,
        database: config.database,
        user: config.user,
        ssl: config.ssl,
        maxConnections: config.max,
        connectionTimeout: config.connectionTimeoutMillis,
        idleTimeout: config.idleTimeoutMillis,
        keepAlive: config.keepAlive,
        applicationName: config.application_name
      },
      environmentVariables: {
        hostVar: `${deploymentMode.toUpperCase()}_POSTGRES_HOST`,
        hostValue: process.env[`${deploymentMode.toUpperCase()}_POSTGRES_HOST`],
        portVar: `${deploymentMode.toUpperCase()}_POSTGRES_PORT`,
        portValue: process.env[`${deploymentMode.toUpperCase()}_POSTGRES_PORT`],
        databaseVar: `${deploymentMode.toUpperCase()}_POSTGRES_DATABASE`,
        databaseValue: process.env[`${deploymentMode.toUpperCase()}_POSTGRES_DATABASE`],
        userVar: `${deploymentMode.toUpperCase()}_POSTGRES_USER`,
        userValue: process.env[`${deploymentMode.toUpperCase()}_POSTGRES_USER`],
        sslVar: `${deploymentMode.toUpperCase()}_POSTGRES_SSL`,
        sslValue: process.env[`${deploymentMode.toUpperCase()}_POSTGRES_SSL`]
      }
    };
    
    console.log('📊 Network diagnostics completed');
    
    res.json({
      success: true,
      diagnostics,
      recommendations: [
        deploymentMode === 'network' ? 
          'Ensure network connectivity to the PostgreSQL server at 10.73.88.101:5432' :
          'Local mode: Ensure PostgreSQL is running on localhost:5432',
        'Verify firewall settings allow database connections',
        'Check if PostgreSQL service is running and accepting connections',
        'Validate database credentials in .env file',
        'Ensure the public.dag_run_metrics table exists and has proper permissions'
      ]
    });
  } catch (error) {
    console.error('❌ Network diagnostics failed:', error);
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    
    res.status(500).json({
      success: false,
      error: errMsg,
      details: 'Failed to run network diagnostics'
    });
  }
});

export const metricsRoutes = router;
