# InfoArchive Data Transformer - Complete Navigation Guide

## 📖 Table of Contents
1. [Application Overview](#application-overview)
2. [Getting Started](#getting-started)
3. [Main Navigation Areas](#main-navigation-areas)
4. [Detailed Step-by-Step Workflows](#detailed-step-by-step-workflows)
5. [Dashboard & Monitoring](#dashboard--monitoring)
6. [Troubleshooting & Help](#troubleshooting--help)
7. [Advanced Features](#advanced-features)

---

## 🎯 Application Overview

The **InfoArchive Data Transformer** is an enterprise-grade application that automates the process of transforming CSV data into InfoArchive-compatible XML format. It integrates with Apache Airflow 3.x for workflow orchestration and provides a comprehensive web interface for managing data transformation pipelines.

### Key Capabilities:
- ✅ CSV file upload and validation
- ✅ Automatic schema generation for InfoArchive
- ✅ Visual workflow management
- ✅ Real-time monitoring and analytics
- ✅ Enterprise reporting and auditing
- ✅ Multi-step workflow orchestration

---

## 🚀 Getting Started

### Initial Access
1. **Open your browser** and navigate to: `http://localhost:3002`
2. **Connection Status**: Check the top-right corner for Airflow connection status
   - 🟢 **Green**: Connected to Airflow
   - 🔴 **Red**: Disconnected (some features may be limited)
   - 🟡 **Yellow**: Checking connection

### First-Time Setup
- The application will automatically detect your deployment mode (Local/Network)
- Ensure Airflow is running at `http://localhost:8083`
- Verify directory permissions for data processing

---

## 🧭 Main Navigation Areas

The application is organized into **two main sections** accessible via the left sidebar:

### 📊 Management Console
**Purpose**: Monitor, analyze, and manage your data transformation workflows

#### 1. **Dashboard** 🏠
- **Overview**: Real-time summary of all DAGs and workflows
- **Key Metrics**: 
  - Total DAGs (workflows)
  - Active/Running DAGs
  - Paused DAGs
  - Recent execution statistics
- **Quick Actions**: Access to frequently used features

#### 2. **Jobs** ⚡
- **Purpose**: Monitor active workflow executions
- **Features**:
  - Real-time job status
  - Execution progress tracking
  - Performance monitoring
  - Error detection and alerts

#### 3. **Metrics** 📈
- **Purpose**: Performance analytics and insights
- **Features**:
  - Execution time analysis
  - Success/failure rates
  - Resource utilization
  - Historical trend analysis

#### 4. **Reports** 📋
- **Purpose**: Comprehensive reporting and audit trails
- **Report Types**:
  - **Chart Reports**: Visual data distributions
  - **Table Reports**: Structured data views
  - **Metrics Reports**: KPI dashboards
  - **Raw Data Reports**: Complete dataset exports

### 🗂️ Structured Data Archival
**Purpose**: Step-by-step workflow for processing CSV files into InfoArchive format

#### Step 1: **Prerequisites & Source Data Upload** 📤
- Upload CSV files for processing
- File validation and preview
- Header analysis and mapping

#### Step 2: **Configure** ⚙️
- Generate InfoArchive table schema
- Configure field mappings
- Set transformation parameters

#### Step 3: **Validate & Finalize Schema** ✅
- Review generated schema
- Make manual adjustments
- Validate field types and constraints

#### Step 4: **Download IA Schema** 📥
- Download finalized XML schema
- Review transformation settings
- Prepare for data processing

#### Step 5: **Transform CSV Upload** 🔄
- Transform CSV to InfoArchive XML format
- Upload to InfoArchive system
- Monitor transformation progress

---

## 📋 Detailed Step-by-Step Workflows

### 🔄 Complete Data Transformation Workflow

#### **STEP 1: Prerequisites & Source Data Upload**

**🎯 Goal**: Upload and validate your CSV files

**Navigation**: Sidebar → Structured Data Archival → Prerequisites & Source Data Upload

**What You'll See**:
- File upload interface
- Drag-and-drop area for CSV files
- File validation messages
- Preview of uploaded data

**Actions to Take**:
1. **Click "Choose File"** or drag CSV file to upload area
2. **Wait for validation** - the system will analyze your file structure
3. **Review the preview** - check headers and sample data
4. **Click "Continue"** to proceed to configuration

**Success Indicators**:
- ✅ File successfully uploaded
- ✅ Headers detected and displayed
- ✅ Sample rows shown in preview
- ✅ "Continue" button becomes active

---

#### **STEP 2: Generate Table Schema in InfoArchive**

**🎯 Goal**: Create InfoArchive-compatible schema from your CSV structure

**Navigation**: Automatically advances from Step 1, or manually via sidebar

**What You'll See**:
- Schema generation interface
- Field mapping table
- Data type assignments
- InfoArchive compatibility checks

**Actions to Take**:
1. **Review auto-detected fields** from your CSV
2. **Click "Analyze"** to generate the InfoArchive schema
3. **Wait for processing** - DAG will be triggered automatically
4. **Verify success message** confirming schema generation

**Success Indicators**:
- ✅ DAG 'IA_CSV_Metadata_Generator' triggered successfully
- ✅ Schema fields mapped correctly
- ✅ Data types assigned appropriately

---

#### **STEP 3: Validate and Finalize Schema**

**🎯 Goal**: Review, edit, and finalize the generated schema

**Navigation**: Automatically advances from Step 2

**What You'll See**:
- Editable schema interface
- Field-by-field configuration
- Data type selectors
- Validation rules setup

**Actions to Take**:
1. **Review each field** in the generated schema
2. **Edit field properties** as needed:
   - Field names
   - Data types
   - Length constraints
   - Required/optional settings
3. **Add validation rules** if required
4. **Click "Finalize"** when satisfied with the schema

**Success Indicators**:
- ✅ All fields properly configured
- ✅ No validation errors
- ✅ Schema marked as finalized

---

#### **STEP 4: Download IA Schema**

**🎯 Goal**: Download the completed InfoArchive schema and prepare for deployment

**Navigation**: Automatically advances from Step 3

**What You'll See**:
- Download interface
- Schema summary
- Generated XML preview
- Deployment instructions

**Actions to Take**:
1. **Review the schema summary**
2. **Click "Download Schema"** to get the XML file
3. **Review deployment instructions**
4. **Proceed to data transformation** if ready

---

#### **STEP 5: Transform CSV Data to IA XML Format**

**🎯 Goal**: Transform your actual CSV data using the finalized schema

**Navigation**: Automatically advances from Step 4

**What You'll See**:
- Data transformation interface
- Progress indicators
- Transformation settings
- Upload to InfoArchive options

**Actions to Take**:
1. **Configure transformation settings**
2. **Click "Start Transformation"**
3. **Monitor progress** in real-time
4. **Review results** and handle any errors
5. **Upload to InfoArchive** when transformation completes

---

## 📊 Dashboard & Monitoring

### 🏠 Main Dashboard

**Access**: Sidebar → Management Console → Dashboard

**Key Sections**:

#### **DAG Overview**
- **Total DAGs**: Complete count of all workflows
- **Active DAGs**: Currently running processes
- **Paused DAGs**: Temporarily stopped workflows
- **Success Rate**: Overall execution success percentage

#### **Recent Activity**
- Latest DAG executions
- Recent uploads and transformations
- System alerts and notifications

#### **Quick Actions**
- Start new transformation workflow
- View detailed reports
- Access system settings
- Check connection status

#### **Performance Metrics**
- Average execution time
- Data processing volume
- System resource usage
- Error rates and trends

### ⚡ Jobs Monitoring

**Access**: Sidebar → Management Console → Jobs

**Features**:
- **Real-time Status**: Live updates on running jobs
- **Execution Details**: Detailed view of each workflow step
- **Performance Data**: Timing and resource usage
- **Error Tracking**: Immediate notification of issues

### 📈 Metrics & Analytics

**Access**: Sidebar → Management Console → Metrics

**Available Metrics**:
- **Execution Times**: Average, min, max processing times
- **Success Rates**: Percentage of successful transformations
- **Data Volume**: Amount of data processed over time
- **Resource Usage**: CPU, memory, and storage utilization

### 📋 Reports Section

**Access**: Sidebar → Management Console → Reports

**Report Types**:

#### **Chart Reports** 📊
- Visual data distributions
- Pie charts for categorization
- Bar charts for comparisons
- Time series analysis

#### **Table Reports** 📋
- Structured data views
- Sortable columns
- Advanced filtering
- Export capabilities

#### **Metrics Reports** 📈
- KPI dashboards
- Performance indicators
- Trend analysis
- Comparative reports

#### **Raw Data Reports** 📄
- Complete dataset exports
- JSON structure preview
- Data validation results
- Debug information

---

## 🆘 Troubleshooting & Help

### 🔧 Common Issues & Solutions

#### **Connection Issues**
**Problem**: Red "Airflow Disconnected" status
**Solutions**:
1. Check if Airflow is running: `http://localhost:8083`
2. Click "Retry Connection" button
3. Verify network connectivity
4. Check Airflow credentials (admin/admin123)

#### **File Upload Problems**
**Problem**: CSV upload fails or shows errors
**Solutions**:
1. Verify file format (must be valid CSV)
2. Check file size (reasonable limits apply)
3. Ensure proper CSV structure with headers
4. Remove special characters from headers

#### **Schema Generation Errors**
**Problem**: "Analyze" fails or produces incorrect schema
**Solutions**:
1. Verify CSV headers are valid field names
2. Check for special characters in data
3. Ensure consistent data types in columns
4. Review data preview for anomalies

#### **Transformation Failures**
**Problem**: Data transformation step fails
**Solutions**:
1. Verify schema is properly finalized
2. Check input data quality
3. Review transformation logs
4. Ensure sufficient system resources

### 📞 Getting Help

#### **Built-in Help System**
- **Help Button**: Click the "?" icon in the top-right corner
- **Setup Instructions**: Comprehensive setup and configuration guide
- **Tooltips**: Hover over interface elements for context help

#### **AI Assistant Chatbot** 🤖
- **Access**: Available on all pages (bottom-right corner)
- **Capabilities**:
  - Answer questions about your current workflow
  - Provide status updates on DAGs and jobs
  - Explain features and functionality
  - Troubleshoot common issues
  - Guide through complex procedures

**Sample Commands**:
- "What's my dashboard status?"
- "Show me active DAGs"
- "How do I fix connection issues?"
- "Explain the schema generation process"
- "What reports are available?"

---

## 🔧 Advanced Features

### 🎨 Theme & Appearance
- **Dark/Light Mode**: Automatic theme switching
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Accessibility**: Full WCAG 2.1 AA compliance
- **Modern UI**: Clean, professional interface design

### 🔐 Security & Authentication
- **JWT Authentication**: Secure token-based access
- **Input Validation**: Comprehensive data validation
- **Error Boundaries**: Graceful error handling
- **Audit Trails**: Complete activity logging

### ⚡ Performance Features
- **Smart Caching**: Intelligent request caching
- **Request Deduplication**: Prevents duplicate operations
- **Background Processing**: Non-blocking operations
- **Progress Monitoring**: Real-time status updates

### 🔌 Integration Capabilities
- **Apache Airflow 3.x**: Full workflow orchestration
- **InfoArchive API**: Direct system integration
- **REST APIs**: Comprehensive API access
- **Real-time Updates**: WebSocket-based notifications

---

## 📋 Quick Reference

### 🚀 Essential Shortcuts
- **Ctrl/Cmd + B**: Toggle sidebar
- **Dashboard**: Quick access to overview
- **Upload**: Start new transformation workflow
- **Reports**: View analytics and reports

### 📍 Navigation Quick Guide
1. **Start Here**: Dashboard for overview
2. **Upload Data**: Structured Data Archival → Prerequisites & Source Data Upload
3. **Monitor Progress**: Management Console → Jobs
4. **View Results**: Management Console → Reports
5. **Get Help**: AI Assistant (bottom-right) or Help button (top-right)

### 🎯 Success Workflow
```
Dashboard → Upload CSV → Configure Schema → Validate & Finalize → Download Schema → Transform Data → Monitor Results → View Reports
```

---

## 📞 Support & Resources

### 🔗 Important URLs
- **Application**: `http://localhost:3002`
- **Airflow**: `http://localhost:8083`
- **API Documentation**: `http://localhost:3002/api`

### 📁 Key Directories
- **Data Input**: `C:\Docker\airflow3x2\data\incomingcsv`
- **Processed Data**: `C:\Docker\airflow3x2\data\processedcsv`
- **Reports**: `C:\Docker\airflow3x2\reports`
- **DAGs**: `C:\Docker\airflow3x2\dags`

### 🆘 Emergency Procedures
1. **System Restart**: Stop application, restart Airflow, restart application
2. **Clear Cache**: Use browser developer tools to clear application cache
3. **Reset Workflow**: Use "Start Over" button to reset current session
4. **Data Recovery**: Check processed data directories for recovered files

---

**📝 Note**: This guide covers the standard workflow. For custom configurations or enterprise deployments, consult the technical documentation or contact your system administrator.

**🔄 Last Updated**: Based on InfoArchive Data Transformer v2.0 - Sprint 2 Release
