# File Upload Issue - Troubleshooting Guide

## Problem
Files are being uploaded to the local project directory instead of the remote Airflow server at `\\10.73.88.101\data\incomingcsv`.

## Root Cause
The Node.js application cannot directly access UNC network paths (\\server\share) from server-side code. Network paths need to be mapped to drive letters for Windows applications to access them properly.

## Solutions

### Solution 1: Map Network Drive (Recommended)

1. **Run the network drive mapping script:**
   ```cmd
   map-network-drive.bat
   ```

2. **Manual mapping (if script fails):**
   ```cmd
   net use Z: \\10.73.88.101\data /persistent:yes
   ```

3. **With credentials (if required):**
   ```cmd
   net use Z: \\10.73.88.101\data /user:username password /persistent:yes
   ```

4. **Verify mapping:**
   ```cmd
   dir Z:\
   ```

### Solution 2: Update Environment Variables

The .env file has been updated to use mapped drives:

```env
# Updated paths using mapped drive Z:
AIRFLOW_DATA_DIR=Z:\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=Z:\processedcsv
AIRFLOW_REPORTS_DIR=Z:\reports
```

### Solution 3: Alternative - Use Local Copy + Manual Transfer

If network drives don't work:

1. Files will be stored locally in `./data/incomingcsv`
2. Manually copy files to the remote server:
   ```cmd
   copy ".\data\incomingcsv\*.csv" "\\10.73.88.101\data\incomingcsv\"
   ```

### Solution 4: SSH/SCP Transfer (Linux/Advanced)

For Linux environments or if SSH is available:

1. Install SSH client
2. Use SCP to transfer files:
   ```bash
   scp ./uploads/filename.csv user@10.73.88.101:/data/incomingcsv/
   ```

## Verification Steps

1. **Check if network drive is mapped:**
   ```cmd
   net use
   ```

2. **Test file access:**
   ```cmd
   dir Z:\incomingcsv
   ```

3. **Test file creation:**
   ```cmd
   echo test > Z:\incomingcsv\test.txt
   ```

4. **Restart the application:**
   ```cmd
   npm run dev
   ```

## Common Issues and Solutions

### Issue 1: Network Drive Not Accessible
**Error:** `ENOENT: no such file or directory`
**Solution:** 
- Check network connectivity to 10.73.88.101
- Verify shared folder permissions
- Use credentials if required

### Issue 2: Permission Denied
**Error:** `EACCES: permission denied`
**Solution:**
- Run cmd as Administrator
- Check user permissions on the shared folder
- Add user credentials to the mapping

### Issue 3: Drive Mapping Not Persistent
**Error:** Drive disappears after reboot
**Solution:**
- Use `/persistent:yes` flag
- Add to Windows startup scripts

### Issue 4: Application Still Uses Local Path
**Error:** Files still go to local directory
**Solution:**
- Restart the Node.js application
- Clear browser cache
- Check .env file is properly loaded

## Environment Variables Reference

```env
# Client-side (with NEXT_PUBLIC_ prefix)
NEXT_PUBLIC_AIRFLOW_DATA_DIR=Z:\incomingcsv
NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR=Z:\incomingcsv
NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR=Z:\processedcsv

# Server-side
AIRFLOW_DATA_DIR=Z:\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=Z:\processedcsv
AIRFLOW_REPORTS_DIR=Z:\reports
```

## Testing the Fix

1. **Upload a test file** through the web interface
2. **Check the terminal output** for the actual file path
3. **Verify the file exists** on the remote server:
   ```cmd
   dir Z:\incomingcsv
   ```
4. **Check the application logs** for any errors

## If Nothing Works

As a last resort, modify the application to use a local staging directory and set up a scheduled task to sync files:

1. Files upload to `./data/incomingcsv/`
2. Create a PowerShell script to sync files:
   ```powershell
   robocopy ".\data\incomingcsv" "\\10.73.88.101\data\incomingcsv" /MIR
   ```
3. Schedule the script to run every few minutes

## Contact Information

- Check network connectivity with IT team
- Verify Airflow server access permissions
- Confirm shared folder configuration on 10.73.88.101
