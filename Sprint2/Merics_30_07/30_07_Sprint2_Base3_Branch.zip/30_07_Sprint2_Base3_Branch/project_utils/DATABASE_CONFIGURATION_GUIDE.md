# Database Configuration Guide

## Overview

This project uses a centralized database configuration system that supports multiple deployment modes and maintains all connection strings in environment variables for maximum maintainability and security.

## Configuration Files

### 1. Environment Variables (.env)
All database configurations are stored in the `.env` file with clear naming conventions:

```bash
# PostgreSQL Configuration - Network Deployment
NETWORK_POSTGRES_HOST=10.73.88.101
NETWORK_POSTGRES_PORT=5432
NETWORK_POSTGRES_DATABASE=RND
NETWORK_POSTGRES_USER=postgres
NETWORK_POSTGRES_PASSWORD=postgres

# PostgreSQL Configuration - Local Deployment
LOCAL_POSTGRES_HOST=localhost
LOCAL_POSTGRES_PORT=5432
LOCAL_POSTGRES_DATABASE=RND
LOCAL_POSTGRES_USER=postgres
LOCAL_POSTGRES_PASSWORD=admin@12345

# PostgreSQL Connection Pool Settings
POSTGRES_SSL_ENABLED=false
POSTGRES_MAX_CONNECTIONS=10
POSTGRES_IDLE_TIMEOUT=30000
POSTGRES_CONNECTION_TIMEOUT=5000

# Metrics Configuration
METRICS_QUERY_TIMEOUT=30000
METRICS_CACHE_TTL=300
DB_RETRY_ATTEMPTS=3
DB_RETRY_DELAY=1000
```

### 2. Database Configuration Module (shared/database-config.ts)
Centralized configuration management that:
- ✅ Reads from environment variables
- ✅ Supports local/network deployment modes
- ✅ Provides type-safe configuration interfaces
- ✅ Includes connection testing utilities
- ✅ Offers comprehensive logging and debugging

### 3. Metrics API Routes (server/metrics-routes.ts)
RESTful API endpoints for PostgreSQL metrics:
- ✅ `/api/metrics/test-connection` - Test database connectivity
- ✅ `/api/metrics/dag-runs` - Fetch DAG run metrics
- ✅ `/api/metrics/summary` - Get summarized analytics
- ✅ `/api/metrics/config` - Current configuration info

## Key Features

### Environment-Based Configuration
```typescript
// Automatically selects configuration based on deployment mode
const config = getPostgreSQLConfig();
// Returns network or local settings based on DEPLOYMENT_MODE
```

### Type Safety
```typescript
interface PostgreSQLConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
  ssl?: boolean;
  max?: number; // connection pool size
  idleTimeoutMillis?: number;
  connectionTimeoutMillis?: number;
}
```

### Connection Testing
```typescript
const result = await testDatabaseConnection();
console.log(result.success); // true/false
console.log(result.timing.duration); // connection time in ms
```

### Comprehensive Logging
```bash
=== DATABASE CONFIGURATION ===
🚀 Deployment Mode: NETWORK
🐘 PostgreSQL Host: 10.73.88.101:5432
📊 Database: RND
👤 User: postgres
🔒 SSL: Disabled
⏱️ Query Timeout: 30000ms
💾 Cache TTL: 300s
===============================
```

## Deployment Modes

### Network Mode
- **Host**: 10.73.88.101 (shared network server)
- **Use Case**: Production deployment, team collaboration
- **Configuration**: Automatically selected when `DEPLOYMENT_MODE=network`

### Local Mode
- **Host**: localhost
- **Use Case**: Development, testing, offline work
- **Configuration**: Automatically selected when `DEPLOYMENT_MODE=local`

## Usage Examples

### Frontend Integration
```typescript
// React component fetching metrics
const response = await fetch('/api/metrics/dag-runs');
const data = await response.json();
console.log(data.databaseConfig.deploymentMode); // 'network' or 'local'
```

### Backend Configuration
```typescript
import { getPostgreSQLConfig, testDatabaseConnection } from '../shared/database-config';

// Get current configuration
const dbConfig = getPostgreSQLConfig();

// Test connection
const connectionResult = await testDatabaseConnection();
if (connectionResult.success) {
  console.log('Database connected successfully!');
}
```

### Environment Variable Override
```bash
# Override specific settings without changing deployment mode
LOCAL_POSTGRES_PASSWORD=newpassword
POSTGRES_MAX_CONNECTIONS=20
METRICS_QUERY_TIMEOUT=60000
```

## SQL Query Example

The system executes PostgreSQL queries like:
```sql
SELECT id, dag_id as ProcessName, run_id as InstanceId, 
       execution_date, records_processed, records_failed
FROM public.dag_run_metrics
ORDER BY execution_date DESC
```

## API Response Format

```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "processname": "customer_data_processing",
      "instanceid": "run_2024_01_15_001",
      "execution_date": "2024-01-15T10:30:00Z",
      "records_processed": 15420,
      "records_failed": 23
    }
  ],
  "summary": {
    "totalRuns": 8,
    "totalRecordsProcessed": 227226,
    "totalRecordsFailed": 368,
    "successRate": "99.84%"
  },
  "databaseConfig": {
    "host": "10.73.88.101",
    "database": "RND",
    "deploymentMode": "network"
  }
}
```

## Security Best Practices

1. **Environment Variables**: All sensitive data in `.env`
2. **No Hardcoded Credentials**: All passwords configurable
3. **Connection Pooling**: Prevents connection exhaustion
4. **SSL Support**: Configurable SSL encryption
5. **Timeout Controls**: Prevents hanging connections

## Troubleshooting

### Common Issues

1. **Connection Failed**
   ```bash
   # Check environment variables
   echo $NETWORK_POSTGRES_HOST
   
   # Test connectivity
   curl http://localhost:3005/api/metrics/test-connection
   ```

2. **Wrong Deployment Mode**
   ```bash
   # Check current mode
   curl http://localhost:3005/api/metrics/config
   
   # Change mode in .env
   DEPLOYMENT_MODE=local  # or 'network'
   ```

3. **Database Not Accessible**
   - Verify PostgreSQL server is running
   - Check network connectivity to 10.73.88.101
   - Confirm credentials in `.env` file

### Debug Logging
The system provides comprehensive logs on startup:
- Configuration loading
- Database connection details
- Environment variable resolution
- Connection test results

## Maintenance

### Adding New Database Connections
1. Add environment variables to `.env`
2. Update `database-config.ts` interfaces
3. Extend configuration functions
4. Update API routes as needed

### Changing Database Servers
1. Update environment variables:
   ```bash
   NETWORK_POSTGRES_HOST=new.server.ip
   NETWORK_POSTGRES_PORT=5432
   ```
2. Restart application
3. Test connection via API

### Performance Tuning
```bash
# Connection pool settings
POSTGRES_MAX_CONNECTIONS=20
POSTGRES_IDLE_TIMEOUT=60000
POSTGRES_CONNECTION_TIMEOUT=10000

# Query optimization
METRICS_QUERY_TIMEOUT=60000
METRICS_CACHE_TTL=600
```

## Next Steps

- [ ] Implement actual PostgreSQL connectivity (currently simulated)
- [ ] Add database migration scripts
- [ ] Implement connection pooling with real PostgreSQL driver
- [ ] Add SSL certificate configuration
- [ ] Create backup/restore procedures
- [ ] Implement query result caching
- [ ] Add metrics for database performance monitoring

---

*This configuration system provides a robust, maintainable foundation for PostgreSQL metrics integration with support for multiple deployment environments.*
