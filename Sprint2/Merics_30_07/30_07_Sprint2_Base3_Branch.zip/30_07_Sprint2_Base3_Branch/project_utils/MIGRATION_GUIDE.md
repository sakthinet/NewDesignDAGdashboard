# Application Stabilization and Migration Guide

This guide outlines the comprehensive improvements made to stabilize the Airflow DAG application and resolve file upload/network path issues.

## 🔧 **Major Improvements Implemented**

### 1. **Enhanced Path Management System**
- **New File**: `shared/path-manager.ts`
- **Features**:
  - Automatic UNC path normalization
  - Network path accessibility checking with caching
  - Robust fallback to local paths when network fails
  - Centralized directory creation and validation
  - Smart file location detection across multiple directories

### 2. **Unified Configuration Management**
- **New File**: `shared/config-enhanced.ts` 
- **Features**:
  - Type-safe configuration with validation
  - Environment-specific settings
  - Automatic fallback values
  - Configuration health checking
  - Simplified environment variables (see `.env.enhanced`)

### 3. **Robust File Service**
- **New File**: `shared/file-service.ts`
- **Features**:
  - Enhanced CSV parsing with encoding detection
  - Comprehensive file validation
  - Smart error handling and recovery
  - Metadata extraction and file statistics
  - Secure file operations with proper cleanup

### 4. **Enhanced Route Implementation** 
- **New File**: `server/routes-enhanced.ts`
- **Features**:
  - Uses new path management system
  - Improved error handling and logging
  - API response caching for performance
  - Enhanced Airflow authentication
  - Comprehensive health checks

### 5. **Improved DAG Implementation**
- **Enhanced**: `dags/StructuredDataToIA_Resilient.py`
- **Features**:
  - Better error handling and logging
  - Enhanced configuration parameter mapping
  - Robust file discovery with alternative paths
  - Improved encoding support
  - Comprehensive cleanup and finalization

## 📋 **Migration Steps**

### Step 1: Update Environment Configuration

1. **Backup current `.env` file**:
   ```bash
   copy .env .env.backup
   ```

2. **Replace with enhanced configuration**:
   ```bash
   copy .env.enhanced .env
   ```

3. **Review and adjust paths** in `.env` file:
   - For production: Use UNC network paths (`\\\\10.73.88.101\\data\\incomingcsv`)
   - For development: Uncomment local paths at the bottom

### Step 2: Update Application Code

1. **Replace configuration imports** in existing files:
   ```typescript
   // Old import
   import { getServerConfig } from '@shared/config';
   
   // New import
   import { getServerConfig } from '@shared/config-enhanced';
   ```

2. **Update route registration** in `server/index.ts`:
   ```typescript
   // Replace routes import
   import { registerRoutes } from './routes-enhanced';
   ```

3. **Update file operations** to use the new file service:
   ```typescript
   import { fileService } from '@shared/file-service';
   import { pathManager } from '@shared/path-manager';
   ```

### Step 3: Update Package Scripts

Add configuration validation script to `package.json`:
```json
{
  "scripts": {
    "check-config": "node -e \"require('./shared/config-enhanced').logConfiguration()\"",
    "validate-paths": "node -e \"require('./shared/path-manager').pathManager.getPathInfo(process.env.AIRFLOW_INCOMING_CSV_DIR).then(console.log)\""
  }
}
```

### Step 4: Test the Migration

1. **Validate configuration**:
   ```bash
   npm run check-config
   ```

2. **Test file upload**:
   ```bash
   npm run dev
   ```
   - Upload a test CSV file
   - Verify it appears in the correct directory
   - Check console logs for any warnings

3. **Test DAG trigger**:
   - Configure schema settings
   - Trigger the `StructuredDataToIA_Resilient` DAG
   - Monitor logs for improved error messages

## 🔍 **Key Features & Benefits**

### Network Path Stability
- **Automatic Detection**: System detects if network paths are accessible
- **Smart Fallback**: Falls back to local paths when network is unavailable
- **Path Caching**: Caches accessibility checks for 30 seconds to improve performance
- **UNC Path Normalization**: Handles various path formats consistently

### Error Handling
- **Comprehensive Logging**: Detailed logs for debugging path issues
- **Graceful Degradation**: Application continues working even with network issues
- **User Feedback**: Clear messages when files are saved locally vs. network

### Performance Improvements
- **Response Caching**: API responses cached for better performance
- **Batch Operations**: File operations batched where possible
- **Connection Pooling**: Better Airflow authentication management

### Code Quality
- **Type Safety**: Full TypeScript types for configuration and file operations
- **Separation of Concerns**: Dedicated services for different functionalities
- **Consistent Error Handling**: Standardized error responses across the application
- **Documentation**: Comprehensive inline documentation

## 🚨 **Breaking Changes**

### Configuration Structure
The configuration object structure has been enhanced:
```typescript
// Old structure
config.incomingCsvDir

// New structure  
config.paths.incomingCsvDir
config.connection.url
config.application.port
config.debug.enablePathLogging
```

### File Operation APIs
File operations now return structured results:
```typescript
// Old return
{ success: boolean, message: string }

// New return
{
  success: boolean,
  filePath?: string,
  message?: string,
  warnings?: string[],
  isLocalFallback?: boolean
}
```

## 🔧 **Troubleshooting**

### Network Path Issues
1. **Check network connectivity**:
   ```cmd
   ping 10.73.88.101
   ```

2. **Test UNC path access**:
   ```cmd
   dir \\\\10.73.88.101\\data
   ```

3. **Map network drive if needed**:
   ```cmd
   net use Z: \\\\10.73.88.101\\data /persistent:yes
   ```

4. **Update .env to use mapped drive**:
   ```env
   AIRFLOW_INCOMING_CSV_DIR=Z:\\incomingcsv
   ```

### Local Development
For local development without network access:
```env
# Uncomment these lines in .env
AIRFLOW_INCOMING_CSV_DIR=./data/incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=./data/processedcsv
AIRFLOW_REPORTS_DIR=./reports
AIRFLOW_DAGS_DIR=./dags
```

### Configuration Validation
Run validation to check for issues:
```bash
node -e "
const { validateConfiguration } = require('./shared/config-enhanced');
const result = validateConfiguration();
console.log('Validation:', result);
"
```

## 📈 **Performance Monitoring**

### Health Check Endpoint
Access `/api/health` to get system status:
```json
{
  "status": "healthy",
  "configuration": {
    "environment": "development",
    "pathsConfigured": true,
    "validationResult": { "valid": true, "errors": [], "warnings": [] }
  },
  "paths": {
    "incomingCsv": { "accessible": true, "isLocal": false },
    "processedCsv": { "accessible": true, "isLocal": false }
  }
}
```

### File Operation Monitoring
Monitor file operations through enhanced logging:
- Enable via `ENABLE_PATH_LOGGING=true` in `.env`
- Check console for detailed path resolution logs
- Monitor warnings for network accessibility issues

## 🎯 **Next Steps**

1. **Monitor the application** in production for any remaining issues
2. **Gradual rollout** - test with small file uploads first
3. **Performance tuning** - adjust cache TTL and timeout values as needed
4. **Documentation updates** - update user documentation with new features
5. **Cleanup old files** - remove deprecated route files after successful migration

## 📞 **Support**

If issues persist after migration:
1. Check `/api/health` endpoint for system status
2. Review console logs with `ENABLE_PATH_LOGGING=true`
3. Test with local paths first to isolate network issues
4. Verify Airflow server accessibility and permissions
