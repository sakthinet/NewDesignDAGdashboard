#!/usr/bin/env python3
"""
Simple File Lines Analysis - Creates Excel with files and their code line counts
"""

import os
import pandas as pd
from pathlib import Path

# Project configuration
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
INCLUDE_FOLDERS = ["client", "server", "shared", "project_utils"]
ROOT_FILES = [
    "package.json", "vite.config.ts", "tsconfig.json", "tailwind.config.ts",
    "drizzle.config.ts", "postcss.config.js", "components.json", 
    "config-switcher.cjs", "validate-implementation.cjs"
]

# File extensions to analyze
EXTENSIONS = {'.ts', '.tsx', '.js', '.jsx', '.json', '.css', '.md', '.html', '.cjs'}

def count_code_lines(file_path: str) -> int:
    """Count only code lines (excluding empty lines and comments)"""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        code_lines = 0
        for line in lines:
            stripped = line.strip()
            # Skip empty lines
            if not stripped:
                continue
            # Skip comment lines
            if stripped.startswith('//') or stripped.startswith('/*') or stripped.startswith('*') or stripped.startswith('#'):
                continue
            # Count as code line
            code_lines += 1
                    
        return code_lines
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return 0

def get_file_category(file_path: str) -> str:
    """Get file category"""
    rel_path = os.path.relpath(file_path, PROJECT_ROOT)
    
    if rel_path in ROOT_FILES:
        return "Root Configuration"
    elif rel_path.startswith("client\\src\\components\\ui"):
        return "UI Components"
    elif rel_path.startswith("client\\src\\components"):
        return "Business Components"
    elif rel_path.startswith("client\\src\\hooks"):
        return "React Hooks"
    elif rel_path.startswith("client\\src\\contexts"):
        return "React Contexts"
    elif rel_path.startswith("client\\src\\pages"):
        return "Pages"
    elif rel_path.startswith("client\\src\\lib"):
        return "Client Libraries"
    elif rel_path.startswith("client\\src\\utils"):
        return "Client Utils"
    elif rel_path.startswith("client\\src\\styles"):
        return "Styles"
    elif rel_path.startswith("client\\src\\types"):
        return "Type Definitions"
    elif rel_path.startswith("client"):
        return "Client Root"
    elif rel_path.startswith("server"):
        return "Server"
    elif rel_path.startswith("shared"):
        return "Shared"
    elif rel_path.startswith("project_utils"):
        return "Project Documentation"
    else:
        return "Other"

def analyze_files():
    """Analyze all files and return data"""
    files_data = []
    
    print("Analyzing files...")
    
    # Add root files
    for root_file in ROOT_FILES:
        file_path = os.path.join(PROJECT_ROOT, root_file)
        if os.path.exists(file_path):
            code_lines = count_code_lines(file_path)
            files_data.append({
                'File Path': os.path.relpath(file_path, PROJECT_ROOT),
                'File Name': os.path.basename(file_path),
                'Category': get_file_category(file_path),
                'Extension': os.path.splitext(file_path)[1],
                'Code Lines': code_lines
            })
            print(f"✓ {root_file}: {code_lines} lines")
    
    # Scan included folders
    for folder in INCLUDE_FOLDERS:
        folder_path = os.path.join(PROJECT_ROOT, folder)
        if os.path.exists(folder_path):
            print(f"\nScanning {folder} folder...")
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    ext = os.path.splitext(file)[1].lower()
                    
                    if ext in EXTENSIONS:
                        code_lines = count_code_lines(file_path)
                        rel_path = os.path.relpath(file_path, PROJECT_ROOT)
                        files_data.append({
                            'File Path': rel_path,
                            'File Name': file,
                            'Category': get_file_category(file_path),
                            'Extension': ext,
                            'Code Lines': code_lines
                        })
                        print(f"  ✓ {rel_path}: {code_lines} lines")
    
    return files_data

def create_excel_report(files_data, output_file="Project_Files_CodeLines.xlsx"):
    """Create Excel file with files and code lines"""
    print(f"\nCreating Excel report: {output_file}")
    
    # Create DataFrame
    df = pd.DataFrame(files_data)
    
    # Sort by code lines (descending)
    df = df.sort_values('Code Lines', ascending=False)
    
    # Calculate totals
    total_files = len(df)
    total_code_lines = df['Code Lines'].sum()
    
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # Main sheet with all files
        df.to_excel(writer, sheet_name='Files and Code Lines', index=False)
        
        # Summary by category
        category_summary = df.groupby('Category').agg({
            'File Name': 'count',
            'Code Lines': 'sum'
        }).reset_index()
        category_summary.columns = ['Category', 'File Count', 'Total Code Lines']
        category_summary = category_summary.sort_values('Total Code Lines', ascending=False)
        category_summary.to_excel(writer, sheet_name='Summary by Category', index=False)
        
        # Summary by extension
        ext_summary = df.groupby('Extension').agg({
            'File Name': 'count',
            'Code Lines': 'sum'
        }).reset_index()
        ext_summary.columns = ['File Extension', 'File Count', 'Total Code Lines']
        ext_summary = ext_summary.sort_values('Total Code Lines', ascending=False)
        ext_summary.to_excel(writer, sheet_name='Summary by Extension', index=False)
        
        # Top 20 largest files
        top_files = df.head(20)[['File Path', 'File Name', 'Category', 'Code Lines']].copy()
        top_files.to_excel(writer, sheet_name='Top 20 Largest Files', index=False)
    
    print(f"✅ Excel report created: {output_file}")
    print(f"📊 Total Files: {total_files}")
    print(f"📝 Total Code Lines: {total_code_lines:,}")
    
    return total_files, total_code_lines

def main():
    """Main function"""
    os.chdir(PROJECT_ROOT)
    
    print("=" * 60)
    print("PROJECT FILES CODE LINES ANALYSIS")
    print("=" * 60)
    
    # Analyze files
    files_data = analyze_files()
    
    # Create Excel report
    total_files, total_code_lines = create_excel_report(files_data)
    
    print("\n" + "=" * 60)
    print("ANALYSIS COMPLETE!")
    print("=" * 60)
    print(f"📁 Files analyzed: {total_files}")
    print(f"📄 Total code lines: {total_code_lines:,}")
    print("📊 Excel file: Project_Files_CodeLines.xlsx")
    print("=" * 60)

if __name__ == "__main__":
    main()
