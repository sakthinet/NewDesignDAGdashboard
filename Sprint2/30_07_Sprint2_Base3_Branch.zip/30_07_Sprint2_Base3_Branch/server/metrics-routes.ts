import { Router } from 'express';
import { Pool } from 'pg';
import dotenv from 'dotenv';
import path from 'path';
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const router = Router();

function getPostgresConfig() {
  // Set defaults in case environment variables are not loaded
  const mode = process.env.DEPLOYMENT_MODE || 'local';
  console.log(`Using deployment mode: ${mode}`);
  
  if (mode === 'local') {
    // Default values for local
    const host = process.env.LOCAL_POSTGRES_HOST || 'localhost';
    const port = Number(process.env.LOCAL_POSTGRES_PORT || 5432);
    const database = process.env.LOCAL_POSTGRES_DATABASE || 'RND';
    const user = process.env.LOCAL_POSTGRES_USER || 'postgres';
    const password = process.env.LOCAL_POSTGRES_PASSWORD || 'admin@12345';
    const ssl = process.env.LOCAL_POSTGRES_SSL === 'true';
    
    console.log(`Connecting to LOCAL PostgreSQL: ${host}:${port} (SSL: ${ssl})`);
    
    return {
      host,
      port,
      database,
      user,
      password,
      ssl,
    };
  } else {
    // Default values for network
    const host = process.env.NETWORK_POSTGRES_HOST || '10.73.88.101';
    const port = Number(process.env.NETWORK_POSTGRES_PORT || 5432);
    const database = process.env.NETWORK_POSTGRES_DATABASE || 'RND';
    const user = process.env.NETWORK_POSTGRES_USER || 'postgres';
    const password = process.env.NETWORK_POSTGRES_PASSWORD || 'postgres';
    const ssl = process.env.NETWORK_POSTGRES_SSL === 'true';
    
    console.log(`Connecting to NETWORK PostgreSQL: ${host}:${port} (SSL: ${ssl})`);
    
    return {
      host,
      port,
      database,
      user,
      password,
      ssl,
    };
  }
}

const pool = new Pool(getPostgresConfig());

router.get('/dag-runs', async (req, res) => {
  try {
    const table = process.env.DEPLOYMENT_MODE === 'local' ? process.env.LOCAL_POSTGRES_TABLE : process.env.NETWORK_POSTGRES_TABLE;
    const result = await pool.query(`SELECT * FROM ${table}`);
    res.json({ success: true, data: result.rows });
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    res.status(500).json({ success: false, error: errMsg });
  }
});

router.get('/test-connection', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ success: true });
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    res.status(500).json({ success: false, error: errMsg });
  }
});

export const metricsRoutes = router;
