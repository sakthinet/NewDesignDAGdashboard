// src/config.ts
export const API_BASE_URL = "http://localhost:8000";
export const QDRANT_URL = "http://localhost:6333";

export const ENDPOINTS = {
  STATUS: `${API_BASE_URL}/wizard/status`,
  SEARCH: (apiPath: string) => `${API_BASE_URL}${apiPath}`,
  GENERATE_API: `${API_BASE_URL}/wizard/generate`,
  QDRANT_COLLECTIONS: `${QDRANT_URL}/collections`,
};

export const DATABASE_TYPES = ["Qdrant", "Pinecone", "Weaviate", "FAISS"];
export const METRICS = ["cosine", "dot_product", "euclidean"];

export const airflowDagId = "DataForGenAI";

export const airflowToken =
  "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiaXNzIjpbXSwiYXVkIjoiYXBhY2hlLWFpcmZsb3ciLCJuYmYiOjE3NTMyODM2MzQsImV4cCI6MTc1MzM3MDAzNCwiaWF0IjoxNzUzMjgzNjM0fQ.SZ-xYaH8q7dhRUMi54sxGjvJjzrnOFnjy8kx2x1zhyGwwZyW_-vH6kHkcNsliwiNGxLMaseuwgN9LWxMBnv_mg";

export const airflowDagRunUrl = `http://localhost:8080/api/v2/dags/${airflowDagId}/dagRuns/list`;

export const config = {
  API_BASE_URL: "http://localhost:8000",
};


 