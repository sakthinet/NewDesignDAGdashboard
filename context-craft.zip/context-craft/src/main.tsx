import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./index.css";
import AppLayout from "./AppLayout";
import Login from "./pages/Login";
import Dashboard from "./pages/DashboardPage";
import ImportConnectorsPage from "./pages/ImportConnectorsPage";
import NewS3ConnectorPage from "./pages/NewS3ConnectorPage";
import ParsersPage from "./pages/ParsersPage";
import NewParserPage from "./pages/NewParserPage";
import CreatePipeline from "./pages/VectorPipelinesPage";
import PipelineDesigner from "./pages/PipelineDesigner";
import CreateAPI from "./pages/CreateApiPage";
import TestAPI from "./pages/TestApiPage";
import { Toaster } from "react-hot-toast";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<AppLayout />}>
           <Route path="/" element={<Dashboard />} />
	   <Route path="/import-connectors" element={<ImportConnectorsPage />} />
	   <Route path="/import-connectors/new-s3" element={<NewS3ConnectorPage />} />
	   <Route path="/parsers" element={<ParsersPage />} />
	   <Route path="/parsers/new" element={<NewParserPage />} />
           <Route path="/create-pipeline" element={<CreatePipeline />} />
	   <Route path="/pipeline-designer" element={<PipelineDesigner />} />
          <Route path="/create-api" element={<CreateAPI />} />
          <Route path="/test-api" element={<TestAPI />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);