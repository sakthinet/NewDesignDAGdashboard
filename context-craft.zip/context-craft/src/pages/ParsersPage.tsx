import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

type ParserProfile = {
  id: string;
  name: string;
  type: string;
};

export default function ParsersPage() {
  const [profiles, setProfiles] = useState<ParserProfile[]>([
    { id: "1", name: "Invoice OCR", type: "Tesseract" },
  ]);

  const navigate = useNavigate();

  const handleDelete = (id: string) => {
    setProfiles(profiles.filter(p => p.id !== id));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Parser Profiles</h1>
        <Button onClick={() => navigate("/parsers/new")}>+ New Profile</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {profiles.map(p => (
          <Card key={p.id} className="shadow-md">
            <CardContent className="p-4 space-y-2">
              <h2 className="font-semibold text-lg">{p.name}</h2>
              <p className="text-gray-600">{p.type}</p>
              <div className="flex gap-2 mt-2">
                <Button size="sm" onClick={() => navigate(`/parsers/${p.id}`)}>View</Button>
                <Button size="sm" variant="destructive" onClick={() => handleDelete(p.id)}>Delete</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}