import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export default function NewParserPage() {
  const [form, setForm] = useState({
    name: "",
    type: "Tesseract",
    language: "eng",
    dpi: "300",
  });

  const [testImage, setTestImage] = useState<File | null>(null);
  const [output, setOutput] = useState<string>("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleTest = async () => {
    if (!testImage) return;
    // TODO: Send form + file to FastAPI for test run
    setOutput("Sample parsed text from OCR service...");
  };

  const handleSave = () => {
    console.log("Parser Saved", form);
    // TODO: Persist profile to backend
  };

  return (
    <div className="p-6 max-w-xl space-y-4">
      <h1 className="text-2xl font-bold">New Parser Profile</h1>

      <Input name="name" placeholder="Profile Name" value={form.name} onChange={handleChange} />

      <Select
        onValueChange={(value) => setForm({ ...form, type: value })}
        defaultValue={form.type}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Parser Type" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="Tesseract">Tesseract</SelectItem>
          <SelectItem value="PaddleOCR">PaddleOCR</SelectItem>
          <SelectItem value="GraniteOCR">Granite OCR</SelectItem>
        </SelectContent>
      </Select>

      <Input name="language" placeholder="Language (eng)" value={form.language} onChange={handleChange} />
      <Input name="dpi" placeholder="DPI (300)" value={form.dpi} onChange={handleChange} />

      <div className="space-y-2">
        <label className="block font-medium">Test Image</label>
        <Input type="file" accept="image/*,.pdf" onChange={(e) => setTestImage(e.target.files?.[0] || null)} />
        <Button onClick={handleTest}>Run Test</Button>
      </div>

      {output && (
        <div className="p-4 bg-gray-100 rounded-lg">
          <h2 className="font-semibold mb-2">Parsed Output</h2>
          <pre className="text-sm whitespace-pre-wrap">{output}</pre>
        </div>
      )}

      <Button className="w-full mt-4" onClick={handleSave}>
        Save Profile
      </Button>
    </div>
  );
}