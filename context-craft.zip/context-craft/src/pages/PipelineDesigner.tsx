import React, { useState, useCallback, useMemo } from "react";
import ReactFlow, { Background, Controls } from "reactflow";
import type { Node, Edge, NodeTypes } from "reactflow";
import "reactflow/dist/style.css";

/* -------------------------
   Custom Node Component
-------------------------- */
const CustomNode = ({ data }: any) => {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{
        padding: 10,
        border: "1px solid #222",
        borderRadius: 5,
        position: "relative",
        background: "#fff",
        minWidth: 120,
        textAlign: "center",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Node body click → open properties */}
      <div
        onClick={(e) => {
          e.stopPropagation();
          data.onSelect(data.id);
        }}
        style={{ cursor: "pointer" }}
      >
        {data.label}
      </div>

      {/* Plus button only on hover */}
      {hovered && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            data.onAddNext(data.id);
          }}
          style={{
            position: "absolute",
            right: -12,
            top: "50%",
            transform: "translateY(-50%)",
            borderRadius: "50%",
            border: "1px solid #222",
            background: "#eee",
            width: 20,
            height: 20,
            cursor: "pointer",
            fontSize: 14,
            lineHeight: "16px",
          }}
        >
          +
        </button>
      )}
    </div>
  );
};

/* -------------------------
   Stable nodeTypes
-------------------------- */
const nodeTypes: NodeTypes = {
  customNode: CustomNode,
};

/* -------------------------
   Main Component
-------------------------- */
const PipelineDesigner: React.FC = () => {
  const [nodes, setNodes] = useState<Node[]>([
    {
      id: "1",
      type: "customNode",
      data: { label: "Source Node", type: "source" },
      position: { x: 100, y: 100 },
    },
  ]);

  const [edges, setEdges] = useState<Edge[]>([]);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [processName, setProcessName] = useState("My Process");

  /* Select node → open properties */
  const onSelectNode = useCallback((id: string) => {
    setSelectedNodeId(id);
  }, []);

  /* Click on canvas → show process-level properties */
  const onPaneClick = useCallback(() => {
    setSelectedNodeId(null);
  }, []);

  /* Add next node neatly to the right */
  const onAddNextNode = useCallback(
    (sourceId: string) => {
      const sourceNode = nodes.find((n) => n.id === sourceId);
      if (!sourceNode) return;

      const newId = (nodes.length + 1).toString();
      const newNode: Node = {
        id: newId,
        type: "customNode",
        data: {
          label: `Node ${newId}`,
          type: "processor", // default type for new nodes
        },
        position: {
          x: sourceNode.position.x + 180,
          y: sourceNode.position.y,
        },
      };

      setNodes((nds) => [...nds, newNode]);
      setEdges((eds) => [
        ...eds,
        { id: `e${sourceId}-${newId}`, source: sourceId, target: newId },
      ]);
    },
    [nodes]
  );

  /* Inject handlers into node data without touching nodeTypes */
  const nodesWithHandlers = useMemo(
    () =>
      nodes.map((n) => ({
        ...n,
        data: {
          ...n.data,
          onSelect: onSelectNode,
          onAddNext: onAddNextNode,
        },
      })),
    [nodes, onSelectNode, onAddNextNode]
  );

  /* Find selected node object */
  const selectedNode = useMemo(
    () => nodes.find((n) => n.id === selectedNodeId) || null,
    [nodes, selectedNodeId]
  );

  /* Handle property changes */
  const updateNodeData = (id: string, key: string, value: any) => {
    setNodes((nds) =>
      nds.map((n) =>
        n.id === id ? { ...n, data: { ...n.data, [key]: value } } : n
      )
    );
  };

  /* Render dynamic fields */
  const renderPropertiesForm = () => {
    if (!selectedNode) {
      // Process-level properties
      return (
        <>
          <h4>Process Properties</h4>
          <label>
            Process Name:
            <input
              type="text"
              value={processName}
              onChange={(e) => setProcessName(e.target.value)}
              style={{ width: "100%", marginTop: 5 }}
            />
          </label>
        </>
      );
    }

    // Node-specific properties
    if (selectedNode.data.type === "source") {
      return (
        <>
          <h4>Source Node Properties</h4>
          <label>
            Label:
            <input
              type="text"
              value={selectedNode.data.label}
              onChange={(e) =>
                updateNodeData(selectedNode.id, "label", e.target.value)
              }
              style={{ width: "100%", marginTop: 5 }}
            />
          </label>
          <label>
            Data Source:
            <select
              value={selectedNode.data.dataSource || "SFTP"}
              onChange={(e) =>
                updateNodeData(selectedNode.id, "dataSource", e.target.value)
              }
              style={{ width: "100%", marginTop: 5 }}
            >
              <option value="SFTP">SFTP</option>
              <option value="Amazon S3">Amazon S3</option>
            </select>
          </label>
        </>
      );
    }

    // Default for other node types
    return (
      <>
        <h4>{selectedNode.data.type} Node Properties</h4>
        <label>
          Label:
          <input
            type="text"
            value={selectedNode.data.label}
            onChange={(e) =>
              updateNodeData(selectedNode.id, "label", e.target.value)
            }
            style={{ width: "100%", marginTop: 5 }}
          />
        </label>
      </>
    );
  };

  return (
    <div style={{ display: "flex", height: "500px" }}>
      {/* Flow Canvas */}
      <div style={{ flex: 1 }}>
        <ReactFlow
          nodes={nodesWithHandlers}
          edges={edges}
          nodeTypes={nodeTypes}
          fitView
          onPaneClick={onPaneClick} // detect canvas click
        >
          <Background />
          <Controls />
        </ReactFlow>
      </div>

      {/* Properties Panel */}
      <div style={{ width: 250, borderLeft: "1px solid #ccc", padding: 10 }}>
        {renderPropertiesForm()}
      </div>
    </div>
  );
};

export default PipelineDesigner;