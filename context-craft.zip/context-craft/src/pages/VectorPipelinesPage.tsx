"use client";

import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "react-hot-toast";
import { Switch } from "@/components/ui/switch";

const sourceTypes = [
  "AWS S3",
  "GCS",
  "Azure Blob",
  "File shares and network drives",
  "Databases",
  "APIs",
  "Streaming Sources",
];

const documentFormats = ["PDF", "DOCX", "HTML", "TXT", "JSON"];

const parserOptions = {
  Local: ["Tesseract", "Unstructured.io SDK", "LayoutParser", "EmbeddedText"],
  Cloud: [
    "Azure Document AI",
    "Google Document AI",
    "AWS Textract",
    "Landing.ai",
    "LlamaParse",
    "Unstructured.io API",
  ],
  LLM: ["GPT Vision", "Claude Vision", "Granite 3.2 Vision"],
};

const preprocessingOptions = [
  "Remove Stop Words",
  "Lowercase",
  "Stemming",
  "Lemmatization",
  "Language Translation",
];

const chunkingStrategies = ["Fixed No of Characters","Recursive Text Splitter", "Sentence Splitter"];

const vectorDBs = ["Qdrant", "Pinecone", "Weaviate"];

const distanceMetrics = ["cosine", "euclidean", "dot"];

const embeddingModels = ["OpenAI", "Cohere", "HuggingFace", "nomic-embed-text:latest"];

const languageOptions = ["English", "Spanish", "German", "French", "Hindi"];

export default function VectorPipelinesPage() {
  const [pipelineName, setPipelineName] = useState("");
  const [selectedFormats, setSelectedFormats] = useState<string[]>([]);
  const [selectedPreprocessing, setSelectedPreprocessing] = useState<string[]>([]);
  const [selectedParser, setSelectedParser] = useState("");
  const [sourceType, setSourceType] = useState("");
  const [uncPath, setUncPath] = useState("");
  const [vectorDb, setVectorDb] = useState("");
  const [embeddingModel, setEmbeddingModel] = useState("");
  const [targetLanguage, setTargetLanguage] = useState("");
  const [chunkingStrategy, setChunkingStrategy] = useState("");
  const [chunkSize, setChunkSize] = useState("");
  const [chunkOverlap, setChunkOverlap] = useState("");
  const [embeddingDimension, setEmbeddingDimension] = useState("");
  const [collectionName, setCollectionName] = useState("");
  const [distanceMetric, setDistanceMetric] = useState("");
  const [showPreview, setShowPreview] = useState(false);

  const toggleFormat = (format: string) => {
    setSelectedFormats((prev) =>
      prev.includes(format) ? prev.filter((f) => f !== format) : [...prev, format]
    );
  };

  const togglePreprocessing = (item: string) => {
    setSelectedPreprocessing((prev) =>
      prev.includes(item) ? prev.filter((f) => f !== item) : [...prev, item]
    );
  };

const handleCreatePipeline = async () => {
  if (!pipelineName.trim() || !/^[A-Za-z]+$/.test(pipelineName.trim())) {
    toast.error("Pipeline name must be alphabetic and not empty");
    return;
  }

  if (!sourceType) {
    toast.error("Please select a data source");
    return;
  }

  if (sourceType === "File shares and network drives" && !uncPath.trim()) {
    toast.error("UNC Folder Path is required for File shares");
    return;
  }

  const payload = {
    pipelineName,
    sourceType,
    uncPath: sourceType === "File shares and network drives" ? uncPath : undefined,
    formats: selectedFormats,
    parser: selectedParser,
    preprocessing: selectedPreprocessing,
    targetLanguage: selectedPreprocessing.includes("Language Translation") ? targetLanguage : undefined,
    chunkingStrategy,
    chunkSize: Number(chunkSize),
    chunkOverlap: Number(chunkOverlap),
    embeddingModel,
    embeddingDimension: Number(embeddingDimension),
    vectorDbType: vectorDb,
    vectorCollection: collectionName,
    vectorMetric: distanceMetric,
  };

  try {
    const res = await fetch("http://localhost:8000/wizard/run-pipeline", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const err = await res.json();
      toast.error(`Failed: ${err.message}`);
    } else {
      const data = await res.json();
      toast.success(`✅ ${data.message || "Pipeline triggered!"}`);
    }
  } catch (error) {
    console.error(error);
    toast.error("Failed to trigger pipeline");
  }
};

  return (
    <div className="p-6 w-full space-y-6">
      <h2 className="text-2xl font-semibold">Document Vectorization Pipeline</h2>

      <Card>
        <CardHeader><CardTitle>Pipeline Name</CardTitle></CardHeader>
        <CardContent>
          <Input value={pipelineName} onChange={(e) => setPipelineName(e.target.value)} placeholder="Enter pipeline name" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Data Source</CardTitle></CardHeader>
        <CardContent>
          <Select value={sourceType} onValueChange={setSourceType}>
            <SelectTrigger><SelectValue placeholder="Select source" /></SelectTrigger>
            <SelectContent>
              {sourceTypes.map((type) => <SelectItem key={type} value={type}>{type}</SelectItem>)}
            </SelectContent>
          </Select>
          {sourceType === "File shares and network drives" && (
            <div className="mt-4 space-y-1">
              <Label>UNC Folder Path</Label>
              <Input value={uncPath} onChange={(e) => setUncPath(e.target.value)} placeholder="\\server\folder" />
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Document Format</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {documentFormats.map((format) => (
            <div key={format} className="flex items-center space-x-2">
              <Checkbox checked={selectedFormats.includes(format)} onCheckedChange={() => toggleFormat(format)} />
              <Label>{format}</Label>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Document Parser</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(parserOptions).map(([group, options]) => (
            <div key={group} className="space-y-2">
              <Label className="text-muted-foreground text-sm">{group}</Label>
              <RadioGroup value={selectedParser} onValueChange={setSelectedParser} className="flex flex-wrap gap-4">
                {options.map((parser) => (
                  <div key={parser} className="flex items-center space-x-2">
                    <RadioGroupItem value={parser} id={parser} />
                    <Label htmlFor={parser}>{parser}</Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Text Preprocessing</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {preprocessingOptions.map((option) => (
            <div key={option} className="flex items-center space-x-2">
              <Checkbox checked={selectedPreprocessing.includes(option)} onCheckedChange={() => togglePreprocessing(option)} />
              <Label>{option}</Label>
            </div>
          ))}
          {selectedPreprocessing.includes("Language Translation") && (
            <div className="mt-4 space-y-1">
              <Label>Select Target Language</Label>
              <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                <SelectTrigger><SelectValue placeholder="Choose language" /></SelectTrigger>
                <SelectContent>
                  {languageOptions.map((lang) => <SelectItem key={lang} value={lang}>{lang}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Chunking</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <Select value={chunkingStrategy} onValueChange={setChunkingStrategy}>
            <SelectTrigger><SelectValue placeholder="Select strategy" /></SelectTrigger>
            <SelectContent>
              {chunkingStrategies.map((strategy) => <SelectItem key={strategy} value={strategy}>{strategy}</SelectItem>)}
            </SelectContent>
          </Select>
          <Input value={chunkSize} onChange={(e) => setChunkSize(e.target.value)} placeholder="Chunk Size" type="number" />
          <Input value={chunkOverlap} onChange={(e) => setChunkOverlap(e.target.value)} placeholder="Chunk Overlap" type="number" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Vectorization</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <Select value={embeddingModel} onValueChange={setEmbeddingModel}>
            <SelectTrigger><SelectValue placeholder="Embedding Model" /></SelectTrigger>
            <SelectContent>
              {embeddingModels.map((model) => <SelectItem key={model} value={model}>{model}</SelectItem>)}
            </SelectContent>
          </Select>
          <Input value={embeddingDimension} onChange={(e) => setEmbeddingDimension(e.target.value)} placeholder="Embedding Dimension" type="number" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Vector DB</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <Select value={vectorDb} onValueChange={setVectorDb}>
            <SelectTrigger><SelectValue placeholder="Select Vector DB" /></SelectTrigger>
            <SelectContent>
              {vectorDBs.map((db) => <SelectItem key={db} value={db}>{db}</SelectItem>)}
            </SelectContent>
          </Select>
          <Input value={collectionName} onChange={(e) => setCollectionName(e.target.value)} placeholder="Collection Name" />
          <Select value={distanceMetric} onValueChange={setDistanceMetric}>
            <SelectTrigger><SelectValue placeholder="Distance Metric" /></SelectTrigger>
            <SelectContent>
              {distanceMetrics.map((metric) => <SelectItem key={metric} value={metric}>{metric}</SelectItem>)}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Live Payload Preview</CardTitle>
          <div className="flex items-center space-x-2">
            <Label>Show</Label>
            <Switch checked={showPreview} onCheckedChange={setShowPreview} />
          </div>
        </CardHeader>
        {showPreview && (
          <CardContent>
            <pre className="bg-muted p-4 rounded-md text-sm overflow-auto whitespace-pre-wrap">
              {JSON.stringify(payload, null, 2)}
            </pre>
          </CardContent>
        )}
      </Card>

      <div>
        <Button className="w-full" onClick={handleCreatePipeline}>
          Create Pipeline
        </Button>
      </div>
    </div>
  );
}