import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function NewS3ConnectorPage() {
  const [form, setForm] = useState({
    name: "",
    accessKeyId: "",
    secretAccessKey: "",
    region: "",
    bucket: "",
    prefix: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    console.log("S3 Connector Saved", form);
    // TODO: integrate with FastAPI backend to save Airbyte source
  };

  return (
    <div className="p-6 max-w-xl space-y-4">
      <h1 className="text-2xl font-bold">New Amazon S3 Connector</h1>

      <Input name="name" placeholder="Connector Name" value={form.name} onChange={handleChange} />
      <Input name="accessKeyId" placeholder="AWS Access Key ID" value={form.accessKeyId} onChange={handleChange} />
      <Input name="secretAccessKey" placeholder="AWS Secret Access Key" type="password" value={form.secretAccessKey} onChange={handleChange} />
      <Input name="region" placeholder="Region (e.g. us-east-1)" value={form.region} onChange={handleChange} />
      <Input name="bucket" placeholder="Bucket Name" value={form.bucket} onChange={handleChange} />
      <Input name="prefix" placeholder="Optional Path Prefix" value={form.prefix} onChange={handleChange} />

      <Button className="w-full mt-4" onClick={handleSave}>
        Save Connector
      </Button>
    </div>
  );
}