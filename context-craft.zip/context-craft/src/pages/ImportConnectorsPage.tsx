import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";

type Connector = {
  id: string;
  name: string;
  type: string;
};

export default function ImportConnectorsPage() {
  const [connectors, setConnectors] = useState<Connector[]>([
    { id: "1", name: "S3 Finance Docs", type: "Amazon S3" },
  ]);

  const navigate = useNavigate();

  const handleDelete = (id: string) => {
    setConnectors(connectors.filter(c => c.id !== id));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Import Connectors</h1>
        <Button onClick={() => navigate("/import-connectors/new-s3")}>
          + New Connector
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {connectors.map(c => (
          <Card key={c.id} className="shadow-md">
            <CardContent className="p-4 space-y-2">
              <h2 className="font-semibold text-lg">{c.name}</h2>
              <p className="text-gray-600">{c.type}</p>
              <div className="flex gap-2 mt-2">
                <Button size="sm" onClick={() => navigate(`/import-connectors/${c.id}`)}>
                  View
                </Button>
                <Button size="sm" variant="destructive" onClick={() => handleDelete(c.id)}>
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}