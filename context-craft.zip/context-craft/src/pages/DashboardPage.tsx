import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "@/components/ui/card";
import { ENDPOINTS, API_BASE_URL } from "@/config";
import toast from "react-hot-toast";

interface Api {
  name: string;
  url: string;
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const [apis, setApis] = useState<Api[]>([]);
  const [apiCallCount, setApiCallCount] = useState<number>(0);
  const [vectorizedCount, setVectorizedCount] = useState<number>(0);
  const [activePipelineCount, setActivePipelineCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchApis = async () => {
      try {
        const res = await fetch(ENDPOINTS.STATUS);
        const data = await res.json();
        const extractedApis = data.mounted_routers.map((router: any) => ({
          name: router.name,
          url: router.endpoints[0] || router.prefix,
        }));
        setApis(extractedApis);
      } catch (err) {
        toast.error("Failed to load APIs");
        console.error("API load error:", err);
      } finally {
        setLoading(false);
      }
    };

    const fetchApiCallCount = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/logs/count`);
        const data = await res.json();
        setApiCallCount(data.total_api_calls ?? 0);
      } catch (err) {
        console.error("Failed to fetch API call count", err);
      }
    };

    const fetchVectorizedCount = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/vectorized-documents/count`);
        const data = await res.json();
        setVectorizedCount(data.total_vectorized_documents ?? 0);
      } catch (err) {
        console.error("Failed to fetch vectorized document count", err);
      }
    };

    const fetchActivePipelines = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/active-pipelines/count`);
        const data = await res.json();
        setActivePipelineCount(data.active_pipelines ?? 0);
      } catch (err) {
        console.error("Failed to fetch active pipeline count", err);
      }
    };

    fetchApis();
    fetchApiCallCount();
    fetchVectorizedCount();
    fetchActivePipelines();
  }, []);

  return (
    <div className="space-y-6 p-6">
      <h1 className="text-3xl font-bold">Dashboard</h1>
      <p className="text-sm text-gray-600">
        Overview of your vectorization pipelines and APIs
      </p>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Active APIs" value={apis.length} color="text-blue-600" subtitle="APIs Deployed" />
        <StatCard title="Number of API Calls" value={apiCallCount} color="text-purple-600" subtitle="Search requests" />
        <StatCard title="Active Pipelines" value={activePipelineCount} color="text-green-600" subtitle="In Progress" />
        <StatCard title="Documents Vectorized" value={vectorizedCount} color="text-orange-600" subtitle="Documents vectorized" />
      </div>

      {/* Active APIs */}
      <Card>
        <CardHeader>
          <CardTitle>Active APIs</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : apis.length === 0 ? (
            <p className="text-red-500">No active APIs found</p>
          ) : (
            <div className="space-y-3">
              {apis.map((api) => (
                <div
                  key={api.url}
                  className="flex items-center justify-between bg-muted p-4 rounded-xl"
                >
                  <div>
                    <div className="font-semibold">{api.name}</div>
                    <div className="text-sm text-gray-500">{api.url}</div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      onClick={() =>
                        navigate("/test-api", { state: { apiUrl: api.url } })
                      }
                    >
                      Test
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={async () => {
                        try {
                          const res = await fetch(
                            `${API_BASE_URL}/wizard/delete/${api.name}`,
                            { method: "DELETE" }
                          );
                          const data = await res.json();
                          toast.success(data.message);
                          setApis((prev) =>
                            prev.filter((a) => a.name !== api.name)
                          );
                        } catch (err) {
                          toast.error("Delete failed");
                          console.error(err);
                        }
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* DAG Runs */}
      <DagRunList />
    </div>
  );
}

function StatCard({
  title,
  value,
  color,
  subtitle,
}: {
  title: string;
  value: number;
  color: string;
  subtitle: string;
}) {
  return (
    <div className="bg-white p-4 rounded-2xl shadow">
      <h3 className="font-semibold">{title}</h3>
      <p className={`text-2xl font-bold ${color}`}>{value.toLocaleString()}</p>
      <p className="text-sm text-gray-500">{subtitle}</p>
    </div>
  );
}

export function DagRunList() {
  const [dagRuns, setDagRuns] = useState<any[]>([]);
  const [filteredRuns, setFilteredRuns] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState("all");

  const fetchDagRuns = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/airflow/dag-runs/DataForGenAI`);
      const data = await res.json();
      setDagRuns(data);
      setLoading(false);
    } catch (err) {
      console.error("Failed to fetch DAG runs", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDagRuns();
  }, []);

  useEffect(() => {
    if (filter === "all") {
      setFilteredRuns(dagRuns);
    } else {
      setFilteredRuns(dagRuns.filter((run) => run.state === filter));
    }
  }, [filter, dagRuns]);

  return (
    <Card>
      <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
        <CardTitle>DAG Runs: DataForGenAI</CardTitle>
        <div className="flex gap-4">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border rounded px-2 py-1 text-sm"
          >
            <option value="all">All</option>
            <option value="success">Success</option>
            <option value="failed">Failed</option>
            <option value="running">Running</option>
            <option value="queued">Queued</option>
          </select>
          <Button onClick={fetchDagRuns} disabled={loading}>
            {loading ? "Refreshing..." : "Refresh"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {filteredRuns.length === 0 ? (
          <p className="text-gray-500 text-sm">No DAG runs found for selected filter.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full table-auto border rounded text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-3 py-2 text-left">Run ID</th>
		  <th className="px-3 py-2 text-left">DAG ID</th>
                  <th className="px-3 py-2 text-left">Execution Date</th>
                  <th className="px-3 py-2 text-left">Start Date</th>
                  <th className="px-3 py-2 text-left">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredRuns.map((run) => (
                  <tr key={run.run_id} className="border-t hover:bg-gray-50">
                    <td className="px-3 py-2">{run.run_id}</td>
		     <td className="px-3 py-2">{run.dag_id}</td>
                    <td className="px-3 py-2">{new Date(run.execution_date).toLocaleString()}</td>
                    <td className="px-3 py-2">{new Date(run.start_date).toLocaleString()}</td>
                    <td className="px-3 py-2">
                      <span className={`px-2 py-1 rounded text-white text-xs ${
                        run.state === "success"
                          ? "bg-green-500"
                          : run.state === "failed"
                          ? "bg-red-500"
                          : run.state === "running"
                          ? "bg-blue-500"
                          : "bg-gray-500"
                      }`}>
                        {run.state}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}