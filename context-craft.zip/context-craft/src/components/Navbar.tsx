import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function Navbar() {
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:8000/me", { withCredentials: true })
      .then((res) => {
        setUsername(res.data.user);
      })
      .catch(() => {
        setUsername("");
      });
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post("http://localhost:8000/logout", {}, { withCredentials: true });
      navigate("/login");
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  if (!username) return null;

  return (
    <div className="bg-white shadow p-4 flex justify-between items-center rounded-xl mb-4">
      <div className="text-xl font-bold text-gray-800">Context Craft:Transform and Serve Unstructured data to GenAI</div>
      <div className="flex items-center gap-4">
        <span className="text-gray-700">👋 {username}</span>
        <button
          onClick={handleLogout}
          className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md"
        >
          Logout
        </button>
      </div>
    </div>
  );
}