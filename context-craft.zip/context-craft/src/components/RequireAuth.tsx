import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function RequireAuth({ children }: { children: React.ReactNode }) {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:8000/me", { withCredentials: true })
      .then(() => setAuthenticated(true))
      .catch(() => {
        setAuthenticated(false);
        navigate("/login");
      });
  }, [navigate]);

  if (authenticated === null) {
    return <div className="text-center mt-20 text-gray-500">Checking session...</div>;
  }

  return <>{children}</>;
}