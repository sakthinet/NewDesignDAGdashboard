import * as React from "react"
import {
  Toast,
  ToastProps,
  ToastActionElement
} from "@radix-ui/react-toast" // or from your local toast component
import { useToast as useToastPrimitive } from "@/lib/use-toast" // or provide your own

export const useToast = useToastPrimitive

export type { ToastProps, ToastActionElement }
