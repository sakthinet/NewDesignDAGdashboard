import { Outlet, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Sidebar from "./components/Sidebar";
import axios from "axios";

export default function AppLayout() {
  const [username, setUsername] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:8000/me", { withCredentials: true })
      .then(res => setUsername(res.data.user))
      .catch(() => navigate("/login"));
  }, [navigate]);

  const handleLogout = async () => {
    await axios.post("http://localhost:8000/logout", {}, { withCredentials: true });
    localStorage.removeItem("username");
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow px-6 py-4 flex justify-between items-center border-b">
          <h2 className="text-xl font-semibold">Transform & Deliver Unstructured Data To GenAI</h2>
          <div className="flex items-center gap-4">
            {username && <span className="text-sm text-gray-600">Logged in as <strong>{username}</strong></span>}
            <button
              onClick={handleLogout}
              className="bg-red-500 text-white px-3 py-1 text-sm rounded hover:bg-red-600 transition"
            >
              Logout
            </button>
          </div>
        </header>
        <main className="p-6 bg-gray-50 flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}