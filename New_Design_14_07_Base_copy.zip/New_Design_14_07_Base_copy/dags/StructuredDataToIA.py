from airflow import DAG
from airflow.decorators import task
from datetime import datetime
import os, csv, requests, shutil
import xml.etree.ElementTree as ET

# Default configs (can be overridden by DAG configuration)
DEFAULT_WATCH_DIR = "/opt/airflow/data/incomingcsv/"
DEFAULT_PROCESSED_DIR = "/opt/airflow/data/processedcsv/"
DEFAULT_CHUNK_SIZE = 5000
DEFAULT_BEARER_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzdWVAaWFjdXN0b21lci5jb20iLCJ1c2VyX25hbWUiOiJzdWVAaWFjdXN0b21lci5jb20iLCJpc3MiOiJodHRwOi8vMTAuNzMuOTEuMjM6ODA4MCIsInRva2VuX3R5cGUiOiJhY2Nlc3NfdG9rZW4iLCJjbGllbnRfaWQiOiJpbmZvYXJjaGl2ZS5jbGkiLCJhdXRob3JpdGllcyI6WyJHUk9VUF9SRVRFTlRJT05fTUFOQUdFUiIsIkdST1VQX0RFVkVMT1BFUiIsIkdST1VQX0lUX09XTkVSIiwiR1JPVVBfQlVTSU5FU1NfT1dORVIiLCJHUk9VUF9BRE1JTklTVFJBVE9SIiwiR1JPVVBfRU5EX1VTRVIiLCJST0xFX0FETUlOSVNUUkFUT1IiLCJST0xFX0JVU0lORVNTX09XTkVSIiwiUk9MRV9ERVZFTE9QRVIiLCJST0xFX0VORF9VU0VSIiwiUk9MRV9JVF9PV05FUiIsIlJPTEVfUkVURU5USU9OX01BTkFHRVIiXSwiYXVkIjoiaW5mb2FyY2hpdmUuY2xpIiwibmJmIjoxNzUxODcwMTM4LCJncmFudF90eXBlIjoicGFzc3dvcmQiLCJzY29wZSI6WyJzZWFyY2giXSwiZXhwIjozODk5MzUzNzg1LCJpYXQiOjE3NTE4NzAxMzgsImp0aSI6IjQzZjE3MzM3LTdiZWItNGJlOC04NWMzLTZhYzFjMWEzZTA4ZCJ9.OEOX1DoN_d-YHKDBDf290bYRrr2IiujjQqkolLSh34M"
EXPORT_URL_MAP = {
    "PurchaseOrderHeader": "http://10.73.91.23:8765/systemdata/tables/AAAAhw/content",
    "PurchaseOrderItem": "http://10.73.91.23:8765/systemdata/tables/AAAAhg/content",
    "PurchaseOrderPartner": "http://10.73.91.23:8765/systemdata/tables/AAAAhQ/content"
}

default_args = {"owner": "airflow", "retries": 1}

with DAG(
    dag_id="StructuredDataToIA",
    default_args=default_args,
    start_date=datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
    description="Schema and Table Detection,CSV to XML Transformation ,Export with IA",
    tags=['Schema & Table Detection','CSV to XML','Export to InfoArchive']
) as dag:

    @task
    def get_runtime_config(**context):
        """Get runtime configuration from DAG run config or use defaults"""
        dag_run = context.get('dag_run')
        conf = dag_run.conf if dag_run else {}
        
        # Extract config with defaults
        config = {
            'watch_dir': conf.get('processing_config', {}).get('watch_dir', DEFAULT_WATCH_DIR),
            'processed_dir': conf.get('processing_config', {}).get('processed_dir', DEFAULT_PROCESSED_DIR),
            'chunk_size': conf.get('chunk_size', DEFAULT_CHUNK_SIZE),
            'bearer_token': conf.get('bearer_token', DEFAULT_BEARER_TOKEN),
            'table_url': conf.get('table_url'),
            'csv_file': conf.get('csv_file'),
            'triggered_by': conf.get('triggered_by', 'manual'),
            'timestamp': conf.get('timestamp', datetime.now().isoformat())
        }
        
        print(f"🔧 Runtime config: {config}")
        return config

    @task
    def find_csv_file(config):
        """Find CSV file based on configuration"""
        watch_dir = config['watch_dir']
        target_file = config.get('csv_file')
        
        if target_file:
            # Look for specific file
            full_path = os.path.join(watch_dir, target_file)
            if os.path.exists(full_path):
                lock_path = full_path + ".lock"
                if not os.path.exists(lock_path):
                    open(lock_path, 'w').close()  # create lock
                    return {"file": full_path, "lock": lock_path}
                else:
                    raise FileExistsError(f"📁 File {target_file} is already being processed")
            else:
                raise FileNotFoundError(f"📁 Specified file {target_file} not found")
        else:
            # Look for any CSV file (original behavior)
            for fname in os.listdir(watch_dir):
                if fname.endswith(".csv"):
                    full_path = os.path.join(watch_dir, fname)
                    lock_path = full_path + ".lock"
                    if not os.path.exists(lock_path):
                        open(lock_path, 'w').close()  # create lock
                        return {"file": full_path, "lock": lock_path}
            raise FileNotFoundError("📁 No unprocessed CSV file found")

    @task
    def extract_metadata(context, config):
        """Extract metadata from file and config"""
        path = context["file"]
        base = os.path.splitext(os.path.basename(path))[0]
        parts = base.split("_")
        schema = parts[0] if parts else "Schema"
        table = parts[1] if len(parts) > 1 else "Unknown"
        
        # Use table_url from config if provided, otherwise use EXPORT_URL_MAP
        url = config.get('table_url')
        if not url:
            url = EXPORT_URL_MAP.get(table)
            if not url:
                raise ValueError(f"🚫 Unsupported table '{table}' and no table_url provided in config")
        
        return {
            "file": path,
            "lock": context["lock"],
            "base": base,
            "schema": schema,
            "table": table,
            "url": url
        }

    @task
    def read_csv_chunks(metadata, config):
        """Read CSV file in chunks"""
        chunk_size = config.get('chunk_size', DEFAULT_CHUNK_SIZE)
        chunks = []
        
        with open(metadata["file"], encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            chunk = []
            for row in reader:
                chunk.append(row)
                if len(chunk) >= chunk_size:
                    chunks.append(chunk)
                    chunk = []
            if chunk:
                chunks.append(chunk)
        
        print(f"📊 Read {len(chunks)} chunks with size {chunk_size}")
        return {"metadata": metadata, "chunks": chunks}

    @task
    def export_chunks(context, config):
        """Export chunks to InfoArchive"""
        metadata = context["metadata"]
        bearer_token = config.get('bearer_token', DEFAULT_BEARER_TOKEN)
        watch_dir = config['watch_dir']
        
        for idx, chunk in enumerate(context["chunks"]):
            # Convert chunk to XML
            root = ET.Element(metadata["schema"])
            middle = ET.SubElement(root, metadata["table"])
            for row in chunk:
                row_elem = ET.SubElement(middle, "ROW")
                for k, v in row.items():
                    child = ET.SubElement(row_elem, k.strip().replace(" ", "_"))
                    child.text = str(v) if v else ""
            xml_data = ET.tostring(root, encoding="utf-8")
            temp_file = os.path.join(watch_dir, f"{metadata['base']}_chunk_{idx}.xml")
            with open(temp_file, "wb") as f:
                f.write(xml_data)

            # Export via POST
            with open(temp_file, "rb") as f:
                xml_content = f.read()
                response = requests.post(
                    url=metadata["url"],
                    headers={
                        "Authorization": f"Bearer {bearer_token}",
                        "Content-Type": "application/xml"
                    },
                    data=xml_content
                )
            print(f"📤 Chunk {idx} exported | Status: {response.status_code}")
            print(f"⚠️ Response Status: {response.status_code}")
            print(f"📨 Response Text: {response.text}")
            os.remove(temp_file)

    @task
    def cleanup(context, config):
        """Clean up processed files"""
        processed_dir = config['processed_dir']
        
        # Create processed directory if it doesn't exist
        os.makedirs(processed_dir, exist_ok=True)
        
        # Move file to processed directory
        shutil.move(context["metadata"]["file"], os.path.join(processed_dir, os.path.basename(context["metadata"]["file"])))
        
        # Remove lock file
        os.remove(context["metadata"]["lock"])
        
        print(f"✅ File moved and lock removed: {context['metadata']['file']}")

    # Chain execution with configuration
    runtime_config = get_runtime_config()
    file_context = find_csv_file(runtime_config)
    metadata_context = extract_metadata(file_context, runtime_config)
    chunks_context = read_csv_chunks(metadata_context, runtime_config)
    export_chunks(chunks_context, runtime_config) >> cleanup(chunks_context, runtime_config)
