
# PowerShell script to copy file to WSL
$sourcePath = "D:\\Programming\\Reactjs\\InfoArchive_project\\Newdesign\\14_07\\AirflowDagCrafter_New_Design_10_07\\input-files\\migration_epics.csv"
$targetPath = "\\\\wsl$\\Ubuntu-22.04\\home\\netrasami\\airflow\\data\\incomingcsv\\migration_epics.csv"

Write-Host "PowerShell copy operation started"
Write-Host "Source: $sourcePath"
Write-Host "Target: $targetPath"

# Create directory if it doesn't exist
$targetDir = [System.IO.Path]::GetDirectoryName($targetPath)
if (-not (Test-Path $targetDir)) {
    Write-Host "Creating directory: $targetDir"
    New-Item -ItemType Directory -Path $targetDir -Force
}

# Copy file
Copy-Item -Path $sourcePath -Destination $targetPath -Force
if (Test-Path $targetPath) {
    Write-Host "File successfully copied to: $targetPath"
    exit 0
} else {
    Write-Host "Failed to copy file to: $targetPath"
    exit 1
}
