// Airflow API Types
export interface AirflowDAG {
  dag_id: string;
  is_paused: boolean;
  is_active: boolean;
  last_parsed_time: string | null;
  last_pickled: string | null;
  last_expired: string | null;
  scheduler_lock: boolean | null;
  pickle_id: string | null;
  default_view: string;
  fileloc: string;
  file_token: string;
  owners: string[];
  description: string | null;
  schedule_interval: ScheduleInterval;
  tags: AirflowTag[];
  max_active_tasks: number;
  max_active_runs: number;
  has_task_concurrency_limits: boolean;
  has_import_errors: boolean;
  next_dagrun: string | null;
  next_dagrun_data_interval_start: string | null;
  next_dagrun_data_interval_end: string | null;
  next_dagrun_create_after: string | null;
}

export interface AirflowDAGRun {
  dag_run_id: string;
  dag_id: string;
  execution_date: string;
  start_date: string | null;
  end_date: string | null;
  state: DAGRunState;
  external_trigger: boolean;
  run_type: string;
  conf: Record<string, any>;
  data_interval_start: string | null;
  data_interval_end: string | null;
  last_scheduling_decision: string | null;
  run_order: number;
}

export interface AirflowTaskInstance {
  task_id: string;
  dag_id: string;
  run_id: string;
  execution_date: string;
  start_date: string | null;
  end_date: string | null;
  duration: number | null;
  state: TaskInstanceState;
  try_number: number;
  max_tries: number;
  hostname: string;
  unixname: string;
  job_id: number | null;
  pool: string;
  pool_slots: number;
  queue: string;
  priority_weight: number;
  operator: string;
  queued_dttm: string | null;
  pid: number | null;
  executor_config: Record<string, any>;
  sla_miss: any | null;
  rendered_fields: Record<string, any>;
  test_mode: boolean;
  task: AirflowTask;
  dag_run: AirflowDAGRun;
}

export interface AirflowTask {
  task_id: string;
  task_display_name: string;
  owner: string;
  start_date: string;
  end_date: string | null;
  trigger_rule: string;
  extra_links: any[];
  depends_on_past: boolean;
  wait_for_downstream: boolean;
  retries: number;
  queue: string;
  pool: string;
  pool_slots: number;
  execution_timeout: any | null;
  retry_delay: any | null;
  retry_exponential_backoff: boolean;
  priority_weight: number;
  weight_rule: string;
  ui_color: string;
  ui_fgcolor: string;
  template_fields: string[];
  sub_dag: any | null;
  downstream_task_ids: string[];
  upstream_task_ids: string[];
}

export interface AirflowTag {
  name: string;
  color?: string;
}

export interface ScheduleInterval {
  __type: string;
  days: number;
  seconds: number;
  microseconds: number;
}

export type DAGRunState = 
  | 'queued'
  | 'running' 
  | 'success'
  | 'failed'
  | 'up_for_retry'
  | 'up_for_reschedule'
  | 'upstream_failed'
  | 'skipped'
  | 'scheduled';

export type TaskInstanceState = 
  | 'none'
  | 'scheduled'
  | 'queued'
  | 'running'
  | 'success'
  | 'shutdown'
  | 'restarting'
  | 'failed'
  | 'up_for_retry'
  | 'up_for_reschedule'
  | 'upstream_failed'
  | 'skipped'
  | 'removed'
  | 'deferred';

// API Response Types
export interface AirflowAPIResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
}

export interface AirflowDAGListResponse extends AirflowAPIResponse {
  dags: AirflowDAG[];
  total: number;
}

export interface AirflowDAGResponse extends AirflowAPIResponse {
  dag: AirflowDAG;
  runs: AirflowDAGRun[];
  tasks: AirflowTask[];
}

export interface AirflowDAGRunsResponse extends AirflowAPIResponse {
  runs: AirflowDAGRun[];
  total: number;
}

export interface AirflowTaskInstancesResponse extends AirflowAPIResponse {
  task_instances: AirflowTaskInstance[];
}

export interface AirflowTriggerResponse extends AirflowAPIResponse {
  dag_run: AirflowDAGRun;
}

export interface AirflowVersionInfo {
  version: string;
  git_version: string | null;
}

export interface AirflowSystemInfo extends AirflowAPIResponse {
  version: AirflowVersionInfo;
  config: {
    airflow_version: string;
    executor: string;
    sql_alchemy_conn: string;
  };
}

// Enhanced DAG with additional frontend data
export interface EnhancedDAG extends AirflowDAG {
  recent_runs: AirflowDAGRun[];
  run_count: number;
  last_run_state?: DAGRunState;
  next_run?: string;
  avg_duration?: number;
}

// Connection and Status Types
export interface AirflowConnectionStatus {
  connected: boolean;
  url: string;
  version?: string;
  error?: string;
  last_checked?: Date;
}

// DAG Statistics
export interface DAGStatistics {
  total_dags: number;
  active_dags: number;
  paused_dags: number;
  dags_with_errors: number;
  total_runs_today: number;
  successful_runs_today: number;
  failed_runs_today: number;
}

// Filter and Sort Options
export interface DAGFilters {
  state?: DAGRunState[];
  paused?: boolean;
  active?: boolean;
  tags?: string[];
  owner?: string[];
  search?: string;
}

export interface DAGSortOptions {
  field: 'dag_id' | 'last_run' | 'next_run' | 'state' | 'owner';
  direction: 'asc' | 'desc';
}

// Configuration for DAG operations
export interface TriggerDAGConfig {
  dag_run_id?: string;
  execution_date?: string;
  conf?: Record<string, any>;
  replace_microseconds?: boolean;
}

export interface UpdateDAGConfig {
  is_paused?: boolean;
}

// Error Types
export interface AirflowError {
  code: string;
  message: string;
  details?: any;
}

// Events and Logs
export interface DAGRunLog {
  timestamp: string;
  level: string;
  message: string;
  dag_id: string;
  run_id: string;
  task_id?: string;
}

export interface TaskLog {
  content: string;
  metadata: {
    task_id: string;
    dag_id: string;
    execution_date: string;
    try_number: number;
  };
}

// Frontend specific types
export interface DAGCardProps {
  dag: EnhancedDAG;
  onTrigger: (dagId: string) => void;
  onPause: (dagId: string, isPaused: boolean) => void;
  onViewDetails: (dag: EnhancedDAG) => void;
}

export interface DAGRunCardProps {
  run: AirflowDAGRun;
  onViewTasks: (run: AirflowDAGRun) => void;
  onDelete?: (runId: string) => void;
}

export interface TaskInstanceCardProps {
  task: AirflowTaskInstance;
  onViewLogs?: (task: AirflowTaskInstance) => void;
  onRetry?: (task: AirflowTaskInstance) => void;
}