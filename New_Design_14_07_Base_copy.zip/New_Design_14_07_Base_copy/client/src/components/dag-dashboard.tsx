import { useState, useEffect, useCallback, useMemo, memo, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Play, 
  Pause, 
  RefreshCw, 
  CheckCircle,
  XCircle,
  MoreHorizontal,
  Activity,
  Database,
  Eye,
  GitBranch,
  Sun,
  Moon,
  Search,
  Filter
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import DAGModal from "./dag-modal";

interface DAG {
  dag_id: string;
  is_paused: boolean;
  is_active: boolean;
  last_parsed_time: string;
  description: string;
  schedule_interval_display?: string;
  tag_names?: string[];
  max_active_runs: number;
  fileloc: string;
  recent_runs: any[];
  run_count: number;
}

interface Statistics {
  total: number;
  active: number;
  paused: number;
  inactive: number;
  avgMaxRuns: number;
}

// Memoized Statistics Card Component
const StatCard = memo(({ title, value, icon: Icon, color }: {
  title: string;
  value: number;
  icon: any;
  color: string;
}) => (
  <Card className="transition-all duration-200 hover:shadow-md border-slate-200">
    <CardContent className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-600 font-medium">{title}</p>
          <p className="text-2xl font-bold mt-1 text-slate-800">{value}</p>
        </div>
        <Icon className={`w-8 h-8 ${color}`} />
      </div>
    </CardContent>
  </Card>
));

// Updated DagCard Component
const DagCard = memo(({ 
  dag, 
  isSelected, 
  onToggleSelection,
  onDagClick
}: {
  dag: DAG;
  isSelected: boolean;
  onToggleSelection: (dagId: string) => void;
  onDagClick: (dagId: string) => void;
}) => {
  const getFileInfo = useCallback((fileloc: string) => {
    const parts = fileloc.split('/');
    const filename = parts[parts.length - 1];
    const directory = parts.slice(0, -1).join('/');
    return { filename, directory };
  }, []);

  const getStatusColor = useCallback((isPaused: boolean, isActive: boolean) => {
    if (!isActive) return 'bg-slate-100 text-slate-700 border-slate-300';
    if (isPaused) return 'bg-amber-100 text-amber-800 border-amber-300';
    return 'bg-emerald-100 text-emerald-800 border-emerald-300';
  }, []);

  const getStatusText = useCallback((isPaused: boolean, isActive: boolean) => {
    if (!isActive) return 'Inactive';
    if (isPaused) return 'Paused';
    return 'Active';
  }, []);

  const fileInfo = useMemo(() => getFileInfo(dag.fileloc), [dag.fileloc, getFileInfo]);
  
  return (
    <div 
      className={`rounded-xl border-2 transition-all duration-300 hover:shadow-xl hover:scale-[1.02] cursor-pointer ${
        isSelected ? 'ring-2 ring-blue-500' : ''
      } ${
        'bg-white border-gray-200 hover:border-gray-300'
      }`}
      onClick={() => onDagClick(dag.dag_id)}
    >
      <div className="p-6">
        {/* Header with Checkbox */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={isSelected}
              onChange={(e) => {
                e.stopPropagation(); // Prevent modal from opening
                onToggleSelection(dag.dag_id);
              }}
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
              aria-label={`Select Workspace ${dag.dag_id}`}
            />
            <div className={`w-2 h-8 rounded-full ${
              dag.is_active && !dag.is_paused ? 'bg-cyan-500' : 
              dag.is_paused ? 'bg-orange-500' : 'bg-gray-400'
            }`}></div>
            <div>
              <h3 className={`text-lg font-bold truncate max-w-48`} title={dag.dag_id}>
                {dag.dag_id}
              </h3>
              <span className="text-2xl">
                {dag.is_paused ? '⏸️' : dag.is_active ? '▶️' : '⏹️'}
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className={`px-3 py-1 rounded-full text-xs font-bold border-2 ${getStatusColor(dag.is_paused, dag.is_active)}`}>
              {getStatusText(dag.is_paused, dag.is_active)}
            </span>
          </div>
        </div>

        {/* Description */}
        <p className={`text-sm mb-4 line-clamp-2`}>
          {dag.description || 'No description available'}
        </p>

        {/* File Information */}
        <div className={`mb-4 p-3 rounded-lg`}>
          <div className="text-xs">
            <div className={`font-semibold truncate`} title={fileInfo.filename}>
              📁 {fileInfo.filename}
            </div>
            <div className={`mt-1 text-xs truncate`} title={fileInfo.directory}>
              {fileInfo.directory}
            </div>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-2 gap-4 text-sm mb-4">
          <div>
            <span className={``}>Schedule:</span>
            <div className={`font-semibold mt-1 truncate`} title={dag.schedule_interval_display || 'None'}>
              {dag.schedule_interval_display || 'None'}
            </div>
          </div>
          <div>
            <span className={``}>Max Runs:</span>
            <div className={`font-semibold mt-1`}>
              {dag.max_active_runs || 0}
            </div>
          </div>
        </div>

        {/* Last Parsed */}
        <div className="text-xs mb-4">
          <span className={``}>Last Parsed:</span>
          <div className={`mt-1`}>
            {dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}
          </div>
        </div>

        {/* Tags */}
        {dag.tag_names && dag.tag_names.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {dag.tag_names.slice(0, 3).map((tagName, tagIndex) => (
              <span key={tagIndex} className={`text-xs px-2 py-1 rounded-full truncate max-w-20 ${
                'bg-blue-100 text-blue-800 border border-blue-200'
              }`} title={tagName}>
                {tagName}
              </span>
            ))}
            {dag.tag_names.length > 3 && (
              <span className={`text-xs px-2 py-1 rounded-full ${
                'bg-gray-100 text-gray-600'
              }`}>
                +{dag.tag_names.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Recent Runs Info */}
        <div className="text-xs text-gray-500">
          <span>Recent Runs: {dag.recent_runs?.length || 0}</span>
        </div>
      </div>
    </div>
  );
});

// Memoized Search and Filters Component (unchanged)
const SearchAndFilters = memo(({ 
  searchTerm, 
  onSearchChange, 
  statusFilter, 
  onStatusFilterChange, 
  onClearFilters,
  darkMode,
  resultCount,
  totalCount
}: {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  statusFilter: string;
  onStatusFilterChange: (value: string) => void;
  onClearFilters: () => void;
  darkMode: boolean;
  resultCount: number;
  totalCount: number;
}) => (
  <Card className="mb-6">
    <CardContent className="p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Search */}
        <div className="md:col-span-2 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search DAGs by name or description..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className={`w-full pl-10 pr-4 py-2 rounded-lg border transition-colors ${
              darkMode 
                ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400 focus:border-blue-500' 
                : 'bg-white border-gray-300 text-gray-900 placeholder-gray-500 focus:border-blue-500'
            } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20`}
          />
        </div>

        {/* Status Filter */}
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          <select
            value={statusFilter}
            onChange={(e) => onStatusFilterChange(e.target.value)}
            className={`w-full pl-10 pr-4 py-2 rounded-lg border transition-colors appearance-none ${
              darkMode 
                ? 'bg-gray-700 border-gray-600 text-white focus:border-blue-500' 
                : 'bg-white border-gray-300 text-gray-900 focus:border-blue-500'
            } focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-20`}
            aria-label="Filter by status"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>

      {/* Results Summary */}
      <div className="mt-4 flex items-center justify-between">
        <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Showing {resultCount} of {totalCount} Workspaces
          {searchTerm && ` for "${searchTerm}"`}
        </span>
        
        {/* Clear Filters */}
        {(searchTerm || statusFilter !== 'all') && (
          <button
            onClick={onClearFilters}
            className="text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
          >
            Clear filters
          </button>
        )}
      </div>
    </CardContent>
  </Card>
));

export function DagDashboard() {
  const [dags, setDags] = useState<DAG[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  
  // Remove darkMode state - handled by theme system now
  const [viewMode, setViewMode] = useState<'cards' | 'list'>('list'); // Default to list view
  const [selectedDags, setSelectedDags] = useState<Set<string>>(new Set());

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDagId, setSelectedDagId] = useState<string | null>(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Filter states with debouncing
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // CRITICAL: Add refs to prevent infinite loops
  const loadingRef = useRef(false);
  const mountedRef = useRef(true);
  const initialLoadDone = useRef(false);

  const { toast } = useToast();
  const airflowApi = useAirflowApi();

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Calculate statistics using useMemo
  const statistics = useMemo((): Statistics => {
    if (dags.length === 0) {
      return { total: 0, active: 0, paused: 0, inactive: 0, avgMaxRuns: 0 };
    }

    const total = dags.length;
    const active = dags.filter(dag => dag.is_active && !dag.is_paused).length;
    const paused = dags.filter(dag => dag.is_paused).length;
    const inactive = dags.filter(dag => !dag.is_active).length;
    const avgMaxRuns = Math.round(dags.reduce((sum, dag) => sum + (dag.max_active_runs || 0), 0) / total);

    return { total, active, paused, inactive, avgMaxRuns };
  }, [dags]);

  // Filter DAGs using useMemo with debounced search
  const filteredDags = useMemo(() => {
    return dags.filter(dag => {
      const matchesSearch = dag.dag_id.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                           (dag.description || '').toLowerCase().includes(debouncedSearchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || 
                           (statusFilter === 'active' && dag.is_active && !dag.is_paused) ||
                           (statusFilter === 'paused' && dag.is_paused) ||
                           (statusFilter === 'inactive' && !dag.is_active);
      
      return matchesSearch && matchesStatus;
    });
  }, [dags, debouncedSearchTerm, statusFilter]);

  // Paginated DAGs
  const paginatedDags = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredDags.slice(startIndex, endIndex);
  }, [filteredDags, currentPage, itemsPerPage]);

  // Pagination calculations
  const totalPages = Math.ceil(filteredDags.length / itemsPerPage);
  const hasNextPage = currentPage < totalPages;
  const hasPrevPage = currentPage > 1;

  // FIXED: Stable loadData function with proper guards
  const loadData = useCallback(async (forceRefresh = false) => {
    // CRITICAL: Prevent multiple simultaneous calls
    if (loadingRef.current) {
      console.log('⏭️ Load already in progress, skipping...');
      return;
    }

    // CRITICAL: Don't reload if we already have data and it's not a force refresh
    if (!forceRefresh && dags.length > 0 && initialLoadDone.current) {
      console.log('⏭️ Data already loaded, skipping...');
      return;
    }

    loadingRef.current = true;
    setLoading(true);
    setError(null);
    
    try {
      console.log('🔄 Loading Workspaces from Airflow API...');
      const result = await airflowApi.getDags(forceRefresh);
      
      // CRITICAL: Check if component is still mounted
      if (!mountedRef.current) {
        console.log('⏭️ Component unmounted, aborting...');
        return;
      }
      
      if (result && result.dags) {
        console.log(`✅ Loaded ${result.dags.length} Workspaces successfully`);
        setDags(result.dags);
        setLastRefresh(new Date());
        setError(null);
        initialLoadDone.current = true;
      } else {
        throw new Error('No Workspaces data received from API');
      }
    } catch (err) {
      console.error('❌ Error loading Workspaces:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to load Workspaces';
      
      // Only set error if component is still mounted
      if (mountedRef.current) {
        setError(errorMessage);
        toast({
          title: "Failed to load Workspaces",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
      loadingRef.current = false;
    }
  }, [airflowApi, toast, dags.length]); // FIXED: Remove unnecessary dependencies

  const pauseDag = useCallback(async (dagId: string) => {
    try {
      await airflowApi.pauseDag(dagId);
      
      setDags(prev => prev.map(dag => 
        dag.dag_id === dagId ? { ...dag, is_paused: true } : dag
      ));
      
      toast({
        title: "Workspace paused",
        description: `Workspace ${dagId} has been paused`,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to pause Workspace';
      setError(errorMessage);
      toast({
        title: "Failed to pause Workspace",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [airflowApi, toast]);

  const unpauseDag = useCallback(async (dagId: string) => {
    try {
      await airflowApi.unpauseDag(dagId);
      
      setDags(prev => prev.map(dag => 
        dag.dag_id === dagId ? { ...dag, is_paused: false } : dag
      ));
      
      toast({
        title: "Workspace unpaused",
        description: `Workspace ${dagId} has been unpaused`,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to unpause Workspace';
      setError(errorMessage);
      toast({
        title: "Failed to unpause Workspace",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [airflowApi, toast]);

  const triggerDag = useCallback(async (dagId: string) => {
    try {
      const result = await airflowApi.triggerDag(dagId, {
        triggered_by: 'dag_generator',
        timestamp: new Date().toISOString()
      });
      
      if (result) {
        toast({
          title: "Workspace triggered successfully",
          description: `Workspace run has been started for ${dagId}`,
        });
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to trigger Workspace';
      setError(errorMessage);
      toast({
        title: "Failed to trigger Workspace",
        description: errorMessage,
        variant: "destructive",
      });
    }
  }, [airflowApi, toast]);

  const toggleDagSelection = useCallback((dagId: string) => {
    setSelectedDags(prev => {
      const newSelected = new Set(prev);
      if (newSelected.has(dagId)) {
        newSelected.delete(dagId);
      } else {
        newSelected.add(dagId);
      }
      return newSelected;
    });
  }, []);

  const handleClearFilters = useCallback(() => {
    setSearchTerm('');
    setStatusFilter('all');
  }, []);

  const handleManualRefresh = useCallback(() => {
    console.log('🔄 Manual refresh triggered');
    loadData(true); // Force refresh
  }, [loadData]);

  // Modal handlers
  const handleDagClick = useCallback((dagId: string) => {
    setSelectedDagId(dagId);
    setIsModalOpen(true);
  }, []);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedDagId(null);
  }, []);

  // Pagination handlers
  const goToPage = useCallback((page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  }, [totalPages]);

  const goToFirstPage = useCallback(() => {
    setCurrentPage(1);
  }, []);

  const goToLastPage = useCallback(() => {
    setCurrentPage(totalPages);
  }, [totalPages]);

  const goToPrevPage = useCallback(() => {
    setCurrentPage(prev => Math.max(1, prev - 1));
  }, []);

  const goToNextPage = useCallback(() => {
    setCurrentPage(prev => Math.min(totalPages, prev + 1));
  }, [totalPages]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearchTerm, statusFilter]);

  // Enhanced manual refresh with Airflow DAG refresh
  const handleForceRefreshWithAirflow = async () => {
    console.log('🔄 Force refresh with Airflow DAG refresh triggered');
    setLoading(true);
    
    try {
      // Step 1: Force refresh Airflow DAGs
      const refreshResponse = await fetch('/api/airflow/refresh-dags', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      const refreshResult = await refreshResponse.json();
      
      if (refreshResult.success) {
        toast({
          title: "Airflow DAGs refreshed",
          description: refreshResult.message,
        });
      }
      
      // Step 2: Wait for Airflow to process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Step 3: Force reload our data
      await loadData(true);
      
    } catch (error) {
      console.error('Force refresh failed:', error);
      toast({
        title: "Refresh failed",
        description: "Failed to refresh Airflow DAGs",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const clearCache = useCallback(async () => {
    try {
      const response = await fetch('/api/cache/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        toast({
          title: "Cache cleared",
          description: "All cached data has been cleared",
        });
        // Force reload after clearing cache
        loadData(true);
      }
    } catch (error) {
      console.error('Failed to clear cache:', error);
      toast({
        title: "Failed to clear cache",
        description: "Could not clear cache",
        variant: "destructive",
      });
    }
  }, [loadData, toast]);

  // FIXED: Load data only once on component mount
  useEffect(() => {
    mountedRef.current = true;
    
    // Only load if we don't have data yet
    if (dags.length === 0 && !initialLoadDone.current) {
      console.log('🏗️ Component mounted, loading initial data...');
      loadData();
    }
    
    // Cleanup function
    return () => {
      console.log('🧹 Component unmounting...');
      mountedRef.current = false;
    };
  }, []); // CRITICAL: Empty dependency array - only run once!

  if (loading && dags.length === 0) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${
        'bg-gray-50'
      }`}>
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <h2 className={`text-xl font-semibold mb-2`}>
            Loading Workspaces...
          </h2>
          <p className={``}>
            Fetching data from Airflow 3.x API
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen transition-colors duration-300 bg-background relative">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6">{/* Header */}
        <div className="rounded-xl border p-6 mb-6 bg-white border-slate-200 shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-800">
                Migration Dashboard
              </h1>
              <p className="mt-1 text-slate-600">
                Monitor and manage your workspaces
              </p>
            </div>
            <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
              {/* View Mode Toggle */}
              <div className="flex rounded-lg p-1 bg-slate-100">
                <button
                  onClick={() => setViewMode('cards')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    viewMode === 'cards'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  📇 Cards
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
                    viewMode === 'list'
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  📋 List
                </button>
              </div>

              {lastRefresh && (
                <span className="text-sm text-slate-500">
                  Last updated: {lastRefresh.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <StatCard title="Total Workspace" value={statistics.total} icon={Database} color="text-blue-600" />
          <StatCard title="Active Workspace" value={statistics.active} icon={CheckCircle} color="text-emerald-600" />
          <StatCard title="Paused Workspace" value={statistics.paused} icon={Pause} color="text-amber-600" />
          <StatCard title="Avg Max Runs" value={statistics.avgMaxRuns} icon={Activity} color="text-purple-600" />
        </div>

        {/* Search and Filters */}
        <SearchAndFilters
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          onClearFilters={handleClearFilters}
          darkMode={false}
          resultCount={filteredDags.length}
          totalCount={dags.length}
        />

        {/* Error Display */}
        {error && (
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-start">
                <XCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5" />
                <div>
                  <h3 className="font-bold text-red-800">Error</h3>
                  <p className="mt-1 text-sm text-red-700">{error}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4">
              <Button
                onClick={handleManualRefresh}
                disabled={loading}
              >
                {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                {loading ? 'Loading...' : 'Refresh Cache'}
              </Button>
              
              <Button
                onClick={handleForceRefreshWithAirflow}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
                Force Airflow Refresh
              </Button>
              
              <Button
                onClick={clearCache}
                variant="outline"
                disabled={loading}
              >
                Clear Cache
              </Button>
              
              <Button
                onClick={async () => {
                  try {
                    const result = await airflowApi.testConnection();
                    if (result && result.connected) {
                      toast({
                        title: "Connection successful",
                        description: `Connected to Airflow at ${result.url}`,
                      });
                    } else {
                      throw new Error(result?.error || 'Connection test failed');
                    }
                  } catch (err) {
                    const errorMessage = err instanceof Error ? err.message : 'Connection test failed';
                    setError(errorMessage);
                    toast({
                      title: "Connection failed",
                      description: errorMessage,
                      variant: "destructive",
                    });
                  }
                }}
                variant="outline"
                disabled={loading}
              >
                Test Connection
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <GitBranch className="w-5 h-5 mr-2" />
                Workspace Overview ({filteredDags.length}/{dags.length})
                {loading && (
                  <RefreshCw className="w-4 h-4 animate-spin ml-2 text-blue-600" />
                )}
              </div>
              {filteredDags.length > itemsPerPage && (
                <div className="text-sm text-gray-600">
                  Page {currentPage} of {totalPages} 
                </div>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {paginatedDags.length > 0 ? (
              <div className="space-y-4">
                {viewMode === 'cards' ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {paginatedDags.map((dag) => (
                      <DagCard 
                        key={dag.dag_id} 
                        dag={dag}
                        isSelected={selectedDags.has(dag.dag_id)}
                        onToggleSelection={toggleDagSelection}
                        onDagClick={handleDagClick}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {/* List view header */}
                    <div className={`grid grid-cols-12 gap-4 p-3 rounded-lg font-medium text-sm border-b ${
                      'bg-slate-50 border-slate-200 text-slate-700'
                    }`}>
                      <div className="col-span-1">
                        <input
                          type="checkbox"
                          checked={selectedDags.size === filteredDags.length && filteredDags.length > 0}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedDags(new Set(filteredDags.map(dag => dag.dag_id)));
                            } else {
                              setSelectedDags(new Set());
                            }
                          }}
                          className="w-4 h-4"
                          aria-label="Select all Workspaces"
                        />
                      </div>
                      <div className="col-span-4">Workspace ID</div>
                      <div className="col-span-1">Status</div>
                      <div className="col-span-2">Schedule</div>
                      <div className="col-span-2">Last Parsed</div>
                      <div className="col-span-2">Actions</div>
                    </div>
                    
                    {/* List view items */}
                    <div className="space-y-1">
                      {paginatedDags.map((dag) => (
                      <div 
                        key={dag.dag_id} 
                        className={`grid grid-cols-12 gap-4 p-3 rounded-lg border transition-colors hover:bg-opacity-50 cursor-pointer ${
                          'border-slate-200 hover:bg-slate-50'
                        }`}
                        onClick={() => handleDagClick(dag.dag_id)}
                      >
                        <div className="col-span-1">
                          <input
                            type="checkbox"
                            checked={selectedDags.has(dag.dag_id)}
                            onChange={(e) => {
                              e.stopPropagation(); // Prevent modal from opening
                              toggleDagSelection(dag.dag_id);
                            }}
                            className="w-4 h-4"
                            aria-label={`Select Workspace ${dag.dag_id}`}
                          />
                        </div>
                        <div className="col-span-4">
                          <div className="font-medium text-slate-800 truncate" title={dag.dag_id}>
                            {dag.dag_id}
                          </div>
                          <div className="text-sm text-slate-500 truncate" title={dag.description || 'No description'}>
                            {dag.description || 'No description'}
                          </div>
                        </div>
                        <div className="col-span-1">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${
                            dag.is_paused ? 'bg-amber-100 text-amber-800 border-amber-300' : 
                            dag.is_active ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 
                            'bg-slate-100 text-slate-700 border-slate-300'
                          }`}>
                            {dag.is_paused ? 'Paused' : dag.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        <div className="col-span-2 text-slate-700 truncate" title={dag.schedule_interval_display || 'None'}>
                          {dag.schedule_interval_display || 'None'}
                        </div>
                        <div className="col-span-2 text-slate-700 truncate" title={dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}>
                          {dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}
                        </div>
                        <div className="col-span-2">
                          <div className="text-sm text-slate-500">
                            No actions available
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="font-bold mb-2">
                  {dags.length === 0 ? 'No Workspaces found' : 'No Workspaces match your filters'}
                </h3>
                <p className="mb-4 text-gray-500">
                  {dags.length === 0 
                    ? 'Click "Refresh Workspaces" to load Workspaces from Airflow 3.x API' 
                    : 'Try adjusting your search terms or filters'}
                </p>
                {dags.length === 0 && (
                  <Button onClick={handleManualRefresh} disabled={loading}>
                    {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : 'Refresh DAGs'}
                  </Button>
                )}
              </div>
            )}

            {/* Pagination Controls */}
            {filteredDags.length > itemsPerPage && (
              <div className="mt-6 flex items-center justify-between border-t pt-4">
                <div className="text-sm text-gray-600">
                  Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredDags.length)} of {filteredDags.length} Workspaces
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToFirstPage}
                    disabled={!hasPrevPage}
                    className="px-3 py-1"
                  >
                    First
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToPrevPage}
                    disabled={!hasPrevPage}
                    className="px-3 py-1"
                  >
                    Previous
                  </Button>
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      const pageNum = Math.max(1, Math.min(currentPage - 2, totalPages - 4)) + i;
                      if (pageNum > totalPages) return null;
                      return (
                        <Button
                          key={pageNum}
                          variant={pageNum === currentPage ? "default" : "outline"}
                          size="sm"
                          onClick={() => goToPage(pageNum)}
                          className="px-3 py-1 min-w-[32px]"
                        >
                          {pageNum}
                        </Button>
                      );
                    })}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToNextPage}
                    disabled={!hasNextPage}
                    className="px-3 py-1"
                  >
                    Next
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToLastPage}
                    disabled={!hasNextPage}
                    className="px-3 py-1"
                  >
                    Last
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* DAG Modal */}
        <DAGModal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          dagId={selectedDagId}
          darkMode={false}
          airflowApi={airflowApi}
        />
      </div>
    </div>
  );
}