import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowRight, RefreshCw, Play, CheckCircle, X, ExternalLink, Eye, AlertCircle, Download, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { XmlDownloadButton } from "./xml-download-button";

interface ViewXmlSchemaProps {
  uploadedFile: UploadedFile | null;
  config: DagConfig;
  onPrev: () => void;
  onNext: () => void;
}

interface DagRun {
  dagId: string;
  runId: string;
  state: 'success' | 'running' | 'failed' | 'queued';
  runType: 'manual' | 'scheduled';
  startDate: string;
  endDate?: string;
  duration?: string;
  dagVersion: string;
}

interface XmlFile {
  fileName: string;
  path: string;
  size: number;
  modified: string;
}

export function ViewXmlSchema({ uploadedFile, config, onPrev, onNext }: ViewXmlSchemaProps) {
  const [dagRuns, setDagRuns] = useState<DagRun[]>([]);
  const [taskInstances, setTaskInstances] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingTasks, setIsLoadingTasks] = useState(false);
  const { toast } = useToast();
  const { getDagRuns, getTaskInstances } = useAirflowApi();

  useEffect(() => {
    const fetchDagData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch DAG runs for IA_XML_Generator
        const runsResult = await getDagRuns('IA_XML_Generator', 10);
        
        if (runsResult && runsResult.runs) {
          // Transform the runs data to match our DagRun interface
          const transformedRuns: DagRun[] = runsResult.runs.map(run => ({
            dagId: run.dag_id || 'IA_XML_Generator',
            runId: run.run_id || run.dag_run_id || 'unknown',
            state: run.state || 'unknown',
            runType: run.run_type || 'manual',
            startDate: run.start_date || run.execution_date || '',
            endDate: run.end_date || undefined,
            duration: run.duration || (run.end_date && run.start_date ? calculateDuration(run.start_date, run.end_date) : undefined),
            dagVersion: 'v1'
          }));
          
          setDagRuns(transformedRuns);
          
          // If we have runs, fetch task instances for the latest run
          if (transformedRuns.length > 0) {
            const latestRun = transformedRuns[0];
            await fetchTaskInstances(latestRun.dagId, latestRun.runId);
          }
        } else {
          // Fallback to mock data if no real data available
          const mockDagRuns: DagRun[] = [
            {
              dagId: 'IA_XML_Generator',
              runId: '2025-07-10_06:53:59',
              state: 'failed',
              runType: 'manual',
              startDate: '2025-07-10, 06:53:02',
              endDate: '2025-07-10, 06:53:09',
              duration: '6.67s',
              dagVersion: 'v1'
            }
          ];
          
          setDagRuns(mockDagRuns);
          // Load mock task instances
          await fetchTaskInstances('IA_XML_Generator', '2025-07-10_06:53:59');
        }
        
      } catch (error) {
        console.error('Error fetching DAG data:', error);
        toast({
          title: "Error",
          description: "Failed to load DAG execution data.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchDagData();
  }, [getDagRuns, getTaskInstances, toast, uploadedFile]);

  const calculateDuration = (startDate: string, endDate: string) => {
    try {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const diff = end.getTime() - start.getTime();
      const seconds = Math.floor(diff / 1000);
      const minutes = Math.floor(seconds / 60);
      const hours = Math.floor(minutes / 60);
      
      if (hours > 0) {
        return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
      } else if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
      } else {
        return `${seconds}s`;
      }
    } catch (error) {
      return 'unknown';
    }
  };

  const fetchTaskInstances = async (dagId: string, runId: string) => {
    try {
      setIsLoadingTasks(true);
      
      const taskResult = await getTaskInstances(dagId, runId);
      
      if (taskResult && taskResult.task_instances) {
        setTaskInstances(taskResult.task_instances);
      } else {
        // Fallback to mock data
        const mockTaskInstances = [
          {
            task_id: 'process_schema_configuration',
            state: 'success',
            start_date: '2025-07-10T06:53:02Z',
            end_date: '2025-07-10T06:53:04Z',
            duration: '2.1s',
            try_number: 1,
            dag_id: dagId,
            run_id: runId,
            operator: 'PythonOperator',
            log_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/process_schema_configuration/logs/1`,
            details_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/process_schema_configuration`
          },
          {
            task_id: 'generate_xml_schema',
            state: 'failed',
            start_date: '2025-07-10T06:53:04Z',
            end_date: '2025-07-10T06:53:07Z',
            duration: '3.2s',
            try_number: 1,
            dag_id: dagId,
            run_id: runId,
            operator: 'PythonOperator',
            log_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/generate_xml_schema/logs/1`,
            details_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/generate_xml_schema`
          },
          {
            task_id: 'validate_xml_schemas',
            state: 'upstream_failed',
            start_date: null,
            end_date: null,
            duration: null,
            try_number: 0,
            dag_id: dagId,
            run_id: runId,
            operator: 'PythonOperator',
            log_url: null,
            details_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/validate_xml_schemas`
          },
          {
            task_id: 'finalize_ia_schemas',
            state: 'upstream_failed',
            start_date: null,
            end_date: null,
            duration: null,
            try_number: 0,
            dag_id: dagId,
            run_id: runId,
            operator: 'PythonOperator',
            log_url: null,
            details_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/finalize_ia_schemas`
          },
          {
            task_id: 'log_completion',
            state: 'upstream_failed',
            start_date: null,
            end_date: null,
            duration: null,
            try_number: 0,
            dag_id: dagId,
            run_id: runId,
            operator: 'PythonOperator',
            log_url: null,
            details_url: `/api/v1/dags/${dagId}/dagRuns/${runId}/taskInstances/log_completion`
          }
        ];
        
        setTaskInstances(mockTaskInstances);
      }
    } catch (error) {
      console.error('Error fetching task instances:', error);
      toast({
        title: "Error",
        description: "Failed to load task instances.",
        variant: "destructive",
      });
    } finally {
      setIsLoadingTasks(false);
    }
  };

  const handleRefresh = async () => {
    setIsLoading(true);
    try {
      // Refresh DAG runs
      const runsResult = await getDagRuns('IA_XML_Generator', 10, 0, true); // Force refresh
      
      if (runsResult && runsResult.runs && runsResult.runs.length > 0) {
        const transformedRuns: DagRun[] = runsResult.runs.map(run => ({
          dagId: run.dag_id || 'IA_XML_Generator',
          runId: run.run_id || run.dag_run_id || 'unknown',
          state: run.state || 'unknown',
          runType: run.run_type || 'manual',
          startDate: run.start_date || run.execution_date || '',
          endDate: run.end_date || undefined,
          duration: run.duration || (run.end_date && run.start_date ? calculateDuration(run.start_date, run.end_date) : undefined),
          dagVersion: 'v1'
        }));
        
        setDagRuns(transformedRuns);
        
        // Refresh task instances for the latest run
        const latestRun = transformedRuns[0];
        await fetchTaskInstances(latestRun.dagId, latestRun.runId);
      }
      
      toast({
        title: "DAG Status Refreshed",
        description: "Latest execution status has been retrieved.",
      });
    } catch (error) {
      console.error('Refresh error:', error);
      toast({
        title: "Error",
        description: "Failed to refresh DAG status.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handler functions for task actions
  const handleViewLogs = (task: any) => {
    if (task.log_url) {
      // Open logs in a new tab/window
      window.open(task.log_url, '_blank');
    } else {
      toast({
        title: "Logs not available",
        description: `No logs available for task ${task.task_id}`,
        variant: "destructive",
      });
    }
  };

  const handleViewDetails = (task: any) => {
    if (task.details_url) {
      // Open task details in a new tab/window
      window.open(task.details_url, '_blank');
    } else {
      toast({
        title: "Task Details",
        description: `Task ID: ${task.task_id}\nState: ${task.state}\nOperator: ${task.operator || 'PythonOperator'}`,
      });
    }
  };

  const handleRefreshTask = async (task: any) => {
    try {
      // Refresh the specific task by reloading all task instances
      if (dagRuns.length > 0) {
        const latestRun = dagRuns[0];
        await fetchTaskInstances(latestRun.dagId, latestRun.runId);
        toast({
          title: "Task Refreshed",
          description: `Task ${task.task_id} status updated`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to refresh task status",
        variant: "destructive",
      });
    }
  };

  const getStateColor = (state: string) => {
    switch (state) {
      case 'success': return 'bg-blue-100 text-blue-800';
      case 'running': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'queued': return 'bg-yellow-100 text-yellow-800';
      case 'upstream_failed': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStateIcon = (state: string) => {
    switch (state) {
      case 'success': return <CheckCircle className="w-4 h-4 text-blue-600" />;
      case 'running': return <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />;
      case 'failed': return <X className="w-4 h-4 text-red-600" />;
      case 'queued': return <Play className="w-4 h-4 text-yellow-600" />;
      case 'upstream_failed': return <X className="w-4 h-4 text-orange-600" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            STEP 3: View Generated IA XML Schema 
          </h2>
          <p className="text-sm text-gray-600 mt-1">
            Monitor DAG execution and download generated XML schema
          </p>
        </div>
        <div className="flex space-x-2">
          <XmlDownloadButton 
            csvFileName={uploadedFile?.fileName || ''}
            variant="outline"
            size="default"
          />
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isLoading}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
        </div>
      </div>

      {/* DAG Execution Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Play className="w-5 h-5" />
            <span>Workspace Table (Calling IA_XML_Generator DAG Run)</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>DAG ID</TableHead>
                  <TableHead>Run After</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Run Type</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>DAG Version(s)</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dagRuns.map((run, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{run.dagId}</TableCell>
                    <TableCell className="text-blue-600">{run.runId}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStateColor(run.state)}>
                        <span className="flex items-center space-x-1">
                          {getStateIcon(run.state)}
                          <span>{run.state}</span>
                        </span>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <span className="flex items-center space-x-1">
                        <Play className="w-3 h-3" />
                        <span>{run.runType}</span>
                      </span>
                    </TableCell>
                    <TableCell>{run.startDate}</TableCell>
                    <TableCell>{run.endDate || '-'}</TableCell>
                    <TableCell>{run.duration || '-'}</TableCell>
                    <TableCell>{run.dagVersion}</TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm">
                          <RefreshCw className="w-3 h-3" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <span className="text-xs">•</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Task Instances Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Play className="w-5 h-5" />
            <span>IA_XML_Generator Task Instances</span>
            {isLoadingTasks && (
              <RefreshCw className="w-4 h-4 animate-spin text-blue-600" />
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Task ID</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Try Number</TableHead>
                  <TableHead>Operator</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {taskInstances.map((task, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">
                      <span className="text-blue-600 hover:underline cursor-pointer">
                        {task.task_id}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStateColor(task.state)}>
                        <span className="flex items-center space-x-1">
                          {getStateIcon(task.state)}
                          <span>{task.state}</span>
                        </span>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {task.start_date ? new Date(task.start_date).toLocaleString() : '-'}
                    </TableCell>
                    <TableCell>
                      {task.end_date ? new Date(task.end_date).toLocaleString() : '-'}
                    </TableCell>
                    <TableCell>{task.duration || '-'}</TableCell>
                    <TableCell>{task.try_number}</TableCell>
                    <TableCell>
                      <span className="text-sm text-gray-600">{task.operator || 'PythonOperator'}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        {/* Log button */}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          title="View Logs"
                          onClick={() => handleViewLogs(task)}
                          disabled={!task.log_url}
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        
                        {/* Details button */}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          title="View Details"
                          onClick={() => handleViewDetails(task)}
                        >
                          <ExternalLink className="w-3 h-3" />
                        </Button>
                        
                        {/* Refresh button */}
                        <Button 
                          variant="ghost" 
                          size="sm"
                          title="Refresh Task"
                          onClick={() => handleRefreshTask(task)}
                        >
                          <RefreshCw className="w-3 h-3" />
                        </Button>
                        
                        {/* Status indicator */}
                        {task.state === 'failed' && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            title="Task Failed"
                            className="text-red-500"
                          >
                            <AlertCircle className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-6 border-t">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Previous</span>
        </Button>
        
        <Button
          onClick={onNext}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
        >
          <span>Next: Transform CSV Data</span>
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
