import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Activity, Clock, CheckCircle, XCircle, AlertCircle, Play, Pause, FileText, ExternalLink } from "lucide-react";
import { useAirflowApi } from '@/hooks/use-airflow-api';
import { TaskInstance, DAGRun } from '@/hooks/use-airflow-api';
import { TaskInstanceState, DAGRunState } from '@/types/airflow';
import { getStateColor, getStateIcon, getStateDescription } from '@/utils/airflow-utils';
import { useToast } from '@/hooks/use-toast';

interface TaskInstancesLiveProps {
  dagId: string;
  runId?: string;
  autoRefresh?: boolean;
  refreshInterval?: number;
  onTaskClick?: (task: TaskInstance) => void;
  className?: string;
}

interface TaskInstanceDisplay extends TaskInstance {
  formattedDuration?: string;
  formattedStartDate?: string;
  formattedEndDate?: string;
  stateColor?: string;
  stateIcon?: React.ReactNode;
  stateDescription?: string;
  log_url?: string;
}

const REFRESH_INTERVALS = {
  FAST: 2000,    // 2 seconds
  NORMAL: 5000,  // 5 seconds
  SLOW: 10000,   // 10 seconds
  DISABLED: 0    // No auto refresh
};

export function TaskInstancesLive({ 
  dagId, 
  runId, 
  autoRefresh = true, 
  refreshInterval = REFRESH_INTERVALS.NORMAL,
  onTaskClick,
  className = ""
}: TaskInstancesLiveProps) {
  const [taskInstances, setTaskInstances] = useState<TaskInstanceDisplay[]>([]);
  const [dagRuns, setDagRuns] = useState<DAGRun[]>([]);
  const [selectedRunId, setSelectedRunId] = useState<string>(runId || '');
  const [isLoading, setIsLoading] = useState(false);
  const [isAutoRefreshing, setIsAutoRefreshing] = useState(autoRefresh);
  const [currentInterval, setCurrentInterval] = useState(refreshInterval);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshCount, setRefreshCount] = useState(0);
  
  const airflowApi = useAirflowApi();
  const { toast } = useToast();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const mountedRef = useRef(true);

  // Format task instance data for display
  const formatTaskInstance = useCallback((task: TaskInstance): TaskInstanceDisplay => {
    const formatDate = (dateStr: string) => {
      if (!dateStr) return 'N/A';
      try {
        return new Date(dateStr).toLocaleString();
      } catch {
        return dateStr;
      }
    };

    const formatDuration = (start: string, end: string) => {
      if (!start || !end) return 'N/A';
      try {
        const startTime = new Date(start).getTime();
        const endTime = new Date(end).getTime();
        const durationMs = endTime - startTime;
        const seconds = Math.floor(durationMs / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        
        if (hours > 0) {
          return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
        } else if (minutes > 0) {
          return `${minutes}m ${seconds % 60}s`;
        } else {
          return `${seconds}s`;
        }
      } catch {
        return 'N/A';
      }
    };

    const stateColor = getStateColor(task.state as TaskInstanceState);
    const stateIcon = getStateIcon(task.state as TaskInstanceState);
    const stateDescription = getStateDescription(task.state as TaskInstanceState);

    return {
      ...task,
      formattedDuration: formatDuration(task.start_date, task.end_date),
      formattedStartDate: formatDate(task.start_date),
      formattedEndDate: formatDate(task.end_date),
      stateColor,
      stateIcon,
      stateDescription,
      log_url: `/api/v1/dags/${task.dag_id}/dagRuns/${task.run_id}/taskInstances/${task.task_id}/logs/1` // Add log URL
    };
  }, []);

  // Fetch DAG runs to get available runs
  const fetchDagRuns = useCallback(async () => {
    if (!dagId) {
      console.warn('⚠️ Cannot fetch DAG runs: missing dagId');
      return;
    }
    
    console.log('🔄 Fetching DAG runs for', dagId);
    
    try {
      const result = await airflowApi.getDagRuns(dagId, 10, 0, true);
      console.log('📦 DAG runs result:', result);
      
      if (result && result.runs) {
        setDagRuns(result.runs);
        console.log('✅ Set DAG runs:', result.runs);
        
        // Set the first run as selected if no run is specified
        if (!selectedRunId && result.runs.length > 0) {
          const firstRunId = result.runs[0].dag_run_id;
          console.log('🎯 Auto-selecting first run:', firstRunId);
          setSelectedRunId(firstRunId);
        }
      } else {
        console.warn('⚠️ No runs in result:', result);
      }
    } catch (error) {
      console.error('❌ Failed to fetch DAG runs:', error);
      setError(`Failed to fetch DAG runs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }, [dagId, selectedRunId, airflowApi]);

  // Fetch task instances for the selected run
  const fetchTaskInstances = useCallback(async (forceRefresh = false) => {
    if (!dagId || !selectedRunId) {
      console.warn('⚠️ Cannot fetch task instances: missing dagId or selectedRunId', { dagId, selectedRunId });
      return;
    }
    
    console.log('🔄 Fetching task instances for', { dagId, selectedRunId, forceRefresh });
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await airflowApi.getTaskInstances(dagId, selectedRunId, forceRefresh);
      console.log('📦 Task instances result:', result);
      
      if (!mountedRef.current) return;
      
      if (result && result.task_instances) {
        console.log('✅ Processing task instances:', result.task_instances);
        const formattedTasks = result.task_instances.map(formatTaskInstance);
        setTaskInstances(formattedTasks);
        setLastRefresh(new Date());
        setRefreshCount(prev => prev + 1);
        
        // Check if DAG run is in final state (success, failed, etc.)
        const currentRun = dagRuns.find(run => run.dag_run_id === selectedRunId);
        if (currentRun && ['success', 'failed', 'up_for_retry', 'up_for_reschedule', 'upstream_failed', 'skipped'].includes(currentRun.state)) {
          setIsAutoRefreshing(false); // Stop auto-refresh for completed runs
        }
      } else {
        console.warn('⚠️ No task instances in result:', result);
        setTaskInstances([]);
      }
    } catch (error) {
      console.error('❌ Failed to fetch task instances:', error);
      setError(`Failed to fetch task instances: ${error instanceof Error ? error.message : 'Unknown error'}`);
      setTaskInstances([]); // Clear tasks on error
    } finally {
      if (mountedRef.current) {
        setIsLoading(false);
      }
    }
  }, [dagId, selectedRunId, airflowApi, formatTaskInstance, dagRuns]);

  // Handle manual refresh
  const handleManualRefresh = useCallback(() => {
    fetchTaskInstances(true);
  }, [fetchTaskInstances]);

  // Toggle auto refresh
  const toggleAutoRefresh = useCallback(() => {
    setIsAutoRefreshing(prev => !prev);
  }, []);

  // Change refresh interval
  const handleIntervalChange = useCallback((interval: number) => {
    setCurrentInterval(interval);
    if (interval === REFRESH_INTERVALS.DISABLED) {
      setIsAutoRefreshing(false);
    }
  }, []);

  // Handle task click
  const handleTaskClick = useCallback((task: TaskInstanceDisplay) => {
    if (onTaskClick) {
      onTaskClick(task);
    } else {
      toast({
        title: "Task Details",
        description: `Task: ${task.task_id}\nState: ${task.state}\nDuration: ${task.formattedDuration}`,
      });
    }
  }, [onTaskClick, toast]);

  // Handle run selection change
  const handleRunSelectionChange = useCallback((runId: string) => {
    setSelectedRunId(runId);
    setTaskInstances([]); // Clear current tasks while loading new ones
  }, []);

  // Setup auto refresh
  useEffect(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    // Check if current DAG run is in a final state
    const currentRun = dagRuns.find(run => run.dag_run_id === selectedRunId);
    const isRunComplete = currentRun && ['success', 'failed', 'up_for_retry', 'up_for_reschedule', 'upstream_failed', 'skipped'].includes(currentRun.state);

    if (isAutoRefreshing && currentInterval > 0 && !isRunComplete) {
      intervalRef.current = setInterval(() => {
        fetchTaskInstances(true);
      }, currentInterval);
    } else if (isRunComplete) {
      // Stop auto-refresh for completed runs
      setIsAutoRefreshing(false);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isAutoRefreshing, currentInterval, fetchTaskInstances, dagRuns, selectedRunId]);

  // Initial data fetch
  useEffect(() => {
    fetchDagRuns();
  }, [fetchDagRuns]);

  // Fetch task instances when selectedRunId changes
  useEffect(() => {
    if (selectedRunId) {
      fetchTaskInstances(true);
    }
  }, [selectedRunId, fetchTaskInstances]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      mountedRef.current = false;
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const getRunStatusColor = (state: string) => {
    switch (state) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'running': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'queued': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRunStatusIcon = (state: string) => {
    switch (state) {
      case 'success': return <CheckCircle className="w-4 h-4" />;
      case 'running': return <Activity className="w-4 h-4" />;
      case 'failed': return <XCircle className="w-4 h-4" />;
      case 'queued': return <Clock className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Task Instances - Live Data
              </CardTitle>
              <CardDescription>
                Real-time monitoring of task execution for DAG: {dagId}
              </CardDescription>
            </div>
            
            {/* Controls */}
            <div className="flex items-center gap-2">
              {/* Refresh interval selector */}
              <div className="flex items-center gap-1">
                <Button
                  variant={currentInterval === REFRESH_INTERVALS.FAST ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleIntervalChange(REFRESH_INTERVALS.FAST)}
                >
                  Fast (2s)
                </Button>
                <Button
                  variant={currentInterval === REFRESH_INTERVALS.NORMAL ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleIntervalChange(REFRESH_INTERVALS.NORMAL)}
                >
                  Normal (5s)
                </Button>
                <Button
                  variant={currentInterval === REFRESH_INTERVALS.SLOW ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleIntervalChange(REFRESH_INTERVALS.SLOW)}
                >
                  Slow (10s)
                </Button>
              </div>

              {/* Auto refresh toggle */}
              <Button
                variant={isAutoRefreshing ? "default" : "outline"}
                size="sm"
                onClick={toggleAutoRefresh}
              >
                {isAutoRefreshing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                {isAutoRefreshing ? 'Pause' : 'Resume'}
              </Button>

              {/* Manual refresh */}
              <Button
                variant="outline"
                size="sm"
                onClick={handleManualRefresh}
                disabled={isLoading}
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Run selector */}
          {dagRuns.length > 0 && (
            <div className="mb-4 p-4 bg-gray-50 rounded-lg border">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">DAG Run:</span>
                <div className="flex items-center gap-3">
                  <select
                    value={selectedRunId}
                    onChange={(e) => handleRunSelectionChange(e.target.value)}
                    className="px-3 py-2 border rounded-md text-sm min-w-[300px]"
                  >
                    {dagRuns.map((run) => (
                      <option key={run.dag_run_id} value={run.dag_run_id}>
                        {run.dag_run_id} ({run.state}) - {new Date(run.start_date).toLocaleString()}
                      </option>
                    ))}
                  </select>
                  {selectedRunId && (
                    <Badge className={getRunStatusColor(dagRuns.find(r => r.dag_run_id === selectedRunId)?.state || '')}>
                      {getRunStatusIcon(dagRuns.find(r => r.dag_run_id === selectedRunId)?.state || '')}
                      {dagRuns.find(r => r.dag_run_id === selectedRunId)?.state}
                    </Badge>
                  )}
                </div>
              </div>
              {selectedRunId && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    {(() => {
                      const run = dagRuns.find(r => r.dag_run_id === selectedRunId);
                      return run ? (
                        <>
                          <div>
                            <span className="font-medium text-gray-600">Start:</span>
                            <div className="text-gray-900">{new Date(run.start_date).toLocaleString()}</div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-600">End:</span>
                            <div className="text-gray-900">{run.end_date ? new Date(run.end_date).toLocaleString() : 'N/A'}</div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-600">Duration:</span>
                            <div className="text-gray-900">
                              {run.end_date ? 
                                (() => {
                                  const duration = new Date(run.end_date).getTime() - new Date(run.start_date).getTime();
                                  const seconds = Math.floor(duration / 1000);
                                  return seconds > 60 ? `${Math.floor(seconds / 60)}m ${seconds % 60}s` : `${seconds}s`;
                                })() : 'Running...'
                              }
                            </div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-600">Type:</span>
                            <div className="text-gray-900">{run.run_type || 'manual'}</div>
                          </div>
                        </>
                      ) : null;
                    })()}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Status bar */}
          <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <Activity className="w-4 h-4 text-blue-600" />
                  <span className="font-medium">Auto Refresh:</span>
                  <span className={isAutoRefreshing ? 'text-green-600' : 'text-gray-600'}>
                    {isAutoRefreshing ? 'Active' : 'Paused'}
                  </span>
                </div>
                {currentInterval > 0 && (
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span className="font-medium">Interval:</span>
                    <span>{currentInterval / 1000}s</span>
                  </div>
                )}
                {(() => {
                  const currentRun = dagRuns.find(run => run.dag_run_id === selectedRunId);
                  const isRunComplete = currentRun && ['success', 'failed', 'up_for_retry', 'up_for_reschedule', 'upstream_failed', 'skipped'].includes(currentRun.state);
                  return isRunComplete && (
                    <div className="flex items-center gap-1">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="font-medium">Status:</span>
                      <span className="text-green-600">Run Complete</span>
                    </div>
                  );
                })()}
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  <span className="font-medium">Tasks:</span>
                  <span className="text-blue-600">{taskInstances.length}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="font-medium">Refreshes:</span>
                  <span className="text-blue-600">{refreshCount}</span>
                </div>
                {lastRefresh && (
                  <div className="flex items-center gap-1">
                    <span className="font-medium">Last:</span>
                    <span className="text-blue-600">{lastRefresh.toLocaleTimeString()}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Error display */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 rounded-lg border border-red-200">
              <div className="flex items-center gap-2 text-red-700">
                <XCircle className="w-4 h-4" />
                <span className="font-medium">Error:</span>
                <span>{error}</span>
              </div>
            </div>
          )}

          {/* Loading state */}
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-600" />
                <p className="text-sm text-gray-600">
                  {taskInstances.length === 0 ? 'Loading task instances...' : 'Refreshing task instances...'}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  DAG: {dagId} | Run: {selectedRunId}
                </p>
              </div>
            </div>
          )}

          {/* Task instances table */}
          {taskInstances.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-200">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">Task ID</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">State</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">Start Time</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">End Time</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">Duration</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">Try #</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">Operator</th>
                    <th className="border border-gray-200 px-4 py-2 text-left text-sm font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {taskInstances.map((task, index) => (
                    <tr 
                      key={`${task.task_id}-${task.try_number}-${index}`}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleTaskClick(task)}
                    >
                      <td className="border border-gray-200 px-4 py-2">
                        <div className="font-medium text-blue-600 hover:underline">
                          {task.task_id}
                        </div>
                      </td>
                      <td className="border border-gray-200 px-4 py-2">
                        <Badge className={task.stateColor || ''}>
                          <span className="flex items-center gap-1">
                            {task.stateIcon}
                            {task.state}
                          </span>
                        </Badge>
                      </td>
                      <td className="border border-gray-200 px-4 py-2 text-sm">
                        {task.formattedStartDate}
                      </td>
                      <td className="border border-gray-200 px-4 py-2 text-sm">
                        {task.formattedEndDate}
                      </td>
                      <td className="border border-gray-200 px-4 py-2 text-sm">
                        {task.formattedDuration}
                      </td>
                      <td className="border border-gray-200 px-4 py-2 text-sm">
                        {task.try_number}/{task.max_tries}
                      </td>
                      <td className="border border-gray-200 px-4 py-2 text-sm">
                        {task.operator}
                      </td>
                      <td className="border border-gray-200 px-4 py-2">
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleTaskClick(task);
                            }}
                          >
                            <FileText className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Open external link if available
                              if (task.log_url) {
                                window.open(task.log_url, '_blank');
                              }
                            }}
                          >
                            <ExternalLink className="w-3 h-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Empty state */}
          {!isLoading && taskInstances.length === 0 && !error && (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Task Instances</h3>
              <p className="text-gray-600">
                {selectedRunId ? 'No task instances found for this DAG run.' : 'Select a DAG run to view task instances.'}
              </p>
              {selectedRunId && (
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => fetchTaskInstances(true)}
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Retry Loading
                </Button>
              )}
            </div>
          )}

          {/* Show when there's an error but no tasks */}
          {!isLoading && taskInstances.length === 0 && error && (
            <div className="text-center py-8">
              <XCircle className="w-12 h-12 mx-auto mb-4 text-red-400" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Failed to Load Task Instances</h3>
              <p className="text-gray-600 mb-4">
                There was an error loading task instances for this DAG run.
              </p>
              <Button
                variant="outline"
                onClick={() => fetchTaskInstances(true)}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
