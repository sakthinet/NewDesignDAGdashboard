import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  RefreshCw, 
  FileText, 
  BarChart3, 
  Table, 
  Database,
  TrendingUp,
  Calendar,
  Eye,
  AlertCircle
} from "lucide-react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface Report {
  fileName: string;
  name: string;
  type: string;
  data: any;
  lastModified: string;
}

interface ReportsData {
  success: boolean;
  reports: Report[];
  message: string;
  dataPath: string;
  isLocal: boolean;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658', '#FF7C7C'];

export function ReportsViewer() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [dataPath, setDataPath] = useState<string>('');
  const [isLocal, setIsLocal] = useState<boolean>(false);

  const loadReports = async () => {
    setLoading(true);
    setError(null);
    
    try {
      console.log('📊 Loading reports...');
      const response = await fetch('/api/reports');
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data: ReportsData = await response.json();
      
      if (data.success) {
        setReports(data.reports);
        setDataPath(data.dataPath);
        setIsLocal(data.isLocal);
        
        // Auto-select first report if available
        if (data.reports.length > 0) {
          setSelectedReport(data.reports[0]);
        }
        
        console.log(`✅ Loaded ${data.reports.length} reports`);
      } else {
        throw new Error(data.message || 'Failed to load reports');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      setError(errorMessage);
      console.error('❌ Failed to load reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, []);

  const getReportIcon = (type: string) => {
    switch (type) {
      case 'chart': return <BarChart3 className="w-4 h-4" />;
      case 'metrics': return <TrendingUp className="w-4 h-4" />;
      case 'table': return <Table className="w-4 h-4" />;
      case 'complex': return <Database className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getReportTypeColor = (type: string) => {
    switch (type) {
      case 'chart': return 'bg-blue-100 text-blue-800';
      case 'metrics': return 'bg-blue-100 text-blue-800';
      case 'table': return 'bg-purple-100 text-purple-800';
      case 'complex': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const renderChartReport = (data: any) => {
    if (!data.labels || !data.counts) return null;

    const chartData = data.labels.map((label: string, index: number) => ({
      name: label,
      value: data.counts[index],
      percentage: data.percentages ? data.percentages[index] : null
    }));

    return (
      <div className="space-y-6">
        {/* Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2" />
              Distribution Chart
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value, percentage }) => 
                    `${name}: ${value}${percentage ? ` (${percentage}%)` : ''}`
                  }
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {chartData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Bar Chart View</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderMetricsReport = (data: any) => {
    const metrics = Object.entries(data).map(([key, value]) => ({
      name: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      value: value as number,
      key
    }));

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((metric, index) => (
          <Card key={metric.key}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 font-medium">{metric.name}</p>
                  <p className="text-2xl font-bold mt-1">
                    {typeof metric.value === 'number' ? 
                      (metric.value % 1 === 0 ? metric.value : metric.value.toFixed(2)) : 
                      metric.value
                    }
                    {metric.key.includes('percentage') || metric.key.includes('percent') ? '%' : ''}
                  </p>
                </div>
                <TrendingUp className={`w-8 h-8 ${COLORS[index % COLORS.length]} opacity-60`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  const renderTableReport = (data: any[]) => {
    if (!Array.isArray(data) || data.length === 0) return null;

    const headers = Object.keys(data[0]);

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Table className="w-5 h-5 mr-2" />
            Data Table
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  {headers.map((header) => (
                    <th
                      key={header}
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                    >
                      {header.replace(/_/g, ' ')}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data.slice(0, 10).map((row, index) => (
                  <tr key={index}>
                    {headers.map((header) => (
                      <td key={header} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {row[header]}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {data.length > 10 && (
              <p className="text-sm text-gray-500 mt-2 text-center">
                Showing first 10 rows of {data.length} total rows
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderRawReport = (data: any) => {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="w-5 h-5 mr-2" />
            Raw Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto text-sm">
            {JSON.stringify(data, null, 2)}
          </pre>
        </CardContent>
      </Card>
    );
  };

  // Add new intelligent analysis functions
  const analyzeDataStructure = (data: any): {
    hasNumericValues: boolean;
    hasDateValues: boolean;
    hasCategories: boolean;
    numericFields: string[];
    dateFields: string[];
    categoryFields: string[];
    totalRecords: number;
  } => {
    let hasNumericValues = false;
    let hasDateValues = false;
    let hasCategories = false;
    const numericFields: string[] = [];
    const dateFields: string[] = [];
    const categoryFields: string[] = [];
    let totalRecords = 0;

    if (Array.isArray(data)) {
      totalRecords = data.length;
      if (data.length > 0 && typeof data[0] === 'object') {
        const sampleObject = data[0];
        Object.entries(sampleObject).forEach(([key, value]) => {
          if (typeof value === 'number') {
            hasNumericValues = true;
            numericFields.push(key);
          } else if (typeof value === 'string') {
            // Check if it's a date
            if (new Date(value).toString() !== 'Invalid Date' && value.match(/\d{4}-\d{2}-\d{2}/)) {
              hasDateValues = true;
              dateFields.push(key);
            } else {
              hasCategories = true;
              categoryFields.push(key);
            }
          }
        });
      }
    } else if (typeof data === 'object' && data !== null) {
      totalRecords = 1;
      Object.entries(data).forEach(([key, value]) => {
        if (typeof value === 'number') {
          hasNumericValues = true;
          numericFields.push(key);
        } else if (typeof value === 'string') {
          if (new Date(value).toString() !== 'Invalid Date' && value.match(/\d{4}-\d{2}-\d{2}/)) {
            hasDateValues = true;
            dateFields.push(key);
          } else {
            hasCategories = true;
            categoryFields.push(key);
          }
        } else if (Array.isArray(value)) {
          totalRecords = Math.max(totalRecords, value.length);
        }
      });
    }

    return {
      hasNumericValues,
      hasDateValues,
      hasCategories,
      numericFields,
      dateFields,
      categoryFields,
      totalRecords
    };
  };

  const generateStatistics = (data: any) => {
    const analysis = analyzeDataStructure(data);
    const stats: any[] = [];

    // Basic statistics
    stats.push({
      name: 'Total Records',
      value: analysis.totalRecords,
      icon: Database,
      color: 'text-blue-600'
    });

    if (analysis.numericFields.length > 0) {
      stats.push({
        name: 'Numeric Fields',
        value: analysis.numericFields.length,
        icon: TrendingUp,
        color: 'text-blue-600'
      });
    }

    if (analysis.categoryFields.length > 0) {
      stats.push({
        name: 'Category Fields',
        value: analysis.categoryFields.length,
        icon: Table,
        color: 'text-purple-600'
      });
    }

    if (analysis.dateFields.length > 0) {
      stats.push({
        name: 'Date Fields',
        value: analysis.dateFields.length,
        icon: Calendar,
        color: 'text-orange-600'
      });
    }

    // Calculate additional statistics for arrays
    if (Array.isArray(data) && data.length > 0) {
      analysis.numericFields.forEach(field => {
        const values = data.map(item => item[field]).filter(val => typeof val === 'number');
        if (values.length > 0) {
          const sum = values.reduce((a, b) => a + b, 0);
          const avg = sum / values.length;
          const max = Math.max(...values);
          const min = Math.min(...values);

          stats.push({
            name: `${field} (Avg)`,
            value: avg.toFixed(2),
            icon: BarChart3,
            color: 'text-blue-500'
          });

          stats.push({
            name: `${field} (Max)`,
            value: max,
            icon: TrendingUp,
            color: 'text-blue-500'
          });

          stats.push({
            name: `${field} (Min)`,
            value: min,
            icon: TrendingUp,
            color: 'text-red-500'
          });
        }
      });
    }

    return stats;
  };

  const createChartsFromData = (data: any) => {
    const analysis = analyzeDataStructure(data);
    const charts: any[] = [];

    if (Array.isArray(data) && data.length > 0) {
      // Create charts for categorical data
      analysis.categoryFields.forEach(field => {
        const fieldData = data.reduce((acc: any, item: any) => {
          const value = item[field];
          if (value) {
            acc[value] = (acc[value] || 0) + 1;
          }
          return acc;
        }, {});

        const chartData = Object.entries(fieldData)
          .map(([key, value]) => ({ name: key, value: value as number }))
          .sort((a, b) => b.value - a.value)
          .slice(0, 10); // Top 10

        if (chartData.length > 1) {
          charts.push({
            title: `${field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())} Distribution`,
            type: 'pie',
            data: chartData
          });
        }
      });

      // Create bar chart for numeric fields
      if (analysis.numericFields.length > 0 && data.length <= 20) {
        const barData = data.map((item: any, index: number) => {
          const result: any = { name: `Record ${index + 1}` };
          analysis.numericFields.forEach(field => {
            result[field] = item[field] || 0;
          });
          return result;
        });

        charts.push({
          title: 'Numeric Values Comparison',
          type: 'bar',
          data: barData,
          fields: analysis.numericFields
        });
      }

      // Create time series if date fields exist
      if (analysis.dateFields.length > 0 && analysis.numericFields.length > 0) {
        const timeData = data
          .filter((item: any) => item[analysis.dateFields[0]])
          .map((item: any) => ({
            date: new Date(item[analysis.dateFields[0]]).toLocaleDateString(),
            ...analysis.numericFields.reduce((acc: any, field: string) => {
              acc[field] = item[field] || 0;
              return acc;
            }, {})
          }))
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        if (timeData.length > 1) {
          charts.push({
            title: 'Time Series Analysis',
            type: 'line',
            data: timeData,
            fields: analysis.numericFields
          });
        }
      }
    }

    return charts;
  };

  // Enhanced render functions
  const renderEnhancedRawReport = (report: Report) => {
    const statistics = generateStatistics(report.data);
    const charts = createChartsFromData(report.data);

    return (
      <div className="space-y-6">
        {/* Statistics Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2" />
              Data Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {statistics.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                  <stat.icon className={`w-8 h-8 mx-auto mb-2 ${stat.color}`} />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.name}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Generated Charts */}
        {charts.map((chart, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                {chart.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                {chart.type === 'pie' ? (
                  <PieChart>
                    <Pie
                      data={chart.data}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {chart.data.map((entry: any, idx: number) => (
                        <Cell key={`cell-${idx}`} fill={COLORS[idx % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                ) : chart.type === 'bar' ? (
                  <BarChart data={chart.data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    {chart.fields?.map((field: string, idx: number) => (
                      <Bar key={field} dataKey={field} fill={COLORS[idx % COLORS.length]} />
                    ))}
                  </BarChart>
                ) : (
                  <BarChart data={chart.data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    {chart.fields?.map((field: string, idx: number) => (
                      <Bar key={field} dataKey={field} fill={COLORS[idx % COLORS.length]} />
                    ))}
                  </BarChart>
                )}
              </ResponsiveContainer>
            </CardContent>
          </Card>
        ))}

        {/* Raw Data Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              Raw Data Preview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-lg overflow-x-auto">
              <pre className="text-sm">
                {JSON.stringify(report.data, null, 2).slice(0, 2000)}
                {JSON.stringify(report.data, null, 2).length > 2000 && '...'}
              </pre>
            </div>
            {JSON.stringify(report.data, null, 2).length > 2000 && (
              <p className="text-sm text-gray-500 mt-2">
                Showing first 2000 characters. Full data available in download.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderEnhancedTableReport = (data: any[]) => {
    if (!Array.isArray(data) || data.length === 0) {
      return renderEnhancedRawReport({ data } as Report);
    }

    const statistics = generateStatistics(data);
    const charts = createChartsFromData(data);
    const headers = Object.keys(data[0]);

    return (
      <div className="space-y-6">
        {/* Statistics Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2" />
              Table Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {statistics.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                  <stat.icon className={`w-8 h-8 mx-auto mb-2 ${stat.color}`} />
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.name}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Generated Charts */}
        {charts.map((chart, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                {chart.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                {chart.type === 'pie' ? (
                  <PieChart>
                    <Pie
                      data={chart.data}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {chart.data.map((entry: any, idx: number) => (
                        <Cell key={`cell-${idx}`} fill={COLORS[idx % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                ) : (
                  <BarChart data={chart.data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey={chart.type === 'line' ? 'date' : 'name'} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    {chart.fields?.map((field: string, idx: number) => (
                      <Bar key={field} dataKey={field} fill={COLORS[idx % COLORS.length]} />
                    ))}
                  </BarChart>
                )}
              </ResponsiveContainer>
            </CardContent>
          </Card>
        ))}

        {/* Data Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Table className="w-5 h-5 mr-2" />
              Data Table ({data.length} records)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    {headers.map((header) => (
                      <th
                        key={header}
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        {header.replace(/_/g, ' ')}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {data.slice(0, 10).map((row, index) => (
                    <tr key={index}>
                      {headers.map((header) => (
                        <td key={header} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {typeof row[header] === 'number' ? 
                            row[header].toLocaleString() : 
                            String(row[header]).slice(0, 50) + (String(row[header]).length > 50 ? '...' : '')
                          }
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              {data.length > 10 && (
                <p className="text-sm text-gray-500 mt-2 text-center">
                  Showing first 10 rows of {data.length} total rows
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Update the renderReportContent function
  const renderReportContent = (report: Report) => {
    switch (report.type) {
      case 'chart':
        return renderChartReport(report.data);
      case 'metrics':
        return renderMetricsReport(report.data);
      case 'table':
        return renderEnhancedTableReport(report.data);
      case 'complex':
        return renderEnhancedRawReport(report);
      case 'raw':
      default:
        return renderEnhancedRawReport(report);
    }
  };

  if (loading && reports.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-12 h-12 animate-spin mx-auto mb-4 text-blue-600" />
          <h2 className="text-xl font-semibold mb-2">Loading Reports...</h2>
          <p className="text-gray-600">Fetching data from Airflow data folder</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h1 className="text-4xl font-bold text-gray-900">TCS ECM Analytics & Intelligence</h1>
          <p className="mt-1 text-gray-600">
            Advanced data insights and business intelligence reports
            {dataPath && ` (${isLocal ? 'Local' : 'Enterprise'}: ${dataPath})`}
          </p>
        </div>
        <div className="mt-4 lg:mt-0 flex items-center space-x-4">
          <Button onClick={loadReports} disabled={loading}>
            {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            {loading ? 'Loading...' : 'Refresh Reports'}
          </Button>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5" />
              <div>
                <h3 className="font-bold text-red-800">Error Loading Reports</h3>
                <p className="mt-1 text-sm text-red-700">{error}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Reports List and Content */}
      {reports.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Reports List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="w-5 h-5 mr-2" />
                  Available Reports ({reports.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-gray-200">
                  {reports.map((report) => (
                    <button
                      key={report.fileName}
                      onClick={() => setSelectedReport(report)}
                      className={`w-full text-left p-4 hover:bg-gray-50 transition-colors ${
                        selectedReport?.fileName === report.fileName ? 'bg-blue-50 border-r-2 border-blue-500' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900">{report.name}</h3>
                          <p className="text-xs text-gray-500 mt-1">{report.fileName}</p>
                          <div className="flex items-center mt-2 space-x-2">
                            <Badge className={`text-xs ${getReportTypeColor(report.type)}`}>
                              {getReportIcon(report.type)}
                              <span className="ml-1">{report.type}</span>
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">
                            <Calendar className="w-3 h-3 inline mr-1" />
                            {new Date(report.lastModified).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Report Content */}
          <div className="lg:col-span-3">
            {selectedReport ? (
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center">
                          {getReportIcon(selectedReport.type)}
                          <span className="ml-2">{selectedReport.name}</span>
                        </CardTitle>
                        <p className="text-sm text-gray-600 mt-1">
                          {selectedReport.fileName} • Last updated: {new Date(selectedReport.lastModified).toLocaleString()}
                        </p>
                      </div>
                      <Badge className={getReportTypeColor(selectedReport.type)}>
                        {selectedReport.type.toUpperCase()}
                      </Badge>
                    </div>
                  </CardHeader>
                </Card>
                {renderReportContent(selectedReport)}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Eye className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900">Select a Report</h3>
                  <p className="text-gray-600">Choose a report from the list to view its content</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      ) : !loading && !error ? (
        <Card>
          <CardContent className="p-12 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No Reports Found</h3>
            <p className="text-gray-600 mb-4">
              No JSON report files found in the Airflow data directory
            </p>
            <p className="text-sm text-gray-500">
              Expected location: {dataPath || 'C:\\Docker\\airflow3x2\\data'}
            </p>
            <Button onClick={loadReports} className="mt-4">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}