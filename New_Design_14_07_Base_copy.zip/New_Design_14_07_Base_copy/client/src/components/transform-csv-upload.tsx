import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Upload, Database, FileText, AlertCircle, CheckCircle, Activity, RefreshCw } from "lucide-react";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";
import { useWorkflow } from "@/contexts/WorkflowContext";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useToast } from "@/hooks/use-toast";
import { TaskInstancesLive } from "@/components/task-instances-live";

interface TransformCsvUploadProps {
  uploadedFiles: UploadedFile[];
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

interface TransformCsvUploadProps {
  uploadedFiles: UploadedFile[];
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

export function TransformCsvUpload({ 
  uploadedFiles, 
  config, 
  onPrev, 
  onStartOver 
}: TransformCsvUploadProps) {
  const [selectedCsvFile, setSelectedCsvFile] = useState<string>('');
  const [bearerToken, setBearerToken] = useState<string>('');
  const [tableUrl, setTableUrl] = useState<string>('');
  const [chunkSize, setChunkSize] = useState<number>(5000);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadStarted, setUploadStarted] = useState<boolean>(false);
  const [dagRunId, setDagRunId] = useState<string>('');
  const [uploadSuccess, setUploadSuccess] = useState<boolean>(false);
  
  // Use workflow context to get session files
  const workflow = useWorkflow();
  const sessionFiles = workflow.selectedFiles;
  const airflowApi = useAirflowApi();
  const { toast } = useToast();
  
  // Use session files if available, otherwise fall back to props
  const availableFiles = sessionFiles.length > 0 ? sessionFiles : uploadedFiles;

  const handleUploadToIA = async () => {
    if (!selectedCsvFile || selectedCsvFile === 'no-files-available' || !bearerToken || !tableUrl) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    setUploadStarted(true);
    
    try {
      console.log('🚀 Triggering StructuredDataToIA DAG with config:', {
        csvFile: selectedCsvFile,
        bearerToken,
        tableUrl,
        chunkSize
      });
      
      // Configuration for the DAG
      const dagConfig = {
        csv_file: selectedCsvFile,
        bearer_token: bearerToken,
        table_url: tableUrl,
        chunk_size: chunkSize,
        triggered_by: 'transform_csv_upload_page',
        timestamp: new Date().toISOString(),
        source: 'frontend_upload_page',
        // Add processing configurations that the DAG can use
        processing_config: {
          watch_dir: '/opt/airflow/data/incomingcsv/',
          processed_dir: '/opt/airflow/data/processedcsv/',
          file_name: selectedCsvFile,
          export_settings: {
            bearer_token: bearerToken,
            table_url: tableUrl,
            chunk_size: chunkSize
          }
        }
      };
      
      // Trigger the StructuredDataToIA DAG
      const result = await airflowApi.triggerDag('StructuredDataToIA', dagConfig);
      
      if (result && result.success) {
        setUploadSuccess(true);
        
        // Extract the DAG run ID from the result
        if (result.dag_run && result.dag_run.dag_run_id) {
          setDagRunId(result.dag_run.dag_run_id);
        }
        
        toast({
          title: "✅ DAG Triggered Successfully",
          description: `StructuredDataToIA DAG has been started. Monitor the progress below.`,
        });
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
      
    } catch (error) {
      console.error('Failed to trigger DAG:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to trigger DAG';
      
      toast({
        title: "Failed to trigger DAG",
        description: errorMessage,
        variant: "destructive"
      });
      
      setUploadSuccess(false);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Transform CSV Data dump to IA XML Format and Upload</h2>
          <p className="text-slate-600 mt-2">
            Configure the transformation parameters and upload processed data to InfoArchive
          </p>
          {/* Show available files count */}
          <div className="mt-2 text-sm text-slate-500">
            {availableFiles.length > 0 ? (
              <span className="inline-flex items-center gap-1">
                <Database className="h-4 w-4" />
                Processing: {availableFiles.length} file(s) ({availableFiles.map(f => f.fileName).join(', ')})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-orange-600">
                <AlertCircle className="h-4 w-4" />
                No files available. Please upload files in Step 1 first.
              </span>
            )}
          </div>
        </div>
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Upload Configuration
            </CardTitle>
            <CardDescription>
              Configure the CSV transformation and upload settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* CSV File Selection */}
            <div className="space-y-2">
              <Label htmlFor="csv-file">
                Select CSV file to process (from Step 1 uploads)
              </Label>
              <Select value={selectedCsvFile} onValueChange={setSelectedCsvFile}>
                <SelectTrigger>
                  <SelectValue placeholder="Select CSV file to process" />
                </SelectTrigger>
                <SelectContent>
                  {availableFiles.length > 0 ? (
                    availableFiles.map((file) => (
                      <SelectItem key={file.fileName} value={file.fileName}>
                        {file.fileName}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="no-files-available" disabled>
                      No files available - Please upload files in Step 1
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                Only files uploaded in Step 1 will appear here
              </p>
            </div>

            {/* Bearer Token */}
            <div className="space-y-2">
              <Label htmlFor="bearer-token">Bearer Token: &lt;&gt;</Label>
              <Input
                id="bearer-token"
                type="password"
                value={bearerToken}
                onChange={(e) => setBearerToken(e.target.value)}
                placeholder="Enter your bearer token"
                className="font-mono"
              />
            </div>

            {/* Table URL */}
            <div className="space-y-2">
              <Label htmlFor="table-url">Table URL: // - Textbox</Label>
              <Input
                id="table-url"
                type="url"
                value={tableUrl}
                onChange={(e) => setTableUrl(e.target.value)}
                placeholder="Enter table URL"
              />
            </div>

            {/* Chunk Size */}
            <div className="space-y-2">
              <Label htmlFor="chunk-size">Chunk Size: 5000</Label>
              <Input
                id="chunk-size"
                type="number"
                value={chunkSize}
                onChange={(e) => setChunkSize(Number(e.target.value))}
                min="1000"
                max="10000"
                step="1000"
              />
            </div>

            {/* Upload Button */}
            <Button
              onClick={handleUploadToIA}
              disabled={!selectedCsvFile || selectedCsvFile === 'no-files-available' || !bearerToken || !tableUrl || isUploading || availableFiles.length === 0}
              className="w-full"
            >
              {isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  Uploading to IA...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload to IA
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Status/Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Process Status
            </CardTitle>
            <CardDescription>
              Current transformation and upload status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Selected CSV File</span>
                <span className="text-sm text-gray-600">
                  {selectedCsvFile || 'None selected'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Chunk Size</span>
                <span className="text-sm text-gray-600">{chunkSize.toLocaleString()}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Bearer Token</span>
                <span className="text-sm text-gray-600">
                  {bearerToken ? '••••••••' : 'Not set'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Table URL</span>
                <span className="text-sm text-gray-600">
                  {tableUrl || 'Not set'}
                </span>
              </div>
              
              {/* DAG Status */}
              {uploadStarted && (
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <span className="text-sm font-medium">DAG Status</span>
                  <div className="flex items-center gap-2">
                    {isUploading ? (
                      <>
                        <Activity className="h-4 w-4 animate-spin text-blue-600" />
                        <span className="text-sm text-blue-600">Triggering...</span>
                      </>
                    ) : uploadSuccess ? (
                      <>
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm text-green-600">Triggered Successfully</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <span className="text-sm text-red-600">Failed</span>
                      </>
                    )}
                  </div>
                </div>
              )}
              
              {/* DAG Run ID */}
              {dagRunId && (
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                  <span className="text-sm font-medium">DAG Run ID</span>
                  <span className="text-sm text-green-600 font-mono">{dagRunId}</span>
                </div>
              )}
            </div>

            {/* Progress indicator */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Triggering DAG...</span>
                  <span>Processing</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full animate-pulse w-[45%]"></div>
                </div>
              </div>
            )}

            {/* Success message */}
            {uploadSuccess && dagRunId && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">DAG Successfully Triggered</span>
                </div>
                <p className="text-sm text-green-600 mt-1">
                  The StructuredDataToIA DAG is now running. Monitor the task instances below for real-time progress.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Task Instances Live View - Show after DAG is triggered */}
      {uploadSuccess && dagRunId && (
        <div className="mt-6">
          <TaskInstancesLive
            dagId="StructuredDataToIA"
            runId={dagRunId}
            autoRefresh={true}
            refreshInterval={5000} // 5 seconds for active monitoring
            onTaskClick={(task) => {
              toast({
                title: "Task Information",
                description: `Task: ${task.task_id}\nState: ${task.state}\nOperator: ${task.operator}`,
              });
            }}
          />
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-6 border-t">
        <Button
          variant="outline"
          onClick={onStartOver}
          className="flex items-center gap-2"
        >
          Start Over
        </Button>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={onPrev}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Previous
          </Button>
        </div>
      </div>
    </div>
  );
}
