import { useState, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { ColDef, GridApi } from 'ag-grid-community';
import { 
  ArrowLeft, 
  ArrowRight, 
  Database, 
  FileText, 
  Save,
  Loader2,
  Settings,
  CheckCircle,
  AlertCircle,
  Play,
  RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { Badge } from "@/components/ui/badge";

// API request function
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

// Types for the schema configuration (following the image exactly)
export interface SchemaConfiguration {
  applicationName: string;     // Text Box (Non-Editable)
  defaultSchemaName: string;   // Text Box (Non-Editable)  
  locale: string;              // Text Box (Non-Editable)
  schemaName: string;          // Text Box (Non-Editable)
}

export interface TableRowData {
  id: string;
  table: string;           // Taken from JSON file metadata (Editable)
  recordCount: number;     // Calculated based on number of records in JSON data (Editable)
  dataType: string;        // Based on column data type from JSON metadata (Editable)
  fileName: string;        // Original JSON file name for reference
  columnName?: string;     // Column name from JSON metadata
  isNullable?: boolean;    // Nullable flag from JSON metadata
  description?: string;    // Column description from JSON metadata
}

interface EditableSchemaGeneratorProps {
  uploadedFiles: any[];
  onNext: () => void;
  onPrev: () => void;
  onFinalize: () => void;
}

// Data type options for the grid
const DATA_TYPE_OPTIONS = [
  'VARCHAR(50)',
  'VARCHAR(100)', 
  'VARCHAR(255)',
  'TEXT',
  'INT',
  'BIGINT',
  'DECIMAL(10,2)',
  'DATE',
  'DATETIME',
  'TIMESTAMP',
  'BOOLEAN',
  'FLOAT',
  'DOUBLE'
];

export function EditableSchemaGenerator({ 
  uploadedFiles, 
  onNext, 
  onPrev, 
  onFinalize 
}: EditableSchemaGeneratorProps) {
  
  // Step 2.1: Schema Configuration State (Non-Editable as per image)
  const [schemaConfig] = useState<SchemaConfiguration>({
    applicationName: 'InfoArchive_Application',
    defaultSchemaName: 'DefaultSchema', 
    locale: 'en-US',
    schemaName: 'DataArchival_Schema'
  });

  // Grid data state
  const [rowData, setRowData] = useState<TableRowData[]>([]);
  const [gridApi, setGridApi] = useState<GridApi | null>(null);
  const [isFinalizing, setIsFinalizing] = useState(false);
  const [availableJsonFiles, setAvailableJsonFiles] = useState<string[]>([]);
  const [isLoadingJsonFiles, setIsLoadingJsonFiles] = useState(false);

  const { toast } = useToast();
  
  // Airflow API hook
  const { triggerDag, loading: dagLoading, error: dagError } = useAirflowApi();

  // Load available JSON files from processed CSV directory
  const loadAvailableJsonFiles = async () => {
    setIsLoadingJsonFiles(true);
    try {
      console.log('🔍 Loading available JSON files...');
      
      const response = await apiRequest('GET', '/api/get-processed-json-files');
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setAvailableJsonFiles(result.files || []);
          console.log('✅ Loaded JSON files:', result.files);
        } else {
          console.warn('Failed to load JSON files:', result.message);
          setAvailableJsonFiles([]);
        }
      } else {
        console.error('Failed to fetch JSON files');
        setAvailableJsonFiles([]);
      }
    } catch (error) {
      console.error('Error loading JSON files:', error);
      setAvailableJsonFiles([]);
    } finally {
      setIsLoadingJsonFiles(false);
    }
  };

  // Load JSON metadata and populate table data
  const loadJsonMetadata = async (fileName: string) => {
    try {
      console.log(`📊 Loading metadata for: ${fileName}`);
      
      const response = await apiRequest('POST', '/api/load-json-metadata', {
        fileName: fileName
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          console.log('✅ Loaded JSON metadata:', result);
          
          // Create table row data from JSON metadata columns
          const tableDataRows: TableRowData[] = result.columns.map((col: any, index: number) => ({
            id: `json_${fileName}_${index}`,
            table: result.tableName,
            recordCount: result.recordCount,
            dataType: col.data_type || 'VARCHAR(255)',
            fileName: fileName,
            columnName: col.name,
            isNullable: col.is_nullable || false,
            description: col.description || ''
          }));
          
          return tableDataRows;
        } else {
          console.warn('Failed to load JSON metadata:', result.message);
          return [];
        }
      } else {
        console.error('Failed to fetch JSON metadata');
        return [];
      }
    } catch (error) {
      console.error('Error loading JSON metadata:', error);
      return [];
    }
  };

  // Initialize row data from JSON files instead of uploaded CSV files
  const initializeFromJsonFiles = async () => {
    if (availableJsonFiles.length > 0) {
      const allTableData: TableRowData[] = [];
      
      for (const jsonFile of availableJsonFiles) {
        const tableDataRows = await loadJsonMetadata(jsonFile);
        allTableData.push(...tableDataRows);
      }
      
      setRowData(allTableData);
      console.log('📊 Initialized table data from JSON files:', allTableData);
    }
  };

  // Initialize row data from JSON files instead of uploaded CSV files
  useEffect(() => {
    loadAvailableJsonFiles();
  }, []);

  // Initialize table data when JSON files are loaded
  useEffect(() => {
    if (availableJsonFiles.length > 0) {
      initializeFromJsonFiles();
    }
  }, [availableJsonFiles]);

  // AG-Grid column definitions
  const columnDefs: ColDef[] = useMemo(() => [
    {
      headerName: 'Table',
      field: 'table',
      editable: true,
      cellEditor: 'agTextCellEditor',
      flex: 1,
      headerTooltip: 'Taken from JSON file metadata (Editable)'
    },
    {
      headerName: 'Record Count', 
      field: 'recordCount',
      editable: true,
      cellEditor: 'agNumberCellEditor',
      type: 'numericColumn',
      flex: 1,
      headerTooltip: 'Calculated based on number of records in JSON data (Editable)'
    },
    {
      headerName: 'Data Type',
      field: 'dataType', 
      editable: true,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: DATA_TYPE_OPTIONS
      },
      flex: 1,
      headerTooltip: 'Based on column data type from JSON metadata (Editable)'
    }
  ], []);

  // Grid event handlers
  const onGridReady = useCallback((params: any) => {
    setGridApi(params.api);
  }, []);

  const onCellValueChanged = useCallback((event: any) => {
    console.log('Cell value changed:', event);
    // Update the row data state
    const updatedData = [...rowData];
    const rowIndex = event.rowIndex;
    if (rowIndex >= 0 && rowIndex < updatedData.length) {
      updatedData[rowIndex] = { ...updatedData[rowIndex], [event.colDef.field]: event.newValue };
      setRowData(updatedData);
    }
  }, [rowData]);

  // Handle DAG Run 2 (Finalize and Generate IA Schema)
  const handleDAGRun2 = async () => {
    setIsFinalizing(true);
    
    try {
      // Prepare the DAG configuration with schema configuration and table data
      const dagConfig = {
        "Application Name": schemaConfig.applicationName,
        "Default Schema Name": schemaConfig.defaultSchemaName,
        "Locale": schemaConfig.locale,
        "Schema Name": schemaConfig.schemaName,
        "Table Data": rowData.map(row => ({
          tableName: row.table,
          recordCount: row.recordCount,
          dataType: row.dataType,
          fileName: row.fileName
        }))
      };

      console.log('=== DAG RUN 2 TRIGGERED ===');
      console.log('DAG Configuration:', dagConfig);

      // Trigger the specific DAG: IA_XML_Generator
      const result = await triggerDag('IA_XML_Generator', dagConfig);

      if (result && result.success) {
        toast({
          title: "🚀 IA XML Generator Triggered Successfully!",
          description: `DAG 'IA_XML_Generator' executed successfully. DAG Run ID: ${result.dag_run?.dag_run_id || 'Unknown'}`,
          duration: 6000,
        });
        
        // Navigate to the next step
        onFinalize();
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
    } catch (error) {
      console.error('Error triggering DAG:', error);
      toast({
        title: "❌ IA XML Generator Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsFinalizing(false);
    }
  };

  // Validate form
  const isFormValid = () => {
    return rowData.length > 0 && rowData.every(row => 
      row.table.trim() !== '' && row.recordCount > 0 && row.dataType.trim() !== ''
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">STEP 2.1: Validate and Finalize Schema</h2>
          <p className="text-sm text-gray-600 mt-1">
            Configure schema settings and validate table information for InfoArchive processing from JSON files
          </p>
          {availableJsonFiles.length > 0 && (
            <div className="mt-2 text-sm text-blue-600">
              <span className="font-medium">Processing JSON Files: </span>
              {availableJsonFiles.map((file, index) => (
                <span key={index}>
                  {file}
                  {index < availableJsonFiles.length - 1 ? ', ' : ''}
                </span>
              ))}
            </div>
          )}
          {isLoadingJsonFiles && (
            <div className="mt-2 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Loader2 className="h-3 w-3 animate-spin" />
                Loading JSON files from processed CSV directory...
              </span>
            </div>
          )}
        </div>
        <div className="flex flex-col items-end space-y-1 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4" />
            <span>{rowData.length} tables configured</span>
          </div>
          <div className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Schema validation ready</span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={loadAvailableJsonFiles}
              disabled={isLoadingJsonFiles}
              className="flex items-center space-x-1"
            >
              <RefreshCw className={`h-3 w-3 ${isLoadingJsonFiles ? 'animate-spin' : ''}`} />
              <span>Refresh JSON Files</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Schema Configuration - Non-Editable Fields (1-4) */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Schema Configuration
            <Badge variant="outline" className="ml-2 text-red-600 border-red-200">
              Non-Editable
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-medium text-gray-700">
                1. Application Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.applicationName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                2. Default Schema Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.defaultSchemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                3. Locale: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.locale}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                4. Schema Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.schemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editable Table Schema Information (Fields 5-7) */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <FileText className="mr-2 h-5 w-5" />
            Table Schema Information
            <Badge variant="outline" className="ml-2 text-blue-600 border-blue-200">
              Editable
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm text-gray-700">
              <p><strong>5. Table:</strong> Taken from JSON file metadata (Editable)</p>
              <p><strong>6. Record Count:</strong> Calculated based on number of records in JSON data (Editable)</p>
              <p><strong>7. Data Type:</strong> Based on column data type from JSON metadata (Editable)</p>
              <p className="text-xs text-blue-600 mt-2">
                <strong>Note:</strong> Data is loaded from JSON files in the processed CSV directory
              </p>
            </div>
            
            {/* AG-Grid for Excel-like editing */}
            <div className="ag-theme-alpine h-[300px] w-full">
              <AgGridReact
                rowData={rowData}
                columnDefs={columnDefs}
                onGridReady={onGridReady}
                onCellValueChanged={onCellValueChanged}
                defaultColDef={{
                  sortable: true,
                  filter: true,
                  resizable: true,
                }}
                animateRows={true}
                enableCellTextSelection={true}
                ensureDomOrder={true}
                suppressRowClickSelection={true}
                stopEditingWhenCellsLoseFocus={true}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Finalize Button - DAG Run 2 */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <Play className="mr-2 h-5 w-5" />
                Finalize and Generate IA Schema
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Trigger the 'IA_XML_Generator' DAG to finalize schema configuration and generate IA XML schema
              </p>
            </div>
            <Button 
              onClick={handleDAGRun2}
              disabled={!isFormValid() || isFinalizing || dagLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {(isFinalizing || dagLoading) ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating IA XML...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Finalize and Generate IA Schema
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between">
        <Button variant="outline" onClick={onPrev}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Validate Schema
        </Button>
        <Button 
          onClick={onNext}
          disabled={!isFormValid()}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Continue to Transform
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
