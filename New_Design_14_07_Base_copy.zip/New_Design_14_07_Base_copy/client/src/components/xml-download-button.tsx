import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Download, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface XmlDownloadButtonProps {
  csvFileName: string;
  className?: string;
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  size?: "default" | "sm" | "lg" | "icon";
}

export function XmlDownloadButton({ 
  csvFileName, 
  className = "", 
  variant = "outline", 
  size = "default" 
}: XmlDownloadButtonProps) {
  const [isDownloading, setIsDownloading] = useState(false);
  const { toast } = useToast();

  const handleDownload = async () => {
    if (!csvFileName) {
      toast({
        title: "Error",
        description: "No CSV file selected for XML download.",
        variant: "destructive",
      });
      return;
    }

    setIsDownloading(true);
    
    try {
      console.log('🔍 Checking for XML files for:', csvFileName);
      
      // First check if XML files exist
      const checkResponse = await fetch(`/api/xml-files/check/${encodeURIComponent(csvFileName)}`);
      const checkData = await checkResponse.json();
      
      if (!checkData.success || !checkData.files || checkData.files.length === 0) {
        toast({
          title: "XML File Not Available",
          description: "The XML file has not been generated yet. Please ensure the DAG execution is completed successfully.",
          variant: "destructive",
        });
        return;
      }
      
      // If multiple files, download the first one (or you can modify this logic)
      const xmlFile = checkData.files[0];
      console.log('📥 Downloading XML file:', xmlFile.fileName);
      
      // Download the file
      const downloadResponse = await fetch(`/api/xml-files/download/${encodeURIComponent(xmlFile.fileName)}`);
      
      if (!downloadResponse.ok) {
        throw new Error(`Failed to download: ${downloadResponse.statusText}`);
      }
      
      // Create blob and trigger download
      const blob = await downloadResponse.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = xmlFile.fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download Complete",
        description: `XML file "${xmlFile.fileName}" has been downloaded successfully.`,
      });
      
    } catch (error) {
      console.error('❌ Error downloading XML file:', error);
      toast({
        title: "Download Failed",
        description: "Failed to download XML file. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleDownload}
      disabled={isDownloading || !csvFileName}
      className={`flex items-center space-x-2 ${className}`}
    >
      {isDownloading ? (
        <RefreshCw className="w-4 h-4 animate-spin" />
      ) : (
        <Download className="w-4 h-4" />
      )}
      <span>{isDownloading ? 'Downloading...' : 'Download XML'}</span>
    </Button>
  );
}
