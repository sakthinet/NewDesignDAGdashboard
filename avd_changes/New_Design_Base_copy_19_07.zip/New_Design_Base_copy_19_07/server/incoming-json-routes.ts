import { Express, Request, Response } from 'express';
import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { getServerConfig } from "@shared/config";

// Get centralized configuration
const config = getServerConfig();

/**
 * Registers the routes for the incoming JSON handling
 */
export async function registerIncomingJsonRoutes(app: Express) {
  // Load JSON file from network path for the editable schema generator
  app.post("/api/load-json-file-from-network", async (req: Request, res: Response) => {
    try {
      const { fileName, timestamp } = req.body;
      if (!fileName) {
        return res.status(400).json({ success: false, message: "fileName is required" });
      }
      
      console.log(`=== LOAD JSON FILE FROM NETWORK ===`);
      console.log(`Loading file: ${fileName} (timestamp: ${timestamp || 'none'})`);
      
      // Use network directory path for reports - ensure proper UNC format
      const networkDir = config.reportsDir;
      const processedCsvDir = config.processedCsvDir;
      const dataDir = config.dataBaseDir;
      console.log(`Configured network directories: 
        - Reports: ${networkDir}
        - Processed CSV: ${processedCsvDir}
        - Data: ${dataDir}`);
      
      // Build all possible search paths with both .json and as-is extensions
      const fileNameWithExt = fileName.endsWith('.json') ? fileName : `${fileName}.json`;
      const searchPaths = [
        path.join(networkDir, fileNameWithExt),
        path.join(processedCsvDir, fileNameWithExt),
        path.join(dataDir, fileNameWithExt),
        path.join(dataDir, 'processedcsv', fileNameWithExt),
        path.join(dataDir, 'incomingcsv', fileNameWithExt),
        path.join(process.cwd(), 'reports', fileNameWithExt),
        path.join(process.cwd(), 'data', 'processedcsv', fileNameWithExt),
        path.join(process.cwd(), 'data', 'incomingcsv', fileNameWithExt),
        path.join(process.cwd(), 'input-files', fileNameWithExt),
        path.join(process.cwd(), 'data', fileNameWithExt)
      ];
      
      console.log(`Search paths (${searchPaths.length}):`);
      searchPaths.forEach((p, i) => console.log(`[${i+1}] ${p}`));
      
      let filePath = null;
      let fileContent = null;
      let accessError = null;
      
      for (const p of searchPaths) {
        try {
          console.log(`Attempting to access: ${p}`);
          await fs.access(p);
          fileContent = await fs.readFile(p, 'utf8');
          filePath = p;
          console.log(`✅ Successfully read file from: ${p}`);
          console.log(`File content preview (${fileContent.length} bytes): ${fileContent.substring(0, 100)}...`);
          break;
        } catch (error) {
          accessError = error;
          console.log(`❌ Cannot access: ${p} - ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }
      
      if (!filePath || !fileContent) {
        console.error(`File not found: ${fileName}. Last error: ${accessError instanceof Error ? accessError.message : 'Unknown error'}`);
        return res.status(404).json({ 
          success: false, 
          message: `JSON file not found: ${fileName}. Searched in multiple locations including network paths.`,
          searchedPaths: searchPaths,
          error: accessError instanceof Error ? accessError.message : 'Unknown error'
        });
      }
      
      // Check if content is valid JSON and not HTML/XML
      const trimmedContent = fileContent.trim();
      
      if (!trimmedContent) {
        console.error(`File ${fileName} is empty`);
        return res.status(400).json({ 
          success: false, 
          message: `File ${fileName} is empty`,
          filePath: filePath
        });
      }
      
      // Handle HTML/XML content
      if (trimmedContent.startsWith('<!DOCTYPE') || trimmedContent.startsWith('<?xml') || trimmedContent.startsWith('<html')) {
        console.error(`File ${fileName} appears to be HTML/XML, not JSON`);
        console.error(`Content preview: ${trimmedContent.substring(0, 300)}`);
        return res.status(400).json({ 
          success: false, 
          message: `File ${fileName} is not a valid JSON file (appears to be HTML/XML)`,
          contentPreview: trimmedContent.substring(0, 300),
          filePath: filePath
        });
      }
      
      // Check if content looks like JSON
      if (!trimmedContent.startsWith('{') && !trimmedContent.startsWith('[')) {
        console.error(`File ${fileName} does not start with valid JSON characters`);
        console.error(`Content preview: ${trimmedContent.substring(0, 300)}`);
        return res.status(400).json({ 
          success: false, 
          message: `File ${fileName} does not start with valid JSON characters ('{' or '[')`,
          contentPreview: trimmedContent.substring(0, 300),
          filePath: filePath
        });
      }
      
      // Parse JSON
      try {
        const jsonData = JSON.parse(trimmedContent);
        console.log(`✅ Successfully parsed JSON from ${fileName}`);
        
        // Determine data structure type
        let dataType = 'unknown';
        let recordCount = 0;
        
        if (Array.isArray(jsonData)) {
          dataType = 'array';
          recordCount = jsonData.length;
          console.log(`JSON is an array with ${recordCount} records`);
        } else if (jsonData && typeof jsonData === 'object') {
          if (jsonData.tables && Array.isArray(jsonData.tables)) {
            dataType = 'schema';
            recordCount = jsonData.tables.length;
            console.log(`JSON is a schema definition with ${recordCount} tables`);
          } else {
            dataType = 'object';
            recordCount = 1;
            console.log(`JSON is a single object with keys: ${Object.keys(jsonData).join(', ')}`);
          }
        }
        
        return res.json({
          success: true,
          fileName: fileName,
          filePath: filePath,
          jsonData: jsonData,
          isNetworkPath: filePath.includes('\\\\'),
          dataType: dataType,
          recordCount: recordCount
        });
      } catch (parseError) {
        console.error(`JSON parse error for file ${fileName}:`, parseError);
        return res.status(400).json({ 
          success: false, 
          message: `File ${fileName} contains invalid JSON: ${parseError instanceof Error ? parseError.message : 'Parse error'}`,
          contentPreview: trimmedContent.substring(0, 300),
          filePath: filePath
        });
      }
    } catch (error) {
      console.error('Load JSON file from network error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to load JSON file from network'
      });
    }
  });

  // Load individual JSON file from incoming CSV directory
  app.post("/api/load-incoming-json", async (req: Request, res: Response) => {
    try {
      const { fileName, tableName } = req.body;
      if (!fileName) {
        return res.status(400).json({ success: false, message: "fileName is required" });
      }
      
      console.log('=== LOAD INCOMING JSON ===');
      console.log(`Loading file: ${fileName}`);
      
      // Use network directory path - ensure proper UNC format
      const networkDir = config.incomingCsvDir;
      console.log(`Configured network directory: ${networkDir}`);
      
      // Build all possible search paths
      const searchPaths = [
        path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', 'incomingcsv', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'input-files', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', fileName.endsWith('.json') ? fileName : `${fileName}.json`)
      ];
      
      console.log(`Search paths: ${searchPaths.join(', ')}`);
      
      let filePath = null;
      let fileContent = null;
      
      for (const p of searchPaths) {
        try {
          console.log(`Attempting to access: ${p}`);
          await fs.access(p);
          fileContent = await fs.readFile(p, 'utf-8');
          filePath = p;
          console.log(`Successfully read file from: ${p}`);
          console.log(`File content preview: ${fileContent.substring(0, 100)}...`);
          break;
        } catch (accessError) {
          console.log(`Cannot access: ${p} - ${accessError instanceof Error ? accessError.message : 'Unknown error'}`);
        }
      }
      
      if (!filePath || !fileContent) {
        return res.status(404).json({ success: false, message: `JSON file not found: ${fileName}` });
      }
      
      // Check if content is valid JSON and not HTML/XML
      const trimmedContent = fileContent.trim();
      if (!trimmedContent) {
        return res.status(400).json({ success: false, message: `File ${fileName} is empty` });
      }
      
      if (trimmedContent.startsWith('<!DOCTYPE') || trimmedContent.startsWith('<?xml') || trimmedContent.startsWith('<html')) {
        console.log(`File ${fileName} appears to be HTML/XML, not JSON`);
        return res.status(400).json({ success: false, message: `File ${fileName} is not a valid JSON file (appears to be HTML/XML)` });
      }
      
      if (!trimmedContent.startsWith('{') && !trimmedContent.startsWith('[')) {
        console.log(`File ${fileName} does not start with valid JSON characters`);
        return res.status(400).json({ success: false, message: `File ${fileName} does not appear to be valid JSON` });
      }
      
      let jsonData;
      try {
        jsonData = JSON.parse(trimmedContent);
        console.log(`Successfully parsed JSON from ${fileName}`);
      } catch (parseError) {
        console.error(`JSON parse error for file ${fileName}:`, parseError);
        console.error(`Content that failed to parse: ${trimmedContent.substring(0, 200)}...`);
        return res.status(400).json({ 
          success: false, 
          message: `File ${fileName} is not a valid JSON file: ${parseError instanceof Error ? parseError.message : 'Invalid JSON format'}` 
        });
      }
      
      // Check if this is a schema metadata file
      if (jsonData.tables && Array.isArray(jsonData.tables)) {
        // Process for individual table if tableName is provided
        if (tableName) {
          const tableData = jsonData.tables.find((table: any) =>
            table.name === tableName || table.table_name === tableName || table.tableName === tableName
          );
          if (tableData) {
            return res.json({ success: true, fileName, tableName, tableData, sourceFile: filePath, isLocal: !filePath.includes('\\\\') });
          } else {
            return res.status(404).json({ success: false, message: `Table ${tableName} not found in file ${fileName}` });
          }
        }
        // Return the complete JSON data if no specific table was requested
        return res.json({ success: true, fileName, jsonData, sourceFile: filePath, isLocal: !filePath.includes('\\\\') });
      } else {
        // This is a regular JSON file - return it for table display
        return res.json({ 
          success: true, 
          fileName, 
          jsonData, 
          sourceFile: filePath, 
          isLocal: !filePath.includes('\\\\'),
          isDataFile: true // Flag to indicate this is actual data, not schema
        });
      }
    } catch (error) {
      console.error('Load incoming JSON error:', error);
      res.status(500).json({ success: false, message: error instanceof Error ? error.message : 'Failed to load JSON file' });
    }
  });
  
  // List all available JSON files in the incoming directory
  app.get("/api/list-incoming-json", async (req: Request, res: Response) => {
    try {
      console.log('=== LIST INCOMING JSON FILES ===');
      
      // FORCE network paths - prioritize network over local
      const networkPaths = [
        "\\\\10.73.88.101\\data\\incomingcsv",     // Primary target path  
        "\\\\10.73.88.101\\reports",
        "\\\\10.73.88.101\\data\\processedcsv",
        "\\\\10.73.88.101\\data",
      ];
      
      // Local fallback paths (only used if network fails)
      const localPaths = [
        path.join(process.cwd(), 'data', 'incomingcsv'),
        path.join(process.cwd(), 'reports'),
        path.join(process.cwd(), 'data', 'processedcsv'),
        path.join(process.cwd(), 'data'),
        path.join(process.cwd(), 'input-files')
      ];
      
      console.log(`🌐 Priority Network Paths:`, networkPaths);
      console.log(`📁 Local Fallback Paths:`, localPaths);
      
      // Try network paths FIRST
      const searchPaths = [...networkPaths, ...localPaths];
      
      let allFiles: any[] = [];
      let searchResults: Array<{path: string, files: string[], success: boolean, isNetworkPath: boolean, error?: string}> = [];
      
      // Search all directories and collect JSON files from each
      for (const searchPath of searchPaths) {
        const isNetworkPath = searchPath.includes('\\\\10.73.88.101');
        try {
          console.log(`${isNetworkPath ? '🌐' : '📁'} Attempting to read directory: ${searchPath}`);
          const files = await fs.readdir(searchPath);
          const jsonFiles = files.filter(file => file.endsWith('.json'));
          console.log(`[SUCCESS] Directory read from: ${searchPath}`);
          console.log(`JSON files found: ${jsonFiles.length} files - ${jsonFiles.join(', ')}`);
          
          if (jsonFiles.length > 0) {
            // Get detailed file information
            const fileDetails = await Promise.all(
              jsonFiles.map(async (fileName) => {
                try {
                  const fullPath = path.join(searchPath, fileName);
                  const stats = await fs.stat(fullPath);
                  
                  // Read file to determine type
                  const content = await fs.readFile(fullPath, 'utf8');
                  const parsedContent = JSON.parse(content);
                  
                  let fileType = 'data_object';
                  if (Array.isArray(parsedContent)) {
                    fileType = 'data_array';
                  } else if (parsedContent.tables && Array.isArray(parsedContent.tables)) {
                    fileType = 'schema';
                  }
                  
                  return {
                    name: fileName,
                    path: fullPath,
                    size: stats.size,
                    fileType: fileType,
                    lastModified: stats.mtime.toISOString(),
                    isNetworkPath: isNetworkPath
                  };
                } catch (error) {
                  console.warn(`   ⚠️ Error reading file ${fileName}:`, error);
                  return null;
                }
              })
            );
            
            const validFiles = fileDetails.filter(f => f !== null);
            
            // Add files to collection (prioritize network files)
            if (isNetworkPath) {
              // Network files get priority - add them first
              allFiles.unshift(...validFiles);
              console.log(`✅ Found ${validFiles.length} JSON files in NETWORK path: ${searchPath}`);
            } else {
              // Only add local files if we don't already have network versions
              const newLocalFiles = validFiles.filter(localFile => 
                !allFiles.some(existingFile => existingFile.name === localFile.name && existingFile.isNetworkPath)
              );
              allFiles.push(...newLocalFiles);
              if (newLocalFiles.length > 0) {
                console.log(`📁 Added ${newLocalFiles.length} unique local files from: ${searchPath}`);
              }
            }
          }
          
          searchResults.push({
            path: searchPath,
            files: jsonFiles,
            success: true,
            isNetworkPath: isNetworkPath
          });
        } catch (error) {
          console.log(`[FAILED] Cannot read from directory: ${searchPath}`);
          console.log(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
          searchResults.push({
            path: searchPath,
            files: [],
            success: false,
            isNetworkPath: isNetworkPath,
            error: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }
      
      console.log(`Total unique JSON files found: ${allFiles.length}`);
      
      if (allFiles.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'No JSON files found in any data directory',
          searchResults: searchResults,
          totalDirectoriesSearched: searchPaths.length
        });
      }
      
      console.log(`Processing ${allFiles.length} unique JSON files...`);
      
      // Return successful response
      const response = {
        success: true,
        files: allFiles,
        searchResults: searchResults,
        totalDirectoriesSearched: searchPaths.length,
        networkPathsAttempted: networkPaths.length,
        localPathsUsed: allFiles.filter(f => !f.isNetworkPath).length,
        networkPathsUsed: allFiles.filter(f => f.isNetworkPath).length
      };
      
      console.log(`Response summary: ${allFiles.length} files total, ${response.networkPathsUsed} from network, ${response.localPathsUsed} from local`);
      res.json(response);
    } catch (error) {
      console.error('List incoming JSON error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to list JSON files' 
      });
    }
  });
            const stats = await fs.stat(filePath);
            let tableNames: string[] = [];
            let isValid = false;
            let fileType = 'unknown';
            
            try {
              const content = await fs.readFile(filePath, 'utf-8');
              const trimmedContent = content.trim();
              
              if (!trimmedContent) {
                console.log(`Skipping ${fileName}: Empty file`);
                break;
              }
              
              if (trimmedContent.startsWith('<!DOCTYPE') || trimmedContent.startsWith('<?xml') || trimmedContent.startsWith('<html')) {
                console.log(`Skipping ${fileName}: Not a valid JSON file (appears to be HTML/XML)`);
                break;
              }
              
              if (!trimmedContent.startsWith('{') && !trimmedContent.startsWith('[')) {
                console.log(`Skipping ${fileName}: Does not start with valid JSON characters`);
                break;
              }
              
              const data = JSON.parse(trimmedContent);
              
              if (data.tables && Array.isArray(data.tables)) {
                // This is a schema metadata file
                tableNames = data.tables.map((table: any) =>
                  table.name || table.table_name || table.tableName || 'Unknown'
                );
                isValid = true;
                fileType = 'schema';
              } else if (Array.isArray(data)) {
                // This is an array of data
                tableNames = [`${fileName} (Array with ${data.length} items)`];
                isValid = true;
                fileType = 'data_array';
              } else if (typeof data === 'object') {
                // This is an object - could be single record or structured data
                const keys = Object.keys(data);
                tableNames = [`${fileName} (Object with keys: ${keys.slice(0, 5).join(', ')}${keys.length > 5 ? '...' : ''})`];
                isValid = true;
                fileType = 'data_object';
              }
            } catch (readError) {
              console.log(`Skipping ${fileName}: Error reading or parsing file - ${readError instanceof Error ? readError.message : 'Unknown error'}`);
              break;
            }
            
            if (isValid) {
              fileDetails.push({
                name: fileName,
                path: filePath,
                size: stats.size,
                modified: stats.mtime,
                tables: tableNames,
                tableCount: tableNames.length,
                fileType
              });
              fileProcessed = true;
            }
            break; // File processed, move to next file
          } catch (error) {
            console.log(`Error getting details for ${fileName} in ${searchResult.path}: ${error instanceof Error ? error.message : 'Unknown error'}`);
            continue; // Try next search path for this file
          }
        }
        
        if (!fileProcessed) {
          console.log(`Warning: Could not process file ${fileName} from any location`);
        }
      }
      
      res.json({
        success: true,
        files: fileDetails,
        count: fileDetails.length,
        searchResults: searchResults,
        totalDirectoriesSearched: searchResults.length,
        isLocal: true // Simplified for now
      });
    } catch (error) {
      console.error('List incoming JSON error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to list JSON files'
      });
    }
  });
  
  // Load JSON data for table display
  app.post("/api/load-json-table-data", async (req: Request, res: Response) => {
    try {
      const { fileName } = req.body;
      if (!fileName) {
        return res.status(400).json({ success: false, message: "fileName is required" });
      }
      
      console.log('=== LOAD JSON TABLE DATA ===');
      console.log(`Loading file for table display: ${fileName}`);
      
      // Build all possible search paths
      const networkDir = config.incomingCsvDir;
      const searchPaths = [
        path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', 'incomingcsv', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'input-files', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', fileName.endsWith('.json') ? fileName : `${fileName}.json`)
      ];
      
      let filePath = null;
      let fileContent = null;
      
      for (const p of searchPaths) {
        try {
          console.log(`Attempting to access: ${p}`);
          await fs.access(p);
          fileContent = await fs.readFile(p, 'utf-8');
          filePath = p;
          console.log(`Successfully read file from: ${p}`);
          break;
        } catch (accessError) {
          console.log(`Cannot access: ${p} - ${accessError instanceof Error ? accessError.message : 'Unknown error'}`);
        }
      }
      
      if (!filePath || !fileContent) {
        return res.status(404).json({ success: false, message: `JSON file not found: ${fileName}` });
      }
      
      // Parse JSON content
      const trimmedContent = fileContent.trim();
      if (!trimmedContent || !trimmedContent.startsWith('{') && !trimmedContent.startsWith('[')) {
        return res.status(400).json({ success: false, message: `File ${fileName} is not valid JSON` });
      }
      
      let jsonData;
      try {
        jsonData = JSON.parse(trimmedContent);
      } catch (parseError) {
        console.error(`JSON parse error for file ${fileName}:`, parseError);
        return res.status(400).json({ 
          success: false, 
          message: `Invalid JSON in file ${fileName}: ${parseError instanceof Error ? parseError.message : 'Parse error'}` 
        });
      }
      
      // Format data for table display
      let tableData: any[] = [];
      let columns: string[] = [];
      
      if (Array.isArray(jsonData)) {
        // Handle array of objects
        if (jsonData.length > 0) {
          const firstItem = jsonData[0];
          if (typeof firstItem === 'object' && firstItem !== null) {
            columns = Object.keys(firstItem);
            tableData = jsonData;
          } else {
            // Array of primitives
            columns = ['Value'];
            tableData = jsonData.map((item, index) => ({ 
              Index: index, 
              Value: item 
            }));
            columns.unshift('Index');
          }
        }
      } else if (typeof jsonData === 'object' && jsonData !== null) {
        if (jsonData.tables && Array.isArray(jsonData.tables)) {
          // This is a schema metadata file - show table info
          columns = ['Table Name', 'Record Count', 'Columns'];
          tableData = jsonData.tables.map((table: any) => ({
            'Table Name': table.name || table.table_name || table.tableName || 'Unknown',
            'Record Count': table.record_count || table.recordCount || 'Unknown',
            'Columns': table.columns ? table.columns.length : 'Unknown'
          }));
        } else {
          // Single object - convert to key-value pairs
          columns = ['Property', 'Value'];
          tableData = Object.entries(jsonData).map(([key, value]) => ({
            Property: key,
            Value: typeof value === 'object' ? JSON.stringify(value) : String(value)
          }));
        }
      }
      
      res.json({
        success: true,
        fileName,
        tableData,
        columns,
        totalRows: tableData.length,
        sourceFile: filePath,
        isLocal: !filePath.includes('\\\\')
      });
      
    } catch (error) {
      console.error('Load JSON table data error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to load JSON table data' 
      });
    }
  });
  
  // Save edited JSON file
  app.post("/api/save-json-file", async (req: Request, res: Response) => {
    try {
      const { fileName, jsonData } = req.body;
      if (!fileName || !jsonData) {
        return res.status(400).json({ success: false, message: "fileName and jsonData are required" });
      }
      
      console.log('=== SAVE JSON FILE ===');
      console.log(`Saving file: ${fileName}`);
      
      // Build all possible search paths to find the original file
      const networkDir = config.incomingCsvDir;
      const searchPaths = [
        path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', 'incomingcsv', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'input-files', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', fileName.endsWith('.json') ? fileName : `${fileName}.json`)
      ];
      
      let filePath = null;
      
      // Find the existing file path
      for (const p of searchPaths) {
        try {
          await fs.access(p);
          filePath = p;
          console.log(`Found existing file at: ${p}`);
          break;
        } catch (accessError) {
          console.log(`Cannot access: ${p}`);
        }
      }
      
      if (!filePath) {
        // If file doesn't exist, create it in the network directory
        filePath = path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`);
        console.log(`Creating new file at: ${filePath}`);
      }
      
      // Format the JSON data nicely
      const formattedJson = JSON.stringify(jsonData, null, 2);
      
      // Save the file
      await fs.writeFile(filePath, formattedJson, 'utf-8');
      console.log(`Successfully saved file to: ${filePath}`);
      
      res.json({
        success: true,
        message: `File ${fileName} saved successfully`,
        filePath,
        isLocal: !filePath.includes('\\\\')
      });
      
    } catch (error) {
      console.error('Save JSON file error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to save JSON file' 
      });
    }
  });
  
  // Load JSON data for editable table display (preserves original structure)
  app.post("/api/load-json-schema-data", async (req: Request, res: Response) => {
    try {
      const { fileName } = req.body;
      if (!fileName) {
        return res.status(400).json({ success: false, message: "fileName is required" });
      }
      
      console.log('=== LOAD JSON SCHEMA DATA ===');
      console.log(`Loading file for schema editing: ${fileName}`);
      
      // Build all possible search paths
      const networkDir = config.incomingCsvDir;
      const searchPaths = [
        path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', 'incomingcsv', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'input-files', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', fileName.endsWith('.json') ? fileName : `${fileName}.json`)
      ];
      
      let filePath = null;
      let fileContent = null;
      
      for (const p of searchPaths) {
        try {
          console.log(`Attempting to access: ${p}`);
          await fs.access(p);
          fileContent = await fs.readFile(p, 'utf-8');
          filePath = p;
          console.log(`Successfully read file from: ${p}`);
          break;
        } catch (accessError) {
          console.log(`Cannot access: ${p} - ${accessError instanceof Error ? accessError.message : 'Unknown error'}`);
        }
      }
      
      if (!filePath || !fileContent) {
        return res.status(404).json({ success: false, message: `JSON file not found: ${fileName}` });
      }
      
      // Parse JSON content
      const trimmedContent = fileContent.trim();
      if (!trimmedContent || !trimmedContent.startsWith('{') && !trimmedContent.startsWith('[')) {
        return res.status(400).json({ success: false, message: `File ${fileName} is not valid JSON` });
      }
      
      let jsonData;
      try {
        jsonData = JSON.parse(trimmedContent);
      } catch (parseError) {
        console.error(`JSON parse error for file ${fileName}:`, parseError);
        return res.status(400).json({ 
          success: false, 
          message: `Invalid JSON in file ${fileName}: ${parseError instanceof Error ? parseError.message : 'Parse error'}` 
        });
      }
      
      // Return the original JSON structure for editing
      res.json({
        success: true,
        fileName,
        originalData: jsonData,
        sourceFile: filePath,
        isLocal: !filePath.includes('\\\\')
      });
      
    } catch (error) {
      console.error('Load JSON schema data error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to load JSON schema data' 
      });
    }
  });

  // Save edited JSON schema file
  app.post("/api/save-json-schema-file", async (req: Request, res: Response) => {
    try {
      const { fileName, originalData } = req.body;
      if (!fileName || !originalData) {
        return res.status(400).json({ success: false, message: "fileName and originalData are required" });
      }
      
      console.log('=== SAVE JSON SCHEMA FILE ===');
      console.log(`Saving schema file: ${fileName}`);
      
      // Build all possible search paths to find the original file
      const networkDir = config.incomingCsvDir;
      const searchPaths = [
        path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', 'incomingcsv', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'input-files', fileName.endsWith('.json') ? fileName : `${fileName}.json`),
        path.join(process.cwd(), 'data', fileName.endsWith('.json') ? fileName : `${fileName}.json`)
      ];
      
      let filePath = null;
      
      // Find the existing file path
      for (const p of searchPaths) {
        try {
          await fs.access(p);
          filePath = p;
          console.log(`Found existing file at: ${p}`);
          break;
        } catch (accessError) {
          console.log(`Cannot access: ${p}`);
        }
      }
      
      if (!filePath) {
        // If file doesn't exist, create it in the network directory
        filePath = path.join(networkDir, fileName.endsWith('.json') ? fileName : `${fileName}.json`);
        console.log(`Creating new file at: ${filePath}`);
      }
      
      // Format the JSON data nicely
      const formattedJson = JSON.stringify(originalData, null, 2);
      
      // Save the file
      await fs.writeFile(filePath, formattedJson, 'utf-8');
      console.log(`Successfully saved schema file to: ${filePath}`);
      
      res.json({
        success: true,
        message: `Schema file ${fileName} saved successfully`,
        filePath,
        isLocal: !filePath.includes('\\\\')
      });
      
    } catch (error) {
      console.error('Save JSON schema file error:', error);
      res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : 'Failed to save JSON schema file' 
      });
    }
  });
  
  // Debug endpoint for checking raw file contents
  app.post("/api/debug-file-content", async (req: Request, res: Response) => {
    try {
      const { filePath } = req.body;
      if (!filePath) {
        return res.status(400).json({ success: false, message: "filePath is required" });
      }
      
      console.log(`=== DEBUG FILE CONTENT ===`);
      console.log(`Checking file: ${filePath}`);
      
      try {
        // Check if file exists
        await fs.access(filePath);
        
        // Read file content
        const fileContent = await fs.readFile(filePath, 'utf8');
        console.log(`Successfully read file content (${fileContent.length} bytes)`);
        
        // Determine file type based on content
        let fileType = 'unknown';
        const trimmedContent = fileContent.trim();
        
        if (trimmedContent.startsWith('<!DOCTYPE') || trimmedContent.startsWith('<?xml') || trimmedContent.startsWith('<html')) {
          fileType = 'html/xml';
        } else if (trimmedContent.startsWith('{') || trimmedContent.startsWith('[')) {
          fileType = 'json';
        } else if (/^[\w\d,\s"';:]+$/i.test(trimmedContent.substring(0, 100))) {
          fileType = 'text';
        } else if (/[\x00-\x08\x0E-\x1F]/.test(trimmedContent.substring(0, 100))) {
          fileType = 'binary';
        }
        
        // Check if content is valid JSON
        let isValidJson = false;
        let jsonParseError = null;
        let jsonPreview = null;
        
        if (fileType === 'json') {
          try {
            const parsed = JSON.parse(trimmedContent);
            isValidJson = true;
            jsonPreview = JSON.stringify(parsed, null, 2).substring(0, 1000);
          } catch (error) {
            jsonParseError = error instanceof Error ? error.message : 'Unknown parsing error';
          }
        }
        
        return res.json({
          success: true,
          filePath,
          fileSize: fileContent.length,
          fileType,
          contentPreview: fileContent.substring(0, 1000),
          isValidJson,
          jsonParseError,
          jsonPreview
        });
      } catch (error) {
        console.error(`Error accessing file ${filePath}:`, error);
        return res.status(404).json({
          success: false,
          message: `Cannot access file: ${filePath}`,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    } catch (error) {
      console.error('Debug file content error:', error);
      res.status(500).json({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to check file content'
      });
    }
  });
}
