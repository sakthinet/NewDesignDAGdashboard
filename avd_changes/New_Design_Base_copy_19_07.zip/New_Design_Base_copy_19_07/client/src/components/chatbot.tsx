import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Minimize2, 
  Maximize2,
  X,
  Loader2,
  RefreshCw,
  Settings,
  Database,
  FileText,
  BarChart3,
  AlertCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useClientConfig } from "@/hooks/use-client-config";

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  metadata?: {
    dagCount?: number;
    runCount?: number;
    suggestions?: string[];
  };
}

interface ChatbotState {
  isOpen: boolean;
  isMinimized: boolean;
  isLoading: boolean;
  messages: Message[];
  currentInput: string;
}

interface DashboardContext {
  dags: any[];
  totalDags: number;
  runningDags: number;
  pausedDags: number;
  recentRuns: any[];
  connectionStatus: boolean;
}

export function Chatbot() {
  const clientConfig = useClientConfig();
  const [state, setState] = useState<ChatbotState>({
    isOpen: false,
    isMinimized: false,
    isLoading: false,
    messages: [],
    currentInput: ''
  });

  const [dashboardContext, setDashboardContext] = useState<DashboardContext>({
    dags: [],
    totalDags: 0,
    runningDags: 0,
    pausedDags: 0,
    recentRuns: [],
    connectionStatus: false
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const airflowApi = useAirflowApi();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.messages]);

  // Focus input when chatbot opens
  useEffect(() => {
    if (state.isOpen && !state.isMinimized) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [state.isOpen, state.isMinimized]);

  // Load dashboard context
  useEffect(() => {
    loadDashboardContext();
  }, []);

  const loadDashboardContext = async () => {
    try {
      const dags = await airflowApi.getDags(true); // Force refresh
      const connectionTest = await airflowApi.testConnection();
      
      if (dags?.dags) {
        const runningDags = dags.dags.filter((dag: any) => !dag.is_paused).length;
        const pausedDags = dags.dags.filter((dag: any) => dag.is_paused).length;
        const recentRuns = dags.dags.flatMap((dag: any) => dag.recent_runs || []).slice(0, 10);

        setDashboardContext({
          dags: dags.dags,
          totalDags: dags.dags.length,
          runningDags,
          pausedDags,
          recentRuns,
          connectionStatus: connectionTest?.connected || false
        });
      }
    } catch (error) {
      console.error('Failed to load dashboard context:', error);
    }
  };

  const generateSystemPrompt = (context: DashboardContext): string => {
    return `You are TCS ECM Airflow Assistant, an AI helper for the TCS ECM Airflow DAG Generator application.

CURRENT DASHBOARD STATUS:
- Total Workspace: ${context.totalDags}
- Running DAGs: ${context.runningDags}
- Paused DAGs: ${context.pausedDags}
- Airflow Connection: ${context.connectionStatus ? 'Connected' : 'Disconnected'}
- Recent Runs: ${context.recentRuns.length} recent executions

DAG DETAILS:
${context.dags.map(dag => `- ${dag.dag_id}: ${dag.is_paused ? 'Paused' : 'Active'} (${dag.recent_runs?.length || 0} recent runs)`).join('\n')}

You can help users with:
1. Dashboard insights and DAG status explanations
2. Airflow concepts and troubleshooting
3. DAG configuration and best practices
4. File upload and CSV to XML conversion guidance
5. Workflow automation suggestions
6. Performance optimization tips

Keep responses concise, helpful, and focused on Airflow/ETL workflows. If users ask about specific DAGs, refer to the current dashboard data above.`;
  };

  const callLLM = async (userMessage: string, context: DashboardContext): Promise<string> => {
    try {
      // Try Ollama first (local LLM)
      const ollamaResponse = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'llama3.2', // or 'mistral', 'codellama', etc.
          prompt: `${generateSystemPrompt(context)}\n\nUser: ${userMessage}\nAssistant:`,
          stream: false,
          options: {
            temperature: 0.7,
            max_tokens: 500
          }
        })
      });

      if (ollamaResponse.ok) {
        const data = await ollamaResponse.json();
        return data.response || 'I apologize, but I received an empty response.';
      }
    } catch (ollamaError) {
      console.log('Ollama not available, trying fallback...');
    }

    // Fallback to your backend LLM service
    try {
      const backendResponse = await fetch('/api/chatbot/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          context: context,
          systemPrompt: generateSystemPrompt(context)
        })
      });

      if (backendResponse.ok) {
        const data = await backendResponse.json();
        return data.response || 'I apologize, but I received an empty response.';
      }
    } catch (backendError) {
      console.log('Backend LLM not available...');
    }

    // Final fallback - rule-based responses
    return generateFallbackResponse(userMessage, context);
  };

  const generateFallbackResponse = (userMessage: string, context: DashboardContext): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('dag') && message.includes('count')) {
      return `You currently have ${context.totalDags} DAGs in total: ${context.runningDags} active and ${context.pausedDags} paused.`;
    }
    
    if (message.includes('status') || message.includes('dashboard')) {
      return `Dashboard Status:\n• Total Workspace: ${context.totalDags}\n• Active: ${context.runningDags}\n• Paused: ${context.pausedDags}\n• Connection: ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}\n• Recent Runs: ${context.recentRuns.length}`;
    }
    
    if (message.includes('help') || message.includes('what can you do')) {
      return `I can help you with:\n• Dashboard insights and Workspace status\n• Airflow troubleshooting\n• CSV to XML conversion guidance\n• Workflow automation tips\n• Performance optimization\n\nTry asking: "What's my dashboard status?" or "How do I create a Workspace?"`;
    }
    
    if (message.includes('create') && message.includes('dag')) {
      return `To create a new DAG:\n1. Go to Upload section\n2. Upload your CSV file\n3. Configure DAG settings\n4. Generate and deploy\n\nYour current DAGs: ${context.dags.map(d => d.dag_id).join(', ')}`;
    }
    
    if (message.includes('connection') || message.includes('airflow')) {
      return `Airflow Connection: ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}\n\nIf disconnected, ensure Airflow is running at ${clientConfig.airflowUrl}`;
    }
    
    return `I understand you're asking about: "${userMessage}"\n\nI can help with dashboard status, Workspace management, and Airflow workflows. Try asking more specific questions about your ${context.totalDags} Workspaces or workflow automation.`;
  };

  const handleSendMessage = async () => {
    const userMessage = state.currentInput.trim();
    if (!userMessage) return;

    const userMsgId = Date.now().toString();
    const userMsg: Message = {
      id: userMsgId,
      type: 'user',
      content: userMessage,
      timestamp: new Date()
    };

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMsg],
      currentInput: '',
      isLoading: true
    }));

    try {
      // Refresh dashboard context for latest data
      await loadDashboardContext();
      
      const botResponse = await callLLM(userMessage, dashboardContext);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: botResponse,
        timestamp: new Date(),
        metadata: {
          dagCount: dashboardContext.totalDags,
          runCount: dashboardContext.recentRuns.length,
          suggestions: generateSuggestions(userMessage)
        }
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, botMsg],
        isLoading: false
      }));

    } catch (error) {
      console.error('Chat error:', error);
      
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: 'I apologize, but I encountered an error. Please try again or check your connection.',
        timestamp: new Date()
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, errorMsg],
        isLoading: false
      }));

      toast({
        title: "Chat Error",
        description: "Unable to process your message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const generateSuggestions = (userMessage: string): string[] => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('dag')) {
      return [
        "Show me DAG performance metrics",
        "How do I troubleshoot failed DAGs?",
        "Best practices for DAG scheduling"
      ];
    }
    
    if (message.includes('upload') || message.includes('csv')) {
      return [
        "What CSV format is supported?",
        "How to handle large CSV files?",
        "XML output customization options"
      ];
    }

    // NEW: Add reports-specific suggestions
    if (message.includes('report') || message.includes('analytics') || message.includes('intelligence')) {
      return [
        "What types of reports are available?",
        "How do I view business intelligence?",
        "Show me analytics dashboard features"
      ];
    }

    if (message.includes('dashboard')) {
      return [
        "Show me reports section",
        "What analytics are available?",
        "DAG performance overview"
      ];
    }
    
    return [
      "What's my dashboard status?",
      "Show me reports and analytics",
      "How do I create a new DAG?",
      "View business intelligence features"
    ];
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleChatbot = () => {
    setState(prev => ({ ...prev, isOpen: !prev.isOpen }));
    if (!state.isOpen && state.messages.length === 0) {
      // Add welcome message with enhanced reports info
      const welcomeMsg: Message = {
        id: 'welcome',
        type: 'bot',
        content: `Hello! I'm your TCS ECM Airflow Assistant. I can help you with:

• **Dashboard**: Monitor your ${dashboardContext.totalDags} DAGs and workflow status
• **Reports & Analytics**: View business intelligence and performance metrics  
• **DAG Management**: Create, configure, and troubleshoot workflows
• **Data Processing**: CSV to XML conversion guidance
• **System Support**: Performance optimization and troubleshooting

What would you like to know?`,
        timestamp: new Date(),
        metadata: {
          dagCount: dashboardContext.totalDags,
          suggestions: [
            "What's my dashboard status?",
            "Show me reports and analytics",
            "How do I create a DAG?",
            "View business intelligence features"
          ]
        }
      };
      
      setState(prev => ({ ...prev, messages: [welcomeMsg] }));
    }
  };

  const toggleMinimize = () => {
    setState(prev => ({ ...prev, isMinimized: !prev.isMinimized }));
  };

  const clearChat = () => {
    setState(prev => ({ ...prev, messages: [] }));
  };

  const refreshContext = async () => {
    await loadDashboardContext();
    toast({
      title: "Context Refreshed",
      description: "Dashboard data has been updated for the chatbot.",
    });
  };

  if (!state.isOpen) {
    return (
      <Button
        onClick={toggleChatbot}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg z-50"
      >
        <MessageCircle className="h-6 w-6 text-white" />
      </Button>
    );
  }

  return (
    <Card className={`fixed bottom-6 right-6 z-50 w-96 shadow-xl transition-all duration-300 ${
      state.isMinimized ? 'h-16' : 'h-[600px]'
    }`}>
      <CardHeader className="flex flex-row items-center justify-between p-4 pb-2">
        <div className="flex items-center space-x-2">
          <Bot className="h-5 w-5 text-blue-600" />
          <CardTitle className="text-lg">Buddy</CardTitle>
          {dashboardContext.connectionStatus && (
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={refreshContext}>
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleMinimize}>
            {state.isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleChatbot}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      {!state.isMinimized && (
        <CardContent className="flex flex-col h-[500px] p-4 pt-0">
          {/* Dashboard Status Bar */}
          <div className="flex items-center justify-between text-xs bg-gray-50 p-2 rounded mb-3">
            <div className="flex items-center space-x-4">
              <span className="flex items-center">
                <Database className="h-3 w-3 mr-1" />
                {dashboardContext.totalDags} DAGs
              </span>
              <span className="flex items-center">
                <BarChart3 className="h-3 w-3 mr-1" />
                {dashboardContext.runningDags} Active
              </span>
              {!dashboardContext.connectionStatus && (
                <span className="flex items-center text-red-600">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Offline
                </span>
              )}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 mb-4">
            {state.messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-blue-600 text-white ml-4'
                      : 'bg-gray-100 text-gray-900 mr-4'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.type === 'bot' && <Bot className="h-4 w-4 mt-1 flex-shrink-0" />}
                    {message.type === 'user' && <User className="h-4 w-4 mt-1 flex-shrink-0" />}
                    <div className="flex-1">
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                      {message.metadata?.suggestions && (
                        <div className="mt-2 space-y-1">
                          {message.metadata.suggestions.map((suggestion, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className="text-xs h-6 w-full"
                              onClick={() => setState(prev => ({ ...prev, currentInput: suggestion }))}
                            >
                              {suggestion}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            
            {state.isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 text-gray-900 p-3 rounded-lg mr-4">
                  <div className="flex items-center space-x-2">
                    <Bot className="h-4 w-4" />
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="flex space-x-2">
            <Input
              ref={inputRef}
              value={state.currentInput}
              onChange={(e) => setState(prev => ({ ...prev, currentInput: e.target.value }))}
              onKeyPress={handleKeyPress}
              placeholder="Ask about your DAGs, workflows, or Airflow..."
              disabled={state.isLoading}
              className="flex-1"
            />
            <Button 
              onClick={handleSendMessage} 
              disabled={state.isLoading || !state.currentInput.trim()}
              size="sm"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="flex justify-center mt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={clearChat}
              className="text-xs"
            >
              Clear Chat
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
