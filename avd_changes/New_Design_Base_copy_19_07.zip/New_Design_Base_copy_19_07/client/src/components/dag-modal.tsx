import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  X,
  Clock,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  RefreshCw,
  Activity,
  Database,
  GitBranch,
  Calendar,
  User,
  FileText,
  AlertCircle,
  TrendingUp,
  Code,
  Settings,
  Zap
} from 'lucide-react';

interface DAGModalProps {
  isOpen: boolean;
  onClose: () => void;
  dagId: string | null;
  darkMode: boolean;
  airflowApi: any;
}

interface DAGDetails {
  dag: any;
  runs: any[];
  tasks: any[];
}

const getStateColor = (state: string, darkMode: boolean): string => {
  const lightColors = {
    success: 'bg-cyan-100 text-cyan-800 border-cyan-200',
    running: 'bg-blue-100 text-blue-800 border-blue-200',
    failed: 'bg-red-100 text-red-800 border-red-200',
    queued: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    scheduled: 'bg-purple-100 text-purple-800 border-purple-200',
    up_for_retry: 'bg-orange-100 text-orange-800 border-orange-200',
    up_for_reschedule: 'bg-orange-100 text-orange-800 border-orange-200',
    upstream_failed: 'bg-red-50 text-red-600 border-red-200',
    skipped: 'bg-gray-100 text-gray-800 border-gray-200',
    none: 'bg-gray-50 text-gray-600 border-gray-200',
    paused: 'bg-orange-100 text-orange-800 border-orange-200'
  };

  const darkColors = {
    success: 'bg-cyan-900 text-cyan-300 border-cyan-700',
    running: 'bg-blue-900 text-blue-300 border-blue-700',
    failed: 'bg-red-900 text-red-300 border-red-700',
    queued: 'bg-yellow-900 text-yellow-300 border-yellow-700',
    scheduled: 'bg-purple-900 text-purple-300 border-purple-700',
    up_for_retry: 'bg-orange-900 text-orange-300 border-orange-700',
    up_for_reschedule: 'bg-orange-900 text-orange-300 border-orange-700',
    upstream_failed: 'bg-red-800 text-red-300 border-red-700',
    skipped: 'bg-gray-800 text-gray-300 border-gray-600',
    none: 'bg-gray-800 text-gray-400 border-gray-600',
    paused: 'bg-orange-900 text-orange-300 border-orange-700'
  };

  const colors = darkMode ? darkColors : lightColors;
  return colors[state as keyof typeof colors] || colors.none;
};

const getStateIcon = (state: string): JSX.Element => {
  const iconMap: Record<string, JSX.Element> = {
    success: <CheckCircle className="w-4 h-4" />,
    running: <RefreshCw className="w-4 h-4 animate-spin" />,
    failed: <XCircle className="w-4 h-4" />,
    queued: <Clock className="w-4 h-4" />,
    scheduled: <Calendar className="w-4 h-4" />,
    up_for_retry: <RefreshCw className="w-4 h-4" />,
    up_for_reschedule: <Clock className="w-4 h-4" />,
    upstream_failed: <AlertCircle className="w-4 h-4" />,
    skipped: <Play className="w-4 h-4" />,
    none: <Pause className="w-4 h-4" />
  };
  
  return iconMap[state] || iconMap.none;
};

const formatDate = (dateString: string | null): string => {
  if (!dateString) return 'N/A';
  try {
    return new Date(dateString).toLocaleString();
  } catch {
    return 'Invalid Date';
  }
};

const formatDuration = (startDate: string | null, endDate: string | null): string => {
  if (!startDate || !endDate) return 'N/A';
  try {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const durationMs = end.getTime() - start.getTime();
    const seconds = Math.floor(durationMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  } catch {
    return 'N/A';
  }
};

export default function DAGModal({ isOpen, onClose, dagId, darkMode, airflowApi }: DAGModalProps) {
  const [dagDetails, setDagDetails] = useState<DAGDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedRun, setSelectedRun] = useState<any>(null);
  const [showRunLogs, setShowRunLogs] = useState(false);
  const [runLogs, setRunLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const loadingRef = useRef(false);
  const mountedRef = useRef(true);

  // Dragging state
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [modalPosition, setModalPosition] = useState({ x: 0, y: 0 });
  const modalRef = useRef<HTMLDivElement>(null);

  // Reset mounted ref when component mounts
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  // Drag handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (modalRef.current) {
      const rect = modalRef.current.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
      setIsDragging(true);
    }
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging && modalRef.current) {
      const container = modalRef.current.parentElement;
      if (container) {
        const containerRect = container.getBoundingClientRect();
        const modalRect = modalRef.current.getBoundingClientRect();
        
        const newX = e.clientX - containerRect.left - dragOffset.x;
        const newY = e.clientY - containerRect.top - dragOffset.y;
        
        // Constrain within container bounds
        const maxX = containerRect.width - modalRect.width;
        const maxY = containerRect.height - modalRect.height;
        
        const constrainedX = Math.max(0, Math.min(maxX, newX));
        const constrainedY = Math.max(0, Math.min(maxY, newY));
        
        setModalPosition({ x: constrainedX, y: constrainedY });
      }
    }
  }, [isDragging, dragOffset]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  // Add global mouse event listeners
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  // Load DAG details when modal opens
  useEffect(() => {
    if (!isOpen || !dagId) {
      setDagDetails(null);
      setError(null);
      loadingRef.current = false;
      return;
    }

    // Prevent multiple simultaneous loads
    if (loadingRef.current) {
      console.log('⏭️ Load already in progress, skipping...');
      return;
    }

    const loadDagDetails = async () => {
      if (!mountedRef.current) return;
      
      loadingRef.current = true;
      setLoading(true);
      setError(null);

      try {
        console.log(`🔍 Loading details for DAG: ${dagId}`);
        
        // Add small delay to prevent rapid requests
        await new Promise(resolve => setTimeout(resolve, 100));
        
        if (!mountedRef.current) return;

        // Get DAG details, runs, and tasks in parallel
        const [dagResult, runsResult] = await Promise.allSettled([
          airflowApi.getDag(dagId, true), // Force refresh for modal
          airflowApi.getDagRuns(dagId, 10, 0, true)
        ]);

        if (!mountedRef.current) return; // Don't update state if component unmounted

        let dag = null;
        let runs: any[] = [];
        let tasks: any[] = [];

        // Process DAG result
        if (dagResult.status === 'fulfilled' && dagResult.value) {
          dag = dagResult.value.dag;
          tasks = dagResult.value.tasks || [];
        }

        // Process runs result
        if (runsResult.status === 'fulfilled' && runsResult.value) {
          runs = runsResult.value.runs || [];
        }

        if (!dag) {
          throw new Error(`DAG ${dagId} not found or failed to load`);
        }

        if (mountedRef.current) {
          setDagDetails({ dag, runs, tasks });
          console.log(`✅ Successfully loaded details for DAG: ${dagId}`);
        }
        
      } catch (err) {
        if (mountedRef.current) {
          console.error(`❌ Failed to load DAG details for ${dagId}:`, err);
          const errorMessage = err instanceof Error ? err.message : 'Failed to load DAG details';
          setError(errorMessage);
        }
      } finally {
        if (mountedRef.current) {
          setLoading(false);
        }
        loadingRef.current = false;
      }
    };

    loadDagDetails();
  }, [isOpen, dagId]); // Only depend on isOpen and dagId

  // Load individual run logs
  const loadRunLogs = async (runId: string) => {
    if (!dagId || !runId) return;
    
    setLoadingLogs(true);
    setRunLogs([]);
    
    try {
      console.log(`🔍 Loading logs for run: ${runId}`);
      
      // Get task instances for this run
      const result = await airflowApi.getTaskInstances(dagId, runId, true);
      
      if (result && result.task_instances) {
        setRunLogs(result.task_instances);
        console.log(`✅ Loaded ${result.task_instances.length} task instances`);
      } else {
        // Create mock logs if no data available
        setRunLogs([
          {
            task_id: 'start_task',
            state: 'success',
            start_date: new Date().toISOString(),
            end_date: new Date().toISOString(),
            duration: 1.2,
            try_number: 1,
            log_url: '#'
          }
        ]);
      }
    } catch (err) {
      console.error('Failed to load run logs:', err);
      // Create fallback logs
      setRunLogs([
        {
          task_id: 'Error loading logs',
          state: 'failed',
          start_date: new Date().toISOString(),
          end_date: new Date().toISOString(),
          duration: 0,
          try_number: 1,
          log_url: '#',
          error: 'Failed to fetch task logs'
        }
      ]);
    } finally {
      setLoadingLogs(false);
    }
  };

  // Handle run click
  const handleRunClick = async (run: any) => {
    setSelectedRun(run);
    setShowRunLogs(true);
    await loadRunLogs(run.dag_run_id);
  };

  // Calculate statistics
  const statistics = useMemo(() => {
    if (!dagDetails?.runs) return null;
    
    const { runs } = dagDetails;
    const total = runs.length;
    const successful = runs.filter(run => run.state === 'success').length;
    const failed = runs.filter(run => run.state === 'failed').length;
    const running = runs.filter(run => run.state === 'running').length;
    const successRate = total > 0 ? Math.round((successful / total) * 100) : 0;
    
    // Calculate average duration
    const completedRuns = runs.filter(run => run.start_date && run.end_date);
    let avgDuration = 0;
    if (completedRuns.length > 0) {
      const totalDuration = completedRuns.reduce((sum, run) => {
        const start = new Date(run.start_date);
        const end = new Date(run.end_date);
        return sum + (end.getTime() - start.getTime());
      }, 0);
      avgDuration = Math.round(totalDuration / completedRuns.length / 1000); // in seconds
    }
    
    return { total, successful, failed, running, successRate, avgDuration };
  }, [dagDetails]);

  const handleClose = () => {
    setActiveTab('overview'); // Reset to overview tab
    setDagDetails(null); // Clear previous data
    setError(null); // Clear any errors
    setLoading(false); // Stop loading
    setShowRunLogs(false); // Close logs modal
    setSelectedRun(null); // Clear selected run
    loadingRef.current = false; // Reset loading ref
    
    // Reset modal position
    setModalPosition({ x: 0, y: 0 });
    setIsDragging(false);
    
    onClose();
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  if (!isOpen || !dagId) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none"
      onClick={handleBackdropClick}
    >
      <div 
        ref={modalRef}
        className={`relative w-full max-w-4xl max-h-[80vh] overflow-y-auto rounded-lg shadow-2xl border-2 pointer-events-auto ${
          darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-300'
        } ${isDragging ? 'cursor-grabbing' : ''}`}
        style={{
          left: modalPosition.x,
          top: modalPosition.y,
          transform: modalPosition.x === 0 && modalPosition.y === 0 ? 'none' : 'none',
          marginLeft: modalPosition.x === 0 && modalPosition.y === 0 ? 0 : 0,
        }}
      >
        {/* Header */}
        <div 
          className={`flex items-center justify-between p-6 border-b cursor-grab select-none ${
            isDragging ? 'cursor-grabbing' : 'cursor-grab'
          } ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}
          onMouseDown={handleMouseDown}
        >
          <div className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            <div className="flex items-center space-x-2">
              <Database className="w-5 h-5" />
              <span>DAG Details: {dagId}</span>
              <div className="flex items-center space-x-1 ml-4 opacity-50">
                <div className="w-1 h-1 bg-current rounded-full"></div>
                <div className="w-1 h-1 bg-current rounded-full"></div>
                <div className="w-1 h-1 bg-current rounded-full"></div>
                <div className="w-1 h-1 bg-current rounded-full"></div>
              </div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClose}
            onMouseDown={(e) => e.stopPropagation()} // Prevent drag when clicking close
            className={`${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6">
          {loading && (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
                <p className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                  Loading Workspace details...
                </p>
              </div>
            </div>
          )}

          {error && (
            <Card className="border-red-200 bg-red-50 mb-6">
              <CardContent className="p-4">
                <div className="flex items-start">
                  <XCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-red-800">Error Loading Workspace Details</h3>
                    <p className="mt-1 text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {dagDetails && !loading && (
            <div className="space-y-4">
              {/* Custom Tab Navigation */}
              <div className={`flex space-x-1 p-1 rounded-lg overflow-x-auto ${
                darkMode ? 'bg-gray-700' : 'bg-gray-100'
              }`}>
                {[
                  { id: 'overview', label: 'Overview', icon: GitBranch },
                  { id: 'runs', label: `Runs (${dagDetails.runs.length})`, icon: Activity },
                  { id: 'tasks', label: `Tasks (${dagDetails.tasks.length})`, icon: Database },
                  { id: 'events', label: 'Events', icon: Zap },
                  { id: 'code', label: 'Code', icon: Code },
                  { id: 'details', label: 'Details', icon: Settings },
                  { id: 'stats', label: 'Statistics', icon: TrendingUp }
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1 whitespace-nowrap ${
                      activeTab === tab.id
                        ? (darkMode ? 'bg-blue-500 text-white' : 'bg-blue-400 text-white')
                        : (darkMode ? 'text-gray-300 hover:text-white hover:bg-gray-600' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200')
                    }`}
                  >
                    <tab.icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* DAG Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <GitBranch className="w-4 h-4 mr-2" />
                        Workspace Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Status
                        </label>
                        <div className="mt-1">
                          <Badge className={getStateColor(
                            dagDetails.dag.is_paused ? 'paused' : dagDetails.dag.is_active ? 'success' : 'none',
                            darkMode
                          )}>
                            {dagDetails.dag.is_paused ? 'Paused' : dagDetails.dag.is_active ? 'Active' : 'Inactive'}
                          </Badge>
                        </div>
                      </div>
                      
                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Description
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.description || 'No description available'}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Schedule Interval
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.schedule_interval_display || 'None'}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Max Active Runs
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.max_active_runs || 0}
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  {/* File Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FileText className="w-4 h-4 mr-2" />
                        File Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          File Location
                        </label>
                        <p className={`mt-1 text-xs font-mono break-all ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.fileloc || 'N/A'}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Last Parsed
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {formatDate(dagDetails.dag.last_parsed_time)}
                        </p>
                      </div>

                      <div>
                        <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          Owners
                        </label>
                        <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {dagDetails.dag.owners?.join(', ') || 'None'}
                        </p>
                      </div>

                      {dagDetails.dag.tag_names && dagDetails.dag.tag_names.length > 0 && (
                        <div>
                          <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Tags
                          </label>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {dagDetails.dag.tag_names.map((tag: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === 'runs' && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Activity className="w-4 h-4 mr-2" />
                          Recent Workspace Runs
                        </div>
                        {statistics && (
                          <div className="flex items-center space-x-4 text-sm">
                            <span className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                              Success Rate: <span className="font-bold text-cyan-600">{statistics.successRate}%</span>
                            </span>
                            <span className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                              Avg Duration: <span className="font-bold">{statistics.avgDuration}s</span>
                            </span>
                          </div>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {dagDetails.runs.length > 0 ? (
                        <div className="space-y-2">
                          {/* Header */}
                          <div className={`grid grid-cols-6 gap-4 p-3 rounded-lg font-medium text-sm border-b ${
                            darkMode ? 'bg-gray-700 border-gray-600 text-gray-300' : 'bg-gray-50 border-gray-200 text-gray-700'
                          }`}>
                            <div>Run ID</div>
                            <div>State</div>
                            <div>Start Date</div>
                            <div>End Date</div>
                            <div>Duration</div>
                            <div>Type</div>
                          </div>
                          
                          {/* Runs */}
                          <div className="space-y-1">
                            {dagDetails.runs.map((run: any) => (
                              <div key={run.dag_run_id} className={`grid grid-cols-6 gap-4 p-3 rounded-lg border transition-colors hover:bg-opacity-50 ${
                                darkMode ? 'border-gray-600 hover:bg-gray-700' : 'border-gray-200 hover:bg-gray-50'
                              }`}>
                                <div 
                                  className="font-mono text-sm truncate cursor-pointer text-blue-600 hover:text-blue-800 hover:underline" 
                                  title={run.dag_run_id}
                                  onClick={() => handleRunClick(run)}
                                >
                                  {run.dag_run_id}
                                </div>
                                <div>
                                  <Badge className={getStateColor(run.state, darkMode)}>
                                    <span className="flex items-center space-x-1">
                                      {getStateIcon(run.state)}
                                      <span>{run.state}</span>
                                    </span>
                                  </Badge>
                                </div>
                                <div className="text-sm">{formatDate(run.start_date)}</div>
                                <div className="text-sm">{formatDate(run.end_date)}</div>
                                <div className="text-sm">{formatDuration(run.start_date, run.end_date)}</div>
                                <div>
                                  <Badge variant="outline">
                                    {run.run_type || 'manual'}
                                  </Badge>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <Activity className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                          <p className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                            No recent runs found for this Workspace
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === 'tasks' && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Database className="w-4 h-4 mr-2" />
                        Workspace Tasks
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {dagDetails.tasks.length > 0 ? (
                        <div className="space-y-4">
                          {dagDetails.tasks.map((task: any, index: number) => (
                            <div key={task.task_id || index} className={`p-4 rounded-lg border ${
                              darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
                            }`}>
                              <div className="flex items-center justify-between mb-2">
                                <h4 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                  {task.task_id}
                                </h4>
                                <Badge variant="outline">
                                  {task.operator_class_name || task.operator || 'Unknown'}
                                </Badge>
                              </div>
                              
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                <div>
                                  <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                    Retries:
                                  </span>
                                  <span className={`ml-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                    {task.retries || 0}
                                  </span>
                                </div>
                                
                                <div>
                                  <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                    Pool:
                                  </span>
                                  <span className={`ml-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                    {task.pool || 'default_pool'}
                                  </span>
                                </div>
                                
                                <div>
                                  <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                    Queue:
                                  </span>
                                  <span className={`ml-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                    {task.queue || 'default'}
                                  </span>
                                </div>
                                
                                <div>
                                  <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                    Weight:
                                  </span>
                                  <span className={`ml-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                    {task.priority_weight || 1}
                                  </span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <Database className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                          <p className={`${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                            No tasks found for this Workspace
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === 'events' && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Zap className="w-4 h-4 mr-2" />
                        Workspace Events & Audit Log
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Recent Events */}
                        <div className={`p-4 rounded-lg border ${
                          darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
                        }`}>
                          <h4 className={`font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                            Recent Events
                          </h4>
                          <div className="space-y-2">
                            {dagDetails.runs.slice(0, 5).map((run: any, index: number) => (
                              <div key={index} className={`flex items-center justify-between p-2 rounded ${
                                darkMode ? 'bg-gray-600' : 'bg-white'
                              }`}>
                                <div className="flex items-center space-x-2">
                                  {getStateIcon(run.state)}
                                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                    Workspace Run {run.state}
                                  </span>
                                </div>
                                <span className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                  {formatDate(run.start_date)}
                                </span>
                              </div>
                            ))}
                            {dagDetails.runs.length === 0 && (
                              <div className="text-center py-4">
                                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                  No events found
                                </p>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Event Statistics */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className={`p-4 rounded-lg border ${
                            darkMode ? 'bg-gray-700 border-gray-600' : 'bg-blue-50 border-blue-200'
                          }`}>
                            <div className="flex items-center space-x-2">
                              <Calendar className="w-5 h-5 text-blue-600" />
                              <div>
                                <p className={`text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                  Last Activity
                                </p>
                                <p className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                  {dagDetails.runs.length > 0 ? formatDate(dagDetails.runs[0].start_date) : 'N/A'}
                                </p>
                              </div>
                            </div>
                          </div>
                          
                          <div className={`p-4 rounded-lg border ${
                            darkMode ? 'bg-gray-700 border-gray-600' : 'bg-cyan-50 border-cyan-200'
                          }`}>
                            <div className="flex items-center space-x-2">
                              <CheckCircle className="w-5 h-5 text-cyan-600" />
                              <div>
                                <p className={`text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                  Success Rate
                                </p>
                                <p className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                  {statistics ? `${statistics.successRate}%` : '0%'}
                                </p>
                              </div>
                            </div>
                          </div>
                          
                          <div className={`p-4 rounded-lg border ${
                            darkMode ? 'bg-gray-700 border-gray-600' : 'bg-yellow-50 border-yellow-200'
                          }`}>
                            <div className="flex items-center space-x-2">
                              <Clock className="w-5 h-5 text-yellow-600" />
                              <div>
                                <p className={`text-sm font-medium ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                  Avg Duration
                                </p>
                                <p className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                  {dagDetails.runs.length > 0 
                                    ? formatDuration(dagDetails.runs[0].start_date, dagDetails.runs[0].end_date)
                                    : 'N/A'
                                  }
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === 'code' && (
                <div className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Code className="w-4 h-4 mr-2" />
                        Workspace Source Code
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* File Information */}
                        <div className={`p-4 rounded-lg border ${
                          darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
                        }`}>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                File Path:
                              </span>
                              <p className={`mt-1 font-mono text-xs break-all ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                {dagDetails.dag.fileloc || 'N/A'}
                              </p>
                            </div>
                            <div>
                              <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                Last Modified:
                              </span>
                              <p className={`mt-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                {formatDate(dagDetails.dag.last_parsed_time)}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Code Preview */}
                        <div className={`rounded-lg border ${
                          darkMode ? 'bg-gray-800 border-gray-600' : 'bg-gray-900 border-gray-300'
                        }`}>
                          <div className={`px-4 py-2 border-b ${
                            darkMode ? 'border-gray-600 bg-gray-700' : 'border-gray-700 bg-gray-800'
                          }`}>
                            <span className="text-sm font-medium text-white">
                              {dagDetails.dag.fileloc ? dagDetails.dag.fileloc.split('/').pop() : 'Workspace Source'}
                            </span>
                          </div>
                          <div className="p-4">
                            <pre className="text-sm font-mono text-cyan-400 overflow-x-auto">
{`# Workspace Source Code Preview
# File: ${dagDetails.dag.fileloc || 'Unknown'}

from airflow import DAG
from datetime import datetime, timedelta

# Workspace Configuration
default_args = {
    'owner': '${dagDetails.dag.owners?.join(', ') || 'airflow'}',
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='${dagDetails.dag.dag_id}',
    default_args=default_args,
    description='${dagDetails.dag.description || 'No description'}',
    schedule_interval='${dagDetails.dag.schedule_interval_display || 'None'}',
    start_date=datetime(2024, 1, 1),
    catchup=False,
    max_active_runs=${dagDetails.dag.max_active_runs || 1},
    tags=${JSON.stringify(dagDetails.dag.tag_names || [])},
) as dag:
    
    # Tasks would be defined here
    # ${dagDetails.tasks.length} task(s) configured
    ${dagDetails.tasks.map((task: any) => `# - ${task.task_id} (${task.operator_class_name || task.operator || 'Unknown Operator'})`).join('\n    ')}

# Note: This is a reconstructed preview based on Workspace metadata.
# For the complete source code, access the file directly at:
# ${dagDetails.dag.fileloc || 'Unknown location'}`}
                            </pre>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const codeText = document.querySelector('pre')?.textContent;
                              if (codeText && navigator.clipboard) {
                                navigator.clipboard.writeText(codeText);
                              }
                            }}
                          >
                            Copy Code
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (dagDetails.dag.fileloc) {
                                console.log('Open file:', dagDetails.dag.fileloc);
                              }
                            }}
                          >
                            View in Editor
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === 'details' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {/* Configuration Details */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <Settings className="w-4 h-4 mr-2" />
                          Configuration
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Workspace ID
                            </label>
                            <p className={`mt-1 font-mono text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.dag_id}
                            </p>
                          </div>
                          
                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Schedule Interval
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.schedule_interval_display || 'None'}
                            </p>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Max Active Runs
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.max_active_runs || 'Not set'}
                            </p>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Max Active Tasks
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.max_active_tasks || 'Not set'}
                            </p>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Default View
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.default_view || 'graph'}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Runtime Information */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <Activity className="w-4 h-4 mr-2" />
                          Runtime Information
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-3">
                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Status
                            </label>
                            <div className="mt-1">
                              <Badge className={getStateColor(
                                dagDetails.dag.is_paused ? 'paused' : dagDetails.dag.is_active ? 'success' : 'none',
                                darkMode
                              )}>
                                {dagDetails.dag.is_paused ? 'Paused' : dagDetails.dag.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </div>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Last Parsed
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {formatDate(dagDetails.dag.last_parsed_time)}
                            </p>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Has Import Errors
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.has_import_errors ? 'Yes' : 'No'}
                            </p>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Has Task Concurrency Limits
                            </label>
                            <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.has_task_concurrency_limits ? 'Yes' : 'No'}
                            </p>
                          </div>

                          <div>
                            <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              File Token
                            </label>
                            <p className={`mt-1 text-xs font-mono ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                              {dagDetails.dag.file_token || 'N/A'}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Additional Metadata */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Database className="w-4 h-4 mr-2" />
                        Additional Metadata
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div>
                          <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Total Runs
                          </label>
                          <p className={`mt-1 text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                            {dagDetails.runs.length}
                          </p>
                        </div>
                        
                        <div>
                          <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Total Tasks
                          </label>
                          <p className={`mt-1 text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                            {dagDetails.tasks.length}
                          </p>
                        </div>
                        
                        <div>
                          <label className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Owners
                          </label>
                          <p className={`mt-1 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                            {dagDetails.dag.owners?.join(', ') || 'None'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === 'stats' && (
                <div className="space-y-6">
                  {/* Performance Overview */}
                  {statistics && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                Total Runs
                              </p>
                              <p className="text-2xl font-bold mt-1">{statistics.total}</p>
                            </div>
                            <Activity className="w-8 h-8 text-blue-600" />
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                Successful Runs
                              </p>
                              <p className="text-2xl font-bold mt-1 text-cyan-600">{statistics.successful}</p>
                            </div>
                            <CheckCircle className="w-8 h-8 text-cyan-600" />
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                Failed Runs
                              </p>
                              <p className="text-2xl font-bold mt-1 text-red-600">{statistics.failed}</p>
                            </div>
                            <XCircle className="w-8 h-8 text-red-600" />
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                Success Rate
                              </p>
                              <p className="text-2xl font-bold mt-1 text-purple-600">{statistics.successRate}%</p>
                            </div>
                            <TrendingUp className="w-8 h-8 text-purple-600" />
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  )}

                  {/* Performance Metrics */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Activity className="w-4 h-4 mr-2" />
                        Performance Metrics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-blue-50'}`}>
                          <div className="flex items-center space-x-2 mb-2">
                            <Clock className="w-5 h-5 text-blue-600" />
                            <h4 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                              Average Duration
                            </h4>
                          </div>
                          <p className="text-2xl font-bold text-blue-600">
                            {statistics ? `${statistics.avgDuration}s` : 'N/A'}
                          </p>
                          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                            Based on completed runs
                          </p>
                        </div>

                        <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-cyan-50'}`}>
                          <div className="flex items-center space-x-2 mb-2">
                            <TrendingUp className="w-5 h-5 text-cyan-600" />
                            <h4 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                              Reliability Score
                            </h4>
                          </div>
                          <p className="text-2xl font-bold text-cyan-600">
                            {statistics ? `${statistics.successRate}%` : 'N/A'}
                          </p>
                          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                            Success rate over time
                          </p>
                        </div>

                        <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-purple-50'}`}>
                          <div className="flex items-center space-x-2 mb-2">
                            <Database className="w-5 h-5 text-purple-600" />
                            <h4 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                              Active Tasks
                            </h4>
                          </div>
                          <p className="text-2xl font-bold text-purple-600">
                            {dagDetails.tasks.length}
                          </p>
                          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                            Total configured tasks
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Run History Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Run History Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Success/Failure Breakdown */}
                        <div>
                          <h4 className={`font-medium mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                            Run Status Distribution
                          </h4>
                          <div className="space-y-2">
                            {statistics && statistics.total > 0 && (
                              <>
                                <div className="flex items-center justify-between">
                                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                                    Successful ({statistics.successful})
                                  </span>
                                  <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2">
                                    <div 
                                      className="bg-cyan-500 h-2 rounded-full" 
                                      style={{ width: `${(statistics.successful / statistics.total) * 100}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-sm font-medium text-cyan-600">
                                    {Math.round((statistics.successful / statistics.total) * 100)}%
                                  </span>
                                </div>
                                
                                <div className="flex items-center justify-between">
                                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                                    Failed ({statistics.failed})
                                  </span>
                                  <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2">
                                    <div 
                                      className="bg-red-500 h-2 rounded-full" 
                                      style={{ width: `${(statistics.failed / statistics.total) * 100}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-sm font-medium text-red-600">
                                    {Math.round((statistics.failed / statistics.total) * 100)}%
                                  </span>
                                </div>
                                
                                <div className="flex items-center justify-between">
                                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                                    Running ({statistics.running})
                                  </span>
                                  <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2">
                                    <div 
                                      className="bg-blue-500 h-2 rounded-full" 
                                      style={{ width: `${(statistics.running / statistics.total) * 100}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-sm font-medium text-blue-600">
                                    {Math.round((statistics.running / statistics.total) * 100)}%
                                  </span>
                                </div>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Recent Activity Timeline */}
                        <div>
                          <h4 className={`font-medium mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                            Recent Activity Timeline
                          </h4>
                          <div className="space-y-2">
                            {dagDetails.runs.slice(0, 5).map((run: any, index: number) => (
                              <div key={index} className="flex items-center space-x-3">
                                <div className={`w-3 h-3 rounded-full ${
                                  run.state === 'success' ? 'bg-cyan-500' :
                                  run.state === 'failed' ? 'bg-red-500' :
                                  run.state === 'running' ? 'bg-blue-500' : 'bg-gray-400'
                                }`}></div>
                                <span className={`text-sm flex-1 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                                  {run.dag_run_id} - {run.state}
                                </span>
                                <span className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                  {formatDate(run.start_date)}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Run Logs Modal */}
        {showRunLogs && selectedRun && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className={`relative w-full max-w-4xl max-h-[80vh] overflow-y-auto m-4 rounded-lg shadow-xl ${
              darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
            } border`}>
              {/* Logs Header */}
              <div className="flex items-center justify-between p-4 border-b">
                <div>
                  <h3 className={`text-lg font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    Run Details: {selectedRun.dag_run_id}
                  </h3>
                  <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    State: {selectedRun.state} | Duration: {formatDuration(selectedRun.start_date, selectedRun.end_date)}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowRunLogs(false)}
                  className={`${darkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {/* Logs Content */}
              <div className="p-4">
                {loadingLogs ? (
                  <div className="flex items-center justify-center py-8">
                    <RefreshCw className="w-6 h-6 animate-spin mr-2" />
                    <span>Loading task logs...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <h4 className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      Task Instances ({runLogs.length})
                    </h4>
                    
                    {runLogs.map((task: any, index: number) => (
                      <div key={index} className={`p-3 rounded-lg border ${
                        darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
                      }`}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                              {task.task_id}
                            </span>
                            <Badge className={getStateColor(task.state, darkMode)}>
                              {task.state}
                            </Badge>
                          </div>
                          <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                            Try {task.try_number || 1}
                          </span>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                          <div>
                            <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Start:</span>
                            <p className={darkMode ? 'text-gray-300' : 'text-gray-700'}>
                              {formatDate(task.start_date)}
                            </p>
                          </div>
                          <div>
                            <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>End:</span>
                            <p className={darkMode ? 'text-gray-300' : 'text-gray-700'}>
                              {formatDate(task.end_date)}
                            </p>
                          </div>
                          <div>
                            <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Duration:</span>
                            <p className={darkMode ? 'text-gray-300' : 'text-gray-700'}>
                              {task.duration ? `${task.duration}s` : formatDuration(task.start_date, task.end_date)}
                            </p>
                          </div>
                          <div>
                            <span className={`font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Operator:</span>
                            <p className={darkMode ? 'text-gray-300' : 'text-gray-700'}>
                              {task.operator || 'Unknown'}
                            </p>
                          </div>
                        </div>

                        {task.error && (
                          <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-red-700 text-sm">
                            <strong>Error:</strong> {task.error}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}