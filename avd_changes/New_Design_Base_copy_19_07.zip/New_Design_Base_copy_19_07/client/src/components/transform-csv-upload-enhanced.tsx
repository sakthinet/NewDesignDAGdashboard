import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Upload, Database, AlertCircle, CheckCircle, Activity, GitBranch, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { UploadedFile } from "@/pages/dag-generator";
import { TaskInstancesLive } from "@/components/task-instances-live";

interface TransformCsvUploadProps {
  uploadedFiles: UploadedFile[];
  config: any;
  onPrev: () => void;
  onStartOver: () => void;
}

interface UploadStatus {
  isUploading: boolean;
  uploadStarted: boolean;
  uploadSuccess: boolean;
  dagRunId: string;
  errorMessage?: string;
}

interface DagInfo {
  dag_id: string;
  description?: string;
  is_paused: boolean;
  is_active: boolean;
  last_parsed_time?: string;
  next_dagrun?: string;
}

export function TransformCsvUpload({ 
  uploadedFiles, 
  config, 
  onPrev, 
  onStartOver 
}: TransformCsvUploadProps) {
  // Form state
  const [selectedCsvFile, setSelectedCsvFile] = useState<string>('');
  const [bearerToken, setBearerToken] = useState<string>('');
  const [schemaName, setSchemaName] = useState<string>('SAP-PO');
  const [tableUrl, setTableUrl] = useState<string>('');
  const [chunkSize, setChunkSize] = useState<number>(5000);
  
  // Upload state
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>({
    isUploading: false,
    uploadStarted: false,
    uploadSuccess: false,
    dagRunId: ''
  });
  
  // UI state
  const [showJobsOverview, setShowJobsOverview] = useState<boolean>(false);
  const [dags, setDags] = useState<DagInfo[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDagId, setSelectedDagId] = useState<string | null>(null);
  
  const { toast } = useToast();

  // Get available files from uploaded files
  const availableFiles = uploadedFiles.filter(f => f.fileName);

  // Auto-select first file if only one available
  useEffect(() => {
    if (availableFiles.length === 1 && !selectedCsvFile) {
      setSelectedCsvFile(availableFiles[0].fileName);
    }
  }, [availableFiles, selectedCsvFile]);

  // Load default values from environment or config
  useEffect(() => {
    // Load default bearer token if available
    const defaultToken = config?.defaultBearerToken || process.env.VITE_DEFAULT_BEARER_TOKEN;
    if (defaultToken && !bearerToken) {
      setBearerToken(defaultToken);
    }
    
    // Load default export URLs
    const defaultUrl = config?.exportUrls?.purchaseOrderHeader || 
                     'http://10.73.91.23:8765/systemdata/tables/AAAAhw/content';
    if (!tableUrl) {
      setTableUrl(defaultUrl);
    }
  }, [config, bearerToken, tableUrl]);

  // Validation helper
  const validateForm = (): { isValid: boolean; errors: string[] } => {
    const errors: string[] = [];
    
    if (!selectedCsvFile || selectedCsvFile === 'no-files-available') {
      errors.push('Please select a CSV file');
    }
    
    if (!schemaName.trim()) {
      errors.push('Schema name is required');
    }
    
    if (!bearerToken.trim()) {
      errors.push('Bearer token is required');
    }
    
    if (!tableUrl.trim()) {
      errors.push('Export URL is required');
    }
    
    if (availableFiles.length === 0) {
      errors.push('No files available - please upload files in Step 1 first');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  };

  // Enhanced upload handler with better error handling
  const handleUploadToIA = async () => {
    const validation = validateForm();
    
    if (!validation.isValid) {
      toast({
        title: "Validation Error",
        description: validation.errors.join(', '),
        variant: "destructive"
      });
      return;
    }

    setUploadStatus(prev => ({ 
      ...prev, 
      isUploading: true, 
      uploadStarted: true,
      errorMessage: undefined
    }));
    
    try {
      console.log('🚀 InfoArchive Data Upload - DAG Trigger Started');
      
      // Enhanced configuration with proper parameter mapping
      const dagTriggerConfiguration = {
        "CSV_FILENAME": selectedCsvFile,
        "SCHEMA_NAME": schemaName,
        "CHUNK_SIZE": chunkSize,
        "BEARER_TOKEN": bearerToken,
        "EXPORT_URL": tableUrl
      };
      
      console.log('📋 DAG Trigger Configuration:', JSON.stringify(dagTriggerConfiguration, null, 2));
      
      // Trigger the StructuredDataToIA_Resilient DAG
      const result = await apiRequest('POST', '/api/trigger-dag', {
        dagId: 'StructuredDataToIA_Resilient',
        conf: dagTriggerConfiguration
      }) as any;
      
      if (result && result.success) {
        console.log('✅ InfoArchive Data Upload - DAG Triggered Successfully');
        
        const newDagRunId = result.dag_run?.dag_run_id || `manual_${Date.now()}`;
        
        setUploadStatus({
          isUploading: false,
          uploadStarted: true,
          uploadSuccess: true,
          dagRunId: newDagRunId
        });
        
        setShowJobsOverview(true);
        
        // Clear the bearer token after successful process initiation for security
        setBearerToken('');
        
        // Load DAG data for the Jobs overview
        try {
          const dagsResult = await apiRequest('GET', '/api/dags') as any;
          if (dagsResult && dagsResult.dags) {
            setDags(dagsResult.dags);
          }
        } catch (error) {
          console.error('Failed to load DAGs for Jobs Overview:', error);
        }
        
        toast({
          title: "✅ DAG Triggered Successfully",
          description: `StructuredDataToIA_Resilient DAG has been started. Bearer token has been cleared for security.`,
        });
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
      
    } catch (error) {
      console.error('❌ InfoArchive Data Upload - DAG Trigger Failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to trigger DAG';
      
      setUploadStatus(prev => ({
        ...prev,
        isUploading: false,
        uploadSuccess: false,
        errorMessage
      }));
      
      toast({
        title: "Failed to trigger DAG",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  // Handle DAG click for modal display
  const handleDagClick = (dagId: string) => {
    setSelectedDagId(dagId);
    setIsModalOpen(true);
  };

  // Pagination and filtering for DAGs
  const itemsPerPage = 10;
  const filteredDags = dags.filter(dag => 
    dag.dag_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (dag.description && dag.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  const sortedAndFilteredDags = [...filteredDags].sort((a, b) => 
    a.dag_id.localeCompare(b.dag_id)
  );
  
  const totalPages = Math.ceil(sortedAndFilteredDags.length / itemsPerPage);
  const paginatedDags = sortedAndFilteredDags.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Step 4: InfoArchive Data Upload</h2>
          <p className="text-muted-foreground mt-2">
            Configure the transformation parameters and upload processed data to InfoArchive
          </p>
          {/* Show available files count */}
          <div className="mt-2 text-sm text-muted-foreground">
            {availableFiles.length > 0 ? (
              <span className="inline-flex items-center gap-1">
                <Database className="h-4 w-4" />
                Processing: {availableFiles.length} file(s) ({availableFiles.map(f => f.fileName).join(', ')})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-orange-600">
                <AlertCircle className="h-4 w-4" />
                No files available. Please upload files in Step 1 first.
              </span>
            )}
          </div>
        </div>
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Upload Configuration
            </CardTitle>
            <CardDescription>
              Configure the CSV transformation and upload settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* CSV File Selection */}
            <div className="space-y-2">
              <Label htmlFor="csv-file">CSV File Name</Label>
              <Select value={selectedCsvFile} onValueChange={setSelectedCsvFile}>
                <SelectTrigger>
                  <SelectValue placeholder="Select CSV file to process" />
                </SelectTrigger>
                <SelectContent>
                  {availableFiles.length > 0 ? (
                    availableFiles.map((file) => (
                      <SelectItem key={file.fileName} value={file.fileName}>
                        {file.fileName}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="no-files-available" disabled>
                      No files available - Please upload files in Step 1
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                Only files uploaded in Step 1 will appear here
              </p>
            </div>

            {/* Bearer Token */}
            <div className="space-y-2">
              <Label htmlFor="bearer-token">Bearer Token</Label>
              <Input
                id="bearer-token"
                type="password"
                value={bearerToken}
                onChange={(e) => setBearerToken(e.target.value)}
                placeholder="your_token"
                className="font-mono text-sm"
              />
              <p className="text-xs text-gray-500">
                Token will be cleared after successful process initiation
              </p>
            </div>

            {/* Schema Name */}
            <div className="space-y-2">
              <Label htmlFor="schema-name">Schema Name</Label>
              <Input
                id="schema-name"
                value={schemaName}
                onChange={(e) => setSchemaName(e.target.value)}
                placeholder="Schema Name (e.g., SAP-PO)"
              />
            </div>

            {/* Chunk Size */}
            <div className="space-y-2">
              <Label htmlFor="chunk-size">Chunk Size</Label>
              <Input
                id="chunk-size"
                type="number"
                value={chunkSize}
                onChange={(e) => setChunkSize(Number(e.target.value))}
                min="1000"
                max="50000"
                step="1000"
              />
              <p className="text-xs text-gray-500">
                Number of records per processing chunk (1000-50000)
              </p>
            </div>

            {/* Export URL */}
            <div className="space-y-2">
              <Label htmlFor="table-url">Export URL</Label>
              <Input
                id="table-url"
                value={tableUrl}
                onChange={(e) => setTableUrl(e.target.value)}
                placeholder="Export URL for Table"
              />
            </div>

            {/* Upload Button */}
            <Button
              onClick={handleUploadToIA}
              disabled={!validateForm().isValid || uploadStatus.isUploading}
              className="w-full"
            >
              {uploadStatus.isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  Uploading to IA...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Transform CSV Data to IA XML Format and Upload
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Status Card */}
        <Card>
          <CardHeader>
            <CardTitle>Process Status</CardTitle>
            <CardDescription>
              Current status of the InfoArchive upload process
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium">Selected File</span>
              <span className="text-sm text-gray-600">
                {selectedCsvFile || 'Not selected'}
              </span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium">Bearer Token</span>
              <span className="text-sm text-gray-600">
                {bearerToken ? '••••••••' : (uploadStatus.uploadSuccess ? 'Cleared (Process initiated)' : 'Not set')}
              </span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium">Schema Name</span>
              <span className="text-sm text-gray-600">
                {schemaName || 'Not set'}
              </span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium">Chunk Size</span>
              <span className="text-sm text-gray-600">{chunkSize.toLocaleString()}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm font-medium">Export URL</span>
              <span className="text-sm text-gray-600 truncate max-w-40" title={tableUrl}>
                {tableUrl || 'Not set'}
              </span>
            </div>
            
            {/* DAG Status */}
            {uploadStatus.uploadStarted && (
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                <span className="text-sm font-medium">DAG Status</span>
                <div className="flex items-center gap-2">
                  {uploadStatus.isUploading ? (
                    <>
                      <Activity className="h-4 w-4 animate-spin text-blue-600" />
                      <span className="text-sm text-blue-600">Triggering...</span>
                    </>
                  ) : uploadStatus.uploadSuccess ? (
                    <>
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm text-green-600">Triggered Successfully</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      <span className="text-sm text-red-600">Failed</span>
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Error Message */}
            {uploadStatus.errorMessage && (
              <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-sm font-medium text-red-800">Error:</span>
                    <span className="text-sm text-red-700 ml-1">{uploadStatus.errorMessage}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Success Actions */}
            {uploadStatus.uploadSuccess && uploadStatus.dagRunId && (
              <div className="space-y-2">
                <Button
                  variant="default"
                  size="sm"
                  className="w-full"
                  onClick={() => setShowJobsOverview(false)}
                >
                  View Task Details
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => setShowJobsOverview(true)}
                >
                  <GitBranch className="h-4 w-4 mr-1" />
                  Jobs Overview
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Task Instances Live View */}
      {uploadStatus.uploadSuccess && uploadStatus.dagRunId && !showJobsOverview && (
        <div className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Live Task Monitoring</span>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowJobsOverview(true)}
                  >
                    <GitBranch className="h-4 w-4 mr-1" />
                    Switch to Jobs Overview
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TaskInstancesLive
                dagId="StructuredDataToIA_Resilient"
                runId={uploadStatus.dagRunId}
                autoRefresh={true}
                refreshInterval={15000}
              />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Jobs Overview */}
      {uploadStatus.uploadSuccess && showJobsOverview && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <GitBranch className="w-5 h-5 mr-2" />
                  Jobs Overview ({sortedAndFilteredDags.length} total)
                  <RefreshCw 
                    className="w-4 h-4 ml-2 cursor-pointer hover:text-blue-600" 
                    onClick={async () => {
                      try {
                        const dagsResult = await apiRequest('GET', '/api/dags') as any;
                        if (dagsResult && dagsResult.dags) {
                          setDags(dagsResult.dags);
                          setCurrentPage(1);
                        }
                      } catch (error) {
                        console.error('Failed to refresh DAGs:', error);
                      }
                    }}
                  />
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowJobsOverview(false)}
                >
                  View Task Details
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Search and pagination would go here */}
              <div className="space-y-4">
                {paginatedDags.length > 0 ? (
                  <div className="space-y-2">
                    {paginatedDags.map((dag) => (
                      <div 
                        key={dag.dag_id} 
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                        onClick={() => handleDagClick(dag.dag_id)}
                      >
                        <div>
                          <div className="font-medium">{dag.dag_id}</div>
                          <div className="text-sm text-gray-600">
                            {dag.description || 'No description'}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            dag.is_paused ? 'bg-yellow-100 text-yellow-800' :
                            dag.is_active ? 'bg-green-100 text-green-800' : 
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {dag.is_paused ? 'Paused' : dag.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    No DAGs found
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
