// utils/theme-init.ts
// Theme initialization utility for TCS ECM Airflow application

export interface ThemeColors {
  primary: string;
  background: string;
  surface: string;
  text: string;
}

export interface ThemeDefinition {
  id: string;
  colors: ThemeColors;
}

export const THEME_DEFINITIONS: Record<string, ThemeDefinition> = {
  light: {
    id: 'light',
    colors: {
      primary: '#2563eb',
      background: '#ffffff',
      surface: '#ffffff',
      text: '#1e293b'
    }
  },
  dark: {
    id: 'dark',
    colors: {
      primary: '#3b82f6',
      background: '#0f172a',
      surface: '#1e293b',
      text: '#f1f5f9'
    }
  },
  airflow: {
    id: 'airflow',
    colors: {
      primary: '#017cee',
      background: '#fafafa',
      surface: '#ffffff',
      text: '#2c3e50'
    }
  }
};

export const THEME_STORAGE_KEY = 'tcs-ecm-theme';
export const DEFAULT_THEME = 'light';

/**
 * Initialize the theme system on application startup
 * Should be called once in your main App component
 */
export function initializeThemeSystem(): string {
  // Get saved theme or use default
  const savedTheme = localStorage.getItem(THEME_STORAGE_KEY) || DEFAULT_THEME;
  
  // Validate theme exists
  const theme = THEME_DEFINITIONS[savedTheme] || THEME_DEFINITIONS[DEFAULT_THEME];
  
  // Apply theme immediately
  applyTheme(theme);
  
  return theme.id;
}

/**
 * Apply a theme to the document
 */
export function applyTheme(theme: ThemeDefinition): void {
  // Remove all existing theme classes
  const allThemeClasses = Object.keys(THEME_DEFINITIONS).map(id => `theme-${id}`);
  allThemeClasses.forEach(className => {
    document.documentElement.classList.remove(className);
    document.body.classList.remove(className);
  });
  
  // Add current theme class to both html and body for maximum coverage
  const themeClass = `theme-${theme.id}`;
  document.documentElement.classList.add(themeClass);
  document.body.classList.add(themeClass);
  
  // Set CSS custom properties on root
  Object.entries(theme.colors).forEach(([key, value]) => {
    document.documentElement.style.setProperty(`--color-${key}`, value);
  });
  
  // Apply theme colors to body
  document.body.style.setProperty('background-color', theme.colors.background, 'important');
  document.body.style.setProperty('color', theme.colors.text, 'important');
  
  // Force theme application on main containers that might resist theming
  setTimeout(() => {
    forceThemeOnContainers(theme);
  }, 0);
}

/**
 * Force theme application on main application containers
 */
function forceThemeOnContainers(theme: ThemeDefinition): void {
  const containerSelectors = [
    '#root',
    '.app',
    'main',
    '.main-content',
    '.dashboard',
    '.content',
    '.page',
    '.container',
    '.wrapper'
  ];
  
  containerSelectors.forEach(selector => {
    const elements = document.querySelectorAll(selector);
    elements.forEach(element => {
      if (element instanceof HTMLElement) {
        element.style.setProperty('background-color', theme.colors.background, 'important');
        element.style.setProperty('color', theme.colors.text, 'important');
      }
    });
  });
}

/**
 * Get the current active theme
 */
export function getCurrentTheme(): ThemeDefinition {
  const savedTheme = localStorage.getItem(THEME_STORAGE_KEY) || DEFAULT_THEME;
  return THEME_DEFINITIONS[savedTheme] || THEME_DEFINITIONS[DEFAULT_THEME];
}

/**
 * Change theme and persist to localStorage
 */
export function changeTheme(themeId: string): void {
  const theme = THEME_DEFINITIONS[themeId];
  if (!theme) {
    console.warn(`Theme '${themeId}' not found. Available themes:`, Object.keys(THEME_DEFINITIONS));
    return;
  }
  
  // Apply the theme
  applyTheme(theme);
  
  // Save to localStorage
  localStorage.setItem(THEME_STORAGE_KEY, themeId);
  
  // Dispatch custom event for other components to listen
  window.dispatchEvent(new CustomEvent('themeChanged', {
    detail: { theme, themeId }
  }));
}

/**
 * Get all available themes
 */
export function getAllThemes(): ThemeDefinition[] {
  return Object.values(THEME_DEFINITIONS);
}

/**
 * Check if a theme ID is valid
 */
export function isValidTheme(themeId: string): boolean {
  return themeId in THEME_DEFINITIONS;
}

/**
 * Debug function to log current theme state
 */
export function debugThemeState(): void {
  const currentTheme = getCurrentTheme();
  console.group('🎨 Theme Debug Info');
  console.log('Current Theme:', currentTheme.id);
  console.log('HTML Classes:', document.documentElement.className);
  console.log('Body Classes:', document.body.className);
  console.log('CSS Variables:', {
    primary: getComputedStyle(document.documentElement).getPropertyValue('--color-primary'),
    background: getComputedStyle(document.documentElement).getPropertyValue('--color-background'),
    surface: getComputedStyle(document.documentElement).getPropertyValue('--color-surface'),
    text: getComputedStyle(document.documentElement).getPropertyValue('--color-text')
  });
  console.log('Body Styles:', {
    backgroundColor: document.body.style.backgroundColor,
    color: document.body.style.color
  });
  console.groupEnd();
}