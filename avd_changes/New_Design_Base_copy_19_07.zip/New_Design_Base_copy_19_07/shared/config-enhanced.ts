/**
 * Enhanced Configuration Management System
 * Centralized, type-safe configuration with environment detection
 */

interface AirflowConfig {
  // Connection settings
  connection: {
    url: string;
    username: string;
    password: string;
    apiVersion: string;
  };
  
  // Host-side paths (for file operations from the application)
  paths: {
    dataBaseDir: string;
    incomingCsvDir: string;
    processedCsvDir: string;
    reportsDir: string;
    dagsDir: string;
  };
  
  // Container-side paths (for DAG runtime configuration)
  containerPaths: {
    dataDir: string;
    incomingCsvDir: string;
    processedCsvDir: string;
    dagsDir: string;
  };
  
  // Application settings
  application: {
    port: number;
    nodeEnv: string;
    maxFileSize: number;
    allowedFileTypes: string[];
    uploadTimeout: number;
  };
  
  // InfoArchive API settings
  infoArchive: {
    apiBaseUrl: string;
    defaultBearerToken: string;
    defaultChunkSize: number;
    exportUrls: {
      purchaseOrderHeader: string;
      purchaseOrderItem: string;
      purchaseOrderPartner: string;
    };
  };

  // Debug and development settings
  debug: {
    enablePathLogging: boolean;
    enableApiLogging: boolean;
    cacheEnabled: boolean;
  };
}

/**
 * Environment detection utility
 */
function detectEnvironment(): 'development' | 'production' | 'test' {
  if (typeof process !== 'undefined') {
    return (process.env.NODE_ENV as any) || 'development';
  }
  return 'development';
}

/**
 * Safe environment variable getter with fallback
 */
function getEnvVar(key: string, fallback: string = ''): string {
  if (typeof process !== 'undefined' && process.env) {
    return process.env[key] || fallback;
  }
  return fallback;
}

/**
 * Get server-side configuration (Node.js environment)
 */
export function getServerConfig(): AirflowConfig {
  const isProduction = detectEnvironment() === 'production';
  
  return {
    connection: {
      url: getEnvVar('AIRFLOW_URL', 'http://localhost:8080'),
      username: getEnvVar('AIRFLOW_USERNAME', 'airflow'),
      password: getEnvVar('AIRFLOW_PASSWORD', 'airflow'),
      apiVersion: getEnvVar('AIRFLOW_API_VERSION', 'v2'),
    },
    
    paths: {
      dataBaseDir: getEnvVar('AIRFLOW_DATA_BASE_DIR', './data'),
      incomingCsvDir: getEnvVar('AIRFLOW_INCOMING_CSV_DIR', './data/incomingcsv'),
      processedCsvDir: getEnvVar('AIRFLOW_PROCESSED_CSV_DIR', './data/processedcsv'),
      reportsDir: getEnvVar('AIRFLOW_REPORTS_DIR', './reports'),
      dagsDir: getEnvVar('AIRFLOW_DAGS_DIR', './dags'),
    },
    
    containerPaths: {
      dataDir: getEnvVar('AIRFLOW_CONTAINER_DATA_DIR', '/opt/airflow/data'),
      incomingCsvDir: getEnvVar('AIRFLOW_CONTAINER_INCOMING_CSV_DIR', '/opt/airflow/data/incomingcsv'),
      processedCsvDir: getEnvVar('AIRFLOW_CONTAINER_PROCESSED_CSV_DIR', '/opt/airflow/data/processedcsv'),
      dagsDir: getEnvVar('AIRFLOW_CONTAINER_DAGS_DIR', '/opt/airflow/dags'),
    },
    
    application: {
      port: parseInt(getEnvVar('PORT', '3001'), 10),
      nodeEnv: detectEnvironment(),
      maxFileSize: parseInt(getEnvVar('MAX_FILE_SIZE', '10485760'), 10), // 10MB
      allowedFileTypes: getEnvVar('ALLOWED_FILE_TYPES', '.csv,.txt').split(','),
      uploadTimeout: parseInt(getEnvVar('UPLOAD_TIMEOUT', '30000'), 10), // 30 seconds
    },
    
    infoArchive: {
      apiBaseUrl: getEnvVar('INFOARCHIVE_API_BASE_URL', 'http://10.73.91.23:8765'),
      defaultBearerToken: getEnvVar('DEFAULT_BEARER_TOKEN', ''),
      defaultChunkSize: parseInt(getEnvVar('DEFAULT_CHUNK_SIZE', '5000'), 10),
      exportUrls: {
        purchaseOrderHeader: getEnvVar('PURCHASEORDERHEADER_URL', 'http://10.73.91.23:8765/systemdata/tables/AAAAhw/content'),
        purchaseOrderItem: getEnvVar('PURCHASEORDERITEM_URL', 'http://10.73.91.23:8765/systemdata/tables/AAAAhg/content'),
        purchaseOrderPartner: getEnvVar('PURCHASEORDERPARTNER_URL', 'http://10.73.91.23:8765/systemdata/tables/AAAAhQ/content'),
      }
    },

    debug: {
      enablePathLogging: getEnvVar('ENABLE_PATH_LOGGING', 'false') === 'true',
      enableApiLogging: getEnvVar('DEBUG_AIRFLOW_API', 'false') === 'true',
      cacheEnabled: !isProduction,
    }
  };
}

/**
 * Get client-side configuration (browser environment)
 */
export function getClientConfig(): Partial<AirflowConfig> {
  // Browser environment - use Vite environment variables
  if (typeof window !== 'undefined' && typeof import.meta !== 'undefined') {
    const env = import.meta.env;
    
    return {
      connection: {
        url: env.VITE_AIRFLOW_URL as string || 'http://localhost:8080',
        username: '', // Don't expose credentials to client
        password: '',
        apiVersion: 'v2',
      },
      
      paths: {
        dataBaseDir: env.VITE_AIRFLOW_DATA_BASE_DIR as string || './data',
        incomingCsvDir: env.VITE_AIRFLOW_INCOMING_CSV_DIR as string || './data/incomingcsv',
        processedCsvDir: env.VITE_AIRFLOW_PROCESSED_CSV_DIR as string || './data/processedcsv',
        reportsDir: env.VITE_AIRFLOW_REPORTS_DIR as string || './reports',
        dagsDir: env.VITE_AIRFLOW_DAGS_DIR as string || './dags',
      },

      application: {
        port: 0, // Not relevant for client
        nodeEnv: 'client',
        maxFileSize: 10485760, // 10MB
        allowedFileTypes: ['.csv', '.txt'],
        uploadTimeout: 30000,
      },

      debug: {
        enablePathLogging: false,
        enableApiLogging: false,
        cacheEnabled: true,
      }
    };
  }
  
  // SSR environment - use legacy NEXT_PUBLIC variables for compatibility
  return {
    connection: {
      url: getEnvVar('NEXT_PUBLIC_AIRFLOW_URL', 'http://localhost:8080'),
      username: '',
      password: '',
      apiVersion: 'v2',
    },
    
    paths: {
      dataBaseDir: getEnvVar('NEXT_PUBLIC_AIRFLOW_DATA_BASE_DIR', './data'),
      incomingCsvDir: getEnvVar('NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR', './data/incomingcsv'),
      processedCsvDir: getEnvVar('NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR', './data/processedcsv'),
      reportsDir: getEnvVar('NEXT_PUBLIC_AIRFLOW_REPORTS_DIR', './reports'),
      dagsDir: getEnvVar('NEXT_PUBLIC_AIRFLOW_DAGS_DIR', './dags'),
    }
  };
}

/**
 * Validate configuration and report issues
 */
export function validateConfiguration(): { valid: boolean; errors: string[]; warnings: string[] } {
  const config = getServerConfig();
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check required connection settings
  if (!config.connection.url || config.connection.url === 'http://localhost:8080') {
    warnings.push('Using default Airflow URL - ensure this is correct for your environment');
  }

  if (!config.connection.username || config.connection.username === 'airflow') {
    warnings.push('Using default Airflow username - consider using environment-specific credentials');
  }

  // Check InfoArchive settings
  if (!config.infoArchive.defaultBearerToken) {
    warnings.push('No default bearer token configured - users will need to provide tokens manually');
  }

  // Validate URLs
  try {
    new URL(config.connection.url);
  } catch {
    errors.push(`Invalid Airflow URL: ${config.connection.url}`);
  }

  try {
    new URL(config.infoArchive.apiBaseUrl);
  } catch {
    errors.push(`Invalid InfoArchive API URL: ${config.infoArchive.apiBaseUrl}`);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

/**
 * Log configuration for debugging (server-side only)
 */
export function logConfiguration(): void {
  if (typeof window !== 'undefined') {
    console.warn('Configuration logging is only available on server-side');
    return;
  }

  const config = getServerConfig();
  const validation = validateConfiguration();
  
  if (config.debug.enablePathLogging) {
    console.log('=== AIRFLOW CONFIGURATION ===');
    console.log(`Environment: ${config.application.nodeEnv}`);
    console.log(`Airflow URL: ${config.connection.url}`);
    console.log(`Data Base Dir: ${config.paths.dataBaseDir}`);
    console.log(`Incoming CSV Dir: ${config.paths.incomingCsvDir}`);
    console.log(`Processed CSV Dir: ${config.paths.processedCsvDir}`);
    console.log(`Reports Dir: ${config.paths.reportsDir}`);
    console.log(`DAGs Dir: ${config.paths.dagsDir}`);
    console.log(`Container Data Dir: ${config.containerPaths.dataDir}`);
    console.log(`InfoArchive API: ${config.infoArchive.apiBaseUrl}`);
    
    if (validation.warnings.length > 0) {
      console.log('\n=== CONFIGURATION WARNINGS ===');
      validation.warnings.forEach(warning => console.warn(`⚠️ ${warning}`));
    }
    
    if (validation.errors.length > 0) {
      console.log('\n=== CONFIGURATION ERRORS ===');
      validation.errors.forEach(error => console.error(`❌ ${error}`));
    }
    
    console.log('==============================\n');
  }
}

/**
 * Get environment-specific configuration
 */
export function getEnvironmentConfig(): {
  isDevelopment: boolean;
  isProduction: boolean;
  isTest: boolean;
  environment: string;
} {
  const env = detectEnvironment();
  
  return {
    isDevelopment: env === 'development',
    isProduction: env === 'production',
    isTest: env === 'test',
    environment: env
  };
}

export type { AirflowConfig };
