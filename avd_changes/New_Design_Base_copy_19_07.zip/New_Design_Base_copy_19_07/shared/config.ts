/**
 * Environment Configuration Utility
 * Centralized configuration management for all Airflow and application paths
 */

interface AirflowConfig {
  // Connection settings
  url: string;
  username: string;
  password: string;
  apiVersion: string;
  
  // Host-side paths (for file operations from the application)
  dataBaseDir: string;
  dataDir: string;
  incomingCsvDir: string;
  processedCsvDir: string;
  reportsDir: string;
  dagsDir: string;
  
  // Container-side paths (for DAG runtime configuration)
  containerDataDir: string;
  containerIncomingCsvDir: string;
  containerProcessedCsvDir: string;
  containerDagsDir: string;
  
  // InfoArchive API settings
  infoArchiveApiBaseUrl: string;
  defaultBearerToken: string;
  defaultChunkSize: number;
  
  // Export URLs
  exportUrls: {
    purchaseOrderHeader: string;
    purchaseOrderItem: string;
    purchaseOrderPartner: string;
  };
}

/**
 * Get server-side configuration (Node.js environment)
 */
export function getServerConfig(): AirflowConfig {
  return {
    // Connection settings
    url: process.env.AIRFLOW_URL || 'http://localhost:8080',
    username: process.env.AIRFLOW_USERNAME || 'airflow',
    password: process.env.AIRFLOW_PASSWORD || 'airflow',
    apiVersion: process.env.AIRFLOW_API_VERSION || 'v2',
    
    // Host-side paths (for file operations from the application)
    dataBaseDir: process.env.AIRFLOW_DATA_BASE_DIR || './data',
    dataDir: process.env.AIRFLOW_DATA_DIR || './data/incomingcsv',
    incomingCsvDir: process.env.AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv',
    processedCsvDir: process.env.AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv',
    reportsDir: process.env.AIRFLOW_REPORTS_DIR || './reports',
    dagsDir: process.env.AIRFLOW_DAGS_DIR || './dags',
    
    // Container-side paths (for DAG runtime configuration)
    containerDataDir: process.env.AIRFLOW_CONTAINER_DATA_DIR || '/opt/airflow/data',
    containerIncomingCsvDir: process.env.AIRFLOW_CONTAINER_INCOMING_CSV_DIR || '/opt/airflow/data/incomingcsv',
    containerProcessedCsvDir: process.env.AIRFLOW_CONTAINER_PROCESSED_CSV_DIR || '/opt/airflow/data/processedcsv',
    containerDagsDir: process.env.AIRFLOW_CONTAINER_DAGS_DIR || '/opt/airflow/dags',
    
    // InfoArchive API settings
    infoArchiveApiBaseUrl: process.env.INFOARCHIVE_API_BASE_URL || 'http://10.73.91.23:8765',
    defaultBearerToken: process.env.DEFAULT_BEARER_TOKEN || '',
    defaultChunkSize: parseInt(process.env.DEFAULT_CHUNK_SIZE || '5000', 10),
    
    // Export URLs
    exportUrls: {
      purchaseOrderHeader: process.env.PURCHASEORDERHEADER_URL || 'http://10.73.91.23:8765/systemdata/tables/AAAAhw/content',
      purchaseOrderItem: process.env.PURCHASEORDERITEM_URL || 'http://10.73.91.23:8765/systemdata/tables/AAAAhg/content',
      purchaseOrderPartner: process.env.PURCHASEORDERPARTNER_URL || 'http://10.73.91.23:8765/systemdata/tables/AAAAhQ/content',
    }
  };
}

/**
 * Get client-side configuration (browser environment)
 */
export function getClientConfig(): Partial<AirflowConfig> {
  // In browser environment, use import.meta.env for Vite
  // or window object for runtime configuration
  if (typeof window !== 'undefined') {
    // Client-side (browser)
    return {
      url: (import.meta?.env?.VITE_AIRFLOW_URL as string) || 'http://localhost:8080',
      dataBaseDir: (import.meta?.env?.VITE_AIRFLOW_DATA_BASE_DIR as string) || './data',
      dataDir: (import.meta?.env?.VITE_AIRFLOW_DATA_DIR as string) || './data/incomingcsv',
      incomingCsvDir: (import.meta?.env?.VITE_AIRFLOW_INCOMING_CSV_DIR as string) || './data/incomingcsv',
      processedCsvDir: (import.meta?.env?.VITE_AIRFLOW_PROCESSED_CSV_DIR as string) || './data/processedcsv',
      reportsDir: (import.meta?.env?.VITE_AIRFLOW_REPORTS_DIR as string) || './reports',
      dagsDir: (import.meta?.env?.VITE_AIRFLOW_DAGS_DIR as string) || './dags',
    };
  }
  
  // Server-side rendering (SSR)
  return {
    url: process.env.NEXT_PUBLIC_AIRFLOW_URL || 'http://localhost:8080',
    dataBaseDir: process.env.NEXT_PUBLIC_AIRFLOW_DATA_BASE_DIR || './data',
    dataDir: process.env.NEXT_PUBLIC_AIRFLOW_DATA_DIR || './data/incomingcsv',
    incomingCsvDir: process.env.NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv',
    processedCsvDir: process.env.NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv',
    reportsDir: process.env.NEXT_PUBLIC_AIRFLOW_REPORTS_DIR || './reports',
    dagsDir: process.env.NEXT_PUBLIC_AIRFLOW_DAGS_DIR || './dags',
  };
}

/**
 * Utility function to log current configuration for debugging
 */
export function logConfiguration(isServer: boolean = false): void {
  // Only log on server-side to avoid client-side process.env access
  if (typeof window !== 'undefined') {
    console.log('=== CLIENT-SIDE CONFIGURATION ===');
    console.log('Using default client configuration');
    console.log('=====================================');
    return;
  }
  
  const config = isServer ? getServerConfig() : getClientConfig();
  
  if (process.env.ENABLE_PATH_LOGGING === 'true') {
    console.log('=== AIRFLOW CONFIGURATION ===');
    console.log(`Environment: ${isServer ? 'Server' : 'Client'}`);
    console.log(`Airflow URL: ${config.url}`);
    console.log(`Data Base Dir: ${config.dataBaseDir}`);
    console.log(`Incoming CSV Dir: ${config.incomingCsvDir}`);
    console.log(`Processed CSV Dir: ${config.processedCsvDir}`);
    console.log(`Reports Dir: ${config.reportsDir}`);
    console.log(`DAGs Dir: ${config.dagsDir}`);
    
    if (isServer) {
      const serverConfig = config as AirflowConfig;
      console.log(`Container Data Dir: ${serverConfig.containerDataDir}`);
      console.log(`Container Incoming Dir: ${serverConfig.containerIncomingCsvDir}`);
      console.log(`Container Processed Dir: ${serverConfig.containerProcessedCsvDir}`);
      console.log(`InfoArchive API: ${serverConfig.infoArchiveApiBaseUrl}`);
    }
    console.log('=============================');
  }
}

export type { AirflowConfig };
