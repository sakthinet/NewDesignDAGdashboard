# Home & Menu Pages

**Home**
- Hero section: brand name, tagline, "Order Now" button to Menu page.
- Bootstrap carousel with 3 featured items (images + captions).

**Menu**
- Grid (Bootstrap row/col) of items: image, name, price, "Add to cart" button.
- Items loaded from `items` array in app.js.

**Output**
- PLAN + diffs for app.js (add renderHome, renderMenu functions) and index.html (add placeholders).
- Sample `items` array with 5 Coffee products.
