# Styling & UX

- Use Bootstrap color utilities and spacing to make it look like a real coffee shop site.
- Add a `.btn-primary` override in style.css to use a coffee-brown shade.
- Make hero section full-height with a background image (CSS).

**Output**
- PLAN + diffs for style.css; minimal changes to HTML for added classes.
