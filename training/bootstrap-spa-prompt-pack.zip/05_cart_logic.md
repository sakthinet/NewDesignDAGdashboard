# Cart Logic

Implement JS functions:
- `addToCart(itemId, qty)` — add or increase qty.
- `removeFromCart(itemId)` — remove.
- `updateCartQty(itemId, qty)` — change qty.
- `getCartItems()` — read from localStorage.
- `clearCart()` — clear cart.

Update Cart view automatically when changes occur.

**Output**
- PLAN + diffs for app.js with cart functions.
- Short note on how to test in browser console.
