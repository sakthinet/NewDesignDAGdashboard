# Item Details, Cart, and Checkout

**Item Details**
- Click on item in Menu → show details view (image, description, price, "Add to cart").

**Cart**
- Table of items with name, qty (editable), price, remove button.
- Totals section at bottom.

**Checkout**
- Bootstrap form: name, email, address.
- Submit → show confirmation alert, clear cart.

**Output**
- PLAN + diffs for app.js to add renderItemDetails, renderCart, renderCheckout.
- Store cart in localStorage; update total when qty changes.
