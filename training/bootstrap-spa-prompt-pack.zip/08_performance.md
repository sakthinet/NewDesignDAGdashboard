# Performance Improvements

- Lazy-load images with `loading="lazy"`.
- Minify CSS/JS (in production).
- Cache menu data in localStorage to reduce re-fetch (if API used).

**Prompt**
Identify top 3 performance wins with minimal diffs and one-line impact notes.
