# Accessibility Audit

Checklist:
- All images have `alt` text.
- Forms have `<label>` for inputs.
- Color contrast meets WCAG AA.
- Nav is keyboard accessible.

**Prompt**
List a11y issues and give minimal HTML/CSS diffs to fix top 5.
