# Scaffold Base HTML/CSS/JS

Create the base SPA files:
- `index.html` with Bootstrap 5 via CDN, `<nav>` for brand + links: Home, Menu, Cart, Checkout.
- `style.css` for custom overrides.
- `app.js` for navigation, rendering content dynamically in `<main>`.
- A placeholder `<main>` area where content will be injected.
- Footer with © year + brand name.

**Output**
- PLAN + full file contents for index.html, style.css, app.js.
- Navigation links should use `data-page` attributes to switch views without reloading.
