# CoffeeShop / BookShop SPA — Bootstrap/CSS Prompt Pack

**Goal:** Guide juniors to build a Single Page Application (SPA) using **HTML5 + Bootstrap 5 + Vanilla JS/CSS** with AI-assisted prompt coding.

**Stack assumed:**  
- HTML5, Bootstrap 5 (via CDN)  
- Vanilla JS (ES6+)  
- No framework or backend; use localStorage for state  
- Optional: JSON file or in-memory array as "mock data"

## How to use
1. Open your code editor (or Replit HTML/CSS/JS template).  
2. Paste the persona prompt from `01_vibe_persona.md`.  
3. Run `02_scaffold_structure.md` to get the HTML/CSS/JS base.  
4. Add each feature/page using `03_home_menu_pages.md`, `04_item_cart_checkout.md`, etc.  
5. Style & polish with `06_styles.md`.  
6. Do accessibility/performance checks with `07_accessibility.md` and `08_performance.md`.  
7. Troubleshoot using `09_troubleshooting.md`.

Replace "CoffeeShop" with "BookShop" to change the theme.
