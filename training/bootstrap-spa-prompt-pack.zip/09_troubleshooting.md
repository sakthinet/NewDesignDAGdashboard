# Troubleshooting Prompt

When something is broken:
```
Here is the browser console/log output:
<PASTE LOGS>

Fix only the root cause with minimal diffs.
Do not change unrelated code.
Explain the fix in 2–3 bullet points.
```
