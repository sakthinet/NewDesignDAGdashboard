# Troubleshooting & Fix Loop

When something breaks, use this **fix prompt**:

```
Here is the error/test output:
<PASTE LOGS>

Fix only the root cause with the smallest diffs.
Do not change public APIs or unrelated code.
Output diffs + a 2‑3 bullet explanation.
```
