# Vibe / Prompt Snippets

- **Fast plumbing**  
  `Use minimal effort and terse output. Skip explanations unless needed.`

- **Deep design**  
  `Use deep reasoning. Show a short plan first, then code.`

- **Diff‑only PRs**  
  `Output unified diffs only (---/+++ with @@). No prose after code.`

- **Ask before coding**  
  `If anything is ambiguous, ask one clarifying question before coding.`

- **Explain like I'm new**  
  `Explain your changes in bullet points under a 'Why this works' section (max 6 bullets).`
