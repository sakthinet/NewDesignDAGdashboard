# Scaffold the SPA

Create a Vite React + TypeScript project with Tailwind configured.

**Pages & routes**
- `/` Home (hero + featured items)
- `/menu` Catalog list (grid of items with price, rating, "Add to cart")
- `/item/:id` Details page
- `/cart` Cart summary + quantity edit + remove
- `/checkout` Simple form (name, email, address); fake submit

**State**
- React Query + mock API (use MSW or a simple `mockApi.ts` first).
- Cart state in a context with localStorage persistence.

**Deliverables**
- PLAN + diffs to create the project structure under `/src`:
  - `src/pages/{Home,Menu,ItemDetails,Cart,Checkout}.tsx`
  - `src/components/{NavBar,Footer,ProductCard,QuantityInput}.tsx`
  - `src/context/CartContext.tsx`
  - `src/api/{mockApi.ts, hooks.ts}`
  - `src/routes.tsx` with React Router
  - Tailwind setup files
- Commands to run the dev server.
