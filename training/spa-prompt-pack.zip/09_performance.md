# Performance & Loading

**Goals**
- Keep first load small; lazy‑load non‑critical routes (`ItemDetails`, `Checkout`).
- Memoize heavy components; avoid unnecessary re‑renders when cart changes.
- Pre‑fetch item details on hover in `/menu`.

**Prompt**
Identify the top 3 performance wins with minimal diffs (lazy routes, memoization, React Query prefetch). Provide a one‑line expected impact per change.
