# CoffeeShop / BookShop SPA — Prompt Pack (for GPT‑5 + Replit)

**Goal:** Teach juniors how to steer an AI pair‑programmer using small, focused prompts (“vibe/context coding”).  
You can switch the theme by replacing every mention of **CoffeeShop** with **BookShop**.

**Stack assumed:** React 18 + TypeScript + Vite + Tailwind + React Router + React Query + Vitest/RTL.  
**Optional backend:** mock with MSW or JSON Server (later swap to real API).

## How to use
1) Open Replit → Modern Web App → paste the prompt from `01_vibe_persona.md`.  
2) Run `02_scaffold_frontend.md`. Accept changes.  
3) Go page‑by‑page using `03_ui_pages.md`, then add state/APIs via `04_state_api.md`.  
4) Add auth (`05_auth.md`), tests (`06_tests.md`), styles (`07_styles.md`).  
5) Do a11y (`08_accessibility.md`) and perf checks (`09_performance.md`).  
6) Use `11_prompt_snippets.md` to change the *vibe* (fast vs deep vs diff‑only).

> Keep each prompt tight. After each AI output, **run** the app/tests, then paste errors back with the fix prompt from `10_troubleshooting.md`.
