# Optional: Lightweight Auth

Add fake auth for a future admin page.

**Requirements**
- `AuthContext` with `user|null`, `login(email)`, `logout()`.
- Store user in localStorage. No password for now; accept any email.
- Add `/admin` route protected by `RequireAuth` wrapper.
- NavBar shows "Sign in"/"Sign out" based on auth state.

**Output**
- PLAN + diffs + tests for `RequireAuth` (redirects unauthenticated users).
