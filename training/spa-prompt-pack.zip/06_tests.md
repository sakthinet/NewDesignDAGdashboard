# Tests (Vitest + React Testing Library)

Add tests for the most important flows.

**Specs**
1) `ProductCard.test.tsx`: clicking "Add to cart" calls context with item.  
2) `Cart.test.tsx`: quantity changes update totals.  
3) `Checkout.test.tsx`: invalid email blocks submit; valid submits calls clear and shows success.  
4) `hooks.test.ts`: `useItems` and `useItem` render proper states (loading/success).

**Output**
- PLAN + test file diffs + commands to run tests.
