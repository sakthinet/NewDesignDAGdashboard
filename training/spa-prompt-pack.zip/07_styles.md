# Styling & UX Polish

**Tailwind**
- Introduce a color palette suitable for CoffeeShop (browns/cream).  
- Add base styles for headings, buttons, cards in `globals.css` via `@apply`.

**Components**
- `Button`, `Input`, `Badge` components to unify look and feel.
- Add hover/focus states; ensure hit areas are touch friendly.

**Output**
- PLAN + diffs + short before/after screenshots instructions (optional).
