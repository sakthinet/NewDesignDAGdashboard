# Build the Pages (UI only first)

Implement minimal versions of each page with placeholder data. Use Tailwind utility classes.

**Requirements**
- **Home**: brand header, CTA buttons linking to `/menu`.
- **Menu**: responsive grid (2/3/4 columns). `ProductCard` shows title, price, rating, and "Add to cart".
- **ItemDetails**: image, description, price, "Add to cart", suggested items.
- **Cart**: line items with `QuantityInput`, totals, "Checkout" button.
- **Checkout**: form validation (email, address). On submit, toast success and clear cart.

**Output**
- PLAN + **diffs only**. Keep components under ~150 lines. Add TODOs where you defer details.
