# Accessibility Pass (a11y)

**Checklist**
- Ensure every interactive control has an accessible name.
- Keyboard: tab order, focus ring visible, skip‑to‑content link.
- Color contrast meets WCAG AA.
- Forms have labels + error messages with `aria-live="polite"`.

**Prompt**
Perform an a11y audit of the current SPA. List issues and propose **minimal** diffs to fix the top 5. Output diffs only.
