# Data Layer & Cart Logic

**Mock API (phase 1)**
- Create `src/api/mockApi.ts` that returns `Item { id, name, price, rating, imageUrl, description, category }`.
- Add functions: `listItems(q?, category?)`, `getItem(id)`.

**React Query hooks**
- `useItems(q, category)` and `useItem(id)`. Cache for 5m, staleTime 30s.

**CartContext**
- `add(item, qty=1)`, `remove(id)`, `setQty(id, qty)`, `clear()`.
- Persist to localStorage; hydrate on load; derive `subtotal`, `tax`, `total`.

**Wire up pages**
- Menu pulls from `useItems`. ItemDetails uses `useItem`. Cart uses context.
- Buttons call `add` and `setQty` properly.

**Output**
- PLAN + diffs + a short note on where to place provider (in `main.tsx`).
- Provide a minimal `types.ts` for DTOs.
