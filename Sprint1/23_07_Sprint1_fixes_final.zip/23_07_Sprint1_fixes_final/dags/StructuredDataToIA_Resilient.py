from airflow import DAG
from airflow.decorators import task
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python import get_current_context
from datetime import datetime, timedelta
import os, csv, xml.etree.ElementTree as ET, requests, shutil

# Enhanced path configuration with robust fallback
def get_airflow_paths():
    """Get Airflow paths with fallback mechanisms"""
    return {
        'incoming_csv': os.getenv("AIRFLOW_CONTAINER_INCOMING_CSV_DIR", "/opt/airflow/data/incomingcsv/"),
        'processed_csv': os.getenv("AIRFLOW_CONTAINER_PROCESSED_CSV_DIR", "/opt/airflow/data/processedcsv/"),
        'temp_dir': os.getenv("AIRFLOW_CONTAINER_INCOMING_CSV_DIR", "/opt/airflow/data/incomingcsv/")
    }

# Get paths
PATHS = get_airflow_paths()
WATCH_DIR = PATHS['incoming_csv']
CHUNK_TEMP_DIR = PATHS['temp_dir']
PROCESSED_DIR = PATHS['processed_csv']

default_args = {
    "owner": "airflow",
    "retries": 2,
    "retry_delay": timedelta(minutes=3)
}

with DAG(
    dag_id="StructuredDataToIA_Resilient",
    default_args=default_args,
    start_date=datetime(2024, 1, 1),
    schedule=None,
    catchup=False,
    description="Export CSV in parallel XML chunks with metrics tracking",
    tags=["chunked", "resilient", "InfoArchive"]
) as dag:

    @task
    def get_chunk_meta():
        """Enhanced chunk metadata extraction with better error handling"""
        context = get_current_context()
        dag_run = context.get('dag_run')
        
        # Get configuration from dag_run.conf (passed from frontend)
        if dag_run and hasattr(dag_run, 'conf'):
            conf = dag_run.conf or {}
        else:
            conf = {}
        
        # Extract configuration with enhanced validation
        csv_filename = conf.get('CSV_FILENAME') or conf.get('csv_file', 'PurchaseOrderHeader.csv')
        schema_name = conf.get('SCHEMA_NAME') or conf.get('schema_name', 'SAP-PO')
        chunk_size = int(conf.get('CHUNK_SIZE') or conf.get('chunk_size', 5000))
        bearer_token = conf.get('BEARER_TOKEN') or conf.get('bearer_token', 'your_token')
        export_url = conf.get('EXPORT_URL') or conf.get('table_url', 'https://api.example.com/export')
        
        print(f"📋 Configuration received:")
        print(f"  CSV Filename: {csv_filename}")
        print(f"  Schema Name: {schema_name}")
        print(f"  Chunk Size: {chunk_size}")
        print(f"  Export URL: {export_url}")
        print(f"  Paths: {PATHS}")
        
        file_path = os.path.join(WATCH_DIR, csv_filename)
        
        # Enhanced file existence check
        if not os.path.exists(file_path):
            # Try alternative locations
            alternative_paths = [
                os.path.join("/opt/airflow/data/", csv_filename),
                os.path.join("/opt/airflow/", csv_filename),
                csv_filename  # Current directory as last resort
            ]
            
            found_path = None
            for alt_path in alternative_paths:
                if os.path.exists(alt_path):
                    found_path = alt_path
                    print(f"📁 Found file at alternative location: {alt_path}")
                    break
            
            if not found_path:
                error_msg = f"CSV file not found: {file_path}. Checked paths: {[file_path] + alternative_paths}"
                print(f"❌ {error_msg}")
                raise FileNotFoundError(error_msg)
            
            file_path = found_path

        # Count rows with better encoding handling
        try:
            with open(file_path, newline="", encoding="utf-8") as f:
                total_rows = sum(1 for _ in f) - 1
        except UnicodeDecodeError:
            # Try alternative encodings
            for encoding in ['utf-8-sig', 'latin1', 'cp1252']:
                try:
                    with open(file_path, newline="", encoding=encoding) as f:
                        total_rows = sum(1 for _ in f) - 1
                    print(f"📄 Successfully read file with encoding: {encoding}")
                    break
                except UnicodeDecodeError:
                    continue
            else:
                raise ValueError(f"Unable to read file {file_path} with any supported encoding")

        total_chunks = (total_rows + chunk_size - 1) // chunk_size
        
        result = {
            "file": file_path,
            "chunk_size": chunk_size,
            "total_chunks": total_chunks,
            "total_rows": total_rows,
            "schema": schema_name,
            "table": os.path.splitext(os.path.basename(file_path))[0],
            "bearer_token": bearer_token,
            "export_url": export_url
        }
        
        print(f"✅ Metadata extracted: {total_rows} rows, {total_chunks} chunks")
        return result

    @task
    def get_chunk_indexes(chunk_meta):
        return [(i, chunk_meta) for i in range(chunk_meta["total_chunks"])]

    @task
    def extract_chunk(args):
        chunk_index, chunk_meta = args
        start = chunk_index * chunk_meta["chunk_size"]
        end = start + chunk_meta["chunk_size"]
        rows = []

        with open(chunk_meta["file"], newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                if start <= i < end:
                    rows.append(row)

        temp_csv = os.path.join(CHUNK_TEMP_DIR, f"chunk_{chunk_index}.csv")
        with open(temp_csv, "w", newline="", encoding="utf-8") as f_out:
            writer = csv.DictWriter(f_out, fieldnames=reader.fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        return (chunk_index, temp_csv, chunk_meta)

    @task
    def create_xml(args):
        chunk_index, chunk_csv_path, chunk_meta = args
        root = ET.Element(chunk_meta["schema"])
        middle = ET.SubElement(root, chunk_meta["table"])

        with open(chunk_csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                row_elem = ET.SubElement(middle, "ROW")
                for k, v in row.items():
                    child = ET.SubElement(row_elem, k.strip().replace(" ", "_"))
                    child.text = str(v) if v else ""

        xml_path = os.path.join(CHUNK_TEMP_DIR, f"{chunk_meta['table']}_chunk_{chunk_index}.xml")
        with open(xml_path, "wb") as xf:
            xf.write(ET.tostring(root, encoding="utf-8"))

        return (chunk_index, xml_path, chunk_meta)

    @task(retries=3, retry_delay=timedelta(minutes=2))
    def export_chunk(args):
        """Enhanced chunk export with better error handling and logging"""
        chunk_index, xml_path, chunk_meta = args
        
        try:
            print(f"📤 Exporting chunk {chunk_index} from {xml_path}")
            
            # Verify file exists before attempting export
            if not os.path.exists(xml_path):
                raise FileNotFoundError(f"XML file not found: {xml_path}")
            
            # Get file size for logging
            file_size = os.path.getsize(xml_path)
            print(f"📊 Chunk {chunk_index} size: {file_size} bytes")
            
            with open(xml_path, "rb") as f:
                xml_data = f.read()
                
                # Validate XML content is not empty
                if not xml_data:
                    raise ValueError(f"XML file is empty: {xml_path}")
                
                response = requests.post(
                    url=chunk_meta["export_url"],
                    headers={
                        "Authorization": f"Bearer {chunk_meta['bearer_token']}",
                        "Content-Type": "application/xml",
                        "User-Agent": "Airflow-DAG/1.0"
                    },
                    data=xml_data,
                    timeout=300  # 5 minute timeout
                )

            print(f"📡 Export response for chunk {chunk_index}: {response.status_code}")
            
            if response.status_code not in [200, 201]:
                error_msg = f"Chunk {chunk_index} export failed (status {response.status_code})"
                try:
                    response_text = response.text[:500]  # Limit response text for logging
                    error_msg += f": {response_text}"
                except:
                    pass
                
                print(f"❌ {error_msg}")
                raise Exception(error_msg)
            
            print(f"✅ Chunk {chunk_index} exported successfully (size: {file_size} bytes)")
            return {"chunk_index": chunk_index, "status": "success", "size": file_size}
            
        except requests.exceptions.Timeout:
            error_msg = f"Timeout exporting chunk {chunk_index} after 5 minutes"
            print(f"⏱️ {error_msg}")
            raise Exception(error_msg)
        except requests.exceptions.ConnectionError:
            error_msg = f"Connection error exporting chunk {chunk_index}"
            print(f"🔌 {error_msg}")
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Failed to export chunk {chunk_index}: {str(e)}"
            print(f"❌ {error_msg}")
            raise Exception(error_msg)

    @task
    def collect_metrics(chunk_meta):
        ctx = get_current_context()
        rows = chunk_meta["chunk_size"] * chunk_meta["total_chunks"]

        sql = """
        INSERT INTO dag_run_metrics (
            dag_id, run_id, execution_date, records_processed
        )
        VALUES (
            %(dag_id)s, %(run_id)s, %(execution_date)s, %(records_processed)s
        )
        """

        params = {
            "dag_id": ctx["dag"].dag_id,
            "run_id": ctx["run_id"],
            "execution_date": ctx["logical_date"],
            "records_processed": rows
        }

        hook = PostgresHook(postgres_conn_id="metrics_db")
        hook.run(sql, parameters=params)
        print(f"📈 Logged: {rows} rows")

    @task
    def finalize(chunk_meta):
        """Enhanced finalization with comprehensive cleanup and error handling"""
        print(f"🧹 Starting finalization process...")
        
        # Move original file to processed directory
        source_file = chunk_meta["file"]
        
        # Ensure processed directory exists
        os.makedirs(PROCESSED_DIR, exist_ok=True)
        
        if os.path.exists(source_file):
            try:
                destination_file = os.path.join(PROCESSED_DIR, os.path.basename(source_file))
                
                # Add timestamp to avoid conflicts
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                name, ext = os.path.splitext(os.path.basename(source_file))
                destination_file = os.path.join(PROCESSED_DIR, f"{name}_{timestamp}{ext}")
                
                shutil.move(source_file, destination_file)
                print(f"📦 Archived original file to: {destination_file}")
            except Exception as e:
                print(f"⚠️ Could not move original file {source_file}: {e}")
        else:
            print(f"⚠️ Original file not found for archiving: {source_file}")

        # Clean up temporary files with enhanced error handling
        cleanup_patterns = [
            f"{chunk_meta['table']}_chunk_*.xml",
            "chunk_*.csv"
        ]
        
        total_cleaned = 0
        
        try:
            if os.path.exists(CHUNK_TEMP_DIR):
                for filename in os.listdir(CHUNK_TEMP_DIR):
                    should_delete = False
                    
                    # Check if file matches cleanup patterns
                    for pattern in cleanup_patterns:
                        if filename.startswith(pattern.split('*')[0]) and filename.endswith(pattern.split('*')[1]):
                            should_delete = True
                            break
                    
                    if should_delete:
                        try:
                            file_path = os.path.join(CHUNK_TEMP_DIR, filename)
                            file_size = os.path.getsize(file_path)
                            os.remove(file_path)
                            total_cleaned += 1
                            print(f"🗑️ Removed temp file: {filename} ({file_size} bytes)")
                        except Exception as e:
                            print(f"⚠️ Could not remove {filename}: {e}")
            
            print(f"✅ Cleanup completed: {total_cleaned} temporary files removed")
            
        except Exception as e:
            print(f"⚠️ Error during cleanup: {e}")

        # Final summary
        summary = {
            "total_rows_processed": chunk_meta.get("total_rows", 0),
            "total_chunks": chunk_meta.get("total_chunks", 0),
            "chunk_size": chunk_meta.get("chunk_size", 0),
            "schema": chunk_meta.get("schema", "unknown"),
            "table": chunk_meta.get("table", "unknown"),
            "files_cleaned": total_cleaned,
            "completion_time": datetime.now().isoformat()
        }
        
        print(f"📊 Processing Summary: {summary}")
        return summary
        

    # 🔗 DAG Flow
    chunk_meta = get_chunk_meta()
    chunk_args = get_chunk_indexes(chunk_meta)

    extracted = extract_chunk.expand(args=chunk_args)
    xmls = create_xml.expand(args=extracted)
    export_chunk.expand(args=xmls) >> collect_metrics(chunk_meta) >> finalize(chunk_meta)