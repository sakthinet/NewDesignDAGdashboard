// Alternative file transfer method using SSH/SCP for remote servers
// This is a fallback solution if network drives don't work

import { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// Configuration for remote server
const REMOTE_CONFIG = {
  host: '10.73.88.101',
  username: 'airflow', // Update with actual username
  dataPath: '/data/incomingcsv',
  keyPath: '', // Path to SSH key if using key authentication
  usePassword: false // Set to true if using password auth
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  console.log('=== REMOTE FILE TRANSFER API CALLED ===');
  
  if (req.method !== 'POST') {
    return res.status(405).json({ 
      success: false, 
      message: 'Method not allowed' 
    });
  }

  try {
    const { fileName } = req.body;

    if (!fileName) {
      return res.status(400).json({
        success: false,
        message: 'fileName is required'
      });
    }

    // Check if file exists locally
    const tempDir = path.join(process.cwd(), 'uploads');
    const sourcePath = path.join(tempDir, fileName);
    
    if (!fs.existsSync(sourcePath)) {
      return res.status(404).json({
        success: false,
        message: `Source file not found: ${sourcePath}`
      });
    }

    console.log(`📁 Transferring file: ${fileName}`);
    console.log(`📂 Source: ${sourcePath}`);
    console.log(`📂 Target: ${REMOTE_CONFIG.host}:${REMOTE_CONFIG.dataPath}/${fileName}`);

    // Method 1: Using SCP (requires SSH access)
    if (REMOTE_CONFIG.keyPath) {
      const scpCommand = `scp -i "${REMOTE_CONFIG.keyPath}" "${sourcePath}" ${REMOTE_CONFIG.username}@${REMOTE_CONFIG.host}:${REMOTE_CONFIG.dataPath}/`;
      console.log(`Executing SCP command: ${scpCommand}`);
      
      try {
        const { stdout, stderr } = await execAsync(scpCommand);
        console.log('SCP stdout:', stdout);
        if (stderr) console.log('SCP stderr:', stderr);
        
        return res.status(200).json({
          success: true,
          message: `File transferred successfully via SCP`,
          fileName: fileName,
          method: 'scp',
          target: `${REMOTE_CONFIG.host}:${REMOTE_CONFIG.dataPath}/${fileName}`
        });
      } catch (error) {
        console.error('SCP transfer failed:', error);
        throw error;
      }
    }

    // Method 2: Using Windows NET USE to map drive temporarily
    const driveLetter = 'Z:';
    const networkPath = `\\\\${REMOTE_CONFIG.host}\\data`;
    
    try {
      // Map network drive temporarily
      const mapCommand = `net use ${driveLetter} ${networkPath}`;
      console.log(`Mapping network drive: ${mapCommand}`);
      
      await execAsync(mapCommand);
      
      // Copy file to mapped drive
      const targetPath = `${driveLetter}\\incomingcsv\\${fileName}`;
      
      // Ensure target directory exists
      const targetDir = path.dirname(targetPath);
      if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
      }
      
      // Copy file
      fs.copyFileSync(sourcePath, targetPath);
      
      // Verify copy
      if (fs.existsSync(targetPath)) {
        console.log(`✅ File copied successfully to: ${targetPath}`);
        
        // Cleanup: unmap drive
        try {
          await execAsync(`net use ${driveLetter} /delete`);
        } catch (cleanupError) {
          console.warn('Failed to cleanup network drive mapping:', cleanupError);
        }
        
        return res.status(200).json({
          success: true,
          message: `File transferred successfully via network drive`,
          fileName: fileName,
          method: 'network_drive',
          target: targetPath
        });
      } else {
        throw new Error('File copy verification failed');
      }
      
    } catch (error) {
      console.error('Network drive transfer failed:', error);
      
      // Cleanup: unmap drive in case of error
      try {
        await execAsync(`net use ${driveLetter} /delete`);
      } catch (cleanupError) {
        console.warn('Failed to cleanup network drive mapping after error:', cleanupError);
      }
      
      throw error;
    }

  } catch (error) {
    console.error('File transfer failed:', error);
    return res.status(500).json({
      success: false,
      message: 'File transfer failed',
      error: error instanceof Error ? error.message : String(error)
    });
  }
}
