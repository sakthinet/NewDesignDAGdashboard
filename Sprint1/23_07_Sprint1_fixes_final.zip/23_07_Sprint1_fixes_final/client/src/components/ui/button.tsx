import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-none text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border",
  {
    variants: {
      variant: {
        default: "bg-blue-500 text-white border-blue-600 hover:bg-blue-600 hover:border-blue-700 dark:bg-blue-600 dark:border-blue-700 dark:hover:bg-blue-700 dark:hover:border-blue-800",
        destructive:
          "bg-red-500 text-white border-red-600 hover:bg-red-600 hover:border-red-700 dark:bg-red-600 dark:border-red-700 dark:hover:bg-red-700 dark:hover:border-red-800",
        outline:
          "border-blue-500 bg-blue-500 text-white hover:bg-blue-600 hover:text-white hover:border-blue-600 dark:border-blue-400 dark:bg-blue-500 dark:text-white dark:hover:bg-blue-600 dark:hover:text-white dark:hover:border-blue-500",
        secondary:
          "bg-blue-500 text-white border-blue-600 hover:bg-blue-600 hover:border-blue-700 hover:text-white dark:bg-blue-600 dark:text-white dark:border-blue-700 dark:hover:bg-blue-700 dark:hover:border-blue-800 dark:hover:text-white",
        ghost: "border-transparent bg-transparent text-foreground hover:bg-accent hover:text-accent-foreground hover:border-accent",
        link: "text-primary underline-offset-4 hover:underline border-transparent bg-transparent",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3",
        lg: "h-11 px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
