import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { 
  Sun, 
  Moon 
} from "lucide-react";
import { 
  changeTheme, 
  getCurrentTheme, 
  type ThemeDefinition 
} from "../utils/theme-init";

export interface Theme {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  colors: {
    primary: string;
    background: string;
    surface: string;
    text: string;
  };
  cssClass: string;
}

export const THEMES: Theme[] = [
  {
    id: 'light',
    name: 'Light Theme',
    description: 'Clean and modern light interface',
    icon: Sun,
    colors: {
      primary: '#2563eb',
      background: '#ffffff',
      surface: '#f8fafc',
      text: '#1e293b'
    },
    cssClass: 'theme-light'
  },
  {
    id: 'dark',
    name: 'Dark Theme',
    description: 'Modern dark interface for low-light environments',
    icon: Moon,
    colors: {
      primary: '#3b82f6',
      background: '#0f172a',
      surface: '#1e293b',
      text: '#f1f5f9'
    },
    cssClass: 'theme-dark'
  }
];

export function ThemeSelector() {
  const [currentTheme, setCurrentTheme] = useState<string>('light');

  // Load current theme on mount
  useEffect(() => {
    const theme = getCurrentTheme();
    setCurrentTheme(theme.id);
  }, []);

  // Listen for theme changes from other sources
  useEffect(() => {
    const handleThemeChange = (event: CustomEvent) => {
      setCurrentTheme(event.detail.themeId);
    };

    window.addEventListener('themeChanged', handleThemeChange as EventListener);
    return () => {
      window.removeEventListener('themeChanged', handleThemeChange as EventListener);
    };
  }, []);

  const toggleTheme = () => {
    // Toggle between light and dark themes
    const nextTheme = currentTheme === 'light' ? 'dark' : 'light';
    changeTheme(nextTheme);
    setCurrentTheme(nextTheme);
  };

  const isDarkTheme = currentTheme === 'dark';

  return (
    <Button 
      onClick={toggleTheme}
      size="icon"
      variant="ghost"
      className="h-9 w-9 rounded-full transition-all"
      title={isDarkTheme ? "Switch to Light Theme" : "Switch to Dark Theme"}
    >
      {isDarkTheme ? (
        <Sun className="h-5 w-5" />
      ) : (
        <Moon className="h-5 w-5" />
      )}
      <span className="sr-only">
        {isDarkTheme ? "Switch to Light Theme" : "Switch to Dark Theme"}
      </span>
    </Button>
  );
}