# Data Transformer Airflow DAG Generator - Deployment Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Configuration Changes Required](#configuration-changes-required)
3. [Environment Setup](#environment-setup)
4. [Installation Steps](#installation-steps)
5. [Configuration Files](#configuration-files)
6. [Path Configurations](#path-configurations)
7. [Airflow Integration](#airflow-integration)
8. [Database Setup](#database-setup)
9. [Testing & Verification](#testing--verification)
10. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### System Requirements
- **Node.js**: Version 18.0.0 or higher
- **npm**: Version 8.0.0 or higher (comes with Node.js)
- **Git**: For cloning the repository
- **Docker**: For Airflow container (recommended)
- **Python**: 3.8+ (if running Airflow natively)

### Airflow Requirements
- **Apache Airflow**: Version 3.x (recommended) or 2.x
- **Access**: HTTP access to Airflow webserver
- **Authentication**: Admin credentials for Airflow API

---

## Configuration Changes Required

### 1. Airflow Connection Settings

**File**: `server/routes.ts` (Lines 45-55)
```typescript
const AIRFLOW_CONFIG = {
  baseUrl: process.env.AIRFLOW_URL || "http://localhost:8083",  // CHANGE THIS
  apiVersion: '/api/v2',
  authEndpoint: '/auth/token',
  defaultCredentials: {
    username: process.env.AIRFLOW_USERNAME || 'airflow',          // CHANGE THIS
    password: process.env.AIRFLOW_PASSWORD || 'airflow'        // CHANGE THIS
  }
};
```

**Required Changes:**
- `baseUrl`: Replace with your Airflow webserver URL
- `username`: Replace with your Airflow admin username
- `password`: Replace with your Airflow admin password

### 2. Directory Paths Configuration

**Multiple files need path updates:**

#### A. Default Data Paths
**File**: `client/src/components/dag-configuration.tsx` (Line 298)
```typescript
const defaultDataPath = "C:\\Docker\\airflow3x2\\data";        // CHANGE THIS
const defaultDagsPath = "C:\\Docker\\airflow3x2\\dags";        // CHANGE THIS
```

#### B. Server-side Paths
**File**: `server/routes.ts` (Line 852)
```typescript
const dataDirectory = process.env.AIRFLOW_REPORTS_DIR || "\\\\10.73.88.101\\reports";  // CHANGE THIS
```

#### C. DAG Generator Component
**File**: `client/src/pages/dag-generator.tsx` (Lines 30-35)
```typescript
const [dagConfig, setDagConfig] = useState<DagConfig>({
  inputDirectory: 'C:\\Docker\\airflow3x2\\data',              // CHANGE THIS
  outputDirectory: 'C:\\Docker\\airflow3x2\\data',             // CHANGE THIS
  dagsDirectory: 'C:\\Docker\\airflow3x2\\dags'               // CHANGE THIS
});
```

### 3. Environment Variables

Create a `.env` file in the root directory:

```bash
# Airflow Configuration
AIRFLOW_URL=http://your-airflow-server:8080
AIRFLOW_USERNAME=your_admin_username
AIRFLOW_PASSWORD=your_admin_password
AIRFLOW_DATA_DIR=C:\\path\\to\\your\\airflow\\data
AIRFLOW_DAGS_DIR=C:\\path\\to\\your\\airflow\\dags

# Optional: Hugging Face API (for enhanced chatbot)
HUGGINGFACE_API_KEY=your_hf_token_here

# Database (if using external database)
DATABASE_URL=sqlite:./database.db

# Server Configuration
PORT=3000
NODE_ENV=production
```

---

## Environment Setup

### Development Environment
```bash
# Clone the repository
git clone <repository-url>
cd AirflowDagCrafter

# Install dependencies
npm install

# Create environment file
cp .env.example .env
# Edit .env with your configurations

# Start development server
npm run dev
```

### Production Environment
```bash
# Install dependencies
npm install --production

# Build the application
npm run build

# Start production server
npm start
```

---

## Installation Steps

### Step 1: Clone and Setup
```bash
git clone <repository-url>
cd AirflowDagCrafter
npm install
```

### Step 2: Configure Environment
```bash
# Copy environment template
cp .env.example .env

# Edit configuration
nano .env  # or use your preferred editor
```

### Step 3: Update Configuration Files

#### Update Airflow Connection
Edit `server/routes.ts`:
```typescript
const AIRFLOW_CONFIG = {
  baseUrl: "http://YOUR_AIRFLOW_HOST:PORT",
  // ... rest of config
};
```

#### Update Default Paths
Edit `client/src/components/dag-configuration.tsx`:
```typescript
const defaultDataPath = "YOUR_AIRFLOW_DATA_PATH";
const defaultDagsPath = "YOUR_AIRFLOW_DAGS_PATH";
```

### Step 4: Test Configuration
```bash
# Test the setup
npm run test-config

# Start the application
npm run dev
```

---

## Configuration Files

### 1. `.env` File Template
```bash
# ===========================================
# Data Transformer Airflow DAG Generator Configuration
# ===========================================

# Airflow Server Configuration
AIRFLOW_URL=http://10.73.88.101:8080
AIRFLOW_USERNAME=admin
AIRFLOW_PASSWORD=admin123

# Directory Paths (Use forward slashes or double backslashes)
AIRFLOW_DATA_DIR=C:/airflow/data
AIRFLOW_DAGS_DIR=C:/airflow/dags
UPLOAD_DIR=./uploads
TEMP_DIR=./temp

# API Configuration
HUGGINGFACE_API_KEY=your_token_here

# Database Configuration
DATABASE_URL=sqlite:./database.db

# Server Configuration
PORT=3000
NODE_ENV=development
HOST=localhost

# Security Configuration
JWT_SECRET=your_jwt_secret_here
SESSION_SECRET=your_session_secret_here

# Logging Configuration
LOG_LEVEL=info
LOG_DIR=./logs

# Upload Configuration
MAX_FILE_SIZE=10485760  # 10MB in bytes
ALLOWED_FILE_TYPES=.csv,.txt

# Cache Configuration
CACHE_TTL=300  # 5 minutes
REDIS_URL=redis://localhost:6379  # Optional
```

### 2. Configuration Validation Script

Create `config-validator.js`:
```javascript
// filepath: d:\Programming\Reactjs\InfoArchive_project\04_07\AirflowDagCrafter\config-validator.js
const fs = require('fs');
const path = require('path');

function validateConfig() {
  console.log('🔍 Validating Data Transformer Configuration...\n');
  
  // Check .env file
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) {
    console.error('❌ .env file not found. Please create one from .env.example');
    process.exit(1);
  }
  
  // Load environment variables
  require('dotenv').config();
  
  const requiredVars = [
    'AIRFLOW_URL',
    'AIRFLOW_USERNAME',
    'AIRFLOW_PASSWORD',
    'AIRFLOW_DATA_DIR',
    'AIRFLOW_DAGS_DIR'
  ];
  
  const missing = [];
  const found = [];
  
  requiredVars.forEach(varName => {
    if (process.env[varName]) {
      found.push(`✅ ${varName}: ${process.env[varName]}`);
    } else {
      missing.push(`❌ ${varName}: Not set`);
    }
  });
  
  console.log('Required Environment Variables:');
  found.forEach(item => console.log(item));
  missing.forEach(item => console.log(item));
  
  if (missing.length > 0) {
    console.error('\n❌ Configuration validation failed. Please set missing variables.');
    process.exit(1);
  }
  
  console.log('\n✅ Configuration validation passed!');
  
  // Test directory access
  const directories = [
    process.env.AIRFLOW_DATA_DIR,
    process.env.AIRFLOW_DAGS_DIR
  ];
  
  console.log('\nDirectory Access Test:');
  directories.forEach(dir => {
    try {
      if (fs.existsSync(dir)) {
        console.log(`✅ ${dir}: Accessible`);
      } else {
        console.log(`⚠️  ${dir}: Does not exist (will be created)`);
      }
    } catch (error) {
      console.log(`❌ ${dir}: Access denied - ${error.message}`);
    }
  });
}

validateConfig();
```

### 3. Package.json Scripts
Add to your `package.json`:
```json
{
  "scripts": {
    "dev": "concurrently \"npm run server\" \"npm run client\"",
    "build": "npm run build:client && npm run build:server",
    "start": "node dist/server/index.js",
    "test-config": "node config-validator.js",
    "setup": "npm install && npm run test-config",
    "deploy": "npm run build && npm run test-config"
  }
}
```

---

## Path Configurations

### Windows Paths
```typescript
// Use double backslashes or forward slashes
const paths = {
  data: "C:\\airflow\\data",
  dags: "C:\\airflow\\dags",
  // OR
  data: "C:/airflow/data",
  dags: "C:/airflow/dags"
};
```

### Linux/Mac Paths
```typescript
const paths = {
  data: "/opt/airflow/data",
  dags: "/opt/airflow/dags"
};
```

### Docker Paths
```typescript
const paths = {
  data: "/opt/airflow/data",
  dags: "/opt/airflow/dags"
};
```

### Path Configuration by Environment

#### Development (Local Airflow)
```bash
AIRFLOW_DATA_DIR=./data
AIRFLOW_DAGS_DIR=./dags
```

#### Production (Docker)
```bash
AIRFLOW_DATA_DIR=/opt/airflow/data
AIRFLOW_DAGS_DIR=/opt/airflow/dags
```

#### Production (Native Install)
```bash
AIRFLOW_DATA_DIR=/home/airflow/data
AIRFLOW_DAGS_DIR=/home/airflow/dags
```

---

## Airflow Integration

### 1. Airflow URL Configuration

**Default URLs by Setup Type:**

| Setup Type | Default URL | Port |
|------------|-------------|------|
| Docker Compose | http://localhost:8080 | 8080 |
| Docker (custom) | http://localhost:8083 | 8083 |
| Native Install | http://localhost:8080 | 8080 |
| Remote Server | http://server-ip:port | varies |

### 2. Authentication Setup

#### For Airflow 3.x (JWT Token)
```typescript
// Automatic JWT handling in routes.ts
const authenticateAndGetToken = async (): Promise<string> => {
  const response = await fetch(`${AIRFLOW_CONFIG.baseUrl}/auth/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: AIRFLOW_CONFIG.defaultCredentials.username,
      password: AIRFLOW_CONFIG.defaultCredentials.password
    })
  });
  // ... handled automatically
};
```

#### For Airflow 2.x (Basic Auth)
Update authentication method if needed:
```typescript
// In routes.ts, modify authentication
const makeAuthenticatedRequest = async (endpoint: string) => {
  const credentials = btoa(`${username}:${password}`);
  const response = await fetch(url, {
    headers: {
      'Authorization': `Basic ${credentials}`,
      'Content-Type': 'application/json'
    }
  });
};
```

### 3. API Endpoints Testing

Create `test-airflow.js`:
```javascript
// filepath: d:\Programming\Reactjs\InfoArchive_project\04_07\AirflowDagCrafter\test-airflow.js
const fetch = require('node-fetch');

async function testAirflowConnection() {
  const airflowUrl = process.env.AIRFLOW_URL || 'http://localhost:8083';
  const username = process.env.AIRFLOW_USERNAME || 'admin';
  const password = process.env.AIRFLOW_PASSWORD || 'admin123';
  
  console.log(`Testing connection to: ${airflowUrl}`);
  
  try {
    // Test basic connectivity
    const healthResponse = await fetch(`${airflowUrl}/health`);
    console.log(`Health check: ${healthResponse.status}`);
    
    // Test authentication
    const authResponse = await fetch(`${airflowUrl}/api/v2/auth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    
    if (authResponse.ok) {
      console.log('✅ Authentication successful');
    } else {
      console.log('❌ Authentication failed');
    }
    
    // Test DAGs endpoint
    const dagsResponse = await fetch(`${airflowUrl}/api/v2/dags`);
    console.log(`DAGs endpoint: ${dagsResponse.status}`);
    
  } catch (error) {
    console.error('❌ Connection test failed:', error.message);
  }
}

testAirflowConnection();
```

---

## Database Setup

### SQLite (Default)
```javascript
// Automatic setup - no configuration needed
// Database file: ./database.db
```

### PostgreSQL
```bash
# .env configuration
DATABASE_URL=postgresql://username:password@localhost:5432/airflow_dag_generator
```

### MySQL
```bash
# .env configuration
DATABASE_URL=mysql://username:password@localhost:3306/airflow_dag_generator
```

---

## Testing & Verification

### 1. Pre-deployment Checklist

Create `deployment-checklist.md`:
```markdown
# Deployment Checklist

## Configuration
- [ ] .env file created and configured
- [ ] Airflow URL updated in routes.ts
- [ ] Directory paths updated in all components
- [ ] Authentication credentials set
- [ ] Environment variables validated

## Dependencies
- [ ] Node.js installed (18.0.0+)
- [ ] npm dependencies installed
- [ ] Build process successful
- [ ] No TypeScript errors

## Airflow Integration
- [ ] Airflow server accessible
- [ ] Authentication working
- [ ] API endpoints responding
- [ ] Directories accessible
- [ ] File permissions correct

## Application Testing
- [ ] Application starts without errors
- [ ] Dashboard loads successfully
- [ ] File upload works
- [ ] DAG generation works
- [ ] Reports section accessible
- [ ] Chatbot responds

## Production Readiness
- [ ] Environment set to production
- [ ] Logging configured
- [ ] Error handling tested
- [ ] Security settings applied
```

### 2. Test Scripts

Create `test-deployment.js`:
```javascript
// filepath: d:\Programming\Reactjs\InfoArchive_project\04_07\AirflowDagCrafter\test-deployment.js
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

async function runDeploymentTests() {
  console.log('🧪 Running Deployment Tests...\n');
  
  // Test 1: Configuration
  console.log('1. Testing Configuration...');
  require('./config-validator.js');
  
  // Test 2: File Structure
  console.log('\n2. Testing File Structure...');
  const requiredFiles = [
    'package.json',
    '.env',
    'server/routes.ts',
    'client/src/pages/dag-generator.tsx'
  ];
  
  requiredFiles.forEach(file => {
    if (fs.existsSync(file)) {
      console.log(`✅ ${file}: Found`);
    } else {
      console.log(`❌ ${file}: Missing`);
    }
  });
  
  // Test 3: Dependencies
  console.log('\n3. Testing Dependencies...');
  try {
    const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    console.log(`✅ Dependencies: ${Object.keys(packageJson.dependencies || {}).length} packages`);
  } catch (error) {
    console.log('❌ Dependencies: package.json error');
  }
  
  // Test 4: Airflow Connection
  console.log('\n4. Testing Airflow Connection...');
  await testAirflowConnection();
  
  console.log('\n✅ Deployment tests completed!');
}

runDeploymentTests();
```

---

## Troubleshooting

### Common Issues and Solutions

#### 1. Airflow Connection Failed
```bash
Error: ECONNREFUSED
```
**Solutions:**
- Verify Airflow is running: `docker ps` or `airflow webserver`
- Check URL and port in .env file
- Test connectivity: `curl http://localhost:8083/health`

#### 2. Authentication Failed
```bash
Error: HTTP 401: Unauthorized
```
**Solutions:**
- Verify username/password in .env
- Check Airflow user exists: `airflow users list`
- Create user if needed: `airflow users create --username admin --password admin123 --firstname Admin --lastname User --role Admin --email admin@example.com`

#### 3. Path Access Denied
```bash
Error: EACCES: permission denied
```
**Solutions:**
- Check directory permissions: `ls -la /path/to/directory`
- Create directories: `mkdir -p /path/to/directory`
- Set permissions: `chmod 755 /path/to/directory`

#### 4. File Upload Failed
```bash
Error: Failed to move file
```
**Solutions:**
- Verify upload directory exists and is writable
- Check disk space: `df -h`
- Verify file size limits in configuration

#### 5. DAG Not Appearing
```bash
DAG not found in Airflow
```
**Solutions:**
- Check DAGs directory path
- Verify DAG file syntax: `python dag_file.py`
- Refresh DAGs: Restart Airflow scheduler
- Check Airflow logs for errors

### Debug Commands

```bash
# Test configuration
npm run test-config

# Test Airflow connection
node test-airflow.js

# View application logs
tail -f logs/application.log

# Check Airflow logs
docker logs airflow-scheduler
docker logs airflow-webserver

# Test API endpoints
curl http://localhost:3000/api/test-airflow
curl http://localhost:8083/api/v2/dags
```

### Environment-Specific Configurations

#### Windows Development
```bash
AIRFLOW_URL=http://localhost:8083
AIRFLOW_DATA_DIR=C:/Docker/airflow3x2/data
AIRFLOW_DAGS_DIR=C:/Docker/airflow3x2/dags
```

#### Linux Production
```bash
AIRFLOW_URL=http://airflow-server:8080
AIRFLOW_DATA_DIR=/opt/airflow/data
AIRFLOW_DAGS_DIR=/opt/airflow/dags
```

#### Docker Deployment
```bash
AIRFLOW_URL=http://airflow-webserver:8080
AIRFLOW_DATA_DIR=/opt/airflow/data
AIRFLOW_DAGS_DIR=/opt/airflow/dags
```

---

## Support & Maintenance

### Regular Maintenance Tasks
- Update dependencies: `npm update`
- Check Airflow compatibility
- Backup configuration files
- Monitor logs for errors
- Test critical workflows monthly

### Version Compatibility Matrix

| Component | Version | Compatibility |
|-----------|---------|---------------|
| Node.js | 18.0.0+ | Required |
| Airflow | 3.x | Recommended |
| Airflow | 2.5.0+ | Supported |
| React | 18.x | Current |
| TypeScript | 5.x | Current |

### Contact Information
- Technical Support: [Your Support Email]
- Documentation: [Your Docs URL]
- Issue Tracking: [Your Issues URL]

---

*Last Updated: [Current Date]*  
*Version: 1.0*  
*Data Transformer Airflow DAG Generator - Deployment Guide*
