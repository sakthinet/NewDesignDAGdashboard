import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Minimize2, 
  Maximize2,
  X,
  Loader2,
  RefreshCw,
  Settings,
  Database,
  FileText,
  BarChart3,
  AlertCircle,
  Move
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useClientConfig } from "@/hooks/use-client-config";
import { BotIcon } from "@/components/ui/bot-icon";

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  metadata?: {
    dagCount?: number;
    runCount?: number;
    suggestions?: string[];
  };
}

interface ChatbotState {
  isOpen: boolean;
  isMinimized: boolean;
  isLoading: boolean;
  messages: Message[];
  currentInput: string;
  position: { x: number; y: number };
  isDragging: boolean;
}

interface DashboardContext {
  dags: any[];
  totalDags: number;
  runningDags: number;
  pausedDags: number;
  recentRuns: any[];
  connectionStatus: boolean;
  successfulRunsToday: number;
  failedRunsToday: number;
  avgDagRunDuration: number;
  systemHealth: {
    memory: number;
    cpu: number;
    activeWorkers: number;
  };
  tasksStatus: {
    completed: number;
    pending: number;
    failed: number;
    inProgress: number;
  };
  performanceMetrics: {
    totalRecords: number;
    processedRecords: number;
    successRate: number;
    avgProcessingTime: number;
  };
}

export function Chatbot() {
  const clientConfig = useClientConfig();
  const [state, setState] = useState<ChatbotState>({
    isOpen: false,
    isMinimized: false,
    isLoading: false,
    messages: [],
    currentInput: '',
    position: { x: 0, y: 0 }, // Will be set by useEffect
    isDragging: false
  });

  const [dashboardContext, setDashboardContext] = useState<DashboardContext>({
    dags: [],
    totalDags: 0,
    runningDags: 0,
    pausedDags: 0,
    recentRuns: [],
    connectionStatus: false,
    successfulRunsToday: 0,
    failedRunsToday: 0,
    avgDagRunDuration: 0,
    systemHealth: {
      memory: 0,
      cpu: 0,
      activeWorkers: 0
    },
    tasksStatus: {
      completed: 0,
      pending: 0,
      failed: 0,
      inProgress: 0
    },
    performanceMetrics: {
      totalRecords: 0,
      processedRecords: 0,
      successRate: 0,
      avgProcessingTime: 0
    }
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number } | null>(null);
  const { toast } = useToast();
  const airflowApi = useAirflowApi();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.messages]);

  // Focus input when chatbot opens
  useEffect(() => {
    if (state.isOpen && !state.isMinimized) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [state.isOpen, state.isMinimized]);

  // Load dashboard context
  useEffect(() => {
    loadDashboardContext();
  }, []);

  // Handle positioning and cleanup
  useEffect(() => {
    // Set initial position for chat box (bottom-right with better spacing)
    const setInitialPosition = () => {
      const chatWidth = window.innerWidth < 640 ? 320 : window.innerWidth < 1024 ? 400 : 450;
      const chatHeight = window.innerWidth < 640 ? 400 : window.innerWidth < 1024 ? 500 : 550;
      
      // Calculate safe bottom position accounting for page content
      const viewportHeight = window.innerHeight;
      const documentHeight = Math.max(
        document.body.scrollHeight,
        document.body.offsetHeight,
        document.documentElement.clientHeight,
        document.documentElement.scrollHeight,
        document.documentElement.offsetHeight
      );
      
      // Position from bottom of viewport with additional spacing for better UX
      const bottomSpacing = 100; // Increased spacing to avoid overlapping with page elements
      const rightSpacing = 24; // Increased right spacing for better visual balance
      
      setState(prev => {
        // If chat is open, keep current position but ensure it's within bounds
        if (prev.isOpen) {
          return {
            ...prev,
            position: {
              x: Math.max(rightSpacing, Math.min(window.innerWidth - chatWidth - rightSpacing, prev.position.x)),
              y: Math.max(24, Math.min(viewportHeight - chatHeight - bottomSpacing, prev.position.y))
            }
          };
        }
        // If chat is closed, set default bottom-right position with improved spacing
        return {
          ...prev,
          position: {
            x: Math.max(rightSpacing, window.innerWidth - chatWidth - rightSpacing),
            y: Math.max(24, viewportHeight - chatHeight - bottomSpacing)
          }
        };
      });
    };
    
    setInitialPosition();
    window.addEventListener('resize', setInitialPosition);
    
    // Cleanup event listeners
    return () => {
      window.removeEventListener('resize', setInitialPosition);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [state.isOpen]);

  const loadDashboardContext = async () => {
    try {
      console.log('🔄 Loading dashboard context...');
      const dags = await airflowApi.getDags(true); // Force refresh
      const connectionTest = await airflowApi.testConnection();
      
      console.log('📊 Airflow Data:', { dags: dags?.dags?.length, connected: connectionTest?.connected });
      
      if (dags?.dags) {
        const runningDags = dags.dags.filter((dag: any) => !dag.is_paused).length;
        const pausedDags = dags.dags.filter((dag: any) => dag.is_paused).length;
        const recentRuns = dags.dags.flatMap((dag: any) => dag.recent_runs || []).slice(0, 10);

        // Calculate enhanced metrics
        const successfulRuns = recentRuns.filter((run: any) => run.state === 'success').length;
        const failedRuns = recentRuns.filter((run: any) => run.state === 'failed').length;
        
        // Calculate average DAG run duration
        const completedRuns = recentRuns.filter((run: any) => 
          run.end_date && run.start_date && (run.state === 'success' || run.state === 'failed')
        );
        const avgDuration = completedRuns.length > 0 
          ? completedRuns.reduce((acc: number, run: any) => {
              const duration = new Date(run.end_date).getTime() - new Date(run.start_date).getTime();
              return acc + duration;
            }, 0) / completedRuns.length / 60000 // Convert to minutes
          : 0;

        // Load additional metrics from reports if available
        let performanceMetrics = {
          totalRecords: 1000,
          processedRecords: 950,
          successRate: 95.0,
          avgProcessingTime: 2.5
        };

        let tasksStatus = {
          completed: 450,
          pending: 125,
          failed: 75,
          inProgress: 200
        };

        let systemHealth = {
          memory: 256,
          cpu: 78.5,
          activeWorkers: runningDags || 1
        };

        try {
          // Try to load performance metrics from reports
          const metricsResponse = await fetch('/reports/sample_metrics_report.json');
          if (metricsResponse.ok) {
            const metrics = await metricsResponse.json();
            console.log('📈 Loaded performance metrics:', metrics);
            performanceMetrics = {
              totalRecords: metrics.total_records || 1000,
              processedRecords: metrics.processed_records || 950,
              successRate: metrics.success_rate || 95.0,
              avgProcessingTime: metrics.average_processing_time || 2.5
            };
            systemHealth = {
              memory: metrics.memory_usage_mb || 256,
              cpu: metrics.cpu_usage_percent || 78.5,
              activeWorkers: runningDags || 1
            };
          }

          // Try to load task status data
          const taskResponse = await fetch('/reports/task_status_chart.json');
          if (taskResponse.ok) {
            const taskData = await taskResponse.json();
            console.log('📋 Loaded task status:', taskData);
            const [completed, pending, failed, inProgress] = taskData.counts || [450, 125, 75, 200];
            tasksStatus = { completed, pending, failed, inProgress };
          }
        } catch (reportError) {
          console.log('⚠️ Could not load report data, using sample data:', reportError);
        }

        const newContext = {
          dags: dags.dags,
          totalDags: dags.dags.length,
          runningDags,
          pausedDags,
          recentRuns,
          connectionStatus: connectionTest?.connected || false,
          successfulRunsToday: successfulRuns,
          failedRunsToday: failedRuns,
          avgDagRunDuration: Math.round(avgDuration * 100) / 100, // Round to 2 decimal places
          systemHealth,
          tasksStatus,
          performanceMetrics
        };
        
        console.log('✅ New dashboard context:', newContext);
        setDashboardContext(newContext);
      } else {
        console.log('⚠️ No DAGs data received, using fallback context');
        // Set fallback context with sample data
        setDashboardContext(prev => ({
          ...prev,
          connectionStatus: connectionTest?.connected || false,
          performanceMetrics: {
            totalRecords: 1000,
            processedRecords: 950,
            successRate: 95.0,
            avgProcessingTime: 2.5
          },
          systemHealth: {
            memory: 256,
            cpu: 78.5,
            activeWorkers: 1
          },
          tasksStatus: {
            completed: 450,
            pending: 125,
            failed: 75,
            inProgress: 200
          }
        }));
      }
    } catch (error) {
      console.error('❌ Failed to load dashboard context:', error);
      // Set fallback context on error
      setDashboardContext(prev => ({
        ...prev,
        connectionStatus: false,
        performanceMetrics: {
          totalRecords: 1000,
          processedRecords: 950,
          successRate: 95.0,
          avgProcessingTime: 2.5
        },
        systemHealth: {
          memory: 256,
          cpu: 78.5,
          activeWorkers: 1
        },
        tasksStatus: {
          completed: 450,
          pending: 125,
          failed: 75,
          inProgress: 200
        }
      }));
    }
  };

  const generateSystemPrompt = (context: DashboardContext): string => {
    return `You are TCS ECM Airflow Assistant, an AI helper for the TCS ECM Airflow DAG Generator application.

CURRENT DASHBOARD STATUS:
- Total DAGs: ${context.totalDags}
- Running DAGs: ${context.runningDags}
- Paused DAGs: ${context.pausedDags}
- Airflow Connection: ${context.connectionStatus ? 'Connected' : 'Disconnected'}
- Recent Runs: ${context.recentRuns.length} recent executions
- Successful Runs Today: ${context.successfulRunsToday}
- Failed Runs Today: ${context.failedRunsToday}
- Average DAG Duration: ${context.avgDagRunDuration} minutes

SYSTEM PERFORMANCE:
- Memory Usage: ${context.systemHealth.memory} MB
- CPU Usage: ${context.systemHealth.cpu}%
- Active Workers: ${context.systemHealth.activeWorkers}
- Processing Success Rate: ${context.performanceMetrics.successRate}%
- Total Records Processed: ${context.performanceMetrics.processedRecords}/${context.performanceMetrics.totalRecords}

TASK STATUS OVERVIEW:
- Completed Tasks: ${context.tasksStatus.completed}
- Pending Tasks: ${context.tasksStatus.pending}
- Failed Tasks: ${context.tasksStatus.failed}
- In Progress Tasks: ${context.tasksStatus.inProgress}

DAG DETAILS:
${context.dags.map(dag => `- ${dag.dag_id}: ${dag.is_paused ? 'Paused' : 'Active'} (${dag.recent_runs?.length || 0} recent runs)`).join('\n')}

REPORTS & ANALYTICS AVAILABLE:
- Performance Metrics Dashboard
- Task Status Distribution Charts
- Processing Success Rate Analytics
- System Resource Utilization Reports
- DAG Execution Timeline Analytics
- Error Rate Trends and Analysis

You can help users with:
1. **Dashboard Analytics**: Detailed insights into DAG performance, success rates, and system metrics
2. **Performance Monitoring**: CPU, memory usage, processing times, and resource utilization
3. **Task Management**: Status tracking, failure analysis, and workflow optimization
4. **Business Intelligence**: Data processing metrics, success rates, and performance trends
5. **System Health**: Connection status, worker activity, and system diagnostics
6. **Airflow Operations**: DAG management, troubleshooting, and best practices
7. **Data Processing**: CSV to XML conversion, file upload guidance, and workflow automation
8. **Reports**: Generate and explain various analytics and performance reports

Keep responses concise, helpful, and data-driven. When users ask about performance or analytics, provide specific numbers from the current dashboard data above.`;
  };

  const callLLM = async (userMessage: string, context: DashboardContext): Promise<string> => {
    try {
      // Try Ollama first (local LLM)
      const ollamaResponse = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'llama3.2', // or 'mistral', 'codellama', etc.
          prompt: `${generateSystemPrompt(context)}\n\nUser: ${userMessage}\nAssistant:`,
          stream: false,
          options: {
            temperature: 0.7,
            max_tokens: 500
          }
        })
      });

      if (ollamaResponse.ok) {
        const data = await ollamaResponse.json();
        return data.response || 'I apologize, but I received an empty response.';
      }
    } catch (ollamaError) {
      console.log('Ollama not available, trying fallback...');
    }

    // Fallback to your backend LLM service
    try {
      const backendResponse = await fetch('/api/chatbot/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          context: context,
          systemPrompt: generateSystemPrompt(context)
        })
      });

      if (backendResponse.ok) {
        const data = await backendResponse.json();
        return data.response || 'I apologize, but I received an empty response.';
      }
    } catch (backendError) {
      console.log('Backend LLM not available...');
    }

    // Final fallback - rule-based responses
    return generateFallbackResponse(userMessage, context);
  };

  const generateFallbackResponse = (userMessage: string, context: DashboardContext): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('dag') && (message.includes('count') || message.includes('total'))) {
      return `You currently have ${context.totalDags} DAGs in total: ${context.runningDags} active and ${context.pausedDags} paused.`;
    }
    
    if (message.includes('cpu') || message.includes('memory') || message.includes('system')) {
      return `🖥️ **System Performance:**
• CPU Usage: ${context.systemHealth.cpu}%
• Memory Usage: ${context.systemHealth.memory} MB
• Active Workers: ${context.systemHealth.activeWorkers}
• Processing Success Rate: ${context.performanceMetrics.successRate}%
• Total Records Processed: ${context.performanceMetrics.processedRecords}/${context.performanceMetrics.totalRecords}
• Average Processing Time: ${context.performanceMetrics.avgProcessingTime}s

${context.systemHealth.cpu === 0 && context.systemHealth.memory === 0 ? 
'*Note: System metrics may show as 0 if Airflow is not currently processing data or if performance monitoring is not enabled.*' : ''}`;
    }
    
    if (message.includes('status') || message.includes('dashboard')) {
      return `📊 **Dashboard Status Overview:**
• Total DAGs: ${context.totalDags}
• Active: ${context.runningDags} | Paused: ${context.pausedDags}
• Connection: ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}
• Recent Runs: ${context.recentRuns.length}
• Success Rate: ${context.performanceMetrics.successRate}%
• System CPU: ${context.systemHealth.cpu}% | Memory: ${context.systemHealth.memory}MB

**Today's Performance:**
• Successful Runs: ${context.successfulRunsToday}
• Failed Runs: ${context.failedRunsToday}
• Avg Duration: ${context.avgDagRunDuration} min

${context.totalDags === 0 ? '*Note: No DAGs found. Please ensure Airflow is running and DAGs are deployed.*' : ''}`;
    }
    
    if (message.includes('performance') || message.includes('metrics')) {
      return `🚀 **Performance Metrics:**
• Processing Success Rate: ${context.performanceMetrics.successRate}%
• Records Processed: ${context.performanceMetrics.processedRecords}/${context.performanceMetrics.totalRecords}
• Average Processing Time: ${context.performanceMetrics.avgProcessingTime}s
• System CPU Usage: ${context.systemHealth.cpu}%
• Memory Usage: ${context.systemHealth.memory}MB
• Active Workers: ${context.systemHealth.activeWorkers}

${context.performanceMetrics.successRate === 0 ? 
'*Note: Performance metrics may show as 0 if no data processing has occurred recently or if report files are not available.*' : ''}`;
    }
    
    if (message.includes('task') && (message.includes('status') || message.includes('progress'))) {
      return `📋 **Task Status Distribution:**
• Completed: ${context.tasksStatus.completed}
• In Progress: ${context.tasksStatus.inProgress}
• Pending: ${context.tasksStatus.pending}
• Failed: ${context.tasksStatus.failed}
• Total Tasks: ${context.tasksStatus.completed + context.tasksStatus.inProgress + context.tasksStatus.pending + context.tasksStatus.failed}

${context.tasksStatus.completed === 0 && context.tasksStatus.inProgress === 0 ? 
'*Note: Task data may show as 0 if no tasks are currently running or if task reports are not available.*' : ''}`;
    }
    
    if (message.includes('help') || message.includes('what can you do')) {
      return `🤖 **I can help you with:**

**📊 Analytics & Reporting:**
• Dashboard performance insights
• Task status and progress tracking
• Success rate analysis and trends
• System resource utilization reports

**⚙️ System Operations:**
• DAG management and troubleshooting
• Airflow connection diagnostics
• Performance optimization tips
• Workflow automation guidance

**📈 Business Intelligence:**
• Processing metrics and KPIs
• Error analysis and recommendations
• Resource planning insights
• Data pipeline monitoring

**Current System Status:**
• DAGs: ${context.totalDags} (${context.runningDags} active)
• Connection: ${context.connectionStatus ? 'Online ✅' : 'Offline ❌'}
• Success Rate: ${context.performanceMetrics.successRate}%

Try asking: "Show me performance metrics" or "What's my system health status?"`;
    }
    
    if (message.includes('create') && message.includes('dag')) {
      return `🔧 **To create a new DAG:**
1. Go to Upload section
2. Upload your CSV file
3. Configure DAG settings
4. Generate and deploy

**Your current DAGs:** ${context.dags.length > 0 ? context.dags.map(d => d.dag_id).join(', ') : 'No DAGs found'}
**System Status:** ${context.connectionStatus ? 'Ready for deployment ✅' : 'Airflow disconnected ❌'}`;
    }
    
    if (message.includes('connection') || message.includes('airflow')) {
      return `🔗 **Airflow Connection Status:** ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}

${context.connectionStatus ? 
`**System is operational:**
• Active Workers: ${context.systemHealth.activeWorkers}
• CPU Usage: ${context.systemHealth.cpu}%
• Memory: ${context.systemHealth.memory}MB
• Total DAGs: ${context.totalDags}` :
`**Connection Issues:**
• Ensure Airflow is running at ${clientConfig.airflowUrl}
• Check network connectivity
• Verify Airflow service status
• Check if DAGs are properly deployed`}`;
    }

    if (message.includes('report') || message.includes('analytics') || message.includes('intelligence')) {
      return `📊 **Available Reports & Analytics:**

**📈 Performance Reports:**
• Success Rate: ${context.performanceMetrics.successRate}%
• Processing Time Analytics
• Resource Utilization Trends

**🎯 Task Analytics:**
• Status Distribution Charts
• Completion Rate Analysis
• Error Pattern Recognition

**⚡ System Health:**
• Real-time Performance Monitoring
• Resource Usage Dashboards
• Worker Activity Reports

**💡 Business Intelligence:**
• Processing KPIs and Metrics
• Workflow Efficiency Analysis
• Data Pipeline Performance

**Current Data:**
• DAGs: ${context.totalDags} total
• Tasks: ${context.tasksStatus.completed + context.tasksStatus.inProgress + context.tasksStatus.pending + context.tasksStatus.failed} tracked
• Success Rate: ${context.performanceMetrics.successRate}%

Ask me about specific metrics or request detailed analytics!`;
    }
    
    return `I understand you're asking about: "${userMessage}"

🎯 **I can provide insights on:**
• **Performance**: System metrics, success rates, processing times
• **Tasks**: Status tracking, progress monitoring, failure analysis  
• **Analytics**: Business intelligence, reports, trend analysis
• **Operations**: DAG management, system health, troubleshooting

**Current System:** ${context.totalDags} DAGs | ${context.connectionStatus ? 'Connected' : 'Offline'} | ${context.performanceMetrics.successRate}% Success Rate

${context.totalDags === 0 || !context.connectionStatus ? 
'*Note: Some metrics may show as 0 if Airflow is not connected or no data is available. Try refreshing the data or checking your Airflow connection.*' : ''}

Try asking more specific questions about your workflows or system performance!`;
  };

  const handleSendMessage = async () => {
    const userMessage = state.currentInput.trim();
    if (!userMessage) return;

    const userMsgId = Date.now().toString();
    const userMsg: Message = {
      id: userMsgId,
      type: 'user',
      content: userMessage,
      timestamp: new Date()
    };

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMsg],
      currentInput: '',
      isLoading: true
    }));

    try {
      // Refresh dashboard context for latest data
      await loadDashboardContext();
      
      const botResponse = await callLLM(userMessage, dashboardContext);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: botResponse,
        timestamp: new Date(),
        metadata: {
          dagCount: dashboardContext.totalDags,
          runCount: dashboardContext.recentRuns.length,
          suggestions: generateSuggestions(userMessage)
        }
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, botMsg],
        isLoading: false
      }));

    } catch (error) {
      console.error('Chat error:', error);
      
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: 'I apologize, but I encountered an error. Please try again or check your connection.',
        timestamp: new Date()
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, errorMsg],
        isLoading: false
      }));

      toast({
        title: "Chat Error",
        description: "Unable to process your message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const generateSuggestions = (userMessage: string): string[] => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('dag')) {
      return [
        "Show me DAG performance metrics",
        "What's my system health status?",
        "Analyze task failure patterns"
      ];
    }
    
    if (message.includes('upload') || message.includes('csv')) {
      return [
        "What CSV format is supported?",
        "Show processing success rates",
        "How to optimize file uploads?"
      ];
    }

    if (message.includes('report') || message.includes('analytics') || message.includes('intelligence')) {
      return [
        "Show performance dashboard",
        "Analyze processing metrics",
        "Display task status distribution"
      ];
    }

    if (message.includes('performance') || message.includes('metrics')) {
      return [
        "What's my CPU and memory usage?",
        "Show success rate trends",
        "Analyze processing efficiency"
      ];
    }

    if (message.includes('task') || message.includes('status')) {
      return [
        "Show task completion rates",
        "Analyze failed tasks",
        "Display workflow progress"
      ];
    }

    if (message.includes('dashboard') || message.includes('system')) {
      return [
        "Show comprehensive system status",
        "Display performance analytics",
        "Check connection health"
      ];
    }
    
    return [
      "What's my dashboard status?",
      "Show performance metrics",
      "Analyze system health",
      "Display task analytics"
    ];
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Drag functionality
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!cardRef.current) return;
    
    setState(prev => ({ ...prev, isDragging: true }));
    
    const rect = cardRef.current.getBoundingClientRect();
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: rect.left,
      initialY: rect.top
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    e.preventDefault();
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!dragRef.current || !state.isDragging) return;
    
    const deltaX = e.clientX - dragRef.current.startX;
    const deltaY = e.clientY - dragRef.current.startY;
    
    // Get chat box dimensions for better boundary calculations
    const chatWidth = window.innerWidth < 640 ? 320 : window.innerWidth < 1024 ? 400 : 450;
    const chatHeight = window.innerWidth < 640 ? 400 : window.innerWidth < 1024 ? 500 : 550;
    
    // Add improved spacing to prevent overlapping with page elements
    const bottomSpacing = 100; // Increased bottom spacing
    const rightSpacing = 24; // Increased right spacing
    const topSpacing = 24; // Added top spacing
    const leftSpacing = 24; // Added left spacing
    
    const newX = Math.max(leftSpacing, Math.min(window.innerWidth - chatWidth - rightSpacing, dragRef.current.initialX + deltaX));
    const newY = Math.max(topSpacing, Math.min(window.innerHeight - chatHeight - bottomSpacing, dragRef.current.initialY + deltaY));
    
    setState(prev => ({
      ...prev,
      position: { x: newX, y: newY }
    }));
  };

  const handleMouseUp = () => {
    setState(prev => ({ ...prev, isDragging: false }));
    dragRef.current = null;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const toggleChatbot = () => {
    setState(prev => ({ ...prev, isOpen: !prev.isOpen }));
    if (!state.isOpen && state.messages.length === 0) {
      // Add welcome message with current dashboard data
      const welcomeMsg: Message = {
        id: 'welcome',
        type: 'bot',
        content: `👋 Hello! I'm your **TCS ECM Airflow Assistant**. 

📊 **Current System Overview:**
• **${dashboardContext.totalDags} DAGs** (${dashboardContext.runningDags} active, ${dashboardContext.pausedDags} paused)
• **Success Rate:** ${dashboardContext.performanceMetrics.successRate}%
• **System Status:** ${dashboardContext.connectionStatus ? 'Connected ✅' : 'Offline ❌'}
• **CPU Usage:** ${dashboardContext.systemHealth.cpu}%
• **Memory:** ${dashboardContext.systemHealth.memory}MB

🚀 **I can help you with:**
• **Performance Analytics**: Real-time metrics, success rates, processing times
• **Task Management**: Status tracking, failure analysis, workflow optimization  
• **System Health**: Resource monitoring, connection diagnostics, worker activity
• **Business Intelligence**: Reports, trends, KPIs, and data insights
• **DAG Operations**: Creation, configuration, troubleshooting, and deployment
• **Data Processing**: CSV uploads, XML conversion, and pipeline guidance

**What would you like to explore?**`,
        timestamp: new Date(),
        metadata: {
          dagCount: dashboardContext.totalDags,
          suggestions: [
            "What's my CPU and memory usage?",
            "Show me performance dashboard",
            "Display task analytics",
            "Check system health status"
          ]
        }
      };
      
      setState(prev => ({ ...prev, messages: [welcomeMsg] }));
    }
  };

  const toggleMinimize = () => {
    setState(prev => ({ ...prev, isMinimized: !prev.isMinimized }));
  };

  const clearChat = () => {
    setState(prev => ({ ...prev, messages: [] }));
  };

  const refreshContext = async () => {
    try {
      console.log('🔄 Refreshing dashboard context...');
      await loadDashboardContext();
      
      // Debug log the current context
      console.log('📊 Current Dashboard Context:', {
        totalDags: dashboardContext.totalDags,
        connectionStatus: dashboardContext.connectionStatus,
        performanceMetrics: dashboardContext.performanceMetrics,
        systemHealth: dashboardContext.systemHealth,
        tasksStatus: dashboardContext.tasksStatus
      });
      
      toast({
        title: "Context Refreshed",
        description: `Dashboard data updated: ${dashboardContext.totalDags} DAGs, ${dashboardContext.performanceMetrics.successRate}% success rate`,
      });
    } catch (error) {
      console.error('❌ Failed to refresh context:', error);
      toast({
        title: "Refresh Failed",
        description: "Could not update dashboard data. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!state.isOpen) {
    return (
      <Button
        onClick={toggleChatbot}
        className="fixed bottom-24 right-6 z-40 h-12 w-12 sm:h-14 sm:w-14 rounded-full bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
        style={{
          bottom: '100px', // Improved positioning to avoid overlap with page elements
        }}
      >
        <BotIcon size={24} className="text-white" />
      </Button>
    );
  }

  return (
    <Card 
      ref={cardRef}
      className={`fixed z-40 shadow-2xl transition-all duration-300 select-none border-2 border-blue-100 ${
        state.isMinimized ? 'h-14 w-80 sm:w-96' : 'h-[500px] w-80 sm:h-[520px] sm:w-96 lg:h-[550px] lg:w-[450px]'
      } ${state.isDragging ? 'cursor-grabbing shadow-3xl' : 'hover:shadow-xl'}`}
      style={{
        top: `${state.position.y}px`,
        left: `${state.position.x}px`,
      }}
    >
      <CardHeader 
        className="flex flex-row items-center justify-between p-3 sm:p-4 pb-2 cursor-grab active:cursor-grabbing hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 rounded-t-lg transition-all duration-200 border-b border-blue-100"
        onMouseDown={handleMouseDown}
        title="Drag to move chat box"
      >
        <div className="flex items-center space-x-2 sm:space-x-3">
          <Move className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />
          <Bot className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600" />
          <CardTitle className="text-base sm:text-lg font-semibold text-gray-800">Buddy</CardTitle>
          {dashboardContext.connectionStatus && (
            <div className="w-2 h-2 sm:w-2.5 sm:h-2.5 bg-green-500 rounded-full animate-pulse"></div>
          )}
        </div>
        <div className="flex items-center space-x-1 sm:space-x-2">
          <Button variant="ghost" size="sm" onClick={refreshContext} className="h-8 w-8 sm:h-9 sm:w-9 p-0 hover:bg-blue-100">
            <RefreshCw className="h-4 w-4 sm:h-4 sm:w-4 text-blue-600" />
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleMinimize} className="h-8 w-8 sm:h-9 sm:w-9 p-0 hover:bg-blue-100">
            {state.isMinimized ? <Maximize2 className="h-4 w-4 sm:h-4 sm:w-4 text-blue-600" /> : <Minimize2 className="h-4 w-4 sm:h-4 sm:w-4 text-blue-600" />}
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleChatbot} className="h-8 w-8 sm:h-9 sm:w-9 p-0 hover:bg-red-100">
            <X className="h-4 w-4 sm:h-4 sm:w-4 text-red-500" />
          </Button>
        </div>
      </CardHeader>

      {!state.isMinimized && (
        <CardContent className="flex flex-col h-full p-3 sm:p-4 pt-0 pb-3 overflow-hidden">
          {/* Enhanced Dashboard Status Bar */}
          <div className="flex items-center justify-between text-xs bg-gradient-to-r from-blue-50 to-indigo-50 p-2 sm:p-3 rounded-lg mb-3 border border-blue-100 flex-shrink-0">
            <div className="flex items-center space-x-3 sm:space-x-4">
              <span className="flex items-center text-blue-700">
                <Database className="h-3 w-3 sm:h-3.5 sm:w-3.5 mr-1" />
                <span className="font-medium">{dashboardContext.totalDags}</span>
              </span>
              <span className="flex items-center text-green-700">
                <BarChart3 className="h-3 w-3 sm:h-3.5 sm:w-3.5 mr-1" />
                <span className="font-medium">{dashboardContext.runningDags}</span>
              </span>
              <span className="flex items-center text-orange-600">
                <BarChart3 className="h-3 w-3 sm:h-3.5 sm:w-3.5 mr-1" />
                <span className="font-medium">{dashboardContext.performanceMetrics.successRate}%</span>
              </span>
              {!dashboardContext.connectionStatus && (
                <span className="flex items-center text-red-600">
                  <AlertCircle className="h-3 w-3 sm:h-3.5 sm:w-3.5 mr-1" />
                  <span className="text-xs hidden sm:inline font-medium">Offline</span>
                </span>
              )}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 mb-3 min-h-0 scrollbar-thin scrollbar-thumb-blue-200 scrollbar-track-blue-50">
            {state.messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3 sm:p-3.5 rounded-xl transition-all duration-200 ${
                    message.type === 'user'
                      ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white ml-2 rounded-br-md shadow-md'
                      : 'bg-gradient-to-br from-gray-50 to-gray-100 text-gray-900 mr-2 rounded-bl-md shadow-sm border border-gray-200'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.type === 'bot' && <Bot className="h-4 w-4 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0 text-blue-600" />}
                    {message.type === 'user' && <User className="h-4 w-4 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0 text-blue-100" />}
                    <div className="flex-1">
                      <p className="text-sm sm:text-sm whitespace-pre-wrap leading-relaxed font-medium">{message.content}</p>
                      {message.metadata?.suggestions && (
                        <div className="mt-2.5 sm:mt-3 space-y-1.5">
                          {message.metadata.suggestions.slice(0, 2).map((suggestion, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className="text-xs h-6 sm:h-7 w-full text-left justify-start hover:bg-blue-50 border-blue-200 text-blue-700"
                              onClick={() => setState(prev => ({ ...prev, currentInput: suggestion }))}
                            >
                              {suggestion}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <p className="text-xs opacity-70 mt-1.5 font-normal">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            
            {state.isLoading && (
              <div className="flex justify-start">
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 text-gray-900 p-3 sm:p-3.5 rounded-xl mr-2 border border-gray-200">
                  <div className="flex items-center space-x-2">
                    <Bot className="h-4 w-4 sm:h-4 sm:w-4 text-blue-600" />
                    <Loader2 className="h-4 w-4 sm:h-4 sm:w-4 animate-spin text-blue-600" />
                    <span className="text-sm font-medium text-blue-700">Analyzing data...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Enhanced Input Section */}
          <div className="space-y-2 flex-shrink-0">
            <div className="flex space-x-2">
              <Input
                ref={inputRef}
                value={state.currentInput}
                onChange={(e) => setState(prev => ({ ...prev, currentInput: e.target.value }))}
                onKeyPress={handleKeyPress}
                placeholder="Ask about performance, analytics, DAGs..."
                disabled={state.isLoading}
                className="flex-1 text-sm h-9 sm:h-10 border-blue-200 focus:border-blue-400 focus:ring-blue-300"
              />
              <Button 
                onClick={handleSendMessage} 
                disabled={state.isLoading || !state.currentInput.trim()}
                size="sm"
                className="h-9 w-9 sm:h-10 sm:w-10 p-0 bg-blue-600 hover:bg-blue-700 shadow-md flex-shrink-0"
              >
                <Send className="h-4 w-4 text-white" />
              </Button>
            </div>

            {/* Quick Actions */}
            <div className="flex justify-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={clearChat}
                className="text-xs h-7 px-3 hover:bg-blue-50 text-blue-600"
              >
                Clear Chat
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={refreshContext}
                className="text-xs h-7 px-3 hover:bg-green-50 text-green-600"
              >
                Refresh Data
              </Button>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
