import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  AlertCircle,
  Lock,
  Upload,
  Settings,
  Code,
  Eye,
  ArrowRight,
  Info
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Import your existing components
import { FileUpload } from "./file-upload"; // Your existing file upload component
import { ScriptGenerator } from "./script-generator"; // Your existing script generator
import { XmlViewer } from "./xml-viewer"; // Your existing XML viewer

interface UploadedFile {
  fileName: string;
  fileSize: number;
  headers: string[];
  previewRows: string[][];
}

interface DagConfig {
  dagId: string;
  inputDirectory: string;
  outputDirectory: string;
  csvFileName: string;
  description: string;
  scheduleInterval: string;
  dagsDirectory: string;
  chunkSize: number;
}

type Step = 'upload' | 'configure' | 'generate' | 'preview';

interface StepInfo {
  id: Step;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  requiredSteps: Step[];
}

const STEPS: StepInfo[] = [
  {
    id: 'upload',
    title: 'Upload CSV',
    description: 'Upload your CSV file to process',
    icon: Upload,
    requiredSteps: []
  },
  {
    id: 'configure',
    title: 'Configure DAG',
    description: 'Set up DAG parameters and scheduling',
    icon: Settings,
    requiredSteps: ['upload']
  },
  {
    id: 'generate',
    title: 'Generate Script',
    description: 'Create and deploy the DAG script',
    icon: Code,
    requiredSteps: ['upload', 'configure']
  },
  {
    id: 'preview',
    title: 'Preview Output',
    description: 'View the generated XML structure',
    icon: Eye,
    requiredSteps: ['upload', 'configure', 'generate']
  }
];

export function DagGeneratorManager() {
  const [currentStep, setCurrentStep] = useState<Step>('upload');
  const [completedSteps, setCompletedSteps] = useState<Step[]>([]);
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null);
  const [dagConfig, setDagConfig] = useState<DagConfig | null>(null);
  const [generatedScript, setGeneratedScript] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);

  const { toast } = useToast();

  // Check if a step can be accessed
  const canAccessStep = (stepId: Step): boolean => {
    const step = STEPS.find(s => s.id === stepId);
    if (!step) return false;
    
    return step.requiredSteps.every(requiredStep => 
      completedSteps.includes(requiredStep)
    );
  };

  // Mark a step as completed
  const completeStep = (stepId: Step) => {
    if (!completedSteps.includes(stepId)) {
      setCompletedSteps(prev => [...prev, stepId]);
    }
  };

  // Navigate to a specific step (with validation)
  const navigateToStep = (stepId: Step) => {
    if (!canAccessStep(stepId)) {
      const step = STEPS.find(s => s.id === stepId);
      const missingSteps = step?.requiredSteps.filter(req => !completedSteps.includes(req)) || [];
      
      toast({
        title: "Cannot access this step",
        description: `Please complete the following steps first: ${missingSteps.join(', ')}`,
        variant: "destructive",
      });
      return;
    }
    
    setCurrentStep(stepId);
  };

  // Handle file upload completion
  const handleFileUpload = (file: UploadedFile) => {
    setUploadedFile(file);
    completeStep('upload');
    
    toast({
      title: "File uploaded successfully",
      description: `${file.fileName} is ready for processing`,
    });
    
    // Auto-advance to configure step
    setCurrentStep('configure');
  };

  // Handle DAG configuration completion
  const handleDagConfiguration = async (config: DagConfig) => {
    setDagConfig(config);
    setIsGenerating(true);
    
    try {
      // Generate the DAG script
      const response = await fetch('/api/generate-dag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      
      if (result.success) {
        setGeneratedScript(result.dagScript);
        completeStep('configure');
        
        toast({
          title: "DAG configured successfully",
          description: "Script generated and ready for deployment",
        });
        
        // Auto-advance to generate step
        setCurrentStep('generate');
      } else {
        throw new Error(result.message || 'Failed to generate DAG');
      }
    } catch (error) {
      console.error('DAG generation failed:', error);
      toast({
        title: "Configuration failed",
        description: error instanceof Error ? error.message : "Failed to generate DAG script",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Handle script generation completion
  const handleScriptGeneration = () => {
    completeStep('generate');
    
    toast({
      title: "DAG script deployed",
      description: "Your DAG is now available in Airflow",
    });
  };

  // Go to dashboard
  const handleViewDashboard = () => {
    // Navigate to your dashboard route
    window.location.href = '/dashboard';
  };

  // Render step indicator
  const renderStepIndicator = () => (
    <div className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">TCS ECM Pipeline Builder Suite</h1>
          
          <div className="flex items-center space-x-4">
            {STEPS.map((step, index) => {
              const isCompleted = completedSteps.includes(step.id);
              const isCurrent = currentStep === step.id;
              const canAccess = canAccessStep(step.id);
              const IconComponent = step.icon;
              
              return (
                <div key={step.id} className="flex items-center">
                  <button
                    onClick={() => navigateToStep(step.id)}
                    disabled={!canAccess && !isCompleted}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                      isCurrent 
                        ? 'bg-blue-100 text-blue-700 border border-blue-200' 
                        : isCompleted
                        ? 'bg-cyan-100 text-cyan-700 hover:bg-cyan-200'
                        : canAccess
                        ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        : 'bg-gray-50 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      isCompleted 
                        ? 'bg-cyan-600 text-white' 
                        : isCurrent
                        ? 'bg-blue-600 text-white'
                        : canAccess
                        ? 'bg-gray-300 text-gray-600'
                        : 'bg-gray-200 text-gray-400'
                    }`}>
                      {isCompleted ? (
                        <CheckCircle className="w-4 h-4" />
                      ) : canAccess ? (
                        <IconComponent className="w-4 h-4" />
                      ) : (
                        <Lock className="w-4 h-4" />
                      )}
                    </div>
                    <div className="text-left">
                      <div className="text-sm font-medium">{step.title}</div>
                      <div className="text-xs opacity-75">{step.description}</div>
                    </div>
                  </button>
                  
                  {index < STEPS.length - 1 && (
                    <ArrowRight className="mx-2 h-4 w-4 text-gray-400" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );

  // Render current step content
  const renderStepContent = () => {
    switch (currentStep) {
      case 'upload':
        return (
          <FileUpload
            onFileUploaded={handleFileUpload}
            onNext={() => setCurrentStep('configure')}
            uploadedFile={uploadedFile}
          />
        );
        
      case 'configure':
        return null;
        
      case 'generate':
        return (
          <ScriptGenerator
            config={dagConfig!}
            generatedScript={generatedScript}
            onNext={() => navigateToStep('preview')}
            onPrev={() => navigateToStep('configure')}
            onViewDashboard={handleViewDashboard}
            uploadedFile={uploadedFile}
          />
        );
        
      case 'preview':
        return (
          <XmlViewer
            config={dagConfig!}
            onPrev={() => navigateToStep('generate')}
            onStartOver={handleViewDashboard}
            uploadedFile={uploadedFile}
          />
        );
        
      default:
        return <div>Unknown step</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {renderStepIndicator()}
      
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Step validation warning */}
        {!canAccessStep(currentStep) && currentStep !== 'upload' && (
          <Alert className="mb-6 border-orange-200 bg-orange-50">
            <AlertCircle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <strong>Step access restricted:</strong> Complete the previous steps to unlock this section.
              <div className="mt-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => navigateToStep('upload')}
                  className="text-orange-700 border-orange-300 hover:bg-orange-100"
                >
                  Go to Upload Step
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}
        
        {/* Loading state for DAG generation */}
        {isGenerating && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>Generating DAG script...</strong> Please wait while we create your Airflow DAG.
            </AlertDescription>
          </Alert>
        )}
        
        {/* Step content */}
        <div className={`transition-opacity duration-300 ${
          isGenerating ? 'opacity-50 pointer-events-none' : 'opacity-100'
        }`}>
          {renderStepContent()}
        </div>
        
        {/* Progress summary */}
        <div className="mt-8 p-4 bg-white rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Progress: {completedSteps.length} of {STEPS.length} steps completed
              </div>
              <div className="flex space-x-1">
                {STEPS.map((step) => (
                  <div
                    key={step.id}
                    className={`w-2 h-2 rounded-full ${
                      completedSteps.includes(step.id) 
                        ? 'bg-cyan-500' 
                        : currentStep === step.id
                        ? 'bg-blue-500'
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
            </div>
            
            {completedSteps.length === STEPS.length && (
              <Badge className="bg-cyan-600">
                <CheckCircle className="w-3 h-3 mr-1" />
                All steps completed
              </Badge>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}