import { useState, useEffect } from "react";
import { AlertCircle, Server, Maximize2, RefreshCw, Network, HardDrive } from "lucide-react";

// Inject CSS for buttons to ensure they're always visible
const injectButtonStyles = () => {
  const styleId = 'airflow-buttons-style';
  if (!document.getElementById(styleId)) {
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
      .airflow-refresh-btn {
        padding: 0.5rem 0.75rem !important;
        background-color: #3b82f6 !important;
        color: #ffffff !important;
        border: 2px solid #3b82f6 !important;
        border-radius: 6px !important;
        cursor: pointer !important;
        transition: all 0.2s ease-in-out !important;
        display: flex !important;
        align-items: center !important;
        gap: 0.5rem !important;
        font-size: 0.875rem !important;
        font-weight: 600 !important;
        min-width: auto !important;
        white-space: nowrap !important;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3) !important;
        z-index: 1000 !important;
        position: relative !important;
        font-family: inherit !important;
        line-height: 1.5 !important;
        opacity: 1 !important;
        visibility: visible !important;
      }
      
      .airflow-refresh-btn:hover {
        background-color: #2563eb !important;
        border-color: #2563eb !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4) !important;
      }
      
      .airflow-external-btn {
        padding: 0.5rem 0.75rem !important;
        background-color: #10b981 !important;
        color: #ffffff !important;
        border: 2px solid #10b981 !important;
        border-radius: 6px !important;
        cursor: pointer !important;
        transition: all 0.2s ease-in-out !important;
        display: flex !important;
        align-items: center !important;
        gap: 0.5rem !important;
        font-size: 0.875rem !important;
        font-weight: 600 !important;
        min-width: auto !important;
        white-space: nowrap !important;
        box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3) !important;
        z-index: 1000 !important;
        position: relative !important;
        font-family: inherit !important;
        line-height: 1.5 !important;
        opacity: 1 !important;
        visibility: visible !important;
      }
      
      .airflow-external-btn:hover {
        background-color: #059669 !important;
        border-color: #059669 !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4) !important;
      }
      
      .airflow-button-container {
        display: flex !important;
        gap: 0.75rem !important;
        align-items: center !important;
        flex-shrink: 0 !important;
        z-index: 1000 !important;
        position: relative !important;
        opacity: 1 !important;
        visibility: visible !important;
      }
    `;
    document.head.appendChild(style);
  }
};

// CSS for the Airflow integration
const airflowIframeStyles = {
  container: {
    display: "flex",
    flexDirection: "column" as const,
    height: "calc(100vh - 120px)", // Full viewport height minus navbar/padding
    width: "100%",
    backgroundColor: "var(--background)",
    borderRadius: "8px",
    overflow: "hidden",
    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)"
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0.75rem 1.5rem",
    borderBottom: "1px solid var(--border)",
    backgroundColor: "var(--card)",
    minHeight: "60px",
    position: "sticky" as const,
    top: 0,
    zIndex: 10,
    gap: "1rem",
    flexShrink: 0
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 700,
    color: "var(--foreground)",
    display: "flex",
    alignItems: "center",
    gap: "0.75rem",
    whiteSpace: "nowrap" as const,
    overflow: "hidden",
    textOverflow: "ellipsis",
    minWidth: 0,
    flexShrink: 1
  },
  statusContainer: {
    display: "flex",
    alignItems: "center",
    gap: "0.75rem",
    padding: "0.5rem 1rem",
    borderRadius: "6px",
    backgroundColor: "var(--muted)"
  },
  statusIndicator: (isOnline: boolean) => ({
    width: "12px",
    height: "12px",
    borderRadius: "50%",
    backgroundColor: isOnline ? "#22c55e" : "#ef4444",
    boxShadow: `0 0 0 2px ${isOnline ? "#22c55e20" : "#ef444420"}`
  }),
  statusText: (isOnline: boolean) => ({
    fontSize: "0.875rem",
    fontWeight: 600,
    color: isOnline ? "#22c55e" : "#ef4444"
  }),
  iframeContainer: {
    flex: 1,
    position: "relative" as const,
    overflow: "hidden",
    backgroundColor: "#ffffff"
  },
  iframe: {
    width: "100%",
    height: "100%",
    border: "none",
    borderRadius: "0 0 8px 8px",
    backgroundColor: "#ffffff"
  },
  errorContainer: {
    display: "flex",
    flexDirection: "column" as const,
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
    padding: "3rem",
    backgroundColor: "var(--background)",
    color: "var(--foreground)"
  },
  errorIcon: {
    color: "#ef4444",
    width: "64px",
    height: "64px",
    marginBottom: "1.5rem"
  },
  errorMessage: {
    fontSize: "1.25rem",
    fontWeight: 600,
    marginBottom: "0.75rem",
    textAlign: "center" as const
  },
  errorDetails: {
    fontSize: "0.875rem",
    color: "var(--muted-foreground)",
    textAlign: "center" as const,
    maxWidth: "600px",
    lineHeight: 1.6
  },
  retryButton: {
    marginTop: "2rem",
    padding: "0.75rem 1.5rem",
    backgroundColor: "var(--primary)",
    color: "var(--primary-foreground)",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: 600,
    fontSize: "0.875rem",
    transition: "all 0.2s ease-in-out",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)"
  },
  fullscreenButton: {
    padding: "0.5rem 0.75rem",
    backgroundColor: "#f8fafc",
    color: "#475569",
    border: "1px solid #e2e8f0",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "all 0.2s ease-in-out",
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    fontSize: "0.875rem",
    fontWeight: 500,
    minWidth: "auto",
    whiteSpace: "nowrap" as const,
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)"
  },
  refreshButton: {
    padding: "0.5rem 0.75rem",
    backgroundColor: "#3b82f6",
    color: "#ffffff",
    border: "2px solid #3b82f6",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "all 0.2s ease-in-out",
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    fontSize: "0.875rem",
    fontWeight: 600,
    minWidth: "auto",
    whiteSpace: "nowrap" as const,
    boxShadow: "0 2px 8px rgba(59, 130, 246, 0.3)",
    zIndex: 1000,
    position: "relative" as const,
    opacity: 1,
    visibility: "visible" as const
  },
  externalButton: {
    padding: "0.5rem 0.75rem",
    backgroundColor: "#10b981",
    color: "#ffffff",
    border: "2px solid #10b981",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "all 0.2s ease-in-out",
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    fontSize: "0.875rem",
    fontWeight: 600,
    minWidth: "auto",
    whiteSpace: "nowrap" as const,
    boxShadow: "0 2px 8px rgba(16, 185, 129, 0.3)",
    zIndex: 1000,
    position: "relative" as const,
    opacity: 1,
    visibility: "visible" as const
  },
  buttonContainer: {
    display: "flex",
    gap: "0.75rem",
    alignItems: "center",
    flexShrink: 0,
    zIndex: 1000,
    position: "relative" as const
  },
  buttonHover: {
    backgroundColor: "#f1f5f9",
    borderColor: "#cbd5e1",
    transform: "translateY(-1px)",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)"
  }
};

interface AirflowIntegrationProps {
  airflowUrl?: string;
}

type ViewMode = 'iframe' | 'proxy' | 'external' | 'api';

export const AirflowIntegration = ({ 
  airflowUrl = "http://localhost:8083" 
}: AirflowIntegrationProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAirflowOnline, setIsAirflowOnline] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deploymentMode, setDeploymentMode] = useState<'local' | 'network' | 'unknown'>('unknown');
  const [configInfo, setConfigInfo] = useState<{mode: string, url: string} | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('iframe');
  const [csrfError, setCsrfError] = useState(false);
  const [airflowData, setAirflowData] = useState<any>(null);

  // Determine deployment mode based on URL
  const determineDeploymentMode = (url: string): 'local' | 'network' | 'unknown' => {
    if (url.includes('localhost') || url.includes('127.0.0.1')) {
      return 'local';
    } else if (url.includes('10.73.88.101') || url.match(/^\d+\.\d+\.\d+\.\d+/)) {
      return 'network';
    }
    return 'unknown';
  };

  // Fetch deployment configuration from API
  const fetchDeploymentConfig = async () => {
    try {
      const response = await fetch('/api/config/deployment');
      if (response.ok) {
        const config = await response.json();
        setConfigInfo({
          mode: config.deploymentMode || 'unknown',
          url: config.connectionUrl || airflowUrl
        });
        setDeploymentMode(config.deploymentMode || determineDeploymentMode(airflowUrl));
        
        // Auto-select view mode based on deployment
        if (config.deploymentMode === 'network') {
          setViewMode('proxy'); // Use proxy for network mode by default
        }
      }
    } catch (err) {
      console.warn('Could not fetch deployment config, using URL-based detection');
      setDeploymentMode(determineDeploymentMode(airflowUrl));
    }
  };

  // Fetch Airflow data via API proxy
  const fetchAirflowData = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/airflow/proxy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          url: airflowUrl,
          endpoint: '/health' // Start with health check
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        setAirflowData(data);
        setIsAirflowOnline(true);
        setError(null);
        setCsrfError(false);
      } else {
        throw new Error(`API proxy failed: ${response.status}`);
      }
    } catch (err) {
      console.error("Error fetching Airflow data:", err);
      setError("Unable to connect via proxy. Try external view.");
      setIsAirflowOnline(false);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle iframe load errors (CSRF detection)
  const handleIframeError = () => {
    setCsrfError(true);
    setError("Airflow is blocking iframe access due to CSRF protection. Use external view or proxy mode.");
    setIsAirflowOnline(false);
    
    // Auto-switch to proxy mode if iframe fails
    if (deploymentMode === 'network') {
      setViewMode('proxy');
    }
  };

  useEffect(() => {
    fetchDeploymentConfig();
  }, [airflowUrl]);

  useEffect(() => {
    // Inject CSS styles for buttons
    injectButtonStyles();
    
    const checkAirflowAvailability = async () => {
      if (viewMode === 'proxy' || viewMode === 'api') {
        // Use API proxy instead of direct connection
        await fetchAirflowData();
        return;
      }
      
      // For iframe and external modes, do basic connectivity check
      try {
        setIsLoading(true);
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);

        const response = await fetch(airflowUrl, { 
          method: 'HEAD',
          mode: 'no-cors',
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        setIsAirflowOnline(true);
        setError(null);
      } catch (err) {
        console.error("Error checking Airflow availability:", err);
        setIsAirflowOnline(false);
        setError("Unable to connect to Airflow server. Please ensure Airflow is running.");
        
        // If network mode fails with iframe, suggest proxy
        if (deploymentMode === 'network' && viewMode === 'iframe') {
          setError("Connection failed. Network Airflow may have CSRF protection. Try Proxy mode.");
        }
      } finally {
        setIsLoading(false);
      }
    };

    checkAirflowAvailability();
    
    // Set up periodic checking every 30 seconds
    const interval = setInterval(checkAirflowAvailability, 30000);
    
    return () => clearInterval(interval);
  }, [airflowUrl, viewMode, deploymentMode]);

  const handleRetry = () => {
    setError(null);
    setIsLoading(true);
    // This will trigger the useEffect to run again
    setTimeout(() => {
      window.location.reload();
    }, 500);
  };

  const handleIframeLoad = () => {
    setIsLoading(false);
    setIsAirflowOnline(true);
  };

  const handleFullscreen = () => {
    window.open(airflowUrl, '_blank', 'width=1200,height=800,scrollbars=yes,resizable=yes');
  };

  const handleRefresh = () => {
    if (viewMode === 'proxy' || viewMode === 'api') {
      fetchAirflowData();
    } else {
      const iframe = document.querySelector('.airflow-iframe') as HTMLIFrameElement;
      if (iframe) {
        iframe.src = iframe.src;
      }
    }
  };

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    setError(null);
    setCsrfError(false);
    setIsLoading(true);
  };

  const handleButtonHover = (event: React.MouseEvent<HTMLButtonElement>, isHover: boolean) => {
    const button = event.currentTarget;
    if (isHover) {
      Object.assign(button.style, {
        backgroundColor: "#f1f5f9",
        borderColor: "#cbd5e1",
        transform: "translateY(-1px)",
        boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)"
      });
    } else {
      Object.assign(button.style, airflowIframeStyles.fullscreenButton);
    }
  };

  return (
    <div style={airflowIframeStyles.container} className="airflow-console">
      <div style={airflowIframeStyles.header}>
        <div style={airflowIframeStyles.title}>
          <Server size={24} />
          Apache Airflow Console
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "1rem", flexShrink: 0 }}>
          <div style={airflowIframeStyles.statusContainer}>
            <div style={airflowIframeStyles.statusIndicator(isAirflowOnline)} />
            <span style={airflowIframeStyles.statusText(isAirflowOnline)}>
              {isLoading ? "Connecting..." : isAirflowOnline ? "Connected" : "Disconnected"}
            </span>
          </div>
          <div className="airflow-button-container" style={airflowIframeStyles.buttonContainer}>
            <div style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              padding: "0.25rem 0.75rem",
              borderRadius: "4px",
              backgroundColor: deploymentMode === 'network' ? "#3b82f620" : "#f59e0b20",
              border: `1px solid ${deploymentMode === 'network' ? "#3b82f6" : "#f59e0b"}`,
              fontSize: "0.75rem",
              fontWeight: 500,
              color: deploymentMode === 'network' ? "#3b82f6" : "#f59e0b"
            }}>
              {deploymentMode === 'local' && <><HardDrive size={12} /> Local Docker</>}
              {deploymentMode === 'network' && <><Network size={12} /> Network Server</>}
              {deploymentMode === 'unknown' && <><Server size={12} /> Remote</>}
            </div>
            
            {/* View Mode Selector */}
            <select 
              value={viewMode}
              onChange={(e) => handleViewModeChange(e.target.value as ViewMode)}
              style={{
                padding: "0.25rem 0.5rem",
                borderRadius: "4px",
                border: "1px solid #d1d5db",
                fontSize: "0.75rem",
                backgroundColor: "#ffffff",
                color: "#374151"
              }}
            >
              <option value="iframe">Iframe</option>
              <option value="proxy">Proxy</option>
              <option value="external">External</option>
              <option value="api">API View</option>
            </select>
            
            {csrfError && (
              <div style={{
                padding: "0.25rem 0.5rem",
                backgroundColor: "#fef3c7",
                border: "1px solid #f59e0b",
                borderRadius: "4px",
                fontSize: "0.75rem",
                color: "#92400e"
              }}>
                CSRF Blocked
              </div>
            )}
            
            <button 
              className="airflow-refresh-btn"
              style={airflowIframeStyles.refreshButton}
              onClick={handleRefresh}
              title="Refresh Airflow"
            >
              <RefreshCw size={16} />
              Refresh
            </button>
            <button 
              className="airflow-external-btn"
              style={airflowIframeStyles.externalButton}
              onClick={handleFullscreen}
              title="Open in new window"
            >
              <Maximize2 size={16} />
              External
            </button>
          </div>
        </div>
      </div>
      
      <div style={airflowIframeStyles.iframeContainer}>
        {error ? (
          <div style={airflowIframeStyles.errorContainer}>
            <AlertCircle style={airflowIframeStyles.errorIcon} />
            <h3 style={airflowIframeStyles.errorMessage}>
              {csrfError ? "CSRF Protection Detected" : "Unable to connect to Apache Airflow"}
            </h3>
            <p style={airflowIframeStyles.errorDetails}>
              {csrfError ? (
                <>
                  Airflow server at <strong>{airflowUrl}</strong> is blocking iframe access due to CSRF protection.
                  <br /><br />
                  <strong>Recommended Solutions:</strong>
                  <br />• Switch to <strong>Proxy mode</strong> to bypass CSRF restrictions
                  <br />• Use <strong>External mode</strong> to open in a new window
                  <br />• Try <strong>API View</strong> for basic data access
                </>
              ) : (
                <>
                  The Airflow server at <strong>{airflowUrl}</strong> is not responding. 
                  <br />
                  <strong>Deployment Mode:</strong> {deploymentMode.charAt(0).toUpperCase() + deploymentMode.slice(1)}
                  <br />
                  Please ensure that Airflow is running and accessible at this URL.
                  {deploymentMode === 'local' && (
                    <>
                      <br /><br />
                      <strong>Local Setup:</strong> Make sure Docker containers are running and port 8083 is accessible.
                    </>
                  )}
                  {deploymentMode === 'network' && (
                    <>
                      <br /><br />
                      <strong>Network Setup:</strong> Verify network connectivity and that the Airflow server is running on the network.
                      <br />Try switching to <strong>Proxy mode</strong> if you're experiencing CSRF issues.
                    </>
                  )}
                </>
              )}
            </p>
            <div style={{ display: "flex", gap: "1rem", marginTop: "2rem" }}>
              <button 
                style={airflowIframeStyles.retryButton}
                onClick={handleRetry}
              >
                <RefreshCw size={16} style={{ marginRight: "0.5rem" }} />
                Retry Connection
              </button>
              {csrfError && (
                <button 
                  style={{...airflowIframeStyles.retryButton, backgroundColor: "#10b981"}}
                  onClick={() => handleViewModeChange('proxy')}
                >
                  Switch to Proxy Mode
                </button>
              )}
            </div>
          </div>
        ) : (
          <>
            {isLoading && (
              <div style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(255, 255, 255, 0.9)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                zIndex: 10
              }}>
                <div style={{ textAlign: "center" }}>
                  <RefreshCw size={32} style={{ animation: "spin 1s linear infinite", color: "#3b82f6", margin: "0 auto" }} />
                  <p style={{ marginTop: "1rem", color: "#6b7280", fontSize: "0.875rem" }}>
                    Loading Airflow Console... ({viewMode} mode)
                  </p>
                </div>
              </div>
            )}
            
            {/* Render content based on view mode */}
            {viewMode === 'iframe' && (
              <iframe
                src={airflowUrl}
                style={airflowIframeStyles.iframe}
                title="Apache Airflow Interface"
                onLoad={handleIframeLoad}
                onError={handleIframeError}
                className="airflow-iframe"
                sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-top-navigation"
                allow="fullscreen"
              />
            )}
            
            {viewMode === 'proxy' && (
              <div style={{ padding: "2rem", backgroundColor: "#f9fafb", height: "100%" }}>
                <h3 style={{ marginBottom: "1rem", color: "#374151" }}>Airflow Proxy View</h3>
                <p style={{ color: "#6b7280", marginBottom: "2rem" }}>
                  Connecting to Airflow via server proxy to bypass CSRF restrictions...
                </p>
                {airflowData ? (
                  <div style={{ 
                    backgroundColor: "#ffffff", 
                    padding: "1rem", 
                    borderRadius: "8px", 
                    border: "1px solid #e5e7eb",
                    fontFamily: "monospace",
                    fontSize: "0.875rem"
                  }}>
                    <pre>{JSON.stringify(airflowData, null, 2)}</pre>
                  </div>
                ) : (
                  <div style={{ textAlign: "center", padding: "3rem" }}>
                    <p style={{ color: "#9ca3af" }}>Loading Airflow data...</p>
                    <button 
                      style={airflowIframeStyles.retryButton}
                      onClick={() => window.open(airflowUrl, '_blank')}
                    >
                      Open Full Interface
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {viewMode === 'external' && (
              <div style={{ 
                padding: "3rem", 
                textAlign: "center", 
                backgroundColor: "#f9fafb",
                height: "100%",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center"
              }}>
                <h3 style={{ marginBottom: "1rem", color: "#374151" }}>External Window Mode</h3>
                <p style={{ color: "#6b7280", marginBottom: "2rem", maxWidth: "500px" }}>
                  For the best experience with network Airflow instances that have CSRF protection, 
                  open the interface in a new browser window.
                </p>
                <button 
                  style={{...airflowIframeStyles.retryButton, fontSize: "1rem", padding: "1rem 2rem"}}
                  onClick={() => window.open(airflowUrl, '_blank')}
                >
                  <Maximize2 size={20} style={{ marginRight: "0.5rem" }} />
                  Open Airflow in New Window
                </button>
              </div>
            )}
            
            {viewMode === 'api' && (
              <div style={{ padding: "2rem", backgroundColor: "#f9fafb", height: "100%", overflow: "auto" }}>
                <h3 style={{ marginBottom: "1rem", color: "#374151" }}>Airflow API View</h3>
                <p style={{ color: "#6b7280", marginBottom: "2rem" }}>
                  Basic API data from Airflow server. For full functionality, use External mode.
                </p>
                <div style={{ 
                  display: "grid", 
                  gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", 
                  gap: "1rem" 
                }}>
                  <div style={{ 
                    backgroundColor: "#ffffff", 
                    padding: "1rem", 
                    borderRadius: "8px", 
                    border: "1px solid #e5e7eb" 
                  }}>
                    <h4 style={{ margin: "0 0 0.5rem 0", color: "#374151" }}>Server Status</h4>
                    <p style={{ color: isAirflowOnline ? "#10b981" : "#ef4444", margin: 0 }}>
                      {isAirflowOnline ? "✓ Online" : "✗ Offline"}
                    </p>
                  </div>
                  <div style={{ 
                    backgroundColor: "#ffffff", 
                    padding: "1rem", 
                    borderRadius: "8px", 
                    border: "1px solid #e5e7eb" 
                  }}>
                    <h4 style={{ margin: "0 0 0.5rem 0", color: "#374151" }}>Connection URL</h4>
                    <p style={{ color: "#6b7280", margin: 0, fontSize: "0.875rem" }}>{airflowUrl}</p>
                  </div>
                  <div style={{ 
                    backgroundColor: "#ffffff", 
                    padding: "1rem", 
                    borderRadius: "8px", 
                    border: "1px solid #e5e7eb" 
                  }}>
                    <h4 style={{ margin: "0 0 0.5rem 0", color: "#374151" }}>Deployment Mode</h4>
                    <p style={{ color: "#6b7280", margin: 0 }}>
                      {deploymentMode.charAt(0).toUpperCase() + deploymentMode.slice(1)}
                    </p>
                  </div>
                </div>
                
                <div style={{ marginTop: "2rem", textAlign: "center" }}>
                  <button 
                    style={airflowIframeStyles.retryButton}
                    onClick={() => window.open(airflowUrl, '_blank')}
                  >
                    Open Full Airflow Interface
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AirflowIntegration;
