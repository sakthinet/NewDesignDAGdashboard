import { useEffect, useState } from "react";
import AirflowIntegration from "@/components/airflow-integration";

const AirflowPageStyles = {
  container: {
    display: "flex",
    flexDirection: "column" as const,
    height: "100vh",
    width: "100%",
    padding: "1rem"
  },
  header: {
    marginBottom: "1rem"
  },
  title: {
    fontSize: "1.5rem",
    fontWeight: 600,
    color: "var(--foreground)",
    marginBottom: "0.5rem"
  },
  description: {
    fontSize: "0.875rem",
    color: "var(--muted-foreground)",
    marginBottom: "1rem"
  },
  content: {
    flex: 1,
    borderRadius: "0.5rem",
    overflow: "hidden",
    border: "1px solid var(--border)",
    backgroundColor: "var(--card)"
  }
};

export const AirflowPage = () => {
  const [airflowUrl, setAirflowUrl] = useState("http://localhost:8083");

  useEffect(() => {
    // Get the Airflow URL from import.meta.env in Vite or use default
    const configuredUrl = import.meta.env.VITE_AIRFLOW_URL || "http://localhost:8083";
    setAirflowUrl(configuredUrl);
    
    // Add Airflow theme class to the page container for styling
    document.body.classList.add("airflow");
    
    return () => {
      // Clean up theme class when component unmounts
      document.body.classList.remove("airflow");
    };
  }, []);

  return (
    <div style={AirflowPageStyles.container}>
      <div style={AirflowPageStyles.header}>
        <h1 style={AirflowPageStyles.title}>Airflow Management Console</h1>
        <p style={AirflowPageStyles.description}>
          Monitor and manage your data workflows using Apache Airflow. This console provides direct access to the Airflow interface for DAG management, execution history, and system monitoring.
        </p>
      </div>
      
      <div style={AirflowPageStyles.content}>
        <AirflowIntegration airflowUrl={airflowUrl} />
      </div>
    </div>
  );
};

export default AirflowPage;
