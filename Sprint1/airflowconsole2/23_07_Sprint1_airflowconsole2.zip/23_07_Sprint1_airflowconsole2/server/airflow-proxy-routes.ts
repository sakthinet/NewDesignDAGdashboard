import express from 'express';
import https from 'https';

const router = express.Router();

// Create an HTTPS agent that ignores self-signed certificates (for development)
const httpsAgent = new https.Agent({
  rejectUnauthorized: false
});

// Proxy route to bypass CSRF issues
router.post('/proxy', async (req, res) => {
  try {
    const { url, endpoint = '', method = 'GET', headers = {}, body } = req.body;
    
    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    const targetUrl = `${url}${endpoint}`;
    console.log(`Proxying ${method} request to: ${targetUrl}`);

    // Default headers to bypass CSRF and authentication issues
    const proxyHeaders = {
      'User-Agent': 'InfoArchive-Airflow-Proxy/1.0',
      'Accept': 'application/json, text/html, */*',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      // Add CSRF token if available
      'X-CSRFToken': 'proxy-bypass',
      ...headers
    };

    const fetchOptions: RequestInit = {
      method,
      headers: proxyHeaders
    };

    if (body && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
      fetchOptions.body = typeof body === 'string' ? body : JSON.stringify(body);
      (fetchOptions.headers as any)['Content-Type'] = 'application/json';
    }

    const response = await fetch(targetUrl, fetchOptions);
    
    // Get response content type
    const contentType = response.headers.get('content-type') || '';
    
    if (contentType.includes('application/json')) {
      const data = await response.json();
      res.status(response.status).json({
        success: response.ok,
        status: response.status,
        statusText: response.statusText,
        data,
        headers: Object.fromEntries(response.headers.entries())
      });
    } else if (contentType.includes('text/html')) {
      const html = await response.text();
      res.status(response.status).json({
        success: response.ok,
        status: response.status,
        statusText: response.statusText,
        html: html.substring(0, 10000), // Limit HTML size
        contentType,
        message: 'HTML content received - consider using external view mode'
      });
    } else {
      const text = await response.text();
      res.status(response.status).json({
        success: response.ok,
        status: response.status,
        statusText: response.statusText,
        text: text.substring(0, 5000),
        contentType
      });
    }

  } catch (error: any) {
    console.error('Airflow proxy error:', error);
    
    let errorMessage = 'Unknown proxy error';
    let errorCode = 'PROXY_ERROR';
    
    if (error.code === 'ECONNREFUSED') {
      errorMessage = 'Connection refused - Airflow server may be down';
      errorCode = 'CONNECTION_REFUSED';
    } else if (error.code === 'ENOTFOUND') {
      errorMessage = 'Host not found - check Airflow URL';
      errorCode = 'HOST_NOT_FOUND';
    } else if (error.code === 'ETIMEDOUT') {
      errorMessage = 'Request timeout - Airflow server not responding';
      errorCode = 'TIMEOUT';
    } else if (error.message) {
      errorMessage = error.message;
    }

    res.status(500).json({ 
      error: errorMessage,
      code: errorCode,
      details: error.code || 'UNKNOWN'
    });
  }
});

// Health check endpoint
router.get('/health', async (req, res) => {
  const { url } = req.query;
  
  if (!url) {
    return res.status(400).json({ error: 'URL parameter is required' });
  }

  try {
    const response = await fetch(`${url}/health`, {
      method: 'GET',
      headers: {
        'User-Agent': 'InfoArchive-Health-Check/1.0',
        'Accept': 'application/json'
      }
    });

    const isHealthy = response.ok;
    const data = response.ok ? await response.json() : null;

    res.json({
      healthy: isHealthy,
      status: response.status,
      statusText: response.statusText,
      data,
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    res.status(500).json({
      healthy: false,
      error: error.message,
      code: error.code,
      timestamp: new Date().toISOString()
    });
  }
});

// Get Airflow version and basic info
router.get('/info', async (req, res) => {
  const { url } = req.query;
  
  if (!url) {
    return res.status(400).json({ error: 'URL parameter is required' });
  }

  try {
    // Try multiple endpoints to get basic info
    const endpoints = ['/api/v1/version', '/api/v1/config', '/health'];
    const results: any = {};

    for (const endpoint of endpoints) {
      try {
        const response = await fetch(`${url}${endpoint}`, {
          method: 'GET',
          headers: {
            'User-Agent': 'InfoArchive-Info-Check/1.0',
            'Accept': 'application/json'
          }
        });

        if (response.ok) {
          results[endpoint] = await response.json();
        }
      } catch (err) {
        // Silently fail individual endpoints
        results[endpoint] = { error: 'Not accessible' };
      }
    }

    res.json({
      success: true,
      url: url.toString(),
      endpoints: results,
      timestamp: new Date().toISOString()
    });

  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

export default router;
