# Environment Configuration Migration

This document outlines the migration from hardcoded Airflow UNC paths to a centralized environment variable configuration system.

## Overview

All hardcoded paths have been removed and replaced with configurable environment variables managed through a centralized configuration system. This allows for easy deployment across different environments without code changes.

## Configuration Files

### Primary Configuration File: `.env`

The `.env` file now contains all configurable paths and settings:

```bash
# AIRFLOW CONNECTION CONFIGURATION
AIRFLOW_URL=http://10.73.88.101:8080
AIRFLOW_USERNAME=airflow
AIRFLOW_PASSWORD=airflow
AIRFLOW_API_VERSION=v2

# AIRFLOW PATH CONFIGURATION (Host-side paths)
AIRFLOW_DATA_BASE_DIR=\\\\10.73.88.101\\data
AIRFLOW_DATA_DIR=\\\\10.73.88.101\\data\\incomingcsv
AIRFLOW_INCOMING_CSV_DIR=\\\\10.73.88.101\\data\\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=\\\\10.73.88.101\\data\\processedcsv
AIRFLOW_REPORTS_DIR=\\\\10.73.88.101\\reports
AIRFLOW_DAGS_DIR=\\\\10.73.88.101\\dags

# AIRFLOW CONTAINER PATHS (For DAG runtime)
AIRFLOW_CONTAINER_DATA_DIR=/opt/airflow/data
AIRFLOW_CONTAINER_INCOMING_CSV_DIR=/opt/airflow/data/incomingcsv
AIRFLOW_CONTAINER_PROCESSED_CSV_DIR=/opt/airflow/data/processedcsv
AIRFLOW_CONTAINER_DAGS_DIR=/opt/airflow/dags

# CLIENT-SIDE ACCESSIBLE VARIABLES
NEXT_PUBLIC_AIRFLOW_URL=http://10.73.88.101:8080
NEXT_PUBLIC_AIRFLOW_DATA_BASE_DIR=\\\\10.73.88.101\\data
NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR=\\\\10.73.88.101\\data\\incomingcsv
NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR=\\\\10.73.88.101\\data\\processedcsv

# INFOARCHIVE API CONFIGURATION
DEFAULT_CHUNK_SIZE=5000
DEFAULT_BEARER_TOKEN=...
PURCHASEORDERHEADER_URL=http://10.73.91.23:8765/systemdata/tables/AAAAhw/content
PURCHASEORDERITEM_URL=http://10.73.91.23:8765/systemdata/tables/AAAAhg/content
PURCHASEORDERPARTNER_URL=http://10.73.91.23:8765/systemdata/tables/AAAAhQ/content
```

### Configuration Management: `shared/config.ts`

A centralized configuration utility provides:
- Server-side configuration access
- Client-side configuration access (NEXT_PUBLIC_ variables only)
- Configuration logging for debugging
- Type-safe configuration interfaces

## Updated Files

### Server-Side Files

1. **`server/routes.ts`**
   - Removed hardcoded `10.73.88.101` IP addresses
   - Uses centralized config for all path operations
   - Updated AIRFLOW_CONFIG to use environment variables

2. **`server/incoming-json-routes.ts`**
   - Updated all hardcoded paths to use config
   - Centralized path management for JSON operations

3. **`server/index.ts`**
   - Added configuration logging on startup
   - Imports centralized configuration

### Client-Side Files

1. **`client/src/pages/dag-generator.tsx`**
   - Updated hardcoded Airflow URL to use environment variable
   - Uses `NEXT_PUBLIC_AIRFLOW_URL` for client-side access

2. **`temp/ia-table-schema-generator.tsx`**
   - Updated hardcoded WSL path to use environment variables
   - Uses `NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR`

### DAG Files

1. **`dags/StructuredDataToIA.py`**
   - Updated DEFAULT_WATCH_DIR to use `AIRFLOW_CONTAINER_INCOMING_CSV_DIR`
   - Updated DEFAULT_PROCESSED_DIR to use `AIRFLOW_CONTAINER_PROCESSED_CSV_DIR`
   - Updated export URLs to use environment variables

2. **`dags/StructuredDataToIA_Resilient.py`**
   - Updated all directory paths to use container environment variables

### Database Schema

1. **`shared/schema.ts`**
   - Updated default DAGs directory to use `AIRFLOW_CONTAINER_DAGS_DIR`

## Environment Paths Explained

### Host-Side Paths
Used by the Node.js application for file operations:
- `AIRFLOW_DATA_DIR`: Main data directory for file uploads
- `AIRFLOW_INCOMING_CSV_DIR`: Directory for incoming CSV files
- `AIRFLOW_PROCESSED_CSV_DIR`: Directory for processed CSV files
- `AIRFLOW_REPORTS_DIR`: Directory for generated reports

### Container-Side Paths
Used by DAGs running inside Airflow containers:
- `AIRFLOW_CONTAINER_INCOMING_CSV_DIR`: `/opt/airflow/data/incomingcsv`
- `AIRFLOW_CONTAINER_PROCESSED_CSV_DIR`: `/opt/airflow/data/processedcsv`
- `AIRFLOW_CONTAINER_DAGS_DIR`: `/opt/airflow/dags`

## Deployment Configurations

### Production Environment
```bash
# Production with network paths
AIRFLOW_URL=http://10.73.88.101:8080
AIRFLOW_INCOMING_CSV_DIR=\\\\10.73.88.101\\data\\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=\\\\10.73.88.101\\data\\processedcsv
```

### Development Environment
```bash
# Local development
AIRFLOW_URL=http://localhost:8080
AIRFLOW_INCOMING_CSV_DIR=./data/incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=./data/processedcsv
```

### Testing Environment
```bash
# Testing with different server
AIRFLOW_URL=http://test-airflow.company.com:8080
AIRFLOW_INCOMING_CSV_DIR=\\\\test-server\\data\\incomingcsv
AIRFLOW_PROCESSED_CSV_DIR=\\\\test-server\\data\\processedcsv
```

## Benefits

1. **Environment Flexibility**: Easy deployment across different environments
2. **No Hardcoded Paths**: All paths configurable via environment variables
3. **Centralized Management**: Single configuration file and utility
4. **Type Safety**: TypeScript interfaces for configuration
5. **Client/Server Separation**: Proper handling of client vs server variables
6. **Debugging Support**: Configuration logging for troubleshooting

## Migration Checklist

- [x] Updated `.env` file with comprehensive configuration
- [x] Created centralized configuration utility (`shared/config.ts`)
- [x] Updated all server-side routes files
- [x] Updated client-side components
- [x] Updated DAG Python files
- [x] Updated database schema defaults
- [x] Removed all hardcoded IP addresses and paths
- [x] Added configuration logging
- [x] Created migration documentation

## Usage

1. **Update Environment Variables**: Modify `.env` file for your environment
2. **Server Configuration**: Use `getServerConfig()` in server-side code
3. **Client Configuration**: Use `getClientConfig()` in client-side code
4. **Debugging**: Enable `ENABLE_PATH_LOGGING=true` to see configuration values

## Troubleshooting

1. **Check Configuration**: Enable logging with `ENABLE_PATH_LOGGING=true`
2. **Verify Paths**: Ensure all paths in `.env` are accessible
3. **Client Variables**: Ensure client-side variables have `NEXT_PUBLIC_` prefix
4. **Container Paths**: Verify container paths match your Airflow setup

This migration ensures the application is fully configurable and can be deployed in any environment without code changes.
