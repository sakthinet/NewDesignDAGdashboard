/**
 * Configuration Mode Switcher Utility
 * Use this script to test switching between local and network modes
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CONFIG_FILE = '.env.unified';

function switchToLocalMode() {
  const configPath = path.join(__dirname, CONFIG_FILE);
  let content = fs.readFileSync(configPath, 'utf8');
  
  // Update deployment mode
  content = content.replace(/DEPLOYMENT_MODE=network/g, 'DEPLOYMENT_MODE=local');
  
  fs.writeFileSync(configPath, content);
  console.log('✅ Switched to LOCAL mode');
  console.log('🔄 Please restart the server to apply changes');
  console.log('📡 Airflow URL will be: http://localhost:8083');
}

function switchToNetworkMode() {
  const configPath = path.join(__dirname, CONFIG_FILE);
  let content = fs.readFileSync(configPath, 'utf8');
  
  // Update deployment mode
  content = content.replace(/DEPLOYMENT_MODE=local/g, 'DEPLOYMENT_MODE=network');
  
  fs.writeFileSync(configPath, content);
  console.log('✅ Switched to NETWORK mode');
  console.log('🔄 Please restart the server to apply changes');
  console.log('📡 Airflow URL will be: http://10.73.88.101:8080');
}

function getCurrentMode() {
  const configPath = path.join(__dirname, CONFIG_FILE);
  const content = fs.readFileSync(configPath, 'utf8');
  
  const match = content.match(/DEPLOYMENT_MODE=(\w+)/);
  const mode = match ? match[1] : 'unknown';
  
  console.log(`📊 Current deployment mode: ${mode.toUpperCase()}`);
  
  if (mode === 'local') {
    console.log('📡 Airflow URL: http://localhost:8083');
    console.log('📁 Paths: Local Docker directories');
  } else if (mode === 'network') {
    console.log('📡 Airflow URL: http://10.73.88.101:8080');
    console.log('📁 Paths: Network shared directories');
  }
  
  return mode;
}

// Command line interface
const command = process.argv[2];

switch(command) {
  case 'local':
    switchToLocalMode();
    break;
  case 'network':
    switchToNetworkMode();
    break;
  case 'status':
  case 'current':
  default:
    getCurrentMode();
    if (!command) {
      console.log('\n💡 Usage:');
      console.log('  node test-config-switch.js status   - Show current mode');
      console.log('  node test-config-switch.js local    - Switch to local mode');
      console.log('  node test-config-switch.js network  - Switch to network mode');
    }
    break;
}
