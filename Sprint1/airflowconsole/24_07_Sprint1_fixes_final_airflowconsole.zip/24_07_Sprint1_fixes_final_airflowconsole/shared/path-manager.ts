/**
 * Centralized Path Management System
 * Handles all file path operations with robust fallback mechanisms
 */

import { promises as fs } from 'fs';
import path from 'path';
import { getServerConfig } from './config';

export interface PathResolution {
  path: string;
  isLocal: boolean;
  type: 'network' | 'local' | 'mapped_drive';
  accessible: boolean;
}

export interface PathOperationResult {
  success: boolean;
  path?: string;
  fallbackPath?: string;
  error?: string;
  warnings?: string[];
}

class PathManager {
  private static instance: PathManager;
  private accessibilityCache = new Map<string, { accessible: boolean; timestamp: number }>();
  private readonly CACHE_TTL = 30000; // 30 seconds

  private constructor() {}

  static getInstance(): PathManager {
    if (!PathManager.instance) {
      PathManager.instance = new PathManager();
    }
    return PathManager.instance;
  }

  /**
   * Normalize and validate path format
   */
  private normalizePath(inputPath: string): string {
    if (!inputPath) return '';

    // Handle different path formats
    let normalizedPath = inputPath.trim();

    // Convert forward slashes to backslashes for Windows
    normalizedPath = normalizedPath.replace(/\//g, '\\');

    // Handle UNC paths
    if (normalizedPath.match(/^\\{1,2}[\w.-]+\\[\w.-]+/)) {
      // Ensure UNC paths start with exactly two backslashes
      normalizedPath = normalizedPath.replace(/^\\+/, '\\\\');
    }

    // Handle Windows drive letters
    if (normalizedPath.match(/^[a-zA-Z]:[\\]?/)) {
      // Ensure drive letters have proper format
      normalizedPath = normalizedPath.replace(/^([a-zA-Z]:)([^\\])/, '$1\\$2');
    }

    return normalizedPath;
  }

  /**
   * Check if a network path is accessible with caching
   */
  private async isNetworkPathAccessible(networkPath: string): Promise<boolean> {
    const cacheKey = networkPath.toLowerCase();
    const cached = this.accessibilityCache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.accessible;
    }

    try {
      // Extract network root (\\server\share)
      const pathParts = networkPath.split('\\').filter(p => p);
      if (pathParts.length < 2) return false;
      
      const networkRoot = '\\\\' + pathParts.slice(0, 2).join('\\');
      
      await fs.access(networkRoot);
      
      // Test write permissions
      const testDir = path.join(networkRoot, '.accessibility-test');
      try {
        await fs.mkdir(testDir, { recursive: true });
        await fs.rmdir(testDir);
      } catch (dirError) {
        console.warn(`Network path accessible but not writable: ${networkRoot}`);
        return false;
      }

      this.accessibilityCache.set(cacheKey, { accessible: true, timestamp: Date.now() });
      return true;
    } catch (error) {
      this.accessibilityCache.set(cacheKey, { accessible: false, timestamp: Date.now() });
      return false;
    }
  }

  /**
   * Resolve the best available path with fallback options
   */
  async resolvePath(preferredPath: string, pathType: 'data' | 'dags' | 'reports' = 'data'): Promise<PathResolution> {
    const normalizedPath = this.normalizePath(preferredPath);
    
    // Check if it's a network path
    if (normalizedPath.startsWith('\\\\')) {
      const accessible = await this.isNetworkPathAccessible(normalizedPath);
      
      if (accessible) {
        return {
          path: normalizedPath,
          isLocal: false,
          type: 'network',
          accessible: true
        };
      }
      
      // Network path not accessible, return fallback info
      return {
        path: this.getLocalFallbackPath(pathType),
        isLocal: true,
        type: 'local',
        accessible: true
      };
    }

    // Check if it's a mapped drive
    if (normalizedPath.match(/^[a-zA-Z]:\\/)) {
      try {
        await fs.access(normalizedPath);
        return {
          path: normalizedPath,
          isLocal: false,
          type: 'mapped_drive',
          accessible: true
        };
      } catch {
        return {
          path: this.getLocalFallbackPath(pathType),
          isLocal: true,
          type: 'local',
          accessible: true
        };
      }
    }

    // Default to local path
    return {
      path: normalizedPath || this.getLocalFallbackPath(pathType),
      isLocal: true,
      type: 'local',
      accessible: true
    };
  }

  /**
   * Get local fallback path based on type
   */
  private getLocalFallbackPath(pathType: 'data' | 'dags' | 'reports'): string {
    const basePath = process.cwd();
    
    switch (pathType) {
      case 'data':
        return path.join(basePath, 'data', 'incomingcsv');
      case 'dags':
        return path.join(basePath, 'dags');
      case 'reports':
        return path.join(basePath, 'reports');
      default:
        return path.join(basePath, 'data');
    }
  }

  /**
   * Ensure directory exists with proper error handling
   */
  async ensureDirectory(dirPath: string): Promise<PathOperationResult> {
    try {
      const resolution = await this.resolvePath(dirPath);
      
      await fs.mkdir(resolution.path, { recursive: true });
      
      // Test write permissions
      const testFile = path.join(resolution.path, '.write-test-' + Date.now());
      try {
        await fs.writeFile(testFile, 'test');
        await fs.unlink(testFile);
      } catch (writeError) {
        return {
          success: false,
          error: `Directory exists but is not writable: ${resolution.path}`,
          path: resolution.path
        };
      }

      return {
        success: true,
        path: resolution.path,
        fallbackPath: resolution.isLocal ? resolution.path : undefined,
        warnings: resolution.isLocal ? ['Using local fallback due to network path inaccessibility'] : undefined
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        path: dirPath
      };
    }
  }

  /**
   * Copy file with automatic path resolution and fallback
   */
  async copyFile(sourcePath: string, targetPath: string, pathType: 'data' | 'dags' | 'reports' = 'data'): Promise<PathOperationResult> {
    try {
      // Resolve source path
      if (!await this.fileExists(sourcePath)) {
        return {
          success: false,
          error: `Source file not found: ${sourcePath}`
        };
      }

      // Resolve target path
      const targetResolution = await this.resolvePath(targetPath, pathType);
      const targetDir = path.dirname(targetResolution.path);
      
      // Ensure target directory exists
      const dirResult = await this.ensureDirectory(targetDir);
      if (!dirResult.success) {
        return dirResult;
      }

      // Perform the copy operation
      const finalTargetPath = path.join(targetResolution.path, path.basename(sourcePath));
      await fs.copyFile(sourcePath, finalTargetPath);

      return {
        success: true,
        path: finalTargetPath,
        fallbackPath: targetResolution.isLocal ? finalTargetPath : undefined,
        warnings: targetResolution.isLocal ? ['File copied to local fallback location'] : undefined
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        path: targetPath
      };
    }
  }

  /**
   * Check if file exists
   */
  async fileExists(filePath: string): Promise<boolean> {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Find file in multiple possible locations
   */
  async findFile(fileName: string): Promise<string | null> {
    const possibleLocations = [
      path.join(process.cwd(), 'uploads', fileName),
      path.join(process.cwd(), 'input-files', fileName),
      path.join(process.cwd(), 'temp', fileName),
      path.join(process.cwd(), 'data', 'incomingcsv', fileName)
    ];

    for (const location of possibleLocations) {
      if (await this.fileExists(location)) {
        return location;
      }
    }

    return null;
  }

  /**
   * Get comprehensive path information for debugging
   */
  async getPathInfo(inputPath: string): Promise<any> {
    const config = getServerConfig();
    const normalized = this.normalizePath(inputPath);
    const resolution = await this.resolvePath(normalized);
    
    return {
      input: inputPath,
      normalized,
      resolution,
      config: {
        incomingCsvDir: config.incomingCsvDir,
        processedCsvDir: config.processedCsvDir,
        dagsDir: config.dagsDir
      },
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Clear accessibility cache (useful for testing or after network changes)
   */
  clearCache(): void {
    this.accessibilityCache.clear();
  }
}

export const pathManager = PathManager.getInstance();
