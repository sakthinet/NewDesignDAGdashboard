/**
 * Client-side configuration hook for React components
 * This avoids runtime access to process.env which is not available in the browser
 */

import { useMemo } from 'react';

interface ClientConfig {
  airflowUrl: string;
  dataBaseDir: string;
  incomingCsvDir: string;
  processedCsvDir: string;
  reportsDir: string;
  dagsDir: string;
}

/**
 * React hook for accessing client-side configuration
 * This provides fallback values and can be extended to fetch from API if needed
 */
export function useClientConfig(): ClientConfig {
  return useMemo(() => {
    // Use the static config which is loaded from environment variables at build time
    return CLIENT_CONFIG;
  }, []);
}

/**
 * Static configuration for client-side use
 * This provides compile-time defaults from environment variables
 */
export const CLIENT_CONFIG: ClientConfig = {
  airflowUrl: import.meta.env.VITE_AIRFLOW_URL || 'http://localhost:8080',
  dataBaseDir: import.meta.env.VITE_AIRFLOW_DATA_BASE_DIR || './data',
  incomingCsvDir: import.meta.env.VITE_AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv',
  processedCsvDir: import.meta.env.VITE_AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv',
  reportsDir: import.meta.env.VITE_AIRFLOW_REPORTS_DIR || './reports',
  dagsDir: import.meta.env.VITE_AIRFLOW_DAGS_DIR || './dags',
};

/**
 * Get Airflow URL for client-side use
 */
export function getAirflowUrl(): string {
  // Default to localhost for development
  return CLIENT_CONFIG.airflowUrl;
}

/**
 * Get data directories for client-side use
 */
export function getDataDirectories() {
  return {
    base: CLIENT_CONFIG.dataBaseDir,
    incoming: CLIENT_CONFIG.incomingCsvDir,
    processed: CLIENT_CONFIG.processedCsvDir,
    reports: CLIENT_CONFIG.reportsDir,
    dags: CLIENT_CONFIG.dagsDir,
  };
}
