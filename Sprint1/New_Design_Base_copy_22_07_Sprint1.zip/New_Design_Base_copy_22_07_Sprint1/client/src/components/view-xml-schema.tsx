import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ArrowRight, RefreshCw, FileText, Download, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";

interface ViewXmlSchemaProps {
  uploadedFile: UploadedFile | null;
  config: DagConfig;
  onPrev: () => void;
  onNext: () => void;
}

export function ViewXmlSchema({ uploadedFile, config, onPrev, onNext }: ViewXmlSchemaProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [xmlFilesAvailable, setXmlFilesAvailable] = useState(false);
  const [xmlFilesList, setXmlFilesList] = useState<any[]>([]);
  const [isCheckingFiles, setIsCheckingFiles] = useState(false);
  const { toast } = useToast();

  // Check for XML files when component mounts or uploadedFile changes
  useEffect(() => {
    checkXmlFiles();
  }, [uploadedFile]);

  const checkXmlFiles = async () => {
    setIsCheckingFiles(true);
    try {
      console.log('🔍 Checking for XML files...');
      
      // Check for all XML files in the system (return all files, not just latest)
      const response = await fetch('/api/xml-files/check/all?mode=all&all=true');
      const data = await response.json();
      
      if (data.success && data.files && data.files.length > 0) {
        console.log('✅ XML files found:', data.files);
        setXmlFilesList(data.files);
        setXmlFilesAvailable(true);
        
        toast({
          title: "XML Files Detected",
          description: `Found ${data.files.length} XML file(s) available for download.`,
        });
      } else {
        console.log('❌ No XML files found');
        setXmlFilesList([]);
        setXmlFilesAvailable(false);
      }
    } catch (error) {
      console.error('Error checking XML files:', error);
      setXmlFilesList([]);
      setXmlFilesAvailable(false);
    } finally {
      setIsCheckingFiles(false);
    }
  };

  const handleRefresh = async () => {
    setIsLoading(true);
    try {
      // Re-check for XML files
      await checkXmlFiles();
      
      toast({
        title: "Schema Refreshed", 
        description: "Checked for updated XML schema files.",
      });
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh schema files. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">
          Download IA Schema
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Download generated XML schema files
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isLoading || isCheckingFiles}
            className="flex items-center space-x-2"
          >
            <RefreshCw className={`w-4 h-4 ${(isLoading || isCheckingFiles) ? 'animate-spin' : ''}`} />
            <span>{isCheckingFiles ? 'Checking...' : 'Refresh'}</span>
          </Button>
        </div>
      </div>

      {/* XML Files Status Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span>Generated XML Schema Files</span>
            {xmlFilesAvailable && (
              <Badge variant="outline" className="bg-green-100 text-green-800">
                <CheckCircle className="w-3 h-3 mr-1" />
                Available
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isCheckingFiles ? (
            <div className="text-center py-8">
              <RefreshCw className="w-8 h-8 mx-auto mb-4 animate-spin text-blue-600" />
              <p className="text-gray-600">Checking for XML files...</p>
            </div>
          ) : xmlFilesAvailable && xmlFilesList.length > 0 ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground mb-4">
                Found {xmlFilesList.length} XML file(s) ready for download:
              </p>
              <div className="grid gap-2">
                {xmlFilesList.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <div>
                        <p className="font-medium text-sm">{file.fileName}</p>
                        <p className="text-xs text-muted-foreground">
                          Size: {Math.round(file.size / 1024)} KB • 
                          Modified: {new Date(file.modified).toLocaleString()} • 
                          Directory: {file.directory}
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => window.open(`/api/xml-files/download/${encodeURIComponent(file.fileName)}`, '_blank')}
                      className="flex items-center space-x-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download</span>
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No XML Files Found</h3>
              <p className="text-gray-600 mb-4">
                XML schema files haven't been generated yet or aren't available in the expected locations.
              </p>
              <Button 
                variant="outline" 
                onClick={checkXmlFiles}
                disabled={isCheckingFiles}
                className="flex items-center space-x-2"
              >
                <RefreshCw className={`w-4 h-4 ${isCheckingFiles ? 'animate-spin' : ''}`} />
                <span>Check Again</span>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-6 border-t">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Previous</span>
        </Button>
        
        <Button
          onClick={onNext}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
        >
          <span>Next: Transform CSV Data</span>
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
