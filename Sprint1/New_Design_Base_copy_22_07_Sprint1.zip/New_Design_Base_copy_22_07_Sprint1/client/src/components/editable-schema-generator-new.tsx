import { useState, useEffect, useCallback, useMemo, memo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  ArrowRight, 
  Database, 
  FileText, 
  Save,
  Loader2,
  Settings,
  CheckCircle,
  AlertCircle,
  Play,
  RefreshCw,
  X,
  Edit3,
  Plus,
  Trash2,
  ChevronDown
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useWorkflow } from "@/contexts/WorkflowContext";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

// API request function
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

// Types for the schema configuration
export interface SchemaConfiguration {
  applicationName: string;
  defaultSchemaName: string;
  locale: string;
  schemaName: string;
}

// Reference structure from the attached file
export interface TableRowData {
  id: string;
  table: string;           // Taken from JSON file metadata (Editable)
  recordCount: number;     // Calculated based on number of records in JSON data (Editable)
  dataType: string;        // Based on column data type from JSON metadata (Editable)
  fileName: string;        // Original JSON file name for reference
  columnName?: string;     // Column name from JSON metadata
  isNullable?: boolean;    // Nullable flag from JSON metadata
  description?: string;    // Column description from JSON metadata
}

export interface JsonDataItem {
  id: string;
  tableName: string;
  columnName: string;
  dataType: string;
  recordCount: number;
  fileName: string;
  isNullable: boolean;
  description: string;
}

interface EditableSchemaGeneratorProps {
  uploadedFiles: any[];
  onNext: () => void;
  onPrev: () => void;
  onFinalize: () => void;
}

const DATA_TYPE_OPTIONS = [
  'VARCHAR(50)',
  'VARCHAR(100)',
  'VARCHAR(255)',
  'TEXT',
  'INT',
  'BIGINT',
  'DECIMAL(10,2)',
  'DATE',
  'DATETIME',
  'TIMESTAMP',
  'BOOLEAN',
  'FLOAT',
  'DOUBLE'
];

// Data types for column type management
const DATA_TYPES = [
  'VARCHAR', 'INT', 'FLOAT', 'DOUBLE', 'BOOLEAN', 'DATE', 'DATETIME', 'TEXT', 'JSON'
];

// Interface for table schema structure
interface TableSchema {
  table_name: string;
  columns: {
    name: string;
    type: string;
    typeLength: string;
  }[];
  record_count: number;
}

// Helper function to get default type length
const getDefaultTypeLength = (type: string): string => {
  switch (type) {
    case 'VARCHAR':
    case 'TEXT':
      return '255';
    case 'INT':
    case 'FLOAT':
    case 'DOUBLE':
    case 'DATE':
    case 'DATETIME':
      return '64';
    case 'BOOLEAN':
      return '1';
    default:
      return '255';
  }
};

// Simple Table Component to avoid hook issues - memoized for performance
const SimpleTable = memo(({ 
  table, 
  actualTableIndex, 
  isEditingMode, 
  updateColumnName, 
  updateColumnType, 
  updateColumnTypeLength, 
  removeColumn,
  getTablePage,
  rowsPerTable
}: any) => {
  const currentTablePage = getTablePage(actualTableIndex);
  const startIndex = (currentTablePage - 1) * rowsPerTable;
  const endIndex = startIndex + rowsPerTable;
  
  // Memoize paginated columns to prevent recalculation
  const paginatedColumns = useMemo(() => 
    table.columns.slice(startIndex, endIndex), 
    [table.columns, startIndex, endIndex]
  );

  return (
    <div className="table-container" style={{ position: 'relative', minHeight: '300px' }}>
      <table className="json-table-stable w-full table-fixed border-separate border-spacing-0" style={{ tableLayout: 'fixed' }}>
        <thead className="sticky top-0 bg-slate-100 z-10 border-b-2 border-slate-300">
          <tr>
            <th className="w-[200px] min-w-[200px] h-12 bg-slate-100 border-r border-slate-300 text-left font-semibold text-slate-700 px-3" style={{ boxSizing: 'border-box', width: '200px' }}>
              Column Name
            </th>
            <th className="w-[150px] min-w-[150px] h-12 bg-slate-100 border-r border-slate-300 text-left font-semibold text-slate-700 px-3" style={{ boxSizing: 'border-box', width: '150px' }}>
              Data Type
            </th>
            <th className="w-[100px] min-w-[100px] h-12 bg-slate-100 border-r border-slate-300 text-left font-semibold text-slate-700 px-3" style={{ boxSizing: 'border-box', width: '100px' }}>
              Type Length
            </th>
            {isEditingMode && (
              <th className="w-[80px] min-w-[80px] h-12 bg-slate-100 text-center font-semibold text-slate-700 px-3" style={{ boxSizing: 'border-box', width: '80px' }}>
                Actions
              </th>
            )}
          </tr>
        </thead>
        <tbody>
          {paginatedColumns.map((column: any, columnIndex: number) => {
            const actualColumnIndex = startIndex + columnIndex;
            const isEvenRow = actualColumnIndex % 2 === 0;
            const rowBgClass = isEvenRow ? "bg-white" : "bg-gray-50";
            
            return (
              <tr 
                key={`col-${actualColumnIndex}`} 
                className={`h-12 border-b border-slate-200 hover:bg-slate-50 transition-colors ${rowBgClass}`}
                style={{ boxSizing: 'border-box', height: '48px' }}
              >
                <td className="min-w-[200px] h-12 align-middle border-r border-slate-200 p-3" style={{ boxSizing: 'border-box', height: '48px', width: '200px' }}>
                  {isEditingMode ? (
                    <Input
                      value={column.name}
                      onChange={(e) => updateColumnName(actualTableIndex, actualColumnIndex, e.target.value)}
                      className="h-8 w-full bg-white border-slate-300 text-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  ) : (
                    <span className="font-medium text-slate-800">{column.name}</span>
                  )}
                </td>
                <td 
                  className="min-w-[150px] h-12 align-middle border-r border-slate-200 p-3" 
                  style={{ boxSizing: 'border-box', width: '150px' }}
                >
                  {isEditingMode ? (
                    <Select
                      value={column.type}
                      onValueChange={(value) => updateColumnType(actualTableIndex, actualColumnIndex, value)}
                    >
                      <SelectTrigger className="h-8 w-full bg-white border-slate-300">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-white z-50">
                        {DATA_TYPES.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="bg-blue-500 text-white px-3 py-1 rounded-md flex items-center justify-between">
                      <span className="font-medium">{column.type}</span>
                      <ChevronDown className="h-4 w-4 ml-2 opacity-50" />
                    </div>
                  )}
                </td>
                <td className="min-w-[100px] h-12 align-middle border-r border-slate-200 p-3" style={{ boxSizing: 'border-box', height: '48px', width: '100px' }}>
                  {isEditingMode ? (
                    <Input
                      value={column.typeLength}
                      onChange={(e) => updateColumnTypeLength(actualTableIndex, actualColumnIndex, e.target.value)}
                      className="h-8 w-full bg-white border-slate-300 text-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                    />
                  ) : (
                    <span className="text-slate-800 font-medium">{column.typeLength}</span>
                  )}
                </td>
                {isEditingMode && (
                  <td className="min-w-[80px] h-12 align-middle text-center p-3" style={{ boxSizing: 'border-box', width: '80px' }}>
                    <Button
                      onClick={() => removeColumn(actualTableIndex, actualColumnIndex)}
                      size="sm"
                      variant="outline"
                      className="h-8 w-8 p-0 text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
});

export function EditableSchemaGenerator({ 
  uploadedFiles, 
  onNext, 
  onPrev, 
  onFinalize 
}: EditableSchemaGeneratorProps) {
  
  const workflow = useWorkflow();
  const { toast } = useToast();
  const { triggerDag, loading: dagLoading, error: dagError } = useAirflowApi();

  // Use schema configuration from workflow context or fallback to defaults
  const schemaConfig = workflow.schemaConfig || {
    applicationName: 'InfoArchive_Application',
    defaultSchemaName: 'DefaultSchema',
    locale: 'en-US',
    schemaName: 'DataArchival_Schema'
  };

  // JSON file management state - updated for schema format
  const [availableJsonFiles, setAvailableJsonFiles] = useState<string[]>([]);
  const [selectedJsonFile, setSelectedJsonFile] = useState<string>('');
  const [schemaData, setSchemaData] = useState<TableSchema[]>([]);
  const [originalSchemaData, setOriginalSchemaData] = useState<TableSchema[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [isLoadingJson, setIsLoadingJson] = useState(false);
  const [isSavingJson, setIsSavingJson] = useState(false);
  const [isFinalizing, setIsFinalizing] = useState(false);
  const [isEditingMode, setIsEditingMode] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [tablesPerPage] = useState(5);
  
  // Table-specific pagination states
  const [tablePages, setTablePages] = useState<{[key: number]: number}>({});
  const [rowsPerTable] = useState(10);
  const [savingTables, setSavingTables] = useState<{[key: number]: boolean}>({});
  
  // Raw data mode states
  const [isRawDataMode, setIsRawDataMode] = useState(false);
  const [rawTableData, setRawTableData] = useState<any[]>([]);
  const [rawDataColumns, setRawDataColumns] = useState<string[]>([]);

  // Load available JSON files from the network path
  const loadAvailableJsonFiles = async () => {
    setIsLoadingFiles(true);
    try {
      console.log('🔍 Loading available JSON files from network path...');
      const response = await apiRequest('GET', '/api/list-incoming-json');
      
      if (response.ok) {
        const result = await response.json();
        if (result.success && result.files) {
          // Extract file names from the file objects
          const fileNames = result.files.map((file: any) => file.name);
          const sortedFiles = fileNames.sort((a: string, b: string) => {
            // Sort by modification time (newest first) - assuming files have timestamps
            return b.localeCompare(a);
          });
          setAvailableJsonFiles(sortedFiles || []);
          
          // Auto-select the latest JSON file
          if (sortedFiles.length > 0) {
            setSelectedJsonFile(sortedFiles[0]);
            await loadJsonFile(sortedFiles[0]);
          }
          
          toast({
            title: "✅ Files Loaded",
            description: `Found ${sortedFiles.length} JSON files`,
            duration: 100,
          });
        } else {
          console.error('Failed to load JSON files:', result.message);
          toast({
            title: "⚠️ Load Failed",
            description: result.message || "Failed to load JSON files",
            variant: "destructive",
          });
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error loading JSON files:', error);
      toast({
        title: "❌ Error Loading Files",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsLoadingFiles(false);
    }
  };

  // Load a specific JSON file
  const loadJsonFile = async (fileName: string) => {
    if (!fileName) return;
    
    setIsLoadingJson(true);
    try {
      console.log(`📄 Loading JSON file: ${fileName}`);
      const response = await apiRequest('POST', '/api/load-json-file-from-network', {
        fileName: fileName
      });
      
      if (response.ok) {
        const result = await response.json();
        
        if (result.success) {
          let dataToProcess = result.jsonData; // Changed from result.data to result.jsonData
          
          // Check if the data has a 'tables' property (new format)
          if (dataToProcess && dataToProcess.tables) {
            dataToProcess = dataToProcess.tables;
          }
          
          // Ensure we have valid data
          if (!dataToProcess) {
            dataToProcess = [];
          }
          
          // Convert to array if it's not already
          if (!Array.isArray(dataToProcess)) {
            dataToProcess = [dataToProcess];
          }
          
          // Process as table schema data
          const processedSchemaData: TableSchema[] = dataToProcess.map((item: any) => ({
            table_name: item.table_name || 'UnknownTable',
            columns: (item.columns || []).map((col: any) => ({
              name: col.name || 'unknown_column',
              type: col.type || 'VARCHAR',
              typeLength: col.typeLength || getDefaultTypeLength(col.type || 'VARCHAR')
            })),
            record_count: item.record_count || 0
          }));
          
          setSchemaData(processedSchemaData);
          setOriginalSchemaData([...processedSchemaData]);
          setHasChanges(false);
          
          toast({
            title: "✅ JSON File Loaded",
            description: `Successfully loaded ${fileName} with ${processedSchemaData.length} tables`,
            duration: 100,
          });
        } else {
          throw new Error(result.message || 'Failed to load JSON file');
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error loading JSON file:', error);
      toast({
        title: "❌ Error Loading JSON",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsLoadingJson(false);
    }
  };

  // Save the JSON file
  const saveJsonFile = async () => {
    if (!selectedJsonFile || schemaData.length === 0) {
      toast({
        title: "⚠️ Nothing to Save",
        description: "No data to save or no file selected",
        variant: "destructive",
      });
      return;
    }
    
    setIsSavingJson(true);
    try {
      console.log(`💾 Saving JSON file: ${selectedJsonFile}`);
      
      const response = await apiRequest('POST', '/api/save-json-file-to-network', {
        fileName: selectedJsonFile,
        data: schemaData
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          toast({
            title: "✅ JSON File Saved",
            description: `Successfully saved ${selectedJsonFile}`,
            duration: 100,
          });
          
          // Reset changes state and update original data
          setHasChanges(false);
          setOriginalSchemaData([...schemaData]);
        } else {
          throw new Error(result.message || 'Failed to save JSON file');
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error saving JSON file:', error);
      toast({
        title: "❌ Error Saving JSON",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsSavingJson(false);
    }
  };

  // Save individual table changes
  const saveIndividualTable = async (tableIndex: number) => {
    if (!selectedJsonFile || schemaData.length === 0) {
      toast({
        title: "⚠️ Nothing to Save",
        description: "No data to save or no file selected",
        variant: "destructive",
      });
      return;
    }
    
    // Set loading state for this table
    setSavingTables(prev => ({ ...prev, [tableIndex]: true }));
    
    try {
      const table = schemaData[tableIndex];
      console.log(`💾 Saving individual table: ${table.table_name}`);
      
      // Here you could implement individual table saving logic
      // For now, we'll save the entire schema but highlight the specific table
      const response = await apiRequest('POST', '/api/save-json-file-to-network', {
        fileName: selectedJsonFile,
        data: schemaData,
        updatedTableIndex: tableIndex
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          toast({
            title: "✅ Table Saved",
            description: `Table "${table.table_name}" saved successfully`,
            duration: 100,
          });
          
          // Update original data for this table
          const updatedOriginalData = [...originalSchemaData];
          updatedOriginalData[tableIndex] = { ...table };
          setOriginalSchemaData(updatedOriginalData);
          
          // Check if there are still changes in other tables
          const stillHasChanges = schemaData.some((table, index) => 
            JSON.stringify(table) !== JSON.stringify(originalSchemaData[index])
          );
          setHasChanges(stillHasChanges);
        } else {
          throw new Error(result.message || 'Failed to save table');
        }
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error saving table:', error);
      toast({
        title: "❌ Error Saving Table",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      // Clear loading state for this table
      setSavingTables(prev => ({ ...prev, [tableIndex]: false }));
    }
  };

  // Helper function to get table page - memoized for performance
  const getTablePage = useCallback((tableIndex: number) => {
    return tablePages[tableIndex] || 1;
  }, [tablePages]);

  // Helper function to set table page - memoized for performance
  const setTablePage = useCallback((tableIndex: number, page: number) => {
    setTablePages(prev => ({
      ...prev,
      [tableIndex]: page
    }));
  }, []);

  // Helper function to check if table has changes - memoized for performance
  const tableHasChanges = useCallback((tableIndex: number) => {
    if (!originalSchemaData[tableIndex]) return false;
    
    const current = schemaData[tableIndex];
    const original = originalSchemaData[tableIndex];
    
    if (!current || !original) return false;
    
    if (current.table_name !== original.table_name || 
        current.record_count !== original.record_count ||
        current.columns.length !== original.columns.length) {
      return true;
    }
    
    return current.columns.some((col, index) => {
      const originalCol = original.columns[index];
      return !originalCol || 
             col.name !== originalCol.name ||
             col.type !== originalCol.type ||
             col.typeLength !== originalCol.typeLength;
    });
  }, [schemaData, originalSchemaData]);

  // Handle DAG run for finalizing (Step 3)
  const handleDAGRun2 = async () => {
    setIsFinalizing(true);
    
    try {
      // Prepare the DAG configuration with schema configuration and table data
      const dagConfig = {
        "Application Name": schemaConfig.applicationName,
        "Default Schema Name": schemaConfig.defaultSchemaName,
        "Locale": schemaConfig.locale,
        "Schema Name": schemaConfig.schemaName,
        "JSON File": selectedJsonFile,
        "Table Schema Data": schemaData
      };

      console.log('=== DAG RUN 2 TRIGGERED ===');
      console.log('DAG Configuration:', dagConfig);

      // Trigger the specific DAG: IA_XML_Generator
      const result = await triggerDag('IA_XML_Generator', dagConfig);

      console.log('DAG Response:', result);

      if (result.success) {
        toast({
          title: "✅ Schema Finalized Successfully",
          description: `InfoArchive XML schema has been generated and is ready for deployment.`,
          duration: 100,
        });
        
        // Move to next step
        onFinalize();
      } else {
        throw new Error(result.message || 'DAG execution failed');
      }
      
    } catch (error) {
      console.error('DAG run error:', error);
      toast({
        title: "❌ Schema Finalization Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsFinalizing(false);
    }
  };

  // Update raw table data
  const updateRawTableData = (rowIndex: number, columnName: string, value: any) => {
    const updatedData = rawTableData.map((row, index) => {
      if (index === rowIndex) {
        return {
          ...row,
          rowData: {
            ...row.rowData,
            [columnName]: value
          }
        };
      }
      return row;
    });
    setRawTableData(updatedData);
  };

  // Add new row to raw data
  const addNewRowToRawData = () => {
    const newRow: { [key: string]: string } = {};
    rawDataColumns.forEach(col => {
      newRow[col] = '';
    });
    
    const newRowData = {
      id: `row_${rawTableData.length}`,
      rowData: newRow,
      originalData: newRow
    };
    
    setRawTableData([...rawTableData, newRowData]);
  };

  // Remove row from raw data
  const removeRowFromRawData = (rowIndex: number) => {
    const updatedData = rawTableData.filter((_, index) => index !== rowIndex);
    setRawTableData(updatedData);
  };

  // Add new column to raw data
  const addNewColumnToRawData = () => {
    const newColumnName = `new_column_${rawDataColumns.length + 1}`;
    setRawDataColumns([...rawDataColumns, newColumnName]);
    
    const updatedData = rawTableData.map(row => ({
      ...row,
      rowData: {
        ...row.rowData,
        [newColumnName]: ''
      }
    }));
    setRawTableData(updatedData);
  };

  // Remove column from raw data
  const removeColumnFromRawData = (columnName: string) => {
    const updatedColumns = rawDataColumns.filter(col => col !== columnName);
    setRawDataColumns(updatedColumns);
    
    const updatedData = rawTableData.map(row => {
      const newRowData = { ...row.rowData };
      delete newRowData[columnName];
      return {
        ...row,
        rowData: newRowData
      };
    });
    setRawTableData(updatedData);
  };

  // Helper function to infer data type from JSON data
  const inferDataType = (data: any[], column: string): string => {
    if (!data || data.length === 0) return 'VARCHAR';
    
    const sampleValue = data[0][column];
    if (sampleValue === null || sampleValue === undefined) return 'VARCHAR';
    
    const value = String(sampleValue);
    
    if (!isNaN(Number(value))) {
      return value.includes('.') ? 'FLOAT' : 'INT';
    }
    
    if (value.toLowerCase() === 'true' || value.toLowerCase() === 'false') {
      return 'BOOLEAN';
    }
    
    if (value.match(/^\d{4}-\d{2}-\d{2}$/)) {
      return 'DATE';
    }
    
    if (value.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)) {
      return 'DATETIME';
    }
    
    return 'VARCHAR';
  };

  // Helper function to check if a column is nullable
  const checkIfNullable = (data: any[], column: string): boolean => {
    return data.some(item => item[column] === null || item[column] === undefined);
  };

  // Helper function to format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Load JSON files when component mounts
  useEffect(() => {
    loadAvailableJsonFiles();
  }, []);

  // Show warning if no schema configuration from workflow
  useEffect(() => {
    if (!workflow.schemaConfig) {
      toast({
        title: "⚠️ Schema Configuration Missing",
        description: "Using default schema configuration. Please ensure Step 2 was completed properly.",
        variant: "destructive",
        duration: 100,
      });
    } else {
      // Mark schema step as completed
      workflow.markStepCompleted('configure');
    }
  }, [workflow.schemaConfig]);

  // Initialize page on mount
  useEffect(() => {
    loadAvailableJsonFiles();
    setCurrentPage(1);
    setHasChanges(false);
  }, []);

  // Track changes for unsaved changes indicator - optimized to reduce frequent JSON comparisons
  const checkForChanges = useCallback(() => {
    if (!originalSchemaData || originalSchemaData.length === 0) {
      setHasChanges(false);
      return;
    }
    
    // Fast check - compare lengths first
    if (schemaData.length !== originalSchemaData.length) {
      setHasChanges(true);
      return;
    }
    
    // Check each table for changes
    for (let i = 0; i < schemaData.length; i++) {
      const current = schemaData[i];
      const original = originalSchemaData[i];
      
      if (current.table_name !== original.table_name || 
          current.record_count !== original.record_count ||
          current.columns.length !== original.columns.length) {
        setHasChanges(true);
        return;
      }
      
      // Check columns
      for (let j = 0; j < current.columns.length; j++) {
        const currentCol = current.columns[j];
        const originalCol = original.columns[j];
        
        if (currentCol.name !== originalCol.name ||
            currentCol.type !== originalCol.type ||
            currentCol.typeLength !== originalCol.typeLength) {
          setHasChanges(true);
          return;
        }
      }
    }
    
    setHasChanges(false);
  }, [schemaData, originalSchemaData]);

  useEffect(() => {
    checkForChanges();
  }, [checkForChanges]);

  // Schema editing functions - memoized for performance
  const updateTableName = useCallback((tableIndex: number, newName: string) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      updatedData[tableIndex] = {
        ...updatedData[tableIndex],
        table_name: newName
      };
      return updatedData;
    });
  }, []);

  const updateRecordCount = useCallback((tableIndex: number, newCount: number) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      updatedData[tableIndex] = {
        ...updatedData[tableIndex],
        record_count: newCount
      };
      return updatedData;
    });
  }, []);

  const updateColumnName = useCallback((tableIndex: number, columnIndex: number, newName: string) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      const updatedTable = { ...updatedData[tableIndex] };
      const updatedColumns = [...updatedTable.columns];
      updatedColumns[columnIndex] = { ...updatedColumns[columnIndex], name: newName };
      updatedTable.columns = updatedColumns;
      updatedData[tableIndex] = updatedTable;
      return updatedData;
    });
  }, []);

  const updateColumnType = useCallback((tableIndex: number, columnIndex: number, newType: string) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      const updatedTable = { ...updatedData[tableIndex] };
      const updatedColumns = [...updatedTable.columns];
      updatedColumns[columnIndex] = { 
        ...updatedColumns[columnIndex], 
        type: newType,
        typeLength: getDefaultTypeLength(newType)
      };
      updatedTable.columns = updatedColumns;
      updatedData[tableIndex] = updatedTable;
      return updatedData;
    });
  }, []);

  const updateColumnTypeLength = useCallback((tableIndex: number, columnIndex: number, newLength: string) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      const updatedTable = { ...updatedData[tableIndex] };
      const updatedColumns = [...updatedTable.columns];
      updatedColumns[columnIndex] = { ...updatedColumns[columnIndex], typeLength: newLength };
      updatedTable.columns = updatedColumns;
      updatedData[tableIndex] = updatedTable;
      return updatedData;
    });
  }, []);

  const addColumn = useCallback((tableIndex: number) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      const updatedTable = { ...updatedData[tableIndex] };
      const updatedColumns = [...updatedTable.columns];
      updatedColumns.push({
        name: 'new_column',
        type: 'VARCHAR',
        typeLength: '255'
      });
      updatedTable.columns = updatedColumns;
      updatedData[tableIndex] = updatedTable;
      return updatedData;
    });
  }, []);

  const removeColumn = useCallback((tableIndex: number, columnIndex: number) => {
    setSchemaData(prevData => {
      const updatedData = [...prevData];
      const updatedTable = { ...updatedData[tableIndex] };
      const updatedColumns = [...updatedTable.columns];
      updatedColumns.splice(columnIndex, 1);
      updatedTable.columns = updatedColumns;
      updatedData[tableIndex] = updatedTable;
      return updatedData;
    });
  }, []);

  const addTable = useCallback(() => {
    const newTable: TableSchema = {
      table_name: 'new_table',
      columns: [
        {
          name: 'id',
          type: 'INT',
          typeLength: '64'
        }
      ],
      record_count: 0
    };
    setSchemaData(prevData => [...prevData, newTable]);
  }, []);

  const removeTable = useCallback((tableIndex: number) => {
    setSchemaData(prevData => prevData.filter((_, index) => index !== tableIndex));
  }, []);

  const resetChanges = useCallback(() => {
    if (originalSchemaData) {
      setSchemaData([...originalSchemaData]);
    }
  }, [originalSchemaData]);

  // Auto-load JSON file when selected
  useEffect(() => {
    if (selectedJsonFile) {
      loadJsonFile(selectedJsonFile);
    }
  }, [selectedJsonFile]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        if (selectedJsonFile && schemaData.length > 0 && !isSavingJson) {
          saveJsonFile();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedJsonFile, schemaData, isSavingJson]);

  return (
    <>
      <style>{`
        .data-type-select [data-radix-select-trigger] {
          background-color: white !important;
          color: #1e293b !important;
          border: 1px solid #cbd5e1 !important;
        }
        .data-type-select [data-radix-select-value] {
          color: #1e293b !important;
        }
        .data-type-select [data-radix-select-content] {
          background-color: white !important;
          border: 1px solid #cbd5e1 !important;
        }
        .data-type-select [data-radix-select-item] {
          background-color: white !important;
          color: #1e293b !important;
        }
        .data-type-select [data-radix-select-item]:hover {
          background-color: #f1f5f9 !important;
        }
        .data-type-select button {
          background-color: white !important;
          color: #1e293b !important;
          border-color: #cbd5e1 !important;
        }
        .data-type-select span {
          color: #1e293b !important;
        }
      `}</style>
      <div className="space-y-6 relative pr-0 md:pr-64 lg:pr-72">
      {/* Sticky Generate IA Schema Button - Right Corner */}
      {schemaData.length > 0 && (
        <div className="fixed top-24 right-4 lg:right-6 z-50 hidden md:block">
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 border-2 border-blue-300 rounded-xl shadow-xl p-3 w-56">
            <div className="text-center mb-3">
              <div className="text-sm text-blue-800 font-semibold">
                {schemaData.length} table(s) ready
              </div>
              <div className="text-xs text-blue-600 mt-1">
                Ready for IA generation
              </div>
            </div>
            <Button 
              onClick={handleDAGRun2}
              disabled={isFinalizing || schemaData.length === 0}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 disabled:opacity-50 text-xs px-2 py-3 h-auto min-h-[40px]"
              size="sm"
            >
              <div className="flex flex-col items-center justify-center gap-1">
                {isFinalizing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                <span className="font-medium text-center leading-tight">
                  Generate IA Schema
                </span>
              </div>
            </Button>
          </div>
        </div>
      )}

      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Validate and Finalize Schema</h2>
          <p className="text-sm text-gray-600 mt-1">
            Configure schema settings and validate table information for InfoArchive processing from JSON files
          </p>
        </div>
        <div className="flex flex-col items-end space-y-1 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>Step 2.1 of 5</span>
          </div>
          <div className="text-xs">Validate & Finalize Schema</div>
        </div>
      </div>

      {/* Schema Configuration (Non-Editable) */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Schema Configuration
            <Badge variant="outline" className="ml-2 text-red-600 border-red-200">
              Non-Editable
            </Badge>
            {workflow.schemaConfig && (
              <Badge variant="outline" className="ml-2 text-green-600 border-green-200">
                From Step 2
              </Badge>
            )}
          </CardTitle>
          {workflow.schemaConfig && (
            <p className="text-sm text-green-600 mt-1">
              ✅ Schema configuration successfully loaded from Generate IA Table Schema
            </p>
          )}
          {!workflow.schemaConfig && (
            <p className="text-sm text-orange-600 mt-1">
              ⚠️ Using default schema configuration. Please ensure Step 2 was completed properly.
            </p>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-medium text-gray-700">
                Application Name
              </Label>
              <Input
                value={schemaConfig.applicationName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                Default Schema Name
              </Label>
              <Input
                value={schemaConfig.defaultSchemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                Locale
              </Label>
              <Input
                value={schemaConfig.locale}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                Schema Name
              </Label>
              <Input
                value={schemaConfig.schemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced JSON Table Viewer */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Database className="mr-2 h-5 w-5" />
            JSON Table Viewer & Editor
            <Badge variant="outline" className="ml-2 text-blue-600 border-blue-200">
              Editable
            </Badge>
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">
            Load, view, and edit JSON files from the network path with enhanced table functionality
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Selection */}
          <div className="flex items-center space-x-4">
            <Button
              onClick={loadAvailableJsonFiles}
              disabled={isLoadingFiles}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoadingFiles ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              <span>Refresh Files</span>
            </Button>
            
            {/* Latest JSON File Display */}
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4 text-slate-500" />
              <div className="flex flex-col">
                <span className="text-sm font-medium text-slate-700">Latest JSON File:</span>
                <span className="text-sm text-blue-600 truncate max-w-48 font-medium">
                  {availableJsonFiles.length > 0 ? availableJsonFiles[0] : 'No files available'}
                </span>
              </div>
            </div>
            
            <Button
              onClick={() => loadJsonFile(availableJsonFiles[0])}
              disabled={!availableJsonFiles.length || isLoadingJson}
              variant="outline"
            >
              {isLoadingJson ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <FileText className="h-4 w-4 mr-2" />
              )}
              Load Latest JSON
            </Button>
            
            <Button
              onClick={saveJsonFile}
              disabled={!selectedJsonFile || schemaData.length === 0 || isSavingJson}
              variant="outline"
            >
              {isSavingJson ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Save JSON
            </Button>
            
            <Button
              onClick={() => setIsEditingMode(!isEditingMode)}
              variant={isEditingMode ? "default" : "outline"}
              className={`flex items-center space-x-2 ${isEditingMode ? "text-white" : ""}`}
            >
              <Edit3 className="h-4 w-4" />
              <span>{isEditingMode ? "Exit Edit" : "Edit Mode"}</span>
            </Button>
          </div>

          {/* File Information with Enhanced Stats */}
          {selectedJsonFile && (
            <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-2 lg:space-y-0">
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1 min-w-0">
                    <FileText className="h-4 w-4 flex-shrink-0" />
                    <span className="font-medium truncate max-w-xs" title={selectedJsonFile}>{selectedJsonFile}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Database className="h-4 w-4" />
                    <span>{schemaData.length} tables</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <span>{schemaData.reduce((sum, table) => sum + table.columns.length, 0)} total columns</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <span>{schemaData.reduce((sum, table) => sum + table.record_count, 0).toLocaleString()} total records</span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {hasChanges && (
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-orange-600 border-orange-200 animate-pulse">
                        {schemaData.filter((_, index) => tableHasChanges(index)).length} tables modified
                      </Badge>
                      <Button
                        onClick={saveJsonFile}
                        size="sm"
                        variant="default"
                        disabled={isSavingJson}
                        className="flex items-center space-x-1 text-white"
                      >
                        {isSavingJson ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        <span>Save All</span>
                      </Button>
                    </div>
                  )}
                  {!hasChanges && (
                    <Badge variant="outline" className="text-green-600 border-green-200">
                      All changes saved
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          )}

          {availableJsonFiles.length === 0 && !isLoadingFiles && (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p>No JSON files found in the network path</p>
              <p className="text-sm">Click "Refresh Files" to check for new files</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Schema Tables Display */}
      {schemaData.length > 0 && (
        <Card className="shadow-sm border border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800 flex items-center justify-between">
              <div className="flex items-center">
                <Database className="mr-2 h-5 w-5" />
                <span>Database Schema Editor</span>
                <Badge variant="outline" className="ml-2 text-blue-600 border-blue-200">
                  {schemaData.length} Tables
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  onClick={addTable}
                  size="sm"
                  disabled={!isEditingMode}
                  className="flex items-center space-x-1 bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Table</span>
                </Button>
                {hasChanges && (
                  <Button
                    onClick={resetChanges}
                    size="sm"
                    variant="outline"
                    className="flex items-center space-x-1"
                  >
                    <X className="h-4 w-4" />
                    <span>Reset</span>
                  </Button>
                )}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {schemaData.slice(
              (currentPage - 1) * tablesPerPage,
              currentPage * tablesPerPage
            ).map((table, tableIndex) => {
              const actualTableIndex = (currentPage - 1) * tablesPerPage + tableIndex;
              return (
                <div key={actualTableIndex} className="border rounded-lg p-4 bg-white shadow-sm" style={{ boxSizing: 'border-box' }}>
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4 space-y-2 lg:space-y-0" style={{ boxSizing: 'border-box' }}>
                    <div className="flex flex-col lg:flex-row lg:items-center lg:space-x-4 space-y-2 lg:space-y-0" style={{ boxSizing: 'border-box' }}>
                      <div className="flex items-center space-x-2" style={{ boxSizing: 'border-box' }}>
                        <label className="text-sm font-medium text-gray-700 whitespace-nowrap">Table:</label>
                        {isEditingMode ? (
                          <Input
                            value={table.table_name}
                            onChange={(e) => updateTableName(actualTableIndex, e.target.value)}
                            className="h-8 w-48 font-semibold"
                            style={{ color: '#1f2937', borderColor: '#d1d5db', boxSizing: 'border-box' }}
                          />
                        ) : (
                          <span className="font-semibold text-lg text-blue-600">{table.table_name}</span>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <label className="text-sm font-medium text-gray-700 whitespace-nowrap">Records:</label>
                        {isEditingMode ? (
                          <Input
                            type="number"
                            value={table.record_count}
                            onChange={(e) => updateRecordCount(actualTableIndex, parseInt(e.target.value) || 0)}
                            className="h-8 w-24"
                          />
                        ) : (
                          <span className="font-medium text-green-600">{table.record_count.toLocaleString()}</span>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-blue-600 border-blue-200">
                          {table.columns.length} columns
                        </Badge>
                        {tableHasChanges(actualTableIndex) && (
                          <Badge variant="outline" className="text-orange-600 border-orange-200 animate-pulse">
                            Modified
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 flex-wrap">
                      {/* Save Button - Added before Add Column as per requirement */}
                      <Button
                        onClick={() => saveIndividualTable(actualTableIndex)}
                        size="sm"
                        variant="default"
                        disabled={!isEditingMode || savingTables[actualTableIndex]}
                        className="flex items-center space-x-1 bg-green-600 hover:bg-green-700 text-white"
                      >
                        {savingTables[actualTableIndex] ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        <span>Save</span>
                      </Button>
                      
                      <Button
                        onClick={() => addColumn(actualTableIndex)}
                        size="sm"
                        disabled={!isEditingMode}
                        variant="outline"
                        className="flex items-center space-x-1"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Add Column</span>
                      </Button>
                      {/* Remove the duplicate save button that only shows when changes exist */}
                      {false && isEditingMode && tableHasChanges(actualTableIndex) && (
                        <Button
                          onClick={() => saveIndividualTable(actualTableIndex)}
                          size="sm"
                          variant="default"
                          disabled={savingTables[actualTableIndex]}
                          className="flex items-center space-x-1 bg-green-600 hover:bg-green-700 text-white"
                        >
                          {savingTables[actualTableIndex] ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Save className="h-4 w-4" />
                          )}
                          <span>{savingTables[actualTableIndex] ? 'Saving...' : 'Save Table'}</span>
                        </Button>
                      )}
                      {isEditingMode && (
                        <Button
                          onClick={() => removeTable(actualTableIndex)}
                          size="sm"
                          variant="outline"
                          className="flex items-center space-x-1 text-red-600 border-red-200 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                          <span>Remove</span>
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Enhanced JSON Table with improved styling */}
                  <div className="border border-slate-300 rounded-lg overflow-hidden bg-white shadow-sm" style={{ minHeight: '300px', height: '400px' }}>
                    <div 
                      className="overflow-x-auto overflow-y-auto h-full scrollbar-thin scrollbar-thumb-slate-400 scrollbar-track-slate-100" 
                      style={{ 
                        width: '100%', 
                        height: '100%',
                        position: 'relative'
                      }}
                    >
                      <SimpleTable 
                        table={table} 
                        actualTableIndex={actualTableIndex} 
                        isEditingMode={isEditingMode}
                        updateColumnName={updateColumnName}
                        updateColumnType={updateColumnType}
                        updateColumnTypeLength={updateColumnTypeLength}
                        removeColumn={removeColumn}
                        getTablePage={getTablePage}
                        rowsPerTable={rowsPerTable}
                      />
                    </div>
                  </div>

                  {/* Individual Table Pagination */}
                  {table.columns.length > rowsPerTable && (
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200 bg-slate-50 rounded-b-lg px-4 py-3">
                      <div className="text-sm text-slate-600">
                        Showing {((getTablePage(actualTableIndex) - 1) * rowsPerTable) + 1} to {Math.min(getTablePage(actualTableIndex) * rowsPerTable, table.columns.length)} of {table.columns.length} columns
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          onClick={() => setTablePage(actualTableIndex, Math.max(1, getTablePage(actualTableIndex) - 1))}
                          disabled={getTablePage(actualTableIndex) === 1}
                          variant="outline"
                          size="sm"
                          className="flex items-center space-x-1 border-slate-300 text-slate-700 hover:bg-slate-100"
                        >
                          <ArrowLeft className="h-4 w-4" />
                          <span>Previous</span>
                        </Button>
                        <div className="flex items-center space-x-1">
                          <span className="text-sm text-slate-600 font-medium">
                            Page {getTablePage(actualTableIndex)} of {Math.ceil(table.columns.length / rowsPerTable)}
                          </span>
                        </div>
                        <Button
                          onClick={() => setTablePage(actualTableIndex, Math.min(Math.ceil(table.columns.length / rowsPerTable), getTablePage(actualTableIndex) + 1))}
                          disabled={getTablePage(actualTableIndex) === Math.ceil(table.columns.length / rowsPerTable)}
                          variant="outline"
                          size="sm"
                          className="flex items-center space-x-1 border-slate-300 text-slate-700 hover:bg-slate-100"
                        >
                          <span>Next</span>
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            {/* Pagination Controls */}
            {schemaData.length > tablesPerPage && (
              <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-200">
                <div className="text-sm text-slate-600">
                  Showing {((currentPage - 1) * tablesPerPage) + 1} to {Math.min(currentPage * tablesPerPage, schemaData.length)} of {schemaData.length} tables
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                    variant="outline"
                    size="sm"
                    className="border-slate-300 text-slate-700 hover:bg-slate-100"
                  >
                    Previous
                  </Button>
                  <span className="text-sm text-slate-600 font-medium px-3">
                    Page {currentPage} of {Math.ceil(schemaData.length / tablesPerPage)}
                  </span>
                  <Button
                    onClick={() => setCurrentPage(prev => Math.min(Math.ceil(schemaData.length / tablesPerPage), prev + 1))}
                    disabled={currentPage === Math.ceil(schemaData.length / tablesPerPage)}
                    variant="outline"
                    size="sm"
                    className="border-slate-300 text-slate-700 hover:bg-slate-100"
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-6">
        <Button
          onClick={onPrev}
          variant="outline"
          disabled={isFinalizing}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Step 2</span>
        </Button>

        <div className="flex space-x-3">
          <Button
            onClick={handleDAGRun2}
            disabled={isFinalizing || schemaData.length === 0}
            className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isFinalizing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            <span>Generate IA Schema</span>
          </Button>
        </div>
      </div>
    </div>
    </>
  );
}
