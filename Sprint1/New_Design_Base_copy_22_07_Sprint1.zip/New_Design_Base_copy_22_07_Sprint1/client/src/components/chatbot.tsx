import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Minimize2, 
  Maximize2,
  X,
  Loader2,
  RefreshCw,
  Settings,
  Database,
  FileText,
  BarChart3,
  AlertCircle,
  Move
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useClientConfig } from "@/hooks/use-client-config";
import { BotIcon } from "@/components/ui/bot-icon";

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  metadata?: {
    dagCount?: number;
    runCount?: number;
    suggestions?: string[];
  };
}

interface ChatbotState {
  isOpen: boolean;
  isMinimized: boolean;
  isLoading: boolean;
  messages: Message[];
  currentInput: string;
  position: { x: number; y: number };
  isDragging: boolean;
}

interface DashboardContext {
  dags: any[];
  totalDags: number;
  runningDags: number;
  pausedDags: number;
  recentRuns: any[];
  connectionStatus: boolean;
}

export function Chatbot() {
  const clientConfig = useClientConfig();
  const [state, setState] = useState<ChatbotState>({
    isOpen: false,
    isMinimized: false,
    isLoading: false,
    messages: [],
    currentInput: '',
    position: { x: 0, y: 0 }, // Will be set by useEffect
    isDragging: false
  });

  const [dashboardContext, setDashboardContext] = useState<DashboardContext>({
    dags: [],
    totalDags: 0,
    runningDags: 0,
    pausedDags: 0,
    recentRuns: [],
    connectionStatus: false
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number } | null>(null);
  const { toast } = useToast();
  const airflowApi = useAirflowApi();

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [state.messages]);

  // Focus input when chatbot opens
  useEffect(() => {
    if (state.isOpen && !state.isMinimized) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [state.isOpen, state.isMinimized]);

  // Load dashboard context
  useEffect(() => {
    loadDashboardContext();
  }, []);

  // Handle positioning and cleanup
  useEffect(() => {
    // Set initial position for chat box (bottom-right with better spacing)
    const setInitialPosition = () => {
      const chatWidth = window.innerWidth < 640 ? 280 : 400;
      const chatHeight = window.innerWidth < 640 ? 350 : 450;
      
      // Calculate safe bottom position accounting for page content
      const viewportHeight = window.innerHeight;
      const documentHeight = Math.max(
        document.body.scrollHeight,
        document.body.offsetHeight,
        document.documentElement.clientHeight,
        document.documentElement.scrollHeight,
        document.documentElement.offsetHeight
      );
      
      // Position from bottom of viewport with additional spacing
      const bottomSpacing = 80; // Extra spacing to avoid overlapping with page buttons
      const rightSpacing = 20;
      
      setState(prev => {
        // If chat is open, keep current position but ensure it's within bounds
        if (prev.isOpen) {
          return {
            ...prev,
            position: {
              x: Math.max(rightSpacing, Math.min(window.innerWidth - chatWidth - rightSpacing, prev.position.x)),
              y: Math.max(20, Math.min(viewportHeight - chatHeight - bottomSpacing, prev.position.y))
            }
          };
        }
        // If chat is closed, set default bottom-right position with spacing
        return {
          ...prev,
          position: {
            x: Math.max(rightSpacing, window.innerWidth - chatWidth - rightSpacing),
            y: Math.max(20, viewportHeight - chatHeight - bottomSpacing)
          }
        };
      });
    };
    
    setInitialPosition();
    window.addEventListener('resize', setInitialPosition);
    
    // Cleanup event listeners
    return () => {
      window.removeEventListener('resize', setInitialPosition);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [state.isOpen]);

  const loadDashboardContext = async () => {
    try {
      const dags = await airflowApi.getDags(true); // Force refresh
      const connectionTest = await airflowApi.testConnection();
      
      if (dags?.dags) {
        const runningDags = dags.dags.filter((dag: any) => !dag.is_paused).length;
        const pausedDags = dags.dags.filter((dag: any) => dag.is_paused).length;
        const recentRuns = dags.dags.flatMap((dag: any) => dag.recent_runs || []).slice(0, 10);

        setDashboardContext({
          dags: dags.dags,
          totalDags: dags.dags.length,
          runningDags,
          pausedDags,
          recentRuns,
          connectionStatus: connectionTest?.connected || false
        });
      }
    } catch (error) {
      console.error('Failed to load dashboard context:', error);
    }
  };

  const generateSystemPrompt = (context: DashboardContext): string => {
    return `You are TCS ECM Airflow Assistant, an AI helper for the TCS ECM Airflow DAG Generator application.

CURRENT DASHBOARD STATUS:
- Total Workspace: ${context.totalDags}
- Running DAGs: ${context.runningDags}
- Paused DAGs: ${context.pausedDags}
- Airflow Connection: ${context.connectionStatus ? 'Connected' : 'Disconnected'}
- Recent Runs: ${context.recentRuns.length} recent executions

DAG DETAILS:
${context.dags.map(dag => `- ${dag.dag_id}: ${dag.is_paused ? 'Paused' : 'Active'} (${dag.recent_runs?.length || 0} recent runs)`).join('\n')}

You can help users with:
1. Dashboard insights and DAG status explanations
2. Airflow concepts and troubleshooting
3. DAG configuration and best practices
4. File upload and CSV to XML conversion guidance
5. Workflow automation suggestions
6. Performance optimization tips

Keep responses concise, helpful, and focused on Airflow/ETL workflows. If users ask about specific DAGs, refer to the current dashboard data above.`;
  };

  const callLLM = async (userMessage: string, context: DashboardContext): Promise<string> => {
    try {
      // Try Ollama first (local LLM)
      const ollamaResponse = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'llama3.2', // or 'mistral', 'codellama', etc.
          prompt: `${generateSystemPrompt(context)}\n\nUser: ${userMessage}\nAssistant:`,
          stream: false,
          options: {
            temperature: 0.7,
            max_tokens: 500
          }
        })
      });

      if (ollamaResponse.ok) {
        const data = await ollamaResponse.json();
        return data.response || 'I apologize, but I received an empty response.';
      }
    } catch (ollamaError) {
      console.log('Ollama not available, trying fallback...');
    }

    // Fallback to your backend LLM service
    try {
      const backendResponse = await fetch('/api/chatbot/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          context: context,
          systemPrompt: generateSystemPrompt(context)
        })
      });

      if (backendResponse.ok) {
        const data = await backendResponse.json();
        return data.response || 'I apologize, but I received an empty response.';
      }
    } catch (backendError) {
      console.log('Backend LLM not available...');
    }

    // Final fallback - rule-based responses
    return generateFallbackResponse(userMessage, context);
  };

  const generateFallbackResponse = (userMessage: string, context: DashboardContext): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('dag') && message.includes('count')) {
      return `You currently have ${context.totalDags} DAGs in total: ${context.runningDags} active and ${context.pausedDags} paused.`;
    }
    
    if (message.includes('status') || message.includes('dashboard')) {
      return `Dashboard Status:\n• Total Workspace: ${context.totalDags}\n• Active: ${context.runningDags}\n• Paused: ${context.pausedDags}\n• Connection: ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}\n• Recent Runs: ${context.recentRuns.length}`;
    }
    
    if (message.includes('help') || message.includes('what can you do')) {
      return `I can help you with:\n• Dashboard insights and Workspace status\n• Airflow troubleshooting\n• CSV to XML conversion guidance\n• Workflow automation tips\n• Performance optimization\n\nTry asking: "What's my dashboard status?" or "How do I create a Workspace?"`;
    }
    
    if (message.includes('create') && message.includes('dag')) {
      return `To create a new DAG:\n1. Go to Upload section\n2. Upload your CSV file\n3. Configure DAG settings\n4. Generate and deploy\n\nYour current DAGs: ${context.dags.map(d => d.dag_id).join(', ')}`;
    }
    
    if (message.includes('connection') || message.includes('airflow')) {
      return `Airflow Connection: ${context.connectionStatus ? 'Connected ✅' : 'Disconnected ❌'}\n\nIf disconnected, ensure Airflow is running at ${clientConfig.airflowUrl}`;
    }
    
    return `I understand you're asking about: "${userMessage}"\n\nI can help with dashboard status, Workspace management, and Airflow workflows. Try asking more specific questions about your ${context.totalDags} Workspaces or workflow automation.`;
  };

  const handleSendMessage = async () => {
    const userMessage = state.currentInput.trim();
    if (!userMessage) return;

    const userMsgId = Date.now().toString();
    const userMsg: Message = {
      id: userMsgId,
      type: 'user',
      content: userMessage,
      timestamp: new Date()
    };

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMsg],
      currentInput: '',
      isLoading: true
    }));

    try {
      // Refresh dashboard context for latest data
      await loadDashboardContext();
      
      const botResponse = await callLLM(userMessage, dashboardContext);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: botResponse,
        timestamp: new Date(),
        metadata: {
          dagCount: dashboardContext.totalDags,
          runCount: dashboardContext.recentRuns.length,
          suggestions: generateSuggestions(userMessage)
        }
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, botMsg],
        isLoading: false
      }));

    } catch (error) {
      console.error('Chat error:', error);
      
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: 'I apologize, but I encountered an error. Please try again or check your connection.',
        timestamp: new Date()
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, errorMsg],
        isLoading: false
      }));

      toast({
        title: "Chat Error",
        description: "Unable to process your message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const generateSuggestions = (userMessage: string): string[] => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('dag')) {
      return [
        "Show me DAG performance metrics",
        "How do I troubleshoot failed DAGs?",
        "Best practices for DAG scheduling"
      ];
    }
    
    if (message.includes('upload') || message.includes('csv')) {
      return [
        "What CSV format is supported?",
        "How to handle large CSV files?",
        "XML output customization options"
      ];
    }

    // NEW: Add reports-specific suggestions
    if (message.includes('report') || message.includes('analytics') || message.includes('intelligence')) {
      return [
        "What types of reports are available?",
        "How do I view business intelligence?",
        "Show me analytics dashboard features"
      ];
    }

    if (message.includes('dashboard')) {
      return [
        "Show me reports section",
        "What analytics are available?",
        "DAG performance overview"
      ];
    }
    
    return [
      "What's my dashboard status?",
      "Show me reports and analytics",
      "How do I create a new DAG?",
      "View business intelligence features"
    ];
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Drag functionality
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!cardRef.current) return;
    
    setState(prev => ({ ...prev, isDragging: true }));
    
    const rect = cardRef.current.getBoundingClientRect();
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: rect.left,
      initialY: rect.top
    };
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    e.preventDefault();
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!dragRef.current || !state.isDragging) return;
    
    const deltaX = e.clientX - dragRef.current.startX;
    const deltaY = e.clientY - dragRef.current.startY;
    
    // Get chat box dimensions for better boundary calculations
    const chatWidth = window.innerWidth < 640 ? 280 : window.innerWidth < 1024 ? 350 : 400;
    const chatHeight = window.innerWidth < 640 ? 350 : window.innerWidth < 1024 ? 400 : 450;
    
    // Add bottom spacing to prevent overlapping with page buttons
    const bottomSpacing = 80;
    const rightSpacing = 20;
    
    const newX = Math.max(rightSpacing, Math.min(window.innerWidth - chatWidth - rightSpacing, dragRef.current.initialX + deltaX));
    const newY = Math.max(20, Math.min(window.innerHeight - chatHeight - bottomSpacing, dragRef.current.initialY + deltaY));
    
    setState(prev => ({
      ...prev,
      position: { x: newX, y: newY }
    }));
  };

  const handleMouseUp = () => {
    setState(prev => ({ ...prev, isDragging: false }));
    dragRef.current = null;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const toggleChatbot = () => {
    setState(prev => ({ ...prev, isOpen: !prev.isOpen }));
    if (!state.isOpen && state.messages.length === 0) {
      // Add welcome message with enhanced reports info
      const welcomeMsg: Message = {
        id: 'welcome',
        type: 'bot',
        content: `Hello! I'm your TCS ECM Airflow Assistant. I can help you with:

• **Dashboard**: Monitor your ${dashboardContext.totalDags} DAGs and workflow status
• **Reports & Analytics**: View business intelligence and performance metrics  
• **DAG Management**: Create, configure, and troubleshoot workflows
• **Data Processing**: CSV to XML conversion guidance
• **System Support**: Performance optimization and troubleshooting

What would you like to know?`,
        timestamp: new Date(),
        metadata: {
          dagCount: dashboardContext.totalDags,
          suggestions: [
            "What's my dashboard status?",
            "Show me reports and analytics",
            "How do I create a DAG?",
            "View business intelligence features"
          ]
        }
      };
      
      setState(prev => ({ ...prev, messages: [welcomeMsg] }));
    }
  };

  const toggleMinimize = () => {
    setState(prev => ({ ...prev, isMinimized: !prev.isMinimized }));
  };

  const clearChat = () => {
    setState(prev => ({ ...prev, messages: [] }));
  };

  const refreshContext = async () => {
    await loadDashboardContext();
    toast({
      title: "Context Refreshed",
      description: "Dashboard data has been updated for the chatbot.",
    });
  };

  if (!state.isOpen) {
    return (
      <Button
        onClick={toggleChatbot}
        className="fixed bottom-20 right-6 z-40 h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg transition-all duration-300"
        style={{
          bottom: '80px', // Ensure it's positioned well above any page buttons
        }}
      >
        <BotIcon size={20} className="text-white" />
      </Button>
    );
  }

  return (
    <Card 
      ref={cardRef}
      className={`fixed z-40 shadow-xl transition-all duration-300 select-none ${
        state.isMinimized ? 'h-12 w-64 sm:w-72' : 'h-80 w-64 sm:h-96 sm:w-80 lg:h-[400px] lg:w-96'
      } ${state.isDragging ? 'cursor-grabbing' : ''}`}
      style={{
        top: `${state.position.y}px`,
        left: `${state.position.x}px`,
      }}
    >
      <CardHeader 
        className="flex flex-row items-center justify-between p-2 sm:p-3 pb-1 cursor-grab active:cursor-grabbing hover:bg-gray-50 rounded-t-lg transition-colors border-b"
        onMouseDown={handleMouseDown}
        title="Drag to move chat box"
      >
        <div className="flex items-center space-x-1 sm:space-x-2">
          <Move className="h-3 w-3 sm:h-4 sm:w-4 text-gray-400" />
          <Bot className="h-3 w-3 sm:h-4 sm:w-4 text-blue-600" />
          <CardTitle className="text-sm sm:text-base">Buddy</CardTitle>
          {dashboardContext.connectionStatus && (
            <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-blue-500 rounded-full"></div>
          )}
        </div>
        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="sm" onClick={refreshContext} className="h-6 w-6 sm:h-8 sm:w-8 p-0">
            <RefreshCw className="h-3 w-3 sm:h-4 sm:w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleMinimize} className="h-6 w-6 sm:h-8 sm:w-8 p-0">
            {state.isMinimized ? <Maximize2 className="h-3 w-3 sm:h-4 sm:w-4" /> : <Minimize2 className="h-3 w-3 sm:h-4 sm:w-4" />}
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleChatbot} className="h-6 w-6 sm:h-8 sm:w-8 p-0">
            <X className="h-3 w-3 sm:h-4 sm:w-4" />
          </Button>
        </div>
      </CardHeader>

      {!state.isMinimized && (
        <CardContent className="flex flex-col h-full p-2 sm:p-3 pt-0">
          {/* Dashboard Status Bar */}
          <div className="flex items-center justify-between text-xs bg-gray-50 p-1.5 sm:p-2 rounded mb-2 sm:mb-3">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <span className="flex items-center">
                <Database className="h-2.5 w-2.5 sm:h-3 sm:w-3 mr-1" />
                <span className="text-xs">{dashboardContext.totalDags}</span>
              </span>
              <span className="flex items-center">
                <BarChart3 className="h-2.5 w-2.5 sm:h-3 sm:w-3 mr-1" />
                <span className="text-xs">{dashboardContext.runningDags}</span>
              </span>
              {!dashboardContext.connectionStatus && (
                <span className="flex items-center text-red-600">
                  <AlertCircle className="h-2.5 w-2.5 sm:h-3 sm:w-3 mr-1" />
                  <span className="text-xs hidden sm:inline">Offline</span>
                </span>
              )}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-2 mb-2 sm:mb-3 max-h-48 sm:max-h-64 lg:max-h-80">
            {state.messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-2 sm:p-2.5 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-blue-600 text-white ml-2'
                      : 'bg-gray-100 text-gray-900 mr-2'
                  }`}
                >
                  <div className="flex items-start space-x-1 sm:space-x-2">
                    {message.type === 'bot' && <Bot className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0" />}
                    {message.type === 'user' && <User className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0" />}
                    <div className="flex-1">
                      <p className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                      {message.metadata?.suggestions && (
                        <div className="mt-1.5 sm:mt-2 space-y-1">
                          {message.metadata.suggestions.slice(0, 2).map((suggestion, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className="text-xs h-5 sm:h-6 w-full"
                              onClick={() => setState(prev => ({ ...prev, currentInput: suggestion }))}
                            >
                              {suggestion}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            
            {state.isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 text-gray-900 p-2 sm:p-2.5 rounded-lg mr-2">
                  <div className="flex items-center space-x-1 sm:space-x-2">
                    <Bot className="h-3 w-3 sm:h-4 sm:w-4" />
                    <Loader2 className="h-3 w-3 sm:h-4 sm:w-4 animate-spin" />
                    <span className="text-xs sm:text-sm">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="flex space-x-1 sm:space-x-2">
            <Input
              ref={inputRef}
              value={state.currentInput}
              onChange={(e) => setState(prev => ({ ...prev, currentInput: e.target.value }))}
              onKeyPress={handleKeyPress}
              placeholder="Ask about DAGs..."
              disabled={state.isLoading}
              className="flex-1 text-xs sm:text-sm h-7 sm:h-8"
            />
            <Button 
              onClick={handleSendMessage} 
              disabled={state.isLoading || !state.currentInput.trim()}
              size="sm"
              className="h-7 w-7 sm:h-8 sm:w-8 p-0"
            >
              <Send className="h-3 w-3 sm:h-4 sm:w-4" />
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="flex justify-center mt-1 sm:mt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={clearChat}
              className="text-xs h-6 sm:h-7"
            >
              Clear
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
