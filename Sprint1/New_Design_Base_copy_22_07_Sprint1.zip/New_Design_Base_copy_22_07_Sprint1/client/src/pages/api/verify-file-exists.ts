// pages/api/verify-file-exists.ts
// This API endpoint is missing - that's why verification is failing

import { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  console.log('=== VERIFY FILE EXISTS API CALLED ===');
  console.log('Method:', req.method);
  console.log('Body:', req.body);

  if (req.method !== 'POST') {
    return res.status(405).json({ 
      success: false, 
      message: 'Method not allowed',
      exists: false
    });
  }

  try {
    const { filePath } = req.body;

    if (!filePath) {
      console.log('❌ No file path provided');
      return res.status(400).json({
        exists: false,
        message: 'File path is required'
      });
    }

    console.log('🔍 Checking file existence for:', filePath);

    // Normalize the path for Windows
    const normalizedPath = path.resolve(filePath);
    console.log('📁 Normalized path:', normalizedPath);

    try {
      // Check if file exists and get stats
      const stats = fs.statSync(normalizedPath);
      console.log('✅ File exists!');
      console.log('📊 File stats:', {
        size: stats.size,
        isFile: stats.isFile(),
        isDirectory: stats.isDirectory(),
        lastModified: stats.mtime
      });
      
      return res.status(200).json({
        exists: true,
        filePath: normalizedPath,
        fileSize: stats.size,
        lastModified: stats.mtime,
        isFile: stats.isFile(),
        isDirectory: stats.isDirectory(),
        success: true
      });
      
    } catch (fileError) {
      console.log('❌ File does not exist:', normalizedPath);
      console.log('📝 Error details:', fileError);
      
      return res.status(200).json({
        exists: false,
        filePath: normalizedPath,
        message: 'File does not exist at the specified path',
        success: true
      });
    }

  } catch (error) {
    console.error('❌ API Error in verify-file-exists:', error);
    
    return res.status(500).json({
      exists: false,
      success: false,
      message: `Verification failed: ${error instanceof Error ? error.message : String(error)}`,
      error: error instanceof Error ? error.message : String(error)
    });
  }
}