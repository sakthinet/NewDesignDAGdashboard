# Fix for "process is not defined" Error

## Problem
The error `[plugin:runtime-error-plugin] process is not defined` was occurring because client-side React components were trying to access `process.env` at runtime, which is not available in the browser environment.

## Root Cause
In our configuration migration, we introduced direct `process.env` access in client-side code:
```typescript
// ❌ This causes "process is not defined" error in browser
url: process.env.NEXT_PUBLIC_AIRFLOW_URL || 'http://localhost:8080'
```

## Solution
We implemented a client-safe configuration system that avoids runtime `process.env` access:

### 1. Created Client-Safe Configuration Hook
**File**: `client/src/hooks/use-client-config.ts`
- Uses `import.meta.env` for Vite environment variables (build-time)
- Provides static configuration that's safe for client-side use
- No runtime `process.env` access

### 2. Updated Environment Variables
**File**: `.env`
- Added `VITE_` prefixed variables for client-side access
- Kept `NEXT_PUBLIC_` variables for compatibility
- Environment variables are now embedded at build time

### 3. Updated Client Components
**Files**: 
- `client/src/pages/dag-generator.tsx` 
- `temp/ia-table-schema-generator.tsx`

**Changes**:
- Removed direct `process.env` access
- Use `getAirflowUrl()` function from client config
- Fallback to safe default values

### 4. Updated Configuration Utilities
**File**: `shared/config.ts`
- Added browser environment detection
- Prevents client-side `process.env` access in logging
- Safe for both server and client import

## Key Changes Made

### Before (❌ Broken):
```typescript
// This fails in browser
const [connectionStatus, setConnectionStatus] = useState({
  connected: false,
  url: process.env.NEXT_PUBLIC_AIRFLOW_URL || 'http://localhost:8080',
  // ...
});
```

### After (✅ Fixed):
```typescript
import { getAirflowUrl } from "@/hooks/use-client-config";

const [connectionStatus, setConnectionStatus] = useState({
  connected: false,
  url: getAirflowUrl(), // Safe client-side function
  // ...
});
```

## Environment Variable Strategy

### For Server-Side Code:
```bash
# Use regular environment variables
AIRFLOW_URL=http://10.73.88.101:8080
AIRFLOW_DATA_DIR=\\\\10.73.88.101\\data\\incomingcsv
```

### For Client-Side Code:
```bash
# Use VITE_ prefixed variables (embedded at build time)
VITE_AIRFLOW_URL=http://10.73.88.101:8080
VITE_AIRFLOW_INCOMING_CSV_DIR=\\\\10.73.88.101\\data\\incomingcsv
```

## Configuration Access Patterns

### Server-Side:
```typescript
import { getServerConfig } from "@shared/config";
const config = getServerConfig();
const airflowUrl = config.url; // From process.env
```

### Client-Side:
```typescript
import { getAirflowUrl, useClientConfig } from "@/hooks/use-client-config";
const airflowUrl = getAirflowUrl(); // From import.meta.env (build-time)
```

## Benefits of This Approach

1. **No Runtime Errors**: Eliminates "process is not defined" errors
2. **Build-Time Configuration**: Environment variables embedded during build
3. **Type Safety**: TypeScript interfaces for all configuration
4. **Separation of Concerns**: Different strategies for client vs server
5. **Fallback Values**: Safe defaults if environment variables are missing
6. **Compatibility**: Works with both Vite and other bundlers

## Testing the Fix

1. **Start the development server**: `npm run dev`
2. **Check browser console**: Should not see "process is not defined" error
3. **Test Airflow connection**: Connection status should work properly
4. **Verify paths**: File upload and processing should use correct paths

The application now has a robust, environment-aware configuration system that works properly in both browser and server environments.
