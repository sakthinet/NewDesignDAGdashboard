// Load environment variables first, before any other imports
import { config as dotenvConfig } from "dotenv";
dotenvConfig();

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { createServer } from "http";
import net from "net";
import { initializeAirflowSetup } from "./airflow-setup";
import { getUnifiedServerConfig, logUnifiedConfiguration, setViteEnvironmentVariables } from "../shared/config-unified";

// Log unified configuration on startup
logUnifiedConfiguration();

// Set VITE environment variables for client-side deployment mode awareness
setViteEnvironmentVariables();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      // Skip logging for frequent DAG runs polling requests to reduce noise
      if (path.includes('/dags/') && path.includes('/runs') && req.method === 'GET') {
        return;
      }
      
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Function to find an available port
function findAvailablePort(startPort: number): Promise<number> {
  return new Promise((resolve, reject) => {
    const tester = net.createServer()
      .once("error", (err: any) => {
        if (err.code === "EADDRINUSE") {
          resolve(findAvailablePort(startPort + 1));
        } else {
          reject(err);
        }
      })
      .once("listening", () => {
        tester.close(() => resolve(startPort));
      })
      .listen(startPort, "127.0.0.1");
  });
}

// Server startup with Airflow initialization
async function startServer() {
  try {
    // Initialize Airflow directory structure first
    log('🔧 Initializing Airflow DAG Generator setup...');
    await initializeAirflowSetup();
    log('✅ Airflow setup completed successfully!');
    
    // Register routes
    const server = await registerRoutes(app);

    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";

      res.status(status).json({ message });
      throw err;
    });

    // Setup vite/static serving
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // Dynamic port configuration
    const preferredPort = parseInt(process.env.PORT || '5000');
    let port: number;

    try {
      // Try the preferred port first
      port = await findAvailablePort(preferredPort);
      
      if (port !== preferredPort) {
        log(`⚠️ Port ${preferredPort} was not available, using port ${port} instead`);
      }
    } catch (error) {
      log(`❌ Error finding available port: ${error}`);
      // Fallback to a different range if there's an issue
      port = await findAvailablePort(3001);
    }

    server.listen(port, "127.0.0.1", () => {
      log(`🚀 Server running on http://localhost:${port}`);
      log(`📡 API available at http://localhost:${port}/api`);
      log(`🔧 Airflow DAG Generator ready!`);
      
      // If running in development, also log the local network address
      if (app.get("env") === "development") {
        try {
          const os = require('os');
          const networkInterfaces = os.networkInterfaces();
          const addresses = [];
          
          for (const name of Object.keys(networkInterfaces)) {
            for (const net of networkInterfaces[name]) {
              if (net.family === 'IPv4' && !net.internal) {
                addresses.push(`http://${net.address}:${port}`);
              }
            }
          }
          
          if (addresses.length > 0) {
            log(`🌐 Network access: ${addresses.join(', ')}`);
          }
        } catch (e) {
          // Ignore network detection errors
        }
      }
    });

    server.on('error', (err: any) => {
      if (err.code === 'EADDRINUSE') {
        log(`❌ Port ${port} is already in use`);
        log(`💡 Try running: $env:PORT = "${port + 1}"; npm start`);
      } else {
        log(`❌ Server error: ${err.message}`);
      }
      process.exit(1);
    });

  } catch (error) {
    log(`❌ Failed to start server: ${error}`);
    if (error instanceof Error) {
      log(`❌ Error details: ${error.message}`);
    }
    process.exit(1);
  }
}

// Start the server
startServer();