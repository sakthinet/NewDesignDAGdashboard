"""
IA XML Generator DAG
===================

This DAG finalizes the InfoArchive schema configuration and generates the IA XML schema files.
It processes the validated table data and schema configuration to create the final XML schema.

DAG ID: IA_XML_Generator
Purpose: Generate InfoArchive XML schema from validated table data and schema configuration
Trigger: Manual/API trigger from Step 2.1 (Validate and Finalize Schema)
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
import json
import os

# Default arguments for the DAG
default_args = {
    'owner': 'InfoArchive_Team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Create the DAG
dag = DAG(
    'IA_XML_Generator',
    default_args=default_args,
    description='Generate InfoArchive XML schema from validated table data',
    schedule_interval=None,  # Manual trigger only
    catchup=False,
    tags=['InfoArchive', 'XML', 'Schema', 'Generation'],
)

def process_schema_configuration(**context):
    """Process schema configuration and table data"""
    
    # Get configuration from DAG run
    dag_run = context.get('dag_run')
    if dag_run and dag_run.conf:
        config = dag_run.conf
        print(f"📋 Processing schema configuration...")
        print(f"Configuration: {json.dumps(config, indent=2)}")
        
        # Extract schema configuration
        schema_config = {
            'application_name': config.get('Application Name', 'InfoArchive_Application'),
            'default_schema_name': config.get('Default Schema Name', 'DefaultSchema'),
            'locale': config.get('Locale', 'en-US'),
            'schema_name': config.get('Schema Name', 'DataArchival_Schema'),
            'table_data': config.get('Table Data', [])
        }
        
        print(f"✅ Schema configuration processed:")
        print(f"   Application Name: {schema_config['application_name']}")
        print(f"   Default Schema Name: {schema_config['default_schema_name']}")
        print(f"   Locale: {schema_config['locale']}")
        print(f"   Schema Name: {schema_config['schema_name']}")
        print(f"   Table Count: {len(schema_config['table_data'])}")
        
        return schema_config
    else:
        print("⚠️ No configuration found in DAG run")
        return {}

def generate_xml_schema(**context):
    """Generate the InfoArchive XML schema files"""
    
    # Get the schema configuration from the previous task
    task_instance = context['task_instance']
    schema_config = task_instance.xcom_pull(task_ids='process_schema_configuration')
    
    print(f"🔧 Generating XML schema files...")
    print(f"Schema Config: {json.dumps(schema_config, indent=2)}")
    
    # Generate XML schema for each table
    generated_schemas = []
    
    for table_data in schema_config.get('table_data', []):
        table_name = table_data.get('tableName', 'UnknownTable')
        record_count = table_data.get('recordCount', 0)
        data_type = table_data.get('dataType', 'VARCHAR(255)')
        
        # Generate XML schema content
        xml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<schema xmlns="http://www.w3.org/2001/XMLSchema" 
        targetNamespace="urn:{schema_config['application_name'].lower()}"
        xmlns:tns="urn:{schema_config['application_name'].lower()}"
        elementFormDefault="qualified">
  
  <annotation>
    <documentation>
      InfoArchive Schema for {table_name}
      Generated from validated table data
      Application: {schema_config['application_name']}
      Schema: {schema_config['schema_name']}
      Locale: {schema_config['locale']}
      Record Count: {record_count}
    </documentation>
  </annotation>
  
  <!-- Root element for the table -->
  <element name="{table_name}" type="tns:{table_name}Type"/>
  
  <!-- Complex type definition for the table -->
  <complexType name="{table_name}Type">
    <sequence>
      <element name="records" type="tns:RecordsType"/>
    </sequence>
  </complexType>
  
  <!-- Records collection type -->
  <complexType name="RecordsType">
    <sequence>
      <element name="record" type="tns:RecordType" maxOccurs="unbounded"/>
    </sequence>
  </complexType>
  
  <!-- Individual record type -->
  <complexType name="RecordType">
    <sequence>
      <element name="data" type="{data_type.lower()}" minOccurs="0"/>
    </sequence>
  </complexType>
  
</schema>"""
        
        schema_info = {
            'table_name': table_name,
            'xml_content': xml_content,
            'record_count': record_count,
            'data_type': data_type,
            'generated_at': datetime.now().isoformat()
        }
        
        generated_schemas.append(schema_info)
        print(f"✅ Generated XML schema for table: {table_name}")
    
    result = {
        'schemas': generated_schemas,
        'total_schemas': len(generated_schemas),
        'application_name': schema_config['application_name'],
        'schema_name': schema_config['schema_name'],
        'generated_at': datetime.now().isoformat()
    }
    
    print(f"🎉 XML schema generation completed:")
    print(f"   Total schemas generated: {len(generated_schemas)}")
    print(f"   Application: {schema_config['application_name']}")
    print(f"   Schema: {schema_config['schema_name']}")
    
    return result

def validate_xml_schemas(**context):
    """Validate the generated XML schemas"""
    
    # Get the generated schemas from the previous task
    task_instance = context['task_instance']
    schema_result = task_instance.xcom_pull(task_ids='generate_xml_schema')
    
    print(f"🔍 Validating generated XML schemas...")
    print(f"Schema Result: {json.dumps(schema_result, indent=2)}")
    
    # Simulate schema validation
    validation_results = []
    
    for schema_info in schema_result.get('schemas', []):
        table_name = schema_info['table_name']
        xml_content = schema_info['xml_content']
        
        # Basic validation checks
        is_valid = True
        validation_errors = []
        
        # Check if XML content is not empty
        if not xml_content or len(xml_content.strip()) == 0:
            is_valid = False
            validation_errors.append("XML content is empty")
        
        # Check if XML content contains required elements
        required_elements = ['schema', 'element', 'complexType']
        for element in required_elements:
            if element not in xml_content:
                is_valid = False
                validation_errors.append(f"Missing required element: {element}")
        
        validation_result = {
            'table_name': table_name,
            'is_valid': is_valid,
            'validation_errors': validation_errors,
            'validated_at': datetime.now().isoformat()
        }
        
        validation_results.append(validation_result)
        
        if is_valid:
            print(f"✅ Validation passed for table: {table_name}")
        else:
            print(f"❌ Validation failed for table: {table_name}")
            print(f"   Errors: {validation_errors}")
    
    final_validation = {
        'validation_results': validation_results,
        'total_schemas': len(validation_results),
        'valid_schemas': len([r for r in validation_results if r['is_valid']]),
        'invalid_schemas': len([r for r in validation_results if not r['is_valid']]),
        'validation_completed_at': datetime.now().isoformat()
    }
    
    print(f"🔍 XML schema validation completed:")
    print(f"   Total schemas: {final_validation['total_schemas']}")
    print(f"   Valid schemas: {final_validation['valid_schemas']}")
    print(f"   Invalid schemas: {final_validation['invalid_schemas']}")
    
    return final_validation

def finalize_ia_schemas(**context):
    """Finalize the InfoArchive schemas and prepare for deployment"""
    
    # Get results from previous tasks
    task_instance = context['task_instance']
    schema_config = task_instance.xcom_pull(task_ids='process_schema_configuration')
    generated_schemas = task_instance.xcom_pull(task_ids='generate_xml_schema')
    validation_results = task_instance.xcom_pull(task_ids='validate_xml_schemas')
    
    print(f"🔧 Finalizing InfoArchive schemas...")
    print(f"Schema Config: {json.dumps(schema_config, indent=2)}")
    print(f"Generated Schemas: {generated_schemas['total_schemas']}")
    print(f"Validation Results: {validation_results['valid_schemas']}/{validation_results['total_schemas']} valid")
    
    # Prepare final deployment package
    deployment_package = {
        'application_name': schema_config['application_name'],
        'schema_name': schema_config['schema_name'],
        'locale': schema_config['locale'],
        'schemas': generated_schemas['schemas'],
        'validation_summary': {
            'total_schemas': validation_results['total_schemas'],
            'valid_schemas': validation_results['valid_schemas'],
            'invalid_schemas': validation_results['invalid_schemas']
        },
        'deployment_ready': validation_results['invalid_schemas'] == 0,
        'finalized_at': datetime.now().isoformat()
    }
    
    print(f"✅ InfoArchive schemas finalized:")
    print(f"   Application: {deployment_package['application_name']}")
    print(f"   Schema: {deployment_package['schema_name']}")
    print(f"   Total schemas: {deployment_package['validation_summary']['total_schemas']}")
    print(f"   Deployment ready: {deployment_package['deployment_ready']}")
    
    return deployment_package

# Task 1: Process schema configuration
process_schema_configuration_task = PythonOperator(
    task_id='process_schema_configuration',
    python_callable=process_schema_configuration,
    dag=dag,
)

# Task 2: Generate XML schema
generate_xml_schema_task = PythonOperator(
    task_id='generate_xml_schema',
    python_callable=generate_xml_schema,
    dag=dag,
)

# Task 3: Validate XML schemas
validate_xml_schemas_task = PythonOperator(
    task_id='validate_xml_schemas',
    python_callable=validate_xml_schemas,
    dag=dag,
)

# Task 4: Finalize IA schemas
finalize_ia_schemas_task = PythonOperator(
    task_id='finalize_ia_schemas',
    python_callable=finalize_ia_schemas,
    dag=dag,
)

# Task 5: Log completion
log_completion_task = BashOperator(
    task_id='log_completion',
    bash_command='echo "🎉 IA XML Generator completed successfully at $(date)"',
    dag=dag,
)

# Set task dependencies
process_schema_configuration_task >> generate_xml_schema_task >> validate_xml_schemas_task >> finalize_ia_schemas_task >> log_completion_task
