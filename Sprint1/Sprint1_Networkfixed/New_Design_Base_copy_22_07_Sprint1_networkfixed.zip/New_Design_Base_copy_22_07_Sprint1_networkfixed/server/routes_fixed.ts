import express from 'express';
import multer from 'multer';
import path from 'path';
import { promises as fs } from 'fs';

const app = express();

// Environment variables
const AIRFLOW_CONFIG = {
  baseUrl: process.env.AIRFLOW_URL || 'http://localhost:8080',
  username: process.env.AIRFLOW_USERNAME || 'admin',
  password: process.env.AIRFLOW_PASSWORD || 'admin',
  authEndpoint: '/api/v1/security/login',
  apiVersion: '/api/v1'
};

// Helper function to format WSL paths
function formatWSLPath(path: string): string {
  if (path.startsWith('\\\\wsl$\\')) {
    const formattedPath = path.replace(/\\\\/g, '/').replace(/\\/g, '/');
    console.log(`🔄 Formatted WSL path: ${path} → ${formattedPath}`);
    return formattedPath;
  }
  return path;
}

// Helper function to format UNC paths
function formatUNCPath(path: string): string {
  if (path.startsWith('\\\\') && !path.startsWith('\\\\wsl$\\')) {
    const formattedPath = path.replace(/\\\\/g, '\\\\').replace(/\//g, '\\');
    console.log(`🔄 Formatted UNC path: ${path} → ${formattedPath}`);
    return formattedPath;
  }
  return path;
}

// API endpoint to check and download generated XML files
app.get("/api/xml-files/check/:fileName", async (req, res) => {
  try {
    const { fileName } = req.params;
    
    // Check both directories: incomingcsv and processedcsv
    const incomingDir = process.env.AIRFLOW_DATA_DIR || process.env.NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv';
    const processedDir = process.env.AIRFLOW_PROCESSED_CSV_DIR || process.env.NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv';
    
    const formattedIncomingDir = formatUNCPath(incomingDir);
    const formattedProcessedDir = formatUNCPath(processedDir);
    
    console.log(`🔍 Checking for XML file: ${fileName} in multiple directories:`);
    console.log(`   - Incoming: ${formattedIncomingDir}`);
    console.log(`   - Processed: ${formattedProcessedDir}`);
    
    // Look for XML files related to the CSV file
    const baseName = fileName.replace(/\.[^.]+$/, ''); // Remove file extension
    const possibleXmlFiles = [
      `${baseName}.xml`,
      `${baseName}_schema.xml`,
      `${baseName}_transformed.xml`,
      `${baseName}_dbschema.xml`,
      `dbschema.xml` // Common name for XML schema files
    ];
    
    const foundFiles = [];
    const searchDirs = [
      { path: formattedIncomingDir, label: 'incoming' },
      { path: formattedProcessedDir, label: 'processed' }
    ];
    
    for (const dir of searchDirs) {
      console.log(`🔍 Searching in ${dir.label} directory: ${dir.path}`);
      for (const xmlFile of possibleXmlFiles) {
        const xmlPath = path.join(dir.path, xmlFile);
        try {
          const stats = await fs.stat(xmlPath);
          if (stats.isFile()) {
            foundFiles.push({
              fileName: xmlFile,
              path: xmlPath,
              size: stats.size,
              modified: stats.mtime,
              directory: dir.label
            });
            console.log(`✅ Found XML file: ${xmlFile} in ${dir.label} directory`);
          }
        } catch (error) {
          // File doesn't exist, continue
          console.log(`❌ File not found: ${xmlPath}`);
        }
      }
    }
    
    res.json({
      success: true,
      files: foundFiles,
      message: foundFiles.length > 0 ? 
        `Found ${foundFiles.length} XML file(s)` : 
        'No XML files found for this CSV file'
    });
  } catch (error) {
    console.error('Error checking XML files:', error);
    res.status(500).json({
      success: false,
      message: 'Error checking XML files',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// API endpoint to download XML files
app.get("/api/xml-files/download/:fileName", async (req, res) => {
  try {
    const { fileName } = req.params;
    
    // Check both directories: incomingcsv and processedcsv
    const incomingDir = process.env.AIRFLOW_DATA_DIR || process.env.NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv';
    const processedDir = process.env.AIRFLOW_PROCESSED_CSV_DIR || process.env.NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv';
    
    const formattedIncomingDir = formatUNCPath(incomingDir);
    const formattedProcessedDir = formatUNCPath(processedDir);
    
    console.log(`📥 Downloading XML file: ${fileName} from multiple directories:`);
    console.log(`   - Incoming: ${formattedIncomingDir}`);
    console.log(`   - Processed: ${formattedProcessedDir}`);
    
    const searchDirs = [
      { path: formattedIncomingDir, label: 'incoming' },
      { path: formattedProcessedDir, label: 'processed' }
    ];
    
    let xmlPath = '';
    let stats = null;
    
    // Try to find the file in both directories
    for (const dir of searchDirs) {
      const testPath = path.join(dir.path, fileName);
      try {
        const testStats = await fs.stat(testPath);
        if (testStats.isFile()) {
          xmlPath = testPath;
          stats = testStats;
          console.log(`✅ Found XML file: ${fileName} in ${dir.label} directory`);
          break;
        }
      } catch (error) {
        console.log(`❌ File not found in ${dir.label}: ${testPath}`);
        continue;
      }
    }
    
    if (!xmlPath || !stats) {
      return res.status(404).json({
        success: false,
        message: 'XML file not found in any directory'
      });
    }
    
    // Set headers for file download
    res.setHeader('Content-Type', 'application/xml');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Length', stats.size);
    
    // Stream the file
    const fileStream = await fs.readFile(xmlPath);
    res.send(fileStream);
    
  } catch (error) {
    console.error('Error downloading XML file:', error);
    res.status(500).json({
      success: false,
      message: 'Error downloading XML file',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Test endpoint to verify XML file paths
app.get("/api/test-xml-paths", async (req, res) => {
  try {
    const incomingDir = process.env.AIRFLOW_DATA_DIR || process.env.NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR || './data/incomingcsv';
    const processedDir = process.env.AIRFLOW_PROCESSED_CSV_DIR || process.env.NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR || './data/processedcsv';
    
    const formattedIncomingDir = formatUNCPath(incomingDir);
    const formattedProcessedDir = formatUNCPath(processedDir);
    
    console.log('🔍 Testing XML file paths:');
    console.log(`   - Incoming: ${formattedIncomingDir}`);
    console.log(`   - Processed: ${formattedProcessedDir}`);
    
    const testResults: any = {
      incomingDir: formattedIncomingDir,
      processedDir: formattedProcessedDir,
      envVars: {
        AIRFLOW_DATA_DIR: process.env.AIRFLOW_DATA_DIR,
        NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR: process.env.NEXT_PUBLIC_AIRFLOW_INCOMING_CSV_DIR,
        AIRFLOW_PROCESSED_CSV_DIR: process.env.AIRFLOW_PROCESSED_CSV_DIR,
        NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR: process.env.NEXT_PUBLIC_AIRFLOW_PROCESSED_CSV_DIR
      }
    };
    
    // Try to list files in both directories
    try {
      const incomingFiles = await fs.readdir(formattedIncomingDir);
      testResults.incomingFiles = incomingFiles.filter(file => file.endsWith('.xml'));
    } catch (error) {
      testResults.incomingDirError = (error as Error).message;
    }
    
    try {
      const processedFiles = await fs.readdir(formattedProcessedDir);
      testResults.processedFiles = processedFiles.filter(file => file.endsWith('.xml'));
    } catch (error) {
      testResults.processedDirError = (error as Error).message;
    }
    
    res.json({
      success: true,
      data: testResults
    });
  } catch (error) {
    console.error('Error testing XML paths:', error);
    res.status(500).json({
      success: false,
      error: (error as Error).message
    });
  }
});

export default app;
