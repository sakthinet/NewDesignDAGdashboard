import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { useClientConfig } from "@/hooks/use-client-config";

interface AirflowStatus {
  connected: boolean;
  url: string;
  error?: string;
}

export function useAirflow() {
  const clientConfig = useClientConfig();
  const [connectionStatus, setConnectionStatus] = useState<AirflowStatus>({
    connected: false,
    url: clientConfig.airflowUrl
  });
  const { toast } = useToast();

  const testConnection = useCallback(async () => {
    try {
      const response = await fetch('/api/test-airflow');
      const result = await response.json();
      
      setConnectionStatus({
        connected: result.connected,
        url: result.url,
        error: result.error
      });

      if (!result.connected) {
        console.warn('Airflow connection failed:', result.error);
      }
      
      return result;
    } catch (error) {
      console.error('Failed to test Airflow connection:', error);
      const status = {
        connected: false,
        url: clientConfig.airflowUrl,
        error: 'Network error - check if server is running'
      };
      setConnectionStatus(status);
      return status;
    }
  }, []);

  const deployDag = useCallback(async (dagId: string, dagScript: string) => {
    try {
      // This would integrate with Airflow REST API
      const response = await fetch('/api/deploy-dag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dagId, dagScript })
      });

      if (response.ok) {
        toast({
          title: "DAG deployed successfully",
          description: `${dagId} has been deployed to Airflow`,
        });
        return true;
      } else {
        throw new Error('Deployment failed');
      }
    } catch (error) {
      toast({
        title: "Deployment failed",
        description: "Failed to deploy DAG to Airflow",
        variant: "destructive",
      });
      return false;
    }
  }, [toast]);

  return {
    connectionStatus,
    testConnection,
    deployDag
  };
}
