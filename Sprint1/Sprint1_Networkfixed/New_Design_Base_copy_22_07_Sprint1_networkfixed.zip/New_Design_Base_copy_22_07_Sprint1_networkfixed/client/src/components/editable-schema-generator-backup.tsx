import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  ArrowLeft, 
  ArrowRight, 
  Database, 
  FileText, 
  Save,
  Loader2,
  Settings,
  CheckCircle,
  AlertCircle,
  Play,
  RefreshCw,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { useWorkflow } from "@/contexts/WorkflowContext";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";

// API request function
const apiRequest = async (method: string, url: string, body?: any) => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (body) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  return response;
};

// Types for the schema configuration (following the image exactly)
export interface SchemaConfiguration {
  applicationName: string;     // Text Box (Non-Editable)
  defaultSchemaName: string;   // Text Box (Non-Editable)  
  locale: string;              // Text Box (Non-Editable)
  schemaName: string;          // Text Box (Non-Editable)
}

export interface TableRowData {
  id: string;
  table: string;           // Taken from JSON file metadata (Editable)
  recordCount: number;     // Calculated based on number of records in JSON data (Editable)
  dataType: string;        // Based on column data type from JSON metadata (Editable)
  fileName: string;        // Original JSON file name for reference
  columnName?: string;     // Column name from JSON metadata
  isNullable?: boolean;    // Nullable flag from JSON metadata
  description?: string;    // Column description from JSON metadata
}

interface EditableSchemaGeneratorProps {
  uploadedFiles: any[];
  onNext: () => void;
  onPrev: () => void;
  onFinalize: () => void;
}

// Data type options for the grid
// This array is now included in the instructions for the JSON editor
const DATA_TYPE_OPTIONS = [
  'VARCHAR(50)',
  'VARCHAR(100)', 
  'VARCHAR(255)',
  'TEXT',
  'INT',
  'BIGINT',
  'DECIMAL(10,2)',
  'DATE',
  'DATETIME',
  'TIMESTAMP',
  'BOOLEAN',
  'FLOAT',
  'DOUBLE'
];

export function EditableSchemaGenerator({ 
  uploadedFiles, 
  onNext, 
  onPrev, 
  onFinalize 
}: EditableSchemaGeneratorProps) {
  
  // Workflow context
  const workflow = useWorkflow();
  
  // Step 2.1: Schema Configuration State - Get from workflow context or use defaults
  const [schemaConfig] = useState<SchemaConfiguration>(() => {
    const contextConfig = workflow.schemaConfig;
    if (contextConfig) {
      console.log('✅ Using schema configuration from workflow context:', contextConfig);
      return {
        applicationName: contextConfig.applicationName,
        defaultSchemaName: contextConfig.defaultSchemaName,
        locale: contextConfig.locale,
        schemaName: contextConfig.schemaName
      };
    } else {
      console.log('⚠️ No schema configuration found in workflow context, using defaults');
      return {
        applicationName: 'InfoArchive_Application',
        defaultSchemaName: 'DefaultSchema', 
        locale: 'en-US',
        schemaName: 'DataArchival_Schema'
      };
    }
  });

  // JSON data state
  const [tableData, setTableData] = useState<TableRowData[]>([]);
  const [jsonEditorContent, setJsonEditorContent] = useState<string>('');
  const [isFinalizing, setIsFinalizing] = useState(false);
  const [availableJsonFiles, setAvailableJsonFiles] = useState<string[]>([]);
  const [isLoadingJsonFiles, setIsLoadingJsonFiles] = useState(false);
  
  // Data type editor dialog state
  const [isDataTypeEditorOpen, setIsDataTypeEditorOpen] = useState(false);
  const [currentFileName, setCurrentFileName] = useState<string>('');
  const [currentTableName, setCurrentTableName] = useState<string>('');
  const [currentColumns, setCurrentColumns] = useState<{ id: string; columnName: string; dataType: string }[]>([]);

  const { toast } = useToast();
  
  // Airflow API hook
  const { triggerDag, loading: dagLoading, error: dagError } = useAirflowApi();

  // Check schema configuration on component mount
  useEffect(() => {
    if (!workflow.schemaConfig) {
      toast({
        title: "⚠️ No Schema Configuration Found",
        description: "Using default schema configuration. Please ensure Step 2 was completed properly.",
        variant: "default",
        duration: 100,
      });
    } else {
      console.log('✅ Schema configuration successfully loaded from Step 2:', workflow.schemaConfig);
    }
  }, [workflow.schemaConfig, toast]);

  // Open the data type editor dialog for a specific table
  const openDataTypeEditor = (fileName: string, tableName: string) => {
    const columns = tableData
      .filter(item => item.fileName === fileName && item.table === tableName)
      .map(item => ({
        id: item.id,
        columnName: item.columnName || '',
        dataType: item.dataType || 'VARCHAR(255)'
      }));

    setCurrentFileName(fileName);
    setCurrentTableName(tableName);
    setCurrentColumns(columns);
    setIsDataTypeEditorOpen(true);
  };

  // Handle saving data type changes
  const handleSaveDataTypes = (columns: { id: string; columnName: string; dataType: string }[]) => {
    // Update the table data with the new data types
    const newTableData = [...tableData];
    
    columns.forEach(col => {
      const index = newTableData.findIndex(item => item.id === col.id);
      if (index !== -1) {
        newTableData[index].dataType = col.dataType;
      }
    });

    setTableData(newTableData);
    setJsonEditorContent(JSON.stringify(newTableData, null, 2));
    
    toast({
      title: "✅ Data Types Updated",
      description: `Updated ${columns.length} columns for table ${currentTableName}`,
    });
  };
  
  // Validate if the table data is complete and can be submitted
  const validateTable = useCallback(() => {
    if (tableData.length === 0) {
      return false;
    }
    
    // Check that each table has valid table name, record count, and data types
    try {
      return tableData.every(row => 
        row.table && row.table.trim() !== '' && 
        row.recordCount && row.recordCount > 0 && 
        row.dataType && row.dataType.trim() !== ''
      );
    } catch (error) {
      return false;
    }
  }, [tableData]);

  // Load available JSON files from processed CSV directory
  const loadAvailableJsonFiles = async () => {
    setIsLoadingJsonFiles(true);
    try {
      console.log('🔍 Loading available JSON files...');
      
      const response = await apiRequest('GET', '/api/get-processed-json-files');
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setAvailableJsonFiles(result.files || []);
          console.log('✅ Loaded JSON files:', result.files);
        } else {
          console.warn('Failed to load JSON files:', result.message);
          setAvailableJsonFiles([]);
        }
      } else {
        console.error('Failed to fetch JSON files');
        setAvailableJsonFiles([]);
      }
    } catch (error) {
      console.error('Error loading JSON files:', error);
      setAvailableJsonFiles([]);
    } finally {
      setIsLoadingJsonFiles(false);
    }
  };

  // Load JSON metadata and populate table data
  const loadJsonMetadata = async (fileName: string) => {
    try {
      console.log(`📊 Loading metadata for: ${fileName}`);
      
      const response = await apiRequest('POST', '/api/load-json-metadata', {
        fileName: fileName
      });
      
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          console.log('✅ Loaded JSON metadata:', result);
          
          // Create table row data from JSON metadata columns
          const tableDataRows: TableRowData[] = result.columns.map((col: any, index: number) => ({
            id: `json_${fileName}_${index}`,
            table: result.tableName,
            recordCount: result.recordCount,
            dataType: col.data_type || 'VARCHAR(255)',
            fileName: fileName,
            columnName: col.name,
            isNullable: col.is_nullable || false,
            description: col.description || ''
          }));
          
          return tableDataRows;
        } else {
          console.warn('Failed to load JSON metadata:', result.message);
          return [];
        }
      } else {
        console.error('Failed to fetch JSON metadata');
        return [];
      }
    } catch (error) {
      console.error('Error loading JSON metadata:', error);
      return [];
    }
  };

  // Initialize table data from JSON files
  const initializeFromJsonFiles = async () => {
    if (availableJsonFiles.length > 0) {
      const allTableData: TableRowData[] = [];
      
      for (const jsonFile of availableJsonFiles) {
        const tableDataRows = await loadJsonMetadata(jsonFile);
        allTableData.push(...tableDataRows);
      }
      
      setTableData(allTableData);
      // Set the JSON editor content with the prettified JSON
      setJsonEditorContent(JSON.stringify(allTableData, null, 2));
      console.log('📊 Initialized table data from JSON files:', allTableData);
    }
  };

  // Initialize when component mounts
  useEffect(() => {
    loadAvailableJsonFiles();
  }, []);

  // Initialize table data when JSON files are loaded
  useEffect(() => {
    if (availableJsonFiles.length > 0) {
      initializeFromJsonFiles();
    }
  }, [availableJsonFiles]);

  // Handle JSON editor changes
  const handleJsonEditorChange = useCallback((event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setJsonEditorContent(event.target.value);
    try {
      const parsedData = JSON.parse(event.target.value);
      setTableData(parsedData);
      console.log('✅ JSON successfully parsed and updated');
    } catch (error) {
      console.error('❌ Invalid JSON format:', error);
      // We don't update the table data if the JSON is invalid
    }
  }, []);

  // JSON editor utility functions
  const formatJson = useCallback(() => {
    try {
      const parsed = JSON.parse(jsonEditorContent);
      setJsonEditorContent(JSON.stringify(parsed, null, 2));
      setTableData(parsed);
      toast({
        title: "✅ JSON Formatted Successfully",
        description: "The JSON has been formatted and validated.",
      });
    } catch (error) {
      toast({
        title: "❌ Invalid JSON",
        description: "The JSON content contains syntax errors and could not be formatted.",
        variant: "destructive",
      });
    }
  }, [jsonEditorContent, toast]);

  const validateJson = useCallback(() => {
    try {
      const parsed = JSON.parse(jsonEditorContent);
      // Check if it's an array and has required fields
      if (!Array.isArray(parsed)) {
        throw new Error("JSON must be an array of table data objects");
      }
      
      // Check each item has required fields
      const isValid = parsed.every((item: any, index: number) => {
        if (!item.table || !item.recordCount || !item.dataType) {
          throw new Error(`Item #${index + 1} is missing required fields (table, recordCount, dataType)`);
        }
        return true;
      });
      
      toast({
        title: "✅ JSON is Valid",
        description: "All required fields are present and syntax is correct.",
      });
      return true;
    } catch (error) {
      toast({
        title: "❌ JSON Validation Failed",
        description: error instanceof Error ? error.message : "Unknown validation error",
        variant: "destructive",
      });
      return false;
    }
  }, [jsonEditorContent, toast]);

  // Handle DAG Run 2 (Finalize and Generate IA Schema)
  const handleDAGRun2 = async () => {
    setIsFinalizing(true);
    
    try {
      // Use the tableData directly instead of parsing the JSON
      // Prepare the DAG configuration with schema configuration and table data
      const dagConfig = {
        "Application Name": schemaConfig.applicationName,
        "Default Schema Name": schemaConfig.defaultSchemaName,
        "Locale": schemaConfig.locale,
        "Schema Name": schemaConfig.schemaName,
        "Table Data": tableData.map((row: TableRowData) => ({
          tableName: row.table || "DefaultTable",
          recordCount: row.recordCount || 0,
          dataType: row.dataType || "VARCHAR(255)",
          fileName: row.fileName || "unknown.json"
        }))
      };

      console.log('=== DAG RUN 2 TRIGGERED ===');
      console.log('DAG Configuration:', dagConfig);

      // Trigger the specific DAG: IA_XML_Generator
      const result = await triggerDag('IA_XML_Generator', dagConfig);

      if (result && result.success) {
        toast({
          title: "🚀 IA XML Generator Triggered Successfully!",
          description: `DAG 'IA_XML_Generator' executed successfully. DAG Run ID: ${result.dag_run?.dag_run_id || 'Unknown'}`,
          duration: 100,
        });
        
        // Navigate to the next step
        onFinalize();
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
    } catch (error) {
      console.error('Error triggering DAG:', error);
      toast({
        title: "❌ IA XML Generator Failed",
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: "destructive",
      });
    } finally {
      setIsFinalizing(false);
    }
  };

  // Validate form - check if JSON is valid and has required fields
  const isFormValid = () => {
    try {
      if (!jsonEditorContent) return false;
      
      const parsedData = JSON.parse(jsonEditorContent);
      if (!Array.isArray(parsedData) || parsedData.length === 0) return false;
      
      return parsedData.every((row: TableRowData) => 
        row.table && row.table.trim() !== '' && 
        row.recordCount && row.recordCount > 0 && 
        row.dataType && row.dataType.trim() !== ''
      );
    } catch (error) {
      return false; // Invalid JSON
    }
  };

  // DataTypeEditorDialog component
  interface DataTypeEditorDialogProps {
    isOpen: boolean;
    onClose: () => void;
    fileName: string;
    tableName: string;
    columns: {
      id: string;
      columnName: string;
      dataType: string;
    }[];
    onSave: (columns: { id: string; columnName: string; dataType: string }[]) => void;
    dataTypeOptions: string[];
  }

  function DataTypeEditorDialog({
    isOpen,
    onClose,
    fileName,
    tableName,
    columns,
    onSave,
    dataTypeOptions
  }: DataTypeEditorDialogProps) {
    const [editedColumns, setEditedColumns] = useState<{ id: string; columnName: string; dataType: string }[]>([]);

    useEffect(() => {
      setEditedColumns([...columns]);
    }, [columns]);

    const handleDataTypeChange = (id: string, dataType: string) => {
      setEditedColumns(prev => prev.map(col => 
        col.id === id ? { ...col, dataType } : col
      ));
    };

    const handleSave = () => {
      onSave(editedColumns);
      onClose();
    };

    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" /> 
              Edit Column Data Types
            </DialogTitle>
            <DialogDescription>
              {fileName} - Table: {tableName}
            </DialogDescription>
          </DialogHeader>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left">Column Name</th>
                  <th className="px-4 py-2 text-left">Data Type</th>
                </tr>
              </thead>
              <tbody>
                {editedColumns.map((col) => (
                  <tr key={col.id} className="border-b">
                    <td className="px-4 py-3">{col.columnName}</td>
                    <td className="px-4 py-3">
                      <Select value={col.dataType} onValueChange={(value) => handleDataTypeChange(col.id, value)}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select data type" />
                        </SelectTrigger>
                        <SelectContent>
                          {dataTypeOptions.map((type) => (
                            <SelectItem key={type} value={type}>{type}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSave}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Validate and Finalize Schema</h2>
          <p className="text-sm text-gray-600 mt-1">
            Configure schema settings and validate table information for InfoArchive processing from JSON files
          </p>
          {availableJsonFiles.length > 0 && (
            <div className="mt-2 text-sm text-blue-600">
              <span className="font-medium">Processing JSON Files: </span>
              {availableJsonFiles.map((file, index) => (
                <span key={index}>
                  {file}
                  {index < availableJsonFiles.length - 1 ? ', ' : ''}
                </span>
              ))}
            </div>
          )}
          {isLoadingJsonFiles && (
            <div className="mt-2 text-sm text-gray-500">
              <span className="flex items-center gap-1">
                <Loader2 className="h-3 w-3 animate-spin" />
                Loading JSON files from processed CSV directory...
              </span>
            </div>
          )}
        </div>
        <div className="flex flex-col items-end space-y-1 text-sm text-gray-500">
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4" />
            <span>{tableData.length} tables configured</span>
          </div>
          <div className="flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Schema validation ready</span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={loadAvailableJsonFiles}
              disabled={isLoadingJsonFiles}
              className="flex items-center space-x-1"
            >
              <RefreshCw className={`h-3 w-3 ${isLoadingJsonFiles ? 'animate-spin' : ''}`} />
              <span>Refresh JSON Files</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Schema Configuration - Non-Editable Fields (1-4) */}
      <Card className="shadow-sm border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <Settings className="mr-2 h-5 w-5" />
            Schema Configuration
            <Badge variant="outline" className="ml-2 text-red-600 border-red-200">
              Non-Editable
            </Badge>
            {workflow.schemaConfig && (
              <Badge variant="outline" className="ml-2 text-green-600 border-green-200">
                From Step 2
              </Badge>
            )}
          </CardTitle>
          {workflow.schemaConfig && (
            <p className="text-sm text-green-600 mt-1">
              ✅ Schema configuration successfully loaded from Generate IA Table Schema
            </p>
          )}
          {!workflow.schemaConfig && (
            <p className="text-sm text-orange-600 mt-1">
              ⚠️ Using default schema configuration. Please ensure Step 2 was completed properly.
            </p>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-sm font-medium text-gray-700">
                1. Application Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.applicationName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                2. Default Schema Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.defaultSchemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                3. Locale: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.locale}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>

            <div>
              <Label className="text-sm font-medium text-gray-700">
                4. Schema Name: Text Box (Non-Editable)
              </Label>
              <Input
                value={schemaConfig.schemaName}
                readOnly
                disabled
                className="mt-1 bg-gray-50 text-gray-600"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Editable Table Schema Information (Fields 5-7) */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-800 flex items-center">
            <FileText className="mr-2 h-5 w-5" />
            Table Schema Information
            <Badge variant="outline" className="ml-2 text-blue-600 border-blue-200">
              Editable
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm text-gray-700 mb-4">
              <p><strong>5. Table:</strong> Taken from CSV file metadata (Editable)</p>
              <p><strong>6. Record Count:</strong> Calculated based on number of records in CSV data (Editable)</p>
              <p><strong>7. Data Type:</strong> Based on column data type from CSV metadata (Editable)</p>
              <p className="text-xs text-blue-600 mt-2">
                <strong>Note:</strong> Each CSV file is displayed as a separate table below. Click "Edit Types" to modify column data types.
              </p>
              <p className="text-xs text-orange-600 mt-1">
                <strong>Edit Instruction:</strong> Edit the table name and record count directly. Click the Edit Types button to modify data types.
              </p>
            </div>
            
            {/* Table Format Display */}
            <div className="space-y-6">
              {availableJsonFiles.length > 0 ? (
                availableJsonFiles.map((fileName, fileIndex) => {
                  // Filter table data for current file
                  const fileData = tableData.filter(item => item.fileName === fileName);
                  // Group by table name for display
                  const tableGroups = fileData.reduce((acc, curr) => {
                    if (!acc[curr.table]) {
                      acc[curr.table] = {
                        table: curr.table,
                        recordCount: curr.recordCount,
                        dataTypes: new Set()
                      };
                    }
                    acc[curr.table].dataTypes.add(curr.dataType);
                    return acc;
                  }, {} as Record<string, { table: string, recordCount: number, dataTypes: Set<string> }>);
                  
                  return (
                    <div key={`file-${fileIndex}`} className="border border-gray-200 rounded-md bg-white">
                      <div className="bg-blue-50 px-4 py-3 border-b border-gray-200">
                        <h3 className="text-sm font-medium text-gray-800 flex items-center">
                          <FileText className="h-4 w-4 mr-2 text-blue-600" />
                          {fileName}
                        </h3>
                      </div>
                      
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                          <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                              <th className="px-4 py-3">Table Name</th>
                              <th className="px-4 py-3">Record Count</th>
                              <th className="px-4 py-3">Data Types</th>
                              <th className="px-4 py-3">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {Object.values(tableGroups).map((group, groupIndex) => (
                              <tr key={`group-${groupIndex}`} className="bg-white border-b hover:bg-gray-50">
                                <td className="px-4 py-3">
                                  <Input 
                                    value={group.table} 
                                    onChange={(e) => {
                                      // Update all table data entries with this table name
                                      const newData = [...tableData];
                                      newData.forEach(item => {
                                        if (item.fileName === fileName && item.table === group.table) {
                                          item.table = e.target.value;
                                        }
                                      });
                                      setTableData(newData);
                                      setJsonEditorContent(JSON.stringify(newData, null, 2));
                                    }}
                                    className="h-8 text-sm"
                                  />
                                </td>
                                <td className="px-4 py-3">
                                  <Input 
                                    type="number"
                                    value={group.recordCount} 
                                    onChange={(e) => {
                                      // Update all table data entries with this table name
                                      const newData = [...tableData];
                                      const newCount = parseInt(e.target.value) || 0;
                                      newData.forEach(item => {
                                        if (item.fileName === fileName && item.table === group.table) {
                                          item.recordCount = newCount;
                                        }
                                      });
                                      setTableData(newData);
                                      setJsonEditorContent(JSON.stringify(newData, null, 2));
                                    }}
                                    className="h-8 text-sm"
                                  />
                                </td>
                                <td className="px-4 py-3">
                                  <div className="flex flex-wrap gap-1">
                                    {Array.from(group.dataTypes).map((type, typeIndex) => (
                                      <Badge key={`type-${typeIndex}`} variant="outline" className="bg-blue-50">
                                        {type}
                                      </Badge>
                                    ))}
                                  </div>
                                </td>
                                <td className="px-4 py-3">
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    onClick={() => {
                                      openDataTypeEditor(fileName, group.table);
                                    }}
                                  >
                                    Edit Types
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center border border-dashed border-gray-300 rounded-lg">
                  <AlertCircle className="h-10 w-10 text-yellow-500 mb-2" />
                  <h3 className="text-lg font-medium text-gray-900">No JSON files found</h3>
                  <p className="text-sm text-gray-500 max-w-md mt-1">
                    Please ensure you've uploaded CSV files and generated schema metadata in the previous step.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={loadAvailableJsonFiles}
                    className="mt-4"
                    disabled={isLoadingJsonFiles}
                  >
                    {isLoadingJsonFiles ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Loading...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Refresh Files
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Finalize Button - DAG Run 2 */}
      <Card className="shadow-sm border border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <Play className="mr-2 h-5 w-5" />
                Finalize and Generate IA Schema
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Trigger the 'IA_XML_Generator' DAG to finalize schema configuration and generate IA XML schema
              </p>
            </div>
            <Button 
              onClick={handleDAGRun2}
              disabled={isFinalizing || dagLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {(isFinalizing || dagLoading) ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating IA XML...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Finalize and Generate IA Schema
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center space-x-2"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Previous</span>
        </Button>
        <Button
          onClick={handleDAGRun2}
          disabled={isFinalizing || !validateTable()}
          className="flex items-center space-x-2"
        >
          {isFinalizing ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Processing...</span>
            </>
          ) : (
            <>
              <ArrowRight className="h-4 w-4" />
              <span>Generate IA Schema</span>
            </>
          )}
        </Button>
      </div>

      {/* Data Type Editor Dialog */}
      <DataTypeEditorDialog
        isOpen={isDataTypeEditorOpen}
        onClose={() => setIsDataTypeEditorOpen(false)}
        fileName={currentFileName}
        tableName={currentTableName}
        columns={currentColumns}
        onSave={handleSaveDataTypes}
        dataTypeOptions={DATA_TYPE_OPTIONS}
      />
    </div>
  );
}
