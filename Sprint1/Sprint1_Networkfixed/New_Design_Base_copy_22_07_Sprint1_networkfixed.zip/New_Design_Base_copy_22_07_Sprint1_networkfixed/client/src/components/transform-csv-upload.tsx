import { useState, useEffect, useMemo, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Upload, Database, FileText, AlertCircle, CheckCircle, Activity, RefreshCw, Settings, Save, GitBranch } from "lucide-react";
import { UploadedFile, DagConfig } from "@/pages/dag-generator";
import { useWorkflow } from "@/contexts/WorkflowContext";
import { useAirflowApi } from "@/hooks/use-airflow-api";
import { TaskInstancesLive } from "@/components/task-instances-live";
import DAGModal from "./dag-modal";

interface TransformCsvUploadProps {
  uploadedFiles: UploadedFile[];
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

interface TransformCsvUploadProps {
  uploadedFiles: UploadedFile[];
  config: DagConfig;
  onPrev: () => void;
  onStartOver: () => void;
}

export function TransformCsvUpload({ 
  uploadedFiles, 
  config, 
  onPrev, 
  onStartOver 
}: TransformCsvUploadProps) {
  const [selectedCsvFile, setSelectedCsvFile] = useState<string>('');
  const [tableUrl, setTableUrl] = useState<string>('');
  const [chunkSize, setChunkSize] = useState<number>(5000);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadStarted, setUploadStarted] = useState<boolean>(false);
  const [dagRunId, setDagRunId] = useState<string>('');
  const [uploadSuccess, setUploadSuccess] = useState<boolean>(false);
  const [showJobsOverview, setShowJobsOverview] = useState<boolean>(true);
  const [dags, setDags] = useState<any[]>([]);
  
  // Track processed files
  const [processedFiles, setProcessedFiles] = useState<string[]>([]);
  
  // Modal state for DAG details
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDagId, setSelectedDagId] = useState<string | null>(null);
  
  // Pagination state for Jobs Overview
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  
  // Schema configuration state
  const [schemaName, setSchemaName] = useState<string>('');
  const [isSavingSchema, setIsSavingSchema] = useState<boolean>(false);
  
  // Message state for inline notifications
  const [message, setMessage] = useState<{
    type: 'success' | 'error' | 'info';
    text: string;
  } | null>(null);
  
  // Use workflow context to get session files
  const workflow = useWorkflow();
  const sessionFiles = workflow.selectedFiles;
  const airflowApi = useAirflowApi();
  
  // Use session files if available, otherwise fall back to props
  // Filter out processed files
  const allFiles = sessionFiles.length > 0 ? sessionFiles : uploadedFiles;
  const availableFiles = allFiles.filter(f => 
    f.fileName && !processedFiles.includes(f.fileName)
  );

  // Auto-close message after 100ms for success messages
  useEffect(() => {
    if (message && message.type === 'success') {
      const timer = setTimeout(() => {
        setMessage(null);
      }, 100);
      
      return () => clearTimeout(timer);
    }
  }, [message]);

  // Initialize schema name from workflow context or use default
  useEffect(() => {
    if (workflow.schemaConfig?.schemaName) {
      setSchemaName(workflow.schemaConfig.schemaName);
    } else {
      // Default schema name, could be based on available files or configuration
      const defaultSchemaName = availableFiles.length > 0 
        ? `${availableFiles[0].fileName.replace(/\.[^/.]+$/, '')}_Schema`
        : 'your_schema';
      setSchemaName(defaultSchemaName);
    }
  }, [workflow.schemaConfig, availableFiles]);
  
  // Load DAGs when component mounts or when uploadSuccess changes
  useEffect(() => {
    if (uploadSuccess) {
      const loadDags = async () => {
        try {
          const dagsResult = await airflowApi.getDags(true);
          if (dagsResult && dagsResult.dags) {
            setDags(dagsResult.dags);
          }
        } catch (error) {
          console.error('Failed to load DAGs:', error);
        }
      };
      
      loadDags();
    }
  }, [uploadSuccess, airflowApi]);

  // Modal handlers
  const handleDagClick = useCallback((dagId: string) => {
    setSelectedDagId(dagId);
    setIsModalOpen(true);
  }, []);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setSelectedDagId(null);
  }, []);

  // Pagination calculations and filtered DAGs
  const sortedAndFilteredDags = useMemo(() => {
    return dags
      .sort((a, b) => {
        // Sort by last_parsed_time (latest first) and prioritize StructuredDataToIA
        const aIsStructured = a.dag_id.includes('StructuredDataToIA');
        const bIsStructured = b.dag_id.includes('StructuredDataToIA');
        
        // First prioritize StructuredDataToIA DAGs
        if (aIsStructured && !bIsStructured) return -1;
        if (!aIsStructured && bIsStructured) return 1;
        
        // Then sort by last_parsed_time (latest first)
        const aTime = a.last_parsed_time ? new Date(a.last_parsed_time).getTime() : 0;
        const bTime = b.last_parsed_time ? new Date(b.last_parsed_time).getTime() : 0;
        return bTime - aTime;
      });
  }, [dags]);

  const paginatedDags = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return sortedAndFilteredDags.slice(startIndex, endIndex);
  }, [sortedAndFilteredDags, currentPage]);

  const totalPages = Math.ceil(sortedAndFilteredDags.length / itemsPerPage);
  const hasNextPage = currentPage < totalPages;
  const hasPrevPage = currentPage > 1;

  // Pagination handlers
  const goToPage = useCallback((page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
  }, [totalPages]);

  const goToFirstPage = useCallback(() => {
    setCurrentPage(1);
  }, []);

  const goToLastPage = useCallback(() => {
    setCurrentPage(totalPages);
  }, [totalPages]);

  const goToPrevPage = useCallback(() => {
    setCurrentPage(prev => Math.max(1, prev - 1));
  }, []);

  const goToNextPage = useCallback(() => {
    setCurrentPage(prev => Math.min(totalPages, prev + 1));
  }, [totalPages]);

  // Handler for saving schema configuration
  const handleSaveSchema = async () => {
    if (!schemaName.trim()) {
      setMessage({
        type: 'error',
        text: 'Schema name cannot be empty.'
      });
      return;
    }

    setIsSavingSchema(true);
    try {
      // Update workflow context with schema configuration
      const updatedSchemaConfig = {
        ...workflow.schemaConfig,
        schemaName: schemaName.trim(),
        applicationName: workflow.schemaConfig?.applicationName || 'InfoArchive_Application',
        defaultSchemaName: workflow.schemaConfig?.defaultSchemaName || 'DefaultSchema',
        locale: workflow.schemaConfig?.locale || 'en-US'
      };

      workflow.setSchemaConfig(updatedSchemaConfig);

      setMessage({
        type: 'success',
        text: `Schema name "${schemaName}" has been saved successfully.`
      });
    } catch (error) {
      console.error('Error saving schema configuration:', error);
      setMessage({
        type: 'error',
        text: 'Failed to save schema configuration.'
      });
    } finally {
      setIsSavingSchema(false);
    }
  };

  // Upload handler
  const handleUploadToIA = async () => {
    if (!selectedCsvFile || selectedCsvFile === 'no-files-available' || !schemaName || !tableUrl) {
      setMessage({
        type: 'error',
        text: 'Please fill in all required fields including Schema Name'
      });
      return;
    }

    // Validate required fields
    if (!selectedCsvFile.trim()) {
      setMessage({
        type: 'error',
        text: 'Please select a CSV file'
      });
      return;
    }

    if (!schemaName.trim()) {
      setMessage({
        type: 'error',
        text: 'Schema name is required'
      });
      return;
    }

    if (!tableUrl.trim()) {
      setMessage({
        type: 'error',
        text: 'Export URL is required'
      });
      return;
    }

    setIsUploading(true);
    setUploadStarted(true);
    setMessage(null); // Clear any previous messages
    
    try {
      console.log('🚀 InfoArchive Data Upload - DAG Trigger Started');
      
      // Configuration for the DAG - matching the exact format expected by Airflow API
      const dagTriggerConfiguration = {
        "CSV_FILENAME": selectedCsvFile,
        "SCHEMA_NAME": schemaName,
        "CHUNK_SIZE": chunkSize,
        "EXPORT_URL": tableUrl
      };
      
      console.log('📋 DAG Trigger Configuration:', JSON.stringify(dagTriggerConfiguration, null, 2));
      
      // Trigger the StructuredDataToIA DAG with the configuration
      const result = await airflowApi.triggerDag('StructuredDataToIA_Resilient', dagTriggerConfiguration);
      
      if (result && result.success) {
        console.log('✅ InfoArchive Data Upload - DAG Triggered Successfully');
        setUploadSuccess(true);
        setShowJobsOverview(true);
        
        // Add the processed file to the processedFiles list
        setProcessedFiles(prev => [...prev, selectedCsvFile]);
        
        // Clear the selected file
        setSelectedCsvFile('');
        
        // Extract the DAG run ID from the result
        if (result.dag_run && result.dag_run.dag_run_id) {
          setDagRunId(result.dag_run.dag_run_id);
        }
        
        // Load DAG data for the Jobs overview
        try {
          const dagsResult = await airflowApi.getDags(true);
          if (dagsResult && dagsResult.dags) {
            setDags(dagsResult.dags);
          }
        } catch (error) {
          console.error('Failed to load DAGs for Jobs Overview:', error);
        }
        
        setMessage({
          type: 'success',
          text: 'StructuredDataToIA_Resilient DAG has been started.'
        });
      } else {
        throw new Error(result?.message || 'Failed to trigger DAG');
      }
      
    } catch (error) {
      console.error('❌ InfoArchive Data Upload - DAG Trigger Failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to trigger DAG';
      
      setMessage({
        type: 'error',
        text: errorMessage
      });
      
      setUploadSuccess(false);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Table data upload to InfoArchive</h2>
          <p className="text-muted-foreground mt-2">
           Select the IA Table to upload and the chunk size
          </p>
          {/* Show available files count */}
          <div className="mt-2 text-sm text-muted-foreground">
            {availableFiles.length > 0 ? (
              <span className="inline-flex items-center gap-1">
                <Database className="h-4 w-4" />
                Processing: {availableFiles.length} file(s) ({availableFiles.map(f => f.fileName).join(', ')})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-orange-600">
                <AlertCircle className="h-4 w-4" />
                {processedFiles.length > 0 ? 'All files processed' : 'No files available. Please upload files in Step 1 first.'}
              </span>
            )}
          </div>
        </div>
        <Button
          variant="outline"
          onClick={onPrev}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Upload Configuration
            </CardTitle>
            <CardDescription>
              Configure the CSV transformation and upload settings
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Schema Name */}
            <div className="space-y-2">
              <Label htmlFor="schema-name">Schema_Name</Label>
              <Input
                id="schema-name"
                type="text"
                value={schemaName}
                onChange={(e) => {
                  setSchemaName(e.target.value);
                  setMessage(null); // Clear message when user starts typing
                }}
                placeholder="your_schema"
                className="bg-green-50 border-green-200"
              />
            </div>

            {/* CSV File Selection */}
            <div className="space-y-2">
              <Label htmlFor="csv-file">
                Csv_File Name
              </Label>
              <Select value={selectedCsvFile} onValueChange={(value) => {
                setSelectedCsvFile(value);
                setMessage(null); // Clear message when user selects file
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select CSV file to process" />
                </SelectTrigger>
                <SelectContent>
                  {availableFiles.length > 0 ? (
                    availableFiles.map((file) => (
                      <SelectItem key={file.fileName} value={file.fileName}>
                        {file.fileName}
                      </SelectItem>
                    ))
                  ) : processedFiles.length > 0 && allFiles.length > 0 ? (
                    <SelectItem value="all-processed" disabled>
                      All files processed - Upload more files in Step 1
                    </SelectItem>
                  ) : (
                    <SelectItem value="no-files-available" disabled>
                      No files available - Please upload files in Step 1
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500">
                Only files uploaded in Step 1 will appear here
              </p>
            </div>

            {/* Chunk Size */}
            <div className="space-y-2">
              <Label htmlFor="chunk-size">Chunk_Size</Label>
              <Input
                id="chunk-size"
                type="number"
                value={chunkSize}
                onChange={(e) => setChunkSize(Number(e.target.value))}
                step="1000"
              />
            </div>

            {/* Export URL */}
            <div className="space-y-2">
              <Label htmlFor="table-url">Export_Url</Label>
              <Input
                id="table-url"
                type="url"
                value={tableUrl}
                onChange={(e) => {
                  setTableUrl(e.target.value);
                  setMessage(null); // Clear message when user starts typing
                }}
                placeholder="Export URL for Table"
              />
            </div>

            {/* Inline Message Display */}
            {message && (
              <div className={`p-4 rounded-lg border ${
                message.type === 'success' 
                  ? 'bg-green-50 border-green-200 text-green-800' 
                  : message.type === 'error'
                  ? 'bg-red-50 border-red-200 text-red-800'
                  : 'bg-blue-50 border-blue-200 text-blue-800'
              }`}>
                <div className="flex items-center gap-2">
                  {message.type === 'success' && <CheckCircle className="h-4 w-4 text-green-600" />}
                  {message.type === 'error' && <AlertCircle className="h-4 w-4 text-red-600" />}
                  {message.type === 'info' && <AlertCircle className="h-4 w-4 text-blue-600" />}
                  <span className="text-sm font-medium">{message.text}</span>
                </div>
              </div>
            )}

            {/* Upload Button */}
            <Button
              onClick={handleUploadToIA}
              disabled={!selectedCsvFile || selectedCsvFile === 'no-files-available' || !schemaName || !tableUrl || isUploading || availableFiles.length === 0}
              className="w-full"
            >
              {isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  Uploading to IA...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Transform CSV Data dump to IA XML Format and Upload
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Status/Info Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Job Details
            </CardTitle>
            <CardDescription>
              Current transformation and upload status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              {/* Processed Files Section */}
              {processedFiles.length > 0 && (
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <span className="text-sm font-medium">Processed CSV Files:</span>
                  <span className="text-sm text-gray-600">
                    {processedFiles.join(', ')}
                  </span>
                </div>
              )}
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Schema Name</span>
                <span className="text-sm text-gray-600">
                  {schemaName || 'Not set'}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Chunk Size</span>
                <span className="text-sm text-gray-600">{chunkSize.toLocaleString()}</span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium">Export URL</span>
                <span className="text-sm text-gray-600">
                  {tableUrl || 'Not set'}
                </span>
              </div>
              
              {/* DAG Status */}
              {uploadStarted && (
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <span className="text-sm font-medium">DAG Status</span>
                  <div className="flex items-center gap-2">
                    {isUploading ? (
                      <>
                        <Activity className="h-4 w-4 animate-spin text-blue-600" />
                        <span className="text-sm text-blue-600">Triggering...</span>
                      </>
                    ) : uploadSuccess ? (
                      <>
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm text-green-600">Triggered Successfully</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-4 w-4 text-red-600" />
                        <span className="text-sm text-red-600">Failed</span>
                      </>
                    )}
                  </div>
                </div>
              )}
              
              {/* DAG Run ID */}
              {dagRunId && (
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                  <span className="text-sm font-medium">DAG Run ID</span>
                  <span className="text-sm text-green-600 font-mono">{dagRunId}</span>
                </div>
              )}
            </div>

            {/* Progress indicator */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Triggering DAG...</span>
                  <span>Processing</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full animate-pulse w-[45%]"></div>
                </div>
              </div>
            )}

            {/* Success message */}
            {uploadSuccess && dagRunId && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">DAG Successfully Triggered</span>
                </div>
                <p className="text-sm text-green-600 mt-1">
                  The StructuredDataToIA DAG is now running. You can monitor its progress below.
                </p>
                
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex gap-2">
                    <Button
                      variant={showJobsOverview ? "default" : "outline"}
                      onClick={() => setShowJobsOverview(true)}
                      className="flex items-center gap-1"
                      size="sm"
                    >
                      <GitBranch className="h-3 w-3" />
                      Jobs Overview
                    </Button>
                    
                    <Button
                      variant={!showJobsOverview ? "default" : "outline"}
                      onClick={() => setShowJobsOverview(false)}
                      className="flex items-center gap-1"
                      size="sm"
                    >
                      <Activity className="h-3 w-3" />
                      Task Details
                    </Button>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={async () => {
                      try {
                        const dagsResult = await airflowApi.getDags(true);
                        if (dagsResult && dagsResult.dags) {
                          setDags(dagsResult.dags);
                        }
                      } catch (error) {
                        console.error('Failed to refresh DAGs:', error);
                      }
                    }}
                  >
                    <RefreshCw className="h-3 w-3" />
                    Refresh
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>


      {/* Task Instances Live View - Show after DAG is triggered */}
      {uploadSuccess && dagRunId && !showJobsOverview && (
        <div className="mt-6">
          <Card className="mb-4">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Task Instances
              </CardTitle>
              <CardDescription>
                View real-time progress of the DAG execution
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-blue-50 text-blue-700">
                    DAG: StructuredDataToIA_Resilient
                  </Badge>
                  <Badge variant="outline" className="bg-purple-50 text-purple-700">
                    Run ID: {dagRunId}
                  </Badge>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => window.open(`/admin/airflow/graph?dag_id=StructuredDataToIA_Resilient&execution_date=${encodeURIComponent(dagRunId)}`, '_blank')}
                  >
                    View Details
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => setShowJobsOverview(true)}
                  >
                    <GitBranch className="h-4 w-4 mr-1" />
                    Switch to Jobs Overview
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <TaskInstancesLive
            dagId="StructuredDataToIA_Resilient"
            runId={dagRunId}
            autoRefresh={true}
            refreshInterval={30000} // 30 seconds for less frequent polling
          />
        </div>
      )}

      {/* Jobs Overview - Similar to Migration Dashboard */}
      {uploadSuccess && dagRunId && showJobsOverview && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <GitBranch className="w-5 h-5 mr-2" />
                  Jobs Overview ({sortedAndFilteredDags.length} total)
                  <RefreshCw 
                    className="w-4 h-4 ml-2 cursor-pointer hover:text-blue-600" 
                    onClick={async () => {
                      try {
                        const dagsResult = await airflowApi.getDags(true);
                        if (dagsResult && dagsResult.dags) {
                          setDags(dagsResult.dags);
                          setCurrentPage(1); // Reset to first page after refresh
                        }
                      } catch (error) {
                        console.error('Failed to refresh DAGs:', error);
                      }
                    }}
                  />
                </div>
                {sortedAndFilteredDags.length > itemsPerPage && (
                  <div className="text-sm text-gray-600">
                    Page {currentPage} of {totalPages}
                  </div>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {sortedAndFilteredDags.length > 0 ? (
                <div className="space-y-4">
                  {/* Instruction text */}
                  <p className="text-sm text-slate-500 mb-3">
                    Click on any workspace row to view detailed information including runs, tasks, events, and statistics. 
                    Showing {itemsPerPage} items per page, sorted by latest triggered first.
                  </p>
                  
                  {/* List view header */}
                  <div className="grid grid-cols-12 gap-4 p-3 rounded-lg font-medium text-sm border-b bg-slate-50 border-slate-200 text-slate-700">
                    <div className="col-span-5">Workspace ID</div>
                    <div className="col-span-2">Status</div>
                    <div className="col-span-2">Schedule</div>
                    <div className="col-span-3">Last Parsed</div>
                  </div>
                  
                  {/* List view items - Use paginated data */}
                  <div className="space-y-1">
                    {paginatedDags.map((dag) => (
                      <div 
                        key={dag.dag_id} 
                        className="grid grid-cols-12 gap-4 p-3 rounded-lg border transition-colors hover:bg-opacity-50 cursor-pointer border-slate-200 hover:bg-slate-50"
                        onClick={() => handleDagClick(dag.dag_id)}
                      >
                        <div className="col-span-5">
                          <div className="font-medium text-foreground truncate hover:text-primary" title={`Click to view details for ${dag.dag_id}`}>
                            {dag.dag_id}
                          </div>
                          <div className="text-sm text-slate-500 truncate" title={dag.description || 'No description'}>
                            {dag.description || 'No description'}
                          </div>
                        </div>
                        <div className="col-span-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${
                            dag.is_paused ? 'bg-amber-100 text-amber-800 border-amber-300' : 
                            dag.is_active ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 
                            'bg-slate-100 text-slate-700 border-slate-300'
                          }`}>
                            {dag.is_paused ? 'Paused' : dag.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        <div className="col-span-2 text-slate-700 truncate" title={dag.schedule_interval_display || 'None'}>
                          {dag.schedule_interval_display || 'None'}
                        </div>
                        <div className="col-span-3 text-slate-700 truncate" title={dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}>
                          {dag.last_parsed_time ? new Date(dag.last_parsed_time).toLocaleString() : 'N/A'}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Pagination Controls */}
                  {sortedAndFilteredDags.length > itemsPerPage && (
                    <div className="mt-6 flex items-center justify-between border-t pt-4">
                      <div className="text-sm text-gray-600">
                        Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, sortedAndFilteredDags.length)} of {sortedAndFilteredDags.length} Workspaces
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={goToFirstPage}
                          disabled={!hasPrevPage}
                          className="px-3 py-1"
                        >
                          First
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={goToPrevPage}
                          disabled={!hasPrevPage}
                          className="px-3 py-1"
                        >
                          Previous
                        </Button>
                        <div className="flex items-center space-x-1">
                          {Array.from({ length: Math.min(3, totalPages) }, (_, i) => {
                            const pageNum = Math.max(1, Math.min(currentPage - 1, totalPages - 2)) + i;
                            if (pageNum > totalPages) return null;
                            return (
                              <Button
                                key={pageNum}
                                variant={pageNum === currentPage ? "default" : "outline"}
                                size="sm"
                                onClick={() => goToPage(pageNum)}
                                className="px-3 py-1 min-w-[32px]"
                              >
                                {pageNum}
                              </Button>
                            );
                          })}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={goToNextPage}
                          disabled={!hasNextPage}
                          className="px-3 py-1"
                        >
                          Next
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={goToLastPage}
                          disabled={!hasNextPage}
                          className="px-3 py-1"
                        >
                          Last
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="font-bold mb-2">
                    No Workspaces found
                  </h3>
                  <p className="mb-4 text-gray-500">
                    Click "Refresh" to load the latest Workspaces from Airflow API
                  </p>
                  <Button 
                    onClick={async () => {
                      try {
                        const dagsResult = await airflowApi.getDags(true);
                        if (dagsResult && dagsResult.dags) {
                          setDags(dagsResult.dags);
                          setCurrentPage(1);
                        }
                      } catch (error) {
                        console.error('Failed to load DAGs:', error);
                      }
                    }}
                  >
                    Refresh DAGs
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-6 border-t">
        <Button
          variant="outline"
          onClick={onStartOver}
          className="flex items-center gap-2"
        >
          Start Over
        </Button>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={onPrev}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Previous
          </Button>
        </div>
      </div>
      
      {/* DAG Modal */}
      <DAGModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        dagId={selectedDagId}
        darkMode={false}
        airflowApi={airflowApi}
      />
    </div>
  );
}
